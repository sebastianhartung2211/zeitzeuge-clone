# Background Upload Setup Guide

## Plugin Installation

Versuchen Sie zuerst die Installation des Background Upload Plugins:

```bash
npm install @trancever/capacitor-background-upload
npx cap sync
```

**Hinweis:** Falls das Plugin nicht verfügbar ist, funktioniert das System automatisch mit direkten Uploads als Fallback.

## Android Permissions

Fügen Sie in `android/app/src/main/AndroidManifest.xml` hinzu:

```xml
<uses-permission android:name="android.permission.INTERNET" />
<uses-permission android:name="android.permission.WRITE_EXTERNAL_STORAGE" />
<uses-permission android:name="android.permission.ACCESS_NETWORK_STATE" />
<uses-permission android:name="android.permission.WAKE_LOCK" />
```

## iOS Permissions

In `ios/App/App/Info.plist` hinzufügen:

```xml
<key>NSPhotoLibraryUsageDescription</key>
<string>Zugriff auf Fotos für Video-Uploads</string>
<key>NSCameraUsageDescription</key>
<string>Kamera für Videoaufnahmen</string>
<key>UIBackgroundModes</key>
<array>
    <string>background-processing</string>
    <string>background-fetch</string>
</array>
```

## Supabase Storage Bucket

Das System erwartet einen `videos` Bucket. Falls nicht vorhanden, erstellen Sie ihn:

```sql
-- Bucket erstellen
INSERT INTO storage.buckets (id, name, public) 
VALUES ('videos', 'videos', true);

-- RLS Policies für Videos
CREATE POLICY "Authenticated users can upload videos" 
ON storage.objects 
FOR INSERT 
WITH CHECK (bucket_id = 'videos' AND auth.role() = 'authenticated');

CREATE POLICY "Videos are publicly viewable" 
ON storage.objects 
FOR SELECT 
USING (bucket_id = 'videos');
```

## Verwendung

```typescript
import { UploadAndSend } from '@/components/upload/UploadAndSend';

// In einer Komponente:
<UploadAndSend />
```

## Funktionsweise

1. **Video auswählen:** Benutzer wählt Video aus Galerie oder nimmt neues auf
2. **Lokale Speicherung:** Video wird lokal zwischengespeichert  
3. **Signed URL:** Edge Function generiert sichere Upload-URL
4. **Background Upload:** Plugin uploaded im Hintergrund (falls verfügbar)
5. **Fallback:** Direkter Upload bei fehlendem Plugin

## Monitoring

- Upload-Logs sind in der Browser-Konsole sichtbar
- Edge Function Logs: Supabase Dashboard > Functions > create-upload-url > Logs
- Toast-Nachrichten informieren über Upload-Status

## Troubleshooting

- **Plugin-Fehler:** System fällt automatisch auf direkten Upload zurück
- **Signed URL Fehler:** Prüfen Sie SUPABASE_SERVICE_ROLE_KEY in Edge Function
- **Upload-Fehler:** Überprüfen Sie Bucket-Permissions und Netzwerkverbindung