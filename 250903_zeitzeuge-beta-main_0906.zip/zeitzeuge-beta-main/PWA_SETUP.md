# Progressive Web App (PWA) Setup Guide

## Was ist implementiert

Die PWA-Funktionalität bietet:
- **Web App Manifest**: Ermöglicht Installation als native App
- **Service Worker**: Offline-Unterstützung und Caching
- **Background Sync**: Retry-Queue für fehlgeschlagene Uploads
- **Install Prompt**: Automatische Installations-Aufforderung
- **Offline-First**: Funktioniert auch ohne Internetverbindung

## Dateien erstellt

### Core PWA Files
- `public/manifest.webmanifest` - App Manifest mit Metadaten
- `public/sw.js` - Service Worker für Caching und Background Sync
- `src/features/pwa/pwaService.ts` - PWA Service und Install Logic
- `src/components/pwa/PWAInstallPrompt.tsx` - Install Prompt Component
- `src/components/pwa/PWAStatus.tsx` - PWA Status Display

### Integration
- `index.html` - Manifest und PWA Meta Tags hinzugefügt
- `src/main.tsx` - PWA Initialisierung
- `src/App.tsx` - Install Prompt Component eingebunden

## Features

### 1. App Installation
```typescript
import { PWAInstallPrompt } from '@/components/pwa/PWAInstallPrompt';

// Automatisches Install Prompt
<PWAInstallPrompt />

// Programmatische Installation
import { promptInstall } from '@/features/pwa/pwaService';
await promptInstall();
```

### 2. PWA Status Anzeige
```typescript
import { PWAStatus } from '@/components/pwa/PWAStatus';

// Status-Card für Settings
<PWAStatus />
```

### 3. Offline-Unterstützung
- **Static Assets**: Automatisches Caching via Workbox
- **API Responses**: Network-First Strategie für Supabase
- **Images**: Cache-First für optimale Performance
- **Upload Retry**: Background Sync bei fehlgeschlagenen Uploads

### 4. App Shortcuts
Das Manifest definiert Shortcuts für:
- Neue Videoaufnahme (`/record-story`)
- Gespräch starten (`/conversation-starter`)

## Browser-Unterstützung

### Desktop (Chrome/Edge)
- ✅ Installation verfügbar
- ✅ Service Worker aktiv
- ✅ Offline-Modus
- ✅ Background Sync

### Mobile (Chrome/Safari)
- ✅ Installation verfügbar
- ✅ Service Worker aktiv  
- ✅ Offline-Modus
- ✅ Native App Gefühl

### iOS Safari
- ✅ Add to Home Screen
- ✅ Service Worker (iOS 11.3+)
- ⚠️ Install Prompt (begrenzt)

## Anpassungen

### Icons hinzufügen
Erstellen Sie folgende Icon-Dateien in `public/`:
```
/android-chrome-192x192.png
/android-chrome-512x512.png
/apple-touch-icon.png
/favicon.ico
```

### Screenshots hinzufügen
Für bessere App Store Darstellung:
```
/screenshot-wide.png (1280x720)
/screenshot-narrow.png (390x844)
```

### Service Worker erweitern
```javascript
// Zusätzliche Caching-Strategien in public/sw.js
registerRoute(
  ({ url }) => url.pathname.startsWith('/api/custom'),
  new CacheFirst({
    cacheName: 'custom-api'
  })
);
```

## Testing

### Lokale Entwicklung
```bash
npm run build
npm run preview
# Öffnen Sie Chrome DevTools > Application > Service Workers
```

### PWA Audit
- Chrome DevTools > Lighthouse > Progressive Web App
- Überprüfung aller PWA-Kriterien

### Installation testen
1. **Desktop**: Chrome → Adressleiste → Install Icon
2. **Mobile**: Browser Menu → "Add to Home Screen"
3. **Automatisch**: PWA Install Prompt Component

## Deployment

### Vite Build
- Service Worker wird automatisch generiert
- Manifest wird korrekt verlinkt
- Assets werden mit Cache-Headers ausgeliefert

### Hosting Anforderungen
- **HTTPS**: PWA erfordert sichere Verbindung
- **Service Worker**: `/sw.js` muss erreichbar sein
- **Manifest**: `/manifest.webmanifest` muss serviert werden

## Vorteile

### Für Nutzer
- Native App Erfahrung im Browser
- Offline-Funktionalität
- Schnellere Ladezeiten durch Caching
- Push-Benachrichtigungen (wenn implementiert)

### Für Entwicklung
- Kein App Store erforderlich
- Automatische Updates
- Plattformübergreifend
- Mobile + Desktop Support

### Parallel zu nativen Apps
- PWA läuft im Browser
- Native Apps über Capacitor im Store
- Gleiche Codebasis, verschiedene Distributionswege