# Mobile Authentication Setup Guide

## Nach der Capacitor Installation

Nach dem Setup von Capacitor müssen Sie die nativen Dateien für Deep Link Handling konfigurieren:

### iOS Konfiguration (Info.plist)

**Datei:** `ios/App/App/Info.plist`

Fügen Sie folgende Konfiguration hinzu:

```xml
<key>CFBundleURLTypes</key>
<array>
  <dict>
    <key>CFBundleURLSchemes</key>
    <array>
      <string>zeitzeuge</string> <!-- Ihr URL Scheme -->
    </array>
  </dict>
</array>
<key>NSCameraUsageDescription</key><string>Videoaufnahmen für Zeitzeuge</string>
<key>NSMicrophoneUsageDescription</key><string>Audioaufnahmen für Zeitzeuge</string>
<key>NSPhotoLibraryAddUsageDescription</key><string>Speichern von Videos</string>
```

### Android Konfiguration (AndroidManifest.xml)

**Datei:** `android/app/src/main/AndroidManifest.xml`

Fügen Sie den Intent-Filter in die MainActivity hinzu:

```xml
<intent-filter android:autoVerify="true">
  <action android:name="android.intent.action.VIEW" />
  <category android:name="android.intent.category.DEFAULT" />
  <category android:name="android.intent.category.BROWSABLE" />
  <data android:scheme="zeitzeuge" android:host="auth-callback" />
</intent-filter>
```

### Supabase Dashboard Konfiguration

1. Gehen Sie zum Supabase Dashboard: Authentication > URL Configuration
2. Fügen Sie `zeitzeuge://auth-callback` als Redirect URL hinzu
3. Konfigurieren Sie Google OAuth Provider falls noch nicht geschehen

### Nach Änderungen

Führen Sie folgende Befehle aus:

```bash
npm run build
npx cap copy ios android
npx cap sync
```

### Verwendung im Code

```typescript
import { useMobileAuth } from '@/hooks/useMobileAuth';
import { MobileAuthButton } from '@/components/auth/MobileAuthButton';

// In einer Komponente:
const { user, session, loading } = useMobileAuth();

// Für Login Button:
<MobileAuthButton />
```

### Hinweise

- Das System erkennt automatisch ob Web oder Mobile verwendet wird
- Deep Links funktionieren nur auf physischen Geräten oder Emulatoren
- Testen Sie die OAuth-Konfiguration zuerst im Web, dann auf Mobile