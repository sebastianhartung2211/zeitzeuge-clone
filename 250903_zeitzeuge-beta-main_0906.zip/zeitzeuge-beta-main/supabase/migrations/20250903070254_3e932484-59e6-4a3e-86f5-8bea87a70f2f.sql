-- === PROFILE PICTURES BUCKET (public read, owner-only write) ==============

-- 0) Safety: RLS sicherstellen (idempotent)
alter table if exists storage.objects enable row level security;

-- 1) Bucket anlegen (idempotent)
insert into storage.buckets (id, name, public)
values ('profile_pictures', 'profile_pictures', true)
on conflict (id) do nothing;

-- 2) Policies für storage.objects (nur für diesen Bucket)
--    - Öffentliches Lesen (für Login/Familienseite)
--    - Schreiben/Ändern/Löschen nur im eigenen Ordner {auth.uid()}/...

drop policy if exists pp_public_read on storage.objects;
drop policy if exists pp_owner_insert on storage.objects;
drop policy if exists pp_owner_update on storage.objects;
drop policy if exists pp_owner_delete on storage.objects;

create policy pp_public_read
  on storage.objects for select
  using (bucket_id = 'profile_pictures');

create policy pp_owner_insert
  on storage.objects for insert
  with check (
    bucket_id = 'profile_pictures'
    and (name like auth.uid()::text || '/%')
  );

create policy pp_owner_update
  on storage.objects for update
  using (
    bucket_id = 'profile_pictures'
    and (name like auth.uid()::text || '/%')
  )
  with check (
    bucket_id = 'profile_pictures'
    and (name like auth.uid()::text || '/%')
  );

create policy pp_owner_delete
  on storage.objects for delete
  using (
    bucket_id = 'profile_pictures'
    and (name like auth.uid()::text || '/%')
  );

-- Konvention im Frontend:
--   Upload nach: profile_pictures/{auth.uid()}/avatar.(png|jpg|webp)
--   URL speichern in: public.profiles.avatar_url (bereits in Schritt 1 angelegt)