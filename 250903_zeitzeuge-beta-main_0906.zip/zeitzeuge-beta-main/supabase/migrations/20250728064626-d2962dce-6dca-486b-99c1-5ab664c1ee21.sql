-- Call the coordinator-agent for videos that are completed but missing thumbnails
DO $$
DECLARE
    video_record RECORD;
    response jsonb;
BEGIN
    -- Find videos that are completed but missing thumbnails
    FOR video_record IN 
        SELECT id, user_id, title 
        FROM videos 
        WHERE status = 'completed' 
        AND thumbnail_url IS NULL
        LIMIT 5
    LOOP
        BEGIN
            -- Call the coordinator agent to generate thumbnail
            SELECT net.http_post(
                url := 'https://fepcoqrfrkfiaftkkfht.supabase.co/functions/v1/coordinator-agent',
                headers := jsonb_build_object(
                    'Content-Type', 'application/json',
                    'Authorization', 'Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImZlcGNvcXJmcmtmaWFmdGtrZmh0Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTMxNDU4NjUsImV4cCI6MjA2ODcyMTg2NX0.EA3jUpmXSlnMh_YYGNo3yWtZEcBdZ7JkRDSlSjALGdc'
                ),
                body := jsonb_build_object(
                    'videoId', video_record.id,
                    'action', 'generate_thumbnail',
                    'userId', video_record.user_id
                )
            ) INTO response;
            
            RAISE NOTICE 'Called thumbnail generation for video: % - Response: %', video_record.title, response;
            
        EXCEPTION WHEN OTHERS THEN
            RAISE NOTICE 'Error generating thumbnail for video %: %', video_record.title, SQLERRM;
        END;
    END LOOP;
END;
$$;