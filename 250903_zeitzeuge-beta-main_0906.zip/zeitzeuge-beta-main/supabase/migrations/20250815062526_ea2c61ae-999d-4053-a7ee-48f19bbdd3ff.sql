-- 1. DATABASE PERFORMANCE & ERROR HANDLING FIXES

-- Fix duplicate tag creation with UPSERT pattern
CREATE OR REPLACE FUNCTION public.upsert_tag(tag_name TEXT, tag_category TEXT DEFAULT NULL)
RETURNS uuid
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $function$
DECLARE
  tag_id UUID;
BEGIN
  -- Try to insert, on conflict do nothing and return existing id
  INSERT INTO tags (name, category)
  VALUES (tag_name, tag_category)
  ON CONFLICT (name) DO NOTHING
  RETURNING id INTO tag_id;
  
  -- If no id returned (conflict occurred), get existing id
  IF tag_id IS NULL THEN
    SELECT id INTO tag_id FROM tags WHERE name = tag_name;
  END IF;
  
  RETURN tag_id;
END;
$function$;

-- Fix UUID validation function
CREATE OR REPLACE FUNCTION public.is_valid_uuid(input_text TEXT)
RETURNS BOOLEAN
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $function$
BEGIN
  -- Try to cast to UUID, return false if it fails
  PERFORM input_text::UUID;
  RETURN TRUE;
EXCEPTION
  WHEN invalid_text_representation THEN
    RETURN FALSE;
END;
$function$;

-- Fix notification type constraint
ALTER TABLE notifications DROP CONSTRAINT IF EXISTS notifications_notification_type_check;
ALTER TABLE notifications ADD CONSTRAINT notifications_notification_type_check 
CHECK (notification_type IN ('info', 'warning', 'error', 'success', 'processing', 'completed', 'failed'));

-- Add proper indexes for performance
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_tags_name ON tags (name);
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_video_tags_video_id ON video_tags (video_id);
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_transcript_chunks_video_id ON transcript_chunks (video_id);
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_conversations_user_id_created ON conversations (user_id, created_at DESC);

-- Fix all functions to have proper search_path (Security Fix)
CREATE OR REPLACE FUNCTION public.categorize_video_by_tags(video_id_param uuid)
RETURNS text
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $function$
DECLARE
  best_cat TEXT;
  best_score DOUBLE PRECISION;
BEGIN
  -- Determine best category based on tags.category weighted by relevance_score
  SELECT t.category, COALESCE(SUM(vt.relevance_score), 0) AS score
  INTO best_cat, best_score
  FROM video_tags vt
  JOIN tags t ON vt.tag_id = t.id
  WHERE vt.video_id = video_id_param
  GROUP BY t.category
  ORDER BY score DESC NULLS LAST
  LIMIT 1;

  -- Normalize category names and handle synonyms
  IF best_cat IS NOT NULL THEN
    best_cat := TRIM(best_cat);

    IF best_cat ILIKE 'kindheit & familie' OR best_cat ILIKE 'kind & familie' THEN
      RETURN 'Kind & Familie';
    ELSIF best_cat ILIKE 'jugend & schule' THEN
      RETURN 'Jugend & Schule';
    ELSIF best_cat ILIKE 'liebe & beziehung%' OR best_cat ILIKE 'partnerschaft%' THEN
      RETURN 'Liebe & Beziehungen';
    ELSIF best_cat ILIKE 'arbeit & alltag' OR best_cat ILIKE 'beruf%' THEN
      RETURN 'Arbeit & Alltag';
    ELSIF best_cat ILIKE 'zuhause & tradition%' OR best_cat ILIKE 'heimat%' THEN
      RETURN 'Zuhause & Traditionen';
    ELSIF best_cat ILIKE 'zeitgeschichte & wandel' OR best_cat ILIKE 'geschichte%' THEN
      RETURN 'Zeitgeschichte & Wandel';
    ELSIF best_cat ILIKE 'personalisierte themen' THEN
      RETURN 'Personalisierte Themen';
    ELSIF best_cat ILIKE 'erforderlich' OR best_cat ILIKE 'required' THEN
      RETURN 'Erforderlich';
    ELSE
      -- Return detected category as-is
      RETURN best_cat;
    END IF;
  END IF;

  -- Fallback to legacy keyword-based detection using tag names
  RETURN (
    WITH tag_names AS (
      SELECT LOWER(t.name) as name
      FROM video_tags vt
      JOIN tags t ON vt.tag_id = t.id
      WHERE vt.video_id = video_id_param
    )
    SELECT
      CASE
        WHEN EXISTS (SELECT 1 FROM tag_names WHERE name ILIKE ANY(ARRAY['%familie%', '%kind%', '%eltern%', '%geschwister%', '%baby%', '%geburt%']))
          THEN 'Kind & Familie'
        WHEN EXISTS (SELECT 1 FROM tag_names WHERE name ILIKE ANY(ARRAY['%schule%', '%jugend%', '%student%', '%ausbildung%', '%freunde%', '%pubertät%']))
          THEN 'Jugend & Schule'
        WHEN EXISTS (SELECT 1 FROM tag_names WHERE name ILIKE ANY(ARRAY['%liebe%', '%partner%', '%hochzeit%', '%beziehung%', '%heirat%', '%romance%']))
          THEN 'Liebe & Beziehungen'
        WHEN EXISTS (SELECT 1 FROM tag_names WHERE name ILIKE ANY(ARRAY['%arbeit%', '%beruf%', '%karriere%', '%job%', '%alltag%', '%routine%']))
          THEN 'Arbeit & Alltag'
        WHEN EXISTS (SELECT 1 FROM tag_names WHERE name ILIKE ANY(ARRAY['%zuhause%', '%tradition%', '%heimat%', '%kultur%', '%fest%', '%feier%']))
          THEN 'Zuhause & Traditionen'
        WHEN EXISTS (SELECT 1 FROM tag_names WHERE name ILIKE ANY(ARRAY['%geschichte%', '%krieg%', '%politik%', '%wandel%', '%veränderung%', '%historisch%']))
          THEN 'Zeitgeschichte & Wandel'
        ELSE 'Personalisierte Themen'
      END
  );
END;
$function$;

-- Update other functions with proper search_path
CREATE OR REPLACE FUNCTION public.get_user_notifications(user_id_param uuid)
RETURNS TABLE(id uuid, agent_name text, notification_type text, title text, message text, metadata jsonb, is_read boolean, created_at timestamp with time zone, video_id uuid)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $function$
BEGIN
  RETURN QUERY
  SELECT 
    n.id,
    n.agent_name,
    n.notification_type,
    n.title,
    n.message,
    n.metadata,
    n.is_read,
    n.created_at,
    n.video_id
  FROM notifications n
  WHERE n.user_id = user_id_param
  ORDER BY n.created_at DESC
  LIMIT 50;
END;
$function$;