-- === FAMILY CORE MIGRATION (SIMPLIFIED) =================================
-- Adds missing columns and creates new tables for family functionality

-- Extensions
create extension if not exists "pgcrypto";
create extension if not exists "uuid-ossp";

-- -------------------------------------------------------------------------
-- 1) Add missing columns to existing family_members table
-- -------------------------------------------------------------------------
alter table public.family_members 
  add column if not exists email text,
  add column if not exists first_name text,
  add column if not exists last_name text,
  add column if not exists birthdate date,
  add column if not exists status text default 'active',
  add column if not exists invite_token uuid,
  add column if not exists consent_data_processing boolean default false,
  add column if not exists consent_public_display boolean default false,
  add column if not exists consent_given_at timestamptz;

-- Add check constraint for status if not exists
do $$
begin
  if not exists (select 1 from pg_constraint where conname = 'family_members_status_check') then
    alter table public.family_members add constraint family_members_status_check check (status in ('invited','active','left','removed'));
  end if;
exception when others then
  null;
end $$;

-- -------------------------------------------------------------------------
-- 2) Create helper functions for RLS
-- -------------------------------------------------------------------------
create or replace function public.is_family_member(fid uuid)
returns boolean language sql security definer set search_path=public as $$
  select exists(
    select 1
    from public.family_members fm
    where fm.family_id = fid
      and fm.user_id = auth.uid()
      and coalesce(fm.status, 'active') = 'active'
  );
$$;

create or replace function public.is_family_admin(fid uuid)
returns boolean language sql security definer set search_path=public as $$
  select exists(
    select 1
    from public.family_members fm
    where fm.family_id = fid
      and fm.user_id = auth.uid()
      and coalesce(fm.status, 'active') = 'active'
      and fm.role = 'admin'
  );
$$;

-- -------------------------------------------------------------------------
-- 3) Add columns to families table
-- -------------------------------------------------------------------------
alter table public.families 
  add column if not exists description text;

-- -------------------------------------------------------------------------
-- 4) Create profiles table
-- -------------------------------------------------------------------------
create table if not exists public.profiles (
  user_id     uuid primary key references auth.users(id) on delete cascade,
  display_name text,
  first_name   text,
  last_name    text,
  birthdate    date,
  avatar_url   text,
  created_at   timestamptz not null default now(),
  updated_at   timestamptz not null default now()
);

-- Create trigger if table was newly created
do $$
begin
  if not exists (select 1 from pg_trigger where tgname = 'trg_profiles_updated_at') then
    create trigger trg_profiles_updated_at
      before update on public.profiles
      for each row execute function public.update_updated_at_column();
  end if;
end $$;

alter table public.profiles enable row level security;

-- Create profiles policies
drop policy if exists profiles_select_self on public.profiles;
drop policy if exists profiles_insert_self on public.profiles;  
drop policy if exists profiles_update_self on public.profiles;

create policy profiles_select_self
  on public.profiles for select
  using (user_id = auth.uid());

create policy profiles_insert_self
  on public.profiles for insert
  with check (user_id = auth.uid());

create policy profiles_update_self
  on public.profiles for update
  using (user_id = auth.uid())
  with check (user_id = auth.uid());

-- -------------------------------------------------------------------------
-- 5) Create family_events table
-- -------------------------------------------------------------------------
create table if not exists public.family_events (
  id          uuid primary key default gen_random_uuid(),
  family_id   uuid not null references public.families(id) on delete cascade,
  name        text not null,
  event_date  date not null,
  category_id uuid null references public.categories(id) on delete set null,
  created_by  uuid not null references auth.users(id) on delete set null,
  created_at  timestamptz not null default now(),
  updated_at  timestamptz not null default now()
);

create index if not exists idx_family_events_family on public.family_events(family_id);
create index if not exists idx_family_events_date on public.family_events(event_date);

-- Create trigger if table was newly created
do $$
begin
  if not exists (select 1 from pg_trigger where tgname = 'trg_family_events_updated_at') then
    create trigger trg_family_events_updated_at
      before update on public.family_events
      for each row execute function public.update_updated_at_column();
  end if;
end $$;

alter table public.family_events enable row level security;

create policy family_events_select
  on public.family_events for select
  using (public.is_family_member(family_id));

create policy family_events_insert
  on public.family_events for insert
  with check (public.is_family_member(family_id) and created_by = auth.uid());

create policy family_events_update
  on public.family_events for update
  using (public.is_family_admin(family_id) or created_by = auth.uid())
  with check (public.is_family_admin(family_id) or created_by = auth.uid());

create policy family_events_delete
  on public.family_events for delete
  using (public.is_family_admin(family_id) or created_by = auth.uid());

-- -------------------------------------------------------------------------
-- 6) Create questions table
-- -------------------------------------------------------------------------
create table if not exists public.questions (
  id          uuid primary key default gen_random_uuid(),
  text        text not null,
  category_id uuid null references public.categories(id) on delete set null,
  source      text not null default 'custom' check (source in ('system','custom')),
  created_by  uuid not null references auth.users(id) on delete set null,
  created_at  timestamptz not null default now()
);

alter table public.questions enable row level security;

create policy questions_select
  on public.questions for select
  using (true);

create policy questions_insert
  on public.questions for insert
  with check (created_by = auth.uid());

-- -------------------------------------------------------------------------
-- 7) Create question_assignments table
-- -------------------------------------------------------------------------
create table if not exists public.question_assignments (
  id              uuid primary key default gen_random_uuid(),
  family_id       uuid not null references public.families(id) on delete cascade,
  question_id     uuid not null references public.questions(id) on delete cascade,
  assigned_to     uuid not null references public.family_members(id) on delete cascade,
  assigned_by     uuid not null references auth.users(id) on delete set null,
  status          text not null default 'assigned' check (status in ('assigned','answered','dismissed')),
  due_at          timestamptz null,
  answered_at     timestamptz null,
  answer_video_id uuid null references public.videos(id) on delete set null,
  metadata        jsonb default '{}'::jsonb,
  created_at      timestamptz not null default now(),
  updated_at      timestamptz not null default now(),
  unique (question_id, assigned_to)
);

create index if not exists idx_qas_family on public.question_assignments(family_id);
create index if not exists idx_qas_assigned_to on public.question_assignments(assigned_to);
create index if not exists idx_qas_status on public.question_assignments(status);

-- Create trigger if table was newly created
do $$
begin
  if not exists (select 1 from pg_trigger where tgname = 'trg_question_assignments_updated_at') then
    create trigger trg_question_assignments_updated_at
      before update on public.question_assignments
      for each row execute function public.update_updated_at_column();
  end if;
end $$;

alter table public.question_assignments enable row level security;

create policy question_assignments_select
  on public.question_assignments for select
  using (public.is_family_member(family_id));

create policy question_assignments_insert
  on public.question_assignments for insert
  with check (
    public.is_family_admin(family_id)
    or exists(
      select 1 from public.family_members fm
      where fm.id = assigned_to and fm.user_id = auth.uid() and coalesce(fm.status, 'active') = 'active'
    )
  );

create policy question_assignments_update
  on public.question_assignments for update
  using (
    public.is_family_admin(family_id)
    or exists(
      select 1 from public.family_members fm
      where fm.id = question_assignments.assigned_to
        and fm.user_id = auth.uid()
        and coalesce(fm.status, 'active') = 'active'
    )
  )
  with check (
    public.is_family_admin(family_id)
    or exists(
      select 1 from public.family_members fm
      where fm.id = question_assignments.assigned_to
        and fm.user_id = auth.uid()
        and coalesce(fm.status, 'active') = 'active'
    )
  );

-- -------------------------------------------------------------------------
-- 8) Add family/event columns to videos table
-- -------------------------------------------------------------------------
alter table public.videos
  add column if not exists family_id uuid null references public.families(id) on delete set null,
  add column if not exists event_id  uuid null references public.family_events(id) on delete set null;

create index if not exists idx_videos_family on public.videos(family_id);
create index if not exists idx_videos_event  on public.videos(event_id);

-- Add RLS policy for family video access
drop policy if exists videos_family_read on public.videos;
create policy videos_family_read
  on public.videos for select
  using (
    family_id is not null and public.is_family_member(family_id)
  );

-- -------------------------------------------------------------------------
-- 9) Helper function to create family events
-- -------------------------------------------------------------------------
create or replace function public.create_family_event(
  p_family_id uuid,
  p_name text,
  p_event_date date,
  p_category_id uuid default null
) returns uuid
language plpgsql security definer set search_path=public as $$
declare v_id uuid;
begin
  if not public.is_family_member(p_family_id) then
    raise exception 'Not allowed';
  end if;

  insert into public.family_events(family_id, name, event_date, category_id, created_by)
  values (p_family_id, p_name, p_event_date, p_category_id, auth.uid())
  returning id into v_id;

  return v_id;
end $$;