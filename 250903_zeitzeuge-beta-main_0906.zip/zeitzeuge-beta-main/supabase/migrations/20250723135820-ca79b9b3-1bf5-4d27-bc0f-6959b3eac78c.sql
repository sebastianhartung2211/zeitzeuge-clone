-- Create a function to process pending videos
CREATE OR REPLACE FUNCTION process_pending_videos_batch()
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  video_record RECORD;
  processed_count INTEGER := 0;
  result jsonb := '{"processed": [], "errors": []}';
  temp_result jsonb;
BEGIN
  -- Loop through videos that are stuck in processing status for more than 5 minutes
  FOR video_record IN 
    SELECT id, user_id, title 
    FROM videos 
    WHERE status = 'processing' 
    AND created_at < NOW() - INTERVAL '5 minutes'
    ORDER BY created_at
    LIMIT 10
  LOOP
    BEGIN
      -- Call the coordinator agent for each video
      SELECT net.http_post(
        url := 'https://fepcoqrfrkfiaftkkfht.supabase.co/functions/v1/coordinator-agent',
        headers := jsonb_build_object(
          'Content-Type', 'application/json',
          'Authorization', 'Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImZlcGNvcXJmcmtmaWFmdGtrZmh0Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTMxNDU4NjUsImV4cCI6MjA2ODcyMTg2NX0.EA3jUpmXSlnMh_YYGNo3yWtZEcBdZ7JkRDSlSjALGdc'
        ),
        body := jsonb_build_object(
          'videoId', video_record.id,
          'action', 'process_video',
          'userId', video_record.user_id
        )
      ) INTO temp_result;
      
      processed_count := processed_count + 1;
      result := jsonb_set(
        result, 
        '{processed}', 
        (result->'processed') || jsonb_build_array(jsonb_build_object(
          'id', video_record.id,
          'title', video_record.title,
          'status', 'triggered'
        ))
      );
      
    EXCEPTION WHEN OTHERS THEN
      result := jsonb_set(
        result, 
        '{errors}', 
        (result->'errors') || jsonb_build_array(jsonb_build_object(
          'id', video_record.id,
          'title', video_record.title,
          'error', SQLERRM
        ))
      );
    END;
  END LOOP;
  
  -- Add summary
  result := jsonb_set(result, '{summary}', jsonb_build_object(
    'total_processed', processed_count,
    'timestamp', NOW()
  ));
  
  RETURN result;
END;
$$;