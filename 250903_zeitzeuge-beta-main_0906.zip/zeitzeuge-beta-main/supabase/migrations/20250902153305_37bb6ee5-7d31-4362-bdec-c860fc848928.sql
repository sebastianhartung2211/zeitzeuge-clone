-- === VIEWS FOR FAMILY DASHBOARDS ==========================================
-- Diese Views sind read-only und erben RLS der zugrunde liegenden Tabellen.

-- 1) Pro Event & Mitglied: welches Video wurde bereits beigesteuert?
create or replace view public.family_event_member_videos as
select
  fe.id                as event_id,
  fe.family_id,
  fe.name              as event_name,
  fe.event_date,
  fm.id                as family_member_id,
  fm.first_name,
  fm.last_name,
  fm.user_id           as member_user_id,
  v.id                 as video_id,
  v.user_id            as video_owner_id,
  v.created_at         as video_created_at
from public.family_events fe
join public.family_members fm
  on fm.family_id = fe.family_id
 and fm.status = 'active'
left join public.videos v
  on v.event_id = fe.id
 and v.family_id = fe.family_id
 and exists (
   select 1
   from public.family_members mm
   where mm.family_id = fe.family_id
     and mm.user_id = v.user_id
     and mm.status  = 'active'
 );

-- 2) Fragen / Assignments je Mitglied inkl. Antwortstatus & verknüpftem Video
create or replace view public.family_question_status as
select
  qa.id               as assignment_id,
  qa.family_id,
  qa.question_id,
  q.text              as question_text,
  qa.assigned_to      as family_member_id,
  fm.first_name,
  fm.last_name,
  fm.user_id          as member_user_id,
  qa.status,
  qa.due_at,
  qa.answered_at,
  qa.answer_video_id
from public.question_assignments qa
join public.questions q
  on q.id = qa.question_id
join public.family_members fm
  on fm.id = qa.assigned_to;

-- Hinweis: Keine zusätzlichen Grants nötig; RLS der Basistabellen steuert die Sicht.