-- === FAMILY CORE MIGRATION ===============================================
-- Creates families, family_members, profiles, family_events, questions,
-- question_assignments; extends videos with family_id + event_id; RLS+policies.

-- Extensions (safe idempotent)
create extension if not exists "pgcrypto";
create extension if not exists "uuid-ossp";

-- Helper: updated_at trigger (already present in your DB; keep if exists)
-- create or replace function public.update_updated_at_column()
-- returns trigger language plpgsql as $$
-- begin new.updated_at = now(); return new; end $$;

-- -------------------------------------------------------------------------
-- 1) Families
-- -------------------------------------------------------------------------
create table if not exists public.families (
  id           uuid primary key default gen_random_uuid(),
  name         text not null,
  created_by   uuid not null references auth.users(id) on delete cascade,
  created_at   timestamptz not null default now(),
  updated_at   timestamptz not null default now()
);

create index if not exists idx_families_created_by on public.families(created_by);

create trigger trg_families_updated_at
  before update on public.families
  for each row execute function public.update_updated_at_column();

alter table public.families enable row level security;

-- Helper functions for RLS
create or replace function public.is_family_member(fid uuid)
returns boolean language sql security definer set search_path=public as $$
  select exists(
    select 1
    from public.family_members fm
    where fm.family_id = fid
      and fm.user_id = auth.uid()
      and fm.status = 'active'
  );
$$;

create or replace function public.is_family_admin(fid uuid)
returns boolean language sql security definer set search_path=public as $$
  select exists(
    select 1
    from public.family_members fm
    where fm.family_id = fid
      and fm.user_id = auth.uid()
      and fm.status = 'active'
      and fm.role = 'admin'
  );
$$;

-- RLS policies for families
drop policy if exists fam_select on public.families;
drop policy if exists fam_insert on public.families;
drop policy if exists fam_update on public.families;
drop policy if exists fam_delete on public.families;

create policy fam_select
  on public.families for select
  using (public.is_family_member(id) or created_by = auth.uid());

create policy fam_insert
  on public.families for insert
  with check (created_by = auth.uid());

create policy fam_update
  on public.families for update
  using (public.is_family_admin(id) or created_by = auth.uid())
  with check (public.is_family_admin(id) or created_by = auth.uid());

create policy fam_delete
  on public.families for delete
  using (public.is_family_admin(id) or created_by = auth.uid());

-- -------------------------------------------------------------------------
-- 2) Family Members (invites via email or link + consent flags)
-- -------------------------------------------------------------------------
create table if not exists public.family_members (
  id                         uuid primary key default gen_random_uuid(),
  family_id                  uuid not null references public.families(id) on delete cascade,
  user_id                    uuid null references auth.users(id) on delete set null,
  email                      text not null,
  first_name                 text not null,
  last_name                  text not null,
  birthdate                  date null,
  role                       text not null default 'member' check (role in ('admin','member')),
  status                     text not null default 'invited' check (status in ('invited','active','left','removed')),
  invite_token               uuid unique, -- for link-based join
  consent_data_processing    boolean not null default false,
  consent_public_display     boolean not null default false,
  consent_given_at           timestamptz,
  created_at                 timestamptz not null default now(),
  updated_at                 timestamptz not null default now(),
  constraint uq_family_email unique (family_id, email),
  constraint uq_family_user unique (family_id, user_id)
);

create index if not exists idx_family_members_family on public.family_members(family_id);
create index if not exists idx_family_members_user on public.family_members(user_id);

create trigger trg_family_members_updated_at
  before update on public.family_members
  for each row execute function public.update_updated_at_column();

alter table public.family_members enable row level security;

-- RLS: members of a family can read the roster; admins can manage it; users can see/update their own row
drop policy if exists fam_members_select on public.family_members;
drop policy if exists fam_members_insert on public.family_members;
drop policy if exists fam_members_update on public.family_members;
drop policy if exists fam_members_delete on public.family_members;

create policy fam_members_select
  on public.family_members for select
  using (public.is_family_member(family_id) or public.is_family_admin(family_id));

create policy fam_members_insert
  on public.family_members for insert
  with check (
    public.is_family_admin(family_id)
    or (user_id = auth.uid() and status = 'invited') -- self-claim safeguard
  );

create policy fam_members_update
  on public.family_members for update
  using (
    public.is_family_admin(family_id)
    or (user_id = auth.uid())
  )
  with check (
    public.is_family_admin(family_id)
    or (user_id = auth.uid())
  );

create policy fam_members_delete
  on public.family_members for delete
  using (public.is_family_admin(family_id));

-- Invite helpers
create or replace function public.invite_family_member(
  p_family_id uuid,
  p_email text,
  p_first_name text,
  p_last_name text,
  p_birthdate date,
  p_role text default 'member',
  p_consent_data_processing boolean default false,
  p_consent_public_display boolean default false
) returns uuid
language plpgsql security definer set search_path=public as $$
declare
  v_token uuid := gen_random_uuid();
begin
  if not public.is_family_admin(p_family_id) then
    raise exception 'Not allowed';
  end if;

  insert into public.family_members(
    family_id, email, first_name, last_name, birthdate, role,
    invite_token, consent_data_processing, consent_public_display
  )
  values (
    p_family_id, p_email, p_first_name, p_last_name, p_birthdate, coalesce(p_role,'member'),
    v_token, p_consent_data_processing, p_consent_public_display
  )
  on conflict (family_id, email) do update
    set invite_token = excluded.invite_token,
        role = excluded.role,
        consent_data_processing = excluded.consent_data_processing,
        consent_public_display = excluded.consent_public_display,
        updated_at = now()
    where public.family_members.status in ('invited','removed');

  return v_token;
end $$;

create or replace function public.accept_family_invite(p_token uuid)
returns uuid
language plpgsql security definer set search_path=public as $$
declare
  v_member_id uuid;
begin
  update public.family_members
     set user_id = auth.uid(),
         status = 'active',
         consent_given_at = coalesce(consent_given_at, now()),
         updated_at = now()
   where invite_token = p_token
     and (user_id is null or user_id = auth.uid())
     and status in ('invited','removed')
  returning id into v_member_id;

  if v_member_id is null then
    raise exception 'Invalid or already used invite token';
  end if;

  return v_member_id;
end $$;

-- -------------------------------------------------------------------------
-- 3) Profiles (user avatar/profile info)
-- -------------------------------------------------------------------------
create table if not exists public.profiles (
  user_id     uuid primary key references auth.users(id) on delete cascade,
  display_name text,
  first_name   text,
  last_name    text,
  birthdate    date,
  avatar_url   text, -- points to storage public URL (or signed)
  created_at   timestamptz not null default now(),
  updated_at   timestamptz not null default now()
);

create trigger trg_profiles_updated_at
  before update on public.profiles
  for each row execute function public.update_updated_at_column();

alter table public.profiles enable row level security;

drop policy if exists prof_select_self on public.profiles;
drop policy if exists prof_upsert_self on public.profiles;

-- Read your own profile (family roster uses family_members for names)
create policy prof_select_self
  on public.profiles for select
  using (user_id = auth.uid());

-- Upsert your own profile
create policy prof_upsert_self
  on public.profiles for insert
  with check (user_id = auth.uid());

create policy prof_update_self
  on public.profiles for update
  using (user_id = auth.uid())
  with check (user_id = auth.uid());

-- -------------------------------------------------------------------------
-- 4) Family Events (with per-member video inputs via videos.event_id)
-- -------------------------------------------------------------------------
create table if not exists public.family_events (
  id          uuid primary key default gen_random_uuid(),
  family_id   uuid not null references public.families(id) on delete cascade,
  name        text not null,
  event_date  date not null,
  category_id uuid null references public.categories(id) on delete set null,
  created_by  uuid not null references auth.users(id) on delete set null,
  created_at  timestamptz not null default now(),
  updated_at  timestamptz not null default now()
);

create index if not exists idx_family_events_family on public.family_events(family_id);
create index if not exists idx_family_events_date on public.family_events(event_date);

create trigger trg_family_events_updated_at
  before update on public.family_events
  for each row execute function public.update_updated_at_column();

alter table public.family_events enable row level security;

drop policy if exists fe_select on public.family_events;
drop policy if exists fe_insert on public.family_events;
drop policy if exists fe_update on public.family_events;
drop policy if exists fe_delete on public.family_events;

create policy fe_select
  on public.family_events for select
  using (public.is_family_member(family_id));

create policy fe_insert
  on public.family_events for insert
  with check (public.is_family_member(family_id) and created_by = auth.uid());

create policy fe_update
  on public.family_events for update
  using (public.is_family_admin(family_id) or created_by = auth.uid())
  with check (public.is_family_admin(family_id) or created_by = auth.uid());

create policy fe_delete
  on public.family_events for delete
  using (public.is_family_admin(family_id) or created_by = auth.uid());

-- Convenience RPC to create event
create or replace function public.create_family_event(
  p_family_id uuid,
  p_name text,
  p_event_date date,
  p_category_id uuid default null
) returns uuid
language plpgsql security definer set search_path=public as $$
declare v_id uuid;
begin
  if not public.is_family_member(p_family_id) then
    raise exception 'Not allowed';
  end if;

  insert into public.family_events(family_id, name, event_date, category_id, created_by)
  values (p_family_id, p_name, p_event_date, p_category_id, auth.uid())
  returning id into v_id;

  return v_id;
end $$;

-- -------------------------------------------------------------------------
-- 5) Questions & Assignments (forward questions, track answers per member)
-- -------------------------------------------------------------------------
create table if not exists public.questions (
  id          uuid primary key default gen_random_uuid(),
  text        text not null,
  category_id uuid null references public.categories(id) on delete set null,
  source      text not null default 'custom' check (source in ('system','custom')),
  created_by  uuid not null references auth.users(id) on delete set null,
  created_at  timestamptz not null default now()
);

alter table public.questions enable row level security;

drop policy if exists q_select on public.questions;
drop policy if exists q_insert on public.questions;

-- Anyone authenticated may read questions (used as templates); write own
create policy q_select
  on public.questions for select
  using (true);

create policy q_insert
  on public.questions for insert
  with check (created_by = auth.uid());

create table if not exists public.question_assignments (
  id              uuid primary key default gen_random_uuid(),
  family_id       uuid not null references public.families(id) on delete cascade,
  question_id     uuid not null references public.questions(id) on delete cascade,
  assigned_to     uuid not null references public.family_members(id) on delete cascade,
  assigned_by     uuid not null references auth.users(id) on delete set null,
  status          text not null default 'assigned' check (status in ('assigned','answered','dismissed')),
  due_at          timestamptz null,
  answered_at     timestamptz null,
  answer_video_id uuid null references public.videos(id) on delete set null,
  metadata        jsonb default '{}'::jsonb,
  created_at      timestamptz not null default now(),
  updated_at      timestamptz not null default now(),
  constraint uq_q_assignment unique (question_id, assigned_to)
);

create index if not exists idx_qas_family on public.question_assignments(family_id);
create index if not exists idx_qas_assigned_to on public.question_assignments(assigned_to);
create index if not exists idx_qas_status on public.question_assignments(status);

create trigger trg_qas_updated_at
  before update on public.question_assignments
  for each row execute function public.update_updated_at_column();

alter table public.question_assignments enable row level security;

drop policy if exists qas_select on public.question_assignments;
drop policy if exists qas_insert on public.question_assignments;
drop policy if exists qas_update on public.question_assignments;

create policy qas_select
  on public.question_assignments for select
  using (public.is_family_member(family_id));

-- Admins can assign; members can assign to themselves too (optional)
create policy qas_insert
  on public.question_assignments for insert
  with check (
    public.is_family_admin(family_id)
    or exists(
      select 1 from public.family_members fm
      where fm.id = assigned_to and fm.user_id = auth.uid() and fm.status='active'
    )
  );

-- Update: assignee can mark answered; admins can manage
create policy qas_update
  on public.question_assignments for update
  using (
    public.is_family_admin(family_id)
    or exists(
      select 1 from public.family_members fm
      where fm.id = question_assignments.assigned_to
        and fm.user_id = auth.uid()
        and fm.status='active'
    )
  )
  with check (
    public.is_family_admin(family_id)
    or exists(
      select 1 from public.family_members fm
      where fm.id = question_assignments.assigned_to
        and fm.user_id = auth.uid()
        and fm.status='active'
    )
  );

-- RPCs for assigning and marking answered
create or replace function public.forward_question_to_member(
  p_family_id uuid,
  p_question_id uuid,
  p_assigned_to uuid,
  p_due_at timestamptz default null
) returns uuid
language plpgsql security definer set search_path=public as $$
declare v_id uuid;
begin
  if not public.is_family_member(p_family_id) then
    raise exception 'Not allowed';
  end if;

  insert into public.question_assignments(
    family_id, question_id, assigned_to, assigned_by, due_at
  ) values (
    p_family_id, p_question_id, p_assigned_to, auth.uid(), p_due_at
  )
  on conflict (question_id, assigned_to) do update
    set due_at = excluded.due_at,
        updated_at = now()
  returning id into v_id;

  return v_id;
end $$;

create or replace function public.mark_question_answered(
  p_assignment_id uuid,
  p_answer_video_id uuid default null
) returns void
language plpgsql security definer set search_path=public as $$
declare v_family_id uuid; v_assigned_to uuid; v_member_user uuid;
begin
  select qa.family_id, qa.assigned_to into v_family_id, v_assigned_to
  from public.question_assignments qa
  where qa.id = p_assignment_id;

  if v_family_id is null then
    raise exception 'Assignment not found';
  end if;

  -- Only assignee or family admin
  if not public.is_family_admin(v_family_id) then
    select user_id into v_member_user from public.family_members where id = v_assigned_to;
    if v_member_user is distinct from auth.uid() then
      raise exception 'Not allowed';
    end if;
  end if;

  update public.question_assignments
     set status = 'answered',
         answered_at = now(),
         answer_video_id = coalesce(p_answer_video_id, answer_video_id),
         updated_at = now()
   where id = p_assignment_id;
end $$;

-- -------------------------------------------------------------------------
-- 6) Extend videos: add family/event context so event feeds show per family
-- -------------------------------------------------------------------------
-- videos table exists; we add family_id + event_id and FKs
alter table public.videos
  add column if not exists family_id uuid null references public.families(id) on delete set null,
  add column if not exists event_id  uuid null references public.family_events(id) on delete set null;

create index if not exists idx_videos_family on public.videos(family_id);
create index if not exists idx_videos_event  on public.videos(event_id);

-- RLS: allow family members to read videos of their family (in addition to owner policies)
-- Add an extra SELECT policy without breaking the existing owner-only policy.
drop policy if exists vids_family_read on public.videos;
create policy vids_family_read
  on public.videos for select
  using (
    family_id is not null and public.is_family_member(family_id)
  );

-- Optional: constrain inserts for event videos to consistent family
create or replace function public.assert_video_family_consistency()
returns trigger language plpgsql as $$
declare v_fid uuid;
begin
  if new.event_id is not null then
    select family_id into v_fid from public.family_events where id = new.event_id;
    if new.family_id is null then
      new.family_id := v_fid;
    elsif new.family_id <> v_fid then
      raise exception 'videos.family_id must match event''s family';
    end if;
  end if;
  return new;
end $$;

drop trigger if exists trg_videos_family_consistency on public.videos;
create trigger trg_videos_family_consistency
  before insert or update on public.videos
  for each row execute function public.assert_video_family_consistency();