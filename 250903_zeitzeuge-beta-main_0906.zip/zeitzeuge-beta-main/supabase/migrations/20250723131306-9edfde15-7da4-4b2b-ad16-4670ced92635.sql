-- Add custom_date column to videos table for user-specified dates
ALTER TABLE public.videos 
ADD COLUMN custom_date DATE;