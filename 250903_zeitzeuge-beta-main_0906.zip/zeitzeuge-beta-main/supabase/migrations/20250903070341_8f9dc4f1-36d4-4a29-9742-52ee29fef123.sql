-- === PROFILE PICTURES BUCKET SETUP ===
-- Note: The bucket 'profile_pictures' already exists and is public

-- Create a helper function to get profile picture URLs
CREATE OR REPLACE FUNCTION public.get_profile_picture_url(user_id_param UUID, filename TEXT DEFAULT 'avatar.jpg')
RETURNS TEXT
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  -- Return the public URL for profile pictures
  RETURN 'https://fepcoqrfrkfiaftkkfht.supabase.co/storage/v1/object/public/profile_pictures/' || user_id_param::text || '/' || filename;
END;
$$;

-- Grant execute permission to authenticated users
GRANT EXECUTE ON FUNCTION public.get_profile_picture_url(UUID, TEXT) TO authenticated;