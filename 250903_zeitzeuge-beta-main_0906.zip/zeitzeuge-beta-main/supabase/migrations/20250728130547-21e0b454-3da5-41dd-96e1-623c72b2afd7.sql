-- Add category support to videos table
ALTER TABLE public.videos 
ADD COLUMN category TEXT;

-- Create categories table for reference
CREATE TABLE public.categories (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  name TEXT NOT NULL UNIQUE,
  description TEXT,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Insert the seven predefined categories
INSERT INTO public.categories (name, description) VALUES
  ('Kind & Familie', 'Erinnerungen aus der Kindheit und Familienleben'),
  ('Jugend & Schule', 'Schulzeit, Jugend und frühe Erfahrungen'),
  ('Liebe & Beziehungen', 'Romantische Beziehungen und Partnerschaften'),
  ('Arbeit & Alltag', 'Berufsleben und alltägliche Erfahrungen'),
  ('Zuhause & Traditionen', 'Heimat, Traditionen und kulturelle Erinnerungen'),
  ('Zeitgeschichte & Wandel', 'Historische Ereignisse und gesellschaftlicher Wandel'),
  ('Personalisierte Themen', 'Individuelle und persönliche Themen');

-- Enable RLS for categories table
ALTER TABLE public.categories ENABLE ROW LEVEL SECURITY;

-- Create policy for categories (read-only for all authenticated users)
CREATE POLICY "Anyone can view categories" 
ON public.categories 
FOR SELECT 
USING (true);

-- Add index for better performance on video category queries
CREATE INDEX idx_videos_category ON public.videos(category);

-- Update the tagging agent function to also categorize videos
CREATE OR REPLACE FUNCTION public.categorize_video_by_tags(video_id_param UUID)
RETURNS TEXT
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  video_tags TEXT[];
  category_result TEXT;
BEGIN
  -- Get all tags for this video
  SELECT ARRAY_AGG(t.name) INTO video_tags
  FROM video_tags vt
  JOIN tags t ON vt.tag_id = t.id
  WHERE vt.video_id = video_id_param;
  
  -- Simple categorization logic based on tag keywords
  IF video_tags IS NULL OR array_length(video_tags, 1) = 0 THEN
    RETURN 'Personalisierte Themen';
  END IF;
  
  -- Check for family/childhood keywords
  IF EXISTS (
    SELECT 1 FROM unnest(video_tags) AS tag 
    WHERE tag ILIKE ANY(ARRAY['%familie%', '%kind%', '%eltern%', '%geschwister%', '%baby%', '%geburt%'])
  ) THEN
    RETURN 'Kind & Familie';
  END IF;
  
  -- Check for youth/school keywords
  IF EXISTS (
    SELECT 1 FROM unnest(video_tags) AS tag 
    WHERE tag ILIKE ANY(ARRAY['%schule%', '%jugend%', '%student%', '%ausbildung%', '%freunde%', '%pubertät%'])
  ) THEN
    RETURN 'Jugend & Schule';
  END IF;
  
  -- Check for love/relationship keywords
  IF EXISTS (
    SELECT 1 FROM unnest(video_tags) AS tag 
    WHERE tag ILIKE ANY(ARRAY['%liebe%', '%partner%', '%hochzeit%', '%beziehung%', '%heirat%', '%romance%'])
  ) THEN
    RETURN 'Liebe & Beziehungen';
  END IF;
  
  -- Check for work/daily life keywords
  IF EXISTS (
    SELECT 1 FROM unnest(video_tags) AS tag 
    WHERE tag ILIKE ANY(ARRAY['%arbeit%', '%beruf%', '%karriere%', '%job%', '%alltag%', '%routine%'])
  ) THEN
    RETURN 'Arbeit & Alltag';
  END IF;
  
  -- Check for home/tradition keywords
  IF EXISTS (
    SELECT 1 FROM unnest(video_tags) AS tag 
    WHERE tag ILIKE ANY(ARRAY['%zuhause%', '%tradition%', '%heimat%', '%kultur%', '%fest%', '%feier%'])
  ) THEN
    RETURN 'Zuhause & Traditionen';
  END IF;
  
  -- Check for history/change keywords
  IF EXISTS (
    SELECT 1 FROM unnest(video_tags) AS tag 
    WHERE tag ILIKE ANY(ARRAY['%geschichte%', '%krieg%', '%politik%', '%wandel%', '%veränderung%', '%historisch%'])
  ) THEN
    RETURN 'Zeitgeschichte & Wandel';
  END IF;
  
  -- Default to personalized themes
  RETURN 'Personalisierte Themen';
END;
$$;