-- Update "Kind & Familie" to "Kindheit & Familie" for consistency
UPDATE categories 
SET name = 'Kindheit & Familie', 
    description = 'Erinnerungen aus der Kindheit und dem Familienleben'
WHERE name = 'Kind & Familie';

-- Update any videos that still have "Kind & Familie" to use "Kindheit & Familie"
UPDATE videos 
SET category = 'Kindheit & Familie' 
WHERE category = 'Kind & Familie';