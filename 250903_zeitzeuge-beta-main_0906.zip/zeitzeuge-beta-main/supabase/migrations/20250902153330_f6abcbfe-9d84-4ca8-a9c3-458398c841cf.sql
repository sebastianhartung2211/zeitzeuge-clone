-- Fix security definer view issues by recreating views properly
-- Drop and recreate views without any security definer properties

drop view if exists public.family_event_member_videos;
drop view if exists public.family_question_status;

-- Recreate views as standard views (not security definer)
create view public.family_event_member_videos as
select
  fe.id                as event_id,
  fe.family_id,
  fe.name              as event_name,
  fe.event_date,
  fm.id                as family_member_id,
  fm.first_name,
  fm.last_name,
  fm.user_id           as member_user_id,
  v.id                 as video_id,
  v.user_id            as video_owner_id,
  v.created_at         as video_created_at
from public.family_events fe
join public.family_members fm
  on fm.family_id = fe.family_id
 and coalesce(fm.status, 'active') = 'active'
left join public.videos v
  on v.event_id = fe.id
 and v.family_id = fe.family_id
 and exists (
   select 1
   from public.family_members mm
   where mm.family_id = fe.family_id
     and mm.user_id = v.user_id
     and coalesce(mm.status, 'active') = 'active'
 );

create view public.family_question_status as
select
  qa.id               as assignment_id,
  qa.family_id,
  qa.question_id,
  q.text              as question_text,
  qa.assigned_to      as family_member_id,
  fm.first_name,
  fm.last_name,
  fm.user_id          as member_user_id,
  qa.status,
  qa.due_at,
  qa.answered_at,
  qa.answer_video_id
from public.question_assignments qa
join public.questions q
  on q.id = qa.question_id
join public.family_members fm
  on fm.id = qa.assigned_to;