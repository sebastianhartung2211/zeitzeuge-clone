-- Make videos bucket public for playback
UPDATE storage.buckets 
SET public = true 
WHERE id = 'videos';

-- Update video bucket policies for public access
DROP POLICY IF EXISTS "Videos are publicly accessible" ON storage.objects;

CREATE POLICY "Videos are publicly accessible" 
ON storage.objects 
FOR SELECT 
USING (bucket_id = 'videos');

-- Ensure existing videos can be accessed
UPDATE videos SET status = 'processing' WHERE status = 'processing';