-- Create storage policies for thumbnails
CREATE POLICY "Thumbnails are publicly accessible" 
ON storage.objects 
FOR SELECT 
USING (bucket_id = 'videos' AND name LIKE 'thumbnails/%');

CREATE POLICY "Service role can upload thumbnails" 
ON storage.objects 
FOR INSERT 
WITH CHECK (bucket_id = 'videos' AND name LIKE 'thumbnails/%');

CREATE POLICY "Service role can update thumbnails" 
ON storage.objects 
FOR UPDATE 
USING (bucket_id = 'videos' AND name LIKE 'thumbnails/%');