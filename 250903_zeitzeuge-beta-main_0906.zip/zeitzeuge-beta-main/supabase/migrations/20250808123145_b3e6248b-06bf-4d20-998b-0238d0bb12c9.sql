-- Update categorization logic to use tag categories (weighted by relevance) and normalize names
CREATE OR REPLACE FUNCTION public.categorize_video_by_tags(video_id_param uuid)
 RETURNS text
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
DECLARE
  best_cat TEXT;
  best_score DOUBLE PRECISION;
BEGIN
  -- Determine best category based on tags.category weighted by relevance_score
  SELECT t.category, COALESCE(SUM(vt.relevance_score), 0) AS score
  INTO best_cat, best_score
  FROM video_tags vt
  JOIN tags t ON vt.tag_id = t.id
  WHERE vt.video_id = video_id_param
  GROUP BY t.category
  ORDER BY score DESC NULLS LAST
  LIMIT 1;

  -- Normalize category names and handle synonyms
  IF best_cat IS NOT NULL THEN
    best_cat := TRIM(best_cat);

    IF best_cat ILIKE 'kindheit & familie' OR best_cat ILIKE 'kind & familie' THEN
      RETURN 'Kind & Familie';
    ELSIF best_cat ILIKE 'jugend & schule' THEN
      RETURN 'Jugend & Schule';
    ELSIF best_cat ILIKE 'liebe & beziehung%' OR best_cat ILIKE 'partnerschaft%' THEN
      RETURN 'Liebe & Beziehungen';
    ELSIF best_cat ILIKE 'arbeit & alltag' OR best_cat ILIKE 'beruf%' THEN
      RETURN 'Arbeit & Alltag';
    ELSIF best_cat ILIKE 'zuhause & tradition%' OR best_cat ILIKE 'heimat%' THEN
      RETURN 'Zuhause & Traditionen';
    ELSIF best_cat ILIKE 'zeitgeschichte & wandel' OR best_cat ILIKE 'geschichte%' THEN
      RETURN 'Zeitgeschichte & Wandel';
    ELSIF best_cat ILIKE 'personalisierte themen' THEN
      RETURN 'Personalisierte Themen';
    ELSIF best_cat ILIKE 'erforderlich' OR best_cat ILIKE 'required' THEN
      RETURN 'Erforderlich';
    ELSE
      -- Return detected category as-is
      RETURN best_cat;
    END IF;
  END IF;

  -- Fallback to legacy keyword-based detection using tag names
  RETURN (
    WITH tag_names AS (
      SELECT LOWER(t.name) as name
      FROM video_tags vt
      JOIN tags t ON vt.tag_id = t.id
      WHERE vt.video_id = video_id_param
    )
    SELECT
      CASE
        WHEN EXISTS (SELECT 1 FROM tag_names WHERE name ILIKE ANY(ARRAY['%familie%', '%kind%', '%eltern%', '%geschwister%', '%baby%', '%geburt%']))
          THEN 'Kind & Familie'
        WHEN EXISTS (SELECT 1 FROM tag_names WHERE name ILIKE ANY(ARRAY['%schule%', '%jugend%', '%student%', '%ausbildung%', '%freunde%', '%pubertät%']))
          THEN 'Jugend & Schule'
        WHEN EXISTS (SELECT 1 FROM tag_names WHERE name ILIKE ANY(ARRAY['%liebe%', '%partner%', '%hochzeit%', '%beziehung%', '%heirat%', '%romance%']))
          THEN 'Liebe & Beziehungen'
        WHEN EXISTS (SELECT 1 FROM tag_names WHERE name ILIKE ANY(ARRAY['%arbeit%', '%beruf%', '%karriere%', '%job%', '%alltag%', '%routine%']))
          THEN 'Arbeit & Alltag'
        WHEN EXISTS (SELECT 1 FROM tag_names WHERE name ILIKE ANY(ARRAY['%zuhause%', '%tradition%', '%heimat%', '%kultur%', '%fest%', '%feier%']))
          THEN 'Zuhause & Traditionen'
        WHEN EXISTS (SELECT 1 FROM tag_names WHERE name ILIKE ANY(ARRAY['%geschichte%', '%krieg%', '%politik%', '%wandel%', '%veränderung%', '%historisch%']))
          THEN 'Zeitgeschichte & Wandel'
        ELSE 'Personalisierte Themen'
      END
  );
END;
$function$;

-- Ensure all required categories exist in categories table
INSERT INTO public.categories (name, description)
SELECT name, description FROM (
  VALUES
    ('Kind & Familie', 'Familienleben, Kindheit, Elternschaft'),
    ('Jugend & Schule', 'Schulzeit, Ausbildung, Jugend'),
    ('Liebe & Beziehungen', 'Partnerschaft, Ehe, Freundschaften'),
    ('Arbeit & Alltag', 'Beruf, Karriere, tägliches Leben'),
    ('Zuhause & Traditionen', 'Heimat, Kultur, Feste, Traditionen'),
    ('Zeitgeschichte & Wandel', 'Historische Ereignisse, gesellschaftlicher Wandel'),
    ('Personalisierte Themen', 'Individuelle Erinnerungen und besondere Themen')
) AS v(name, description)
WHERE NOT EXISTS (
  SELECT 1 FROM public.categories c WHERE c.name = v.name
);
