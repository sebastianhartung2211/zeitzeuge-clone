-- 1. DATABASE PERFORMANCE & ERROR HANDLING FIXES (Fixed version)

-- Fix duplicate tag creation with UPSERT pattern
CREATE OR REPLACE FUNCTION public.upsert_tag(tag_name TEXT, tag_category TEXT DEFAULT NULL)
RETURNS uuid
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $function$
DECLARE
  tag_id UUID;
BEGIN
  -- Try to insert, on conflict do nothing and return existing id
  INSERT INTO tags (name, category)
  VALUES (tag_name, tag_category)
  ON CONFLICT (name) DO NOTHING
  RETURNING id INTO tag_id;
  
  -- If no id returned (conflict occurred), get existing id
  IF tag_id IS NULL THEN
    SELECT id INTO tag_id FROM tags WHERE name = tag_name;
  END IF;
  
  RETURN tag_id;
END;
$function$;

-- Fix UUID validation function
CREATE OR REPLACE FUNCTION public.is_valid_uuid(input_text TEXT)
RETURNS BOOLEAN
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $function$
BEGIN
  -- Try to cast to UUID, return false if it fails
  PERFORM input_text::UUID;
  RETURN TRUE;
EXCEPTION
  WHEN invalid_text_representation THEN
    RETURN FALSE;
END;
$function$;

-- Fix notification type constraint
ALTER TABLE notifications DROP CONSTRAINT IF EXISTS notifications_notification_type_check;
ALTER TABLE notifications ADD CONSTRAINT notifications_notification_type_check 
CHECK (notification_type IN ('info', 'warning', 'error', 'success', 'processing', 'completed', 'failed'));

-- Add proper indexes for performance (without CONCURRENTLY)
CREATE INDEX IF NOT EXISTS idx_tags_name ON tags (name);
CREATE INDEX IF NOT EXISTS idx_video_tags_video_id ON video_tags (video_id);
CREATE INDEX IF NOT EXISTS idx_transcript_chunks_video_id ON transcript_chunks (video_id);
CREATE INDEX IF NOT EXISTS idx_conversations_user_id_created ON conversations (user_id, created_at DESC);