-- Update existing videos with categories based on their tags
UPDATE videos 
SET category = public.categorize_video_by_tags(id::uuid)
WHERE category IS NULL AND id IN (
  SELECT DISTINCT video_id FROM video_tags
);