-- === PROFILE PICTURES BUCKET (public read, owner-only write) ==============

-- 1) Bucket anlegen (idempotent)
insert into storage.buckets (id, name, public)
values ('profile_pictures', 'profile_pictures', true)
on conflict (id) do nothing;

-- 2) RLS-Policies auf storage.objects
-- Hinweis: storage.objects hat i. d. R. bereits RLS aktiviert. Policies sind idempotent benannt.

drop policy if exists pp_public_read on storage.objects;
drop policy if exists pp_owner_insert on storage.objects;
drop policy if exists pp_owner_update on storage.objects;
drop policy if exists pp_owner_delete on storage.objects;

-- Öffentliches Lesen von Profilbildern (für Login-Bild & Familienseite)
create policy pp_public_read
  on storage.objects for select
  using (bucket_id = 'profile_pictures');

-- Nur der Besitzer (auth.uid()) darf in seinen Ordner {user_id}/... schreiben/ändern/löschen
create policy pp_owner_insert
  on storage.objects for insert
  with check (
    bucket_id = 'profile_pictures'
    and (name like auth.uid()::text || '/%')
  );

create policy pp_owner_update
  on storage.objects for update
  using (
    bucket_id = 'profile_pictures'
    and (name like auth.uid()::text || '/%')
  )
  with check (
    bucket_id = 'profile_pictures'
    and (name like auth.uid()::text || '/%')
  );

create policy pp_owner_delete
  on storage.objects for delete
  using (
    bucket_id = 'profile_pictures'
    and (name like auth.uid()::text || '/%')
  );

-- 3) Profil-Feld ist bereits in Schritt 1 angelegt: public.profiles.avatar_url (TEXT)
-- Konvention: lade unter  profile_pictures/{auth.uid()}/avatar.(png|jpg|webp)
-- und speichere die (öffentliche) URL in profiles.avatar_url.