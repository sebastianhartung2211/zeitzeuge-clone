-- === FAMILY CORE MIGRATION (CORRECTED) ===================================
-- Updates existing tables and creates new ones for family functionality

-- Extensions (safe idempotent)
create extension if not exists "pgcrypto";
create extension if not exists "uuid-ossp";

-- -------------------------------------------------------------------------
-- 1) Update existing family_members table with missing columns
-- -------------------------------------------------------------------------
alter table public.family_members 
  add column if not exists email text,
  add column if not exists first_name text,
  add column if not exists last_name text,
  add column if not exists birthdate date,
  add column if not exists status text default 'active' check (status in ('invited','active','left','removed')),
  add column if not exists invite_token uuid unique,
  add column if not exists consent_data_processing boolean default false,
  add column if not exists consent_public_display boolean default false,
  add column if not exists consent_given_at timestamptz;

-- Update existing family_members constraints
alter table public.family_members 
  add constraint if not exists uq_family_email unique (family_id, email),
  add constraint if not exists uq_family_user_updated unique (family_id, user_id);

-- -------------------------------------------------------------------------
-- 2) Helper functions for RLS (corrected)
-- -------------------------------------------------------------------------
create or replace function public.is_family_member(fid uuid)
returns boolean language sql security definer set search_path=public as $$
  select exists(
    select 1
    from public.family_members fm
    where fm.family_id = fid
      and fm.user_id = auth.uid()
      and coalesce(fm.status, 'active') = 'active'
  );
$$;

create or replace function public.is_family_admin(fid uuid)
returns boolean language sql security definer set search_path=public as $$
  select exists(
    select 1
    from public.family_members fm
    where fm.family_id = fid
      and fm.user_id = auth.uid()
      and coalesce(fm.status, 'active') = 'active'
      and fm.role = 'admin'
  );
$$;

-- -------------------------------------------------------------------------
-- 3) Update families table if needed
-- -------------------------------------------------------------------------
alter table public.families 
  add column if not exists description text,
  add column if not exists invite_code text;

-- Update families RLS policies
drop policy if exists "Users can view their families" on public.families;
drop policy if exists "Users can create families" on public.families;
drop policy if exists "Family admins can update their families" on public.families;

create policy fam_select
  on public.families for select
  using (public.is_family_member(id) or created_by = auth.uid());

create policy fam_insert
  on public.families for insert
  with check (created_by = auth.uid());

create policy fam_update
  on public.families for update
  using (public.is_family_admin(id) or created_by = auth.uid())
  with check (public.is_family_admin(id) or created_by = auth.uid());

-- -------------------------------------------------------------------------
-- 4) Update family_members RLS policies
-- -------------------------------------------------------------------------
drop policy if exists "Users can view family members of their families" on public.family_members;
drop policy if exists "Family admins can invite members" on public.family_members;
drop policy if exists "Users can update their own family profile" on public.family_members;

create policy fam_members_select
  on public.family_members for select
  using (public.is_family_member(family_id) or public.is_family_admin(family_id));

create policy fam_members_insert
  on public.family_members for insert
  with check (
    public.is_family_admin(family_id)
    or (user_id = auth.uid() and coalesce(status, 'active') in ('invited', 'active'))
  );

create policy fam_members_update
  on public.family_members for update
  using (
    public.is_family_admin(family_id)
    or (user_id = auth.uid())
  )
  with check (
    public.is_family_admin(family_id)
    or (user_id = auth.uid())
  );

-- -------------------------------------------------------------------------
-- 5) Profiles table
-- -------------------------------------------------------------------------
create table if not exists public.profiles (
  user_id     uuid primary key references auth.users(id) on delete cascade,
  display_name text,
  first_name   text,
  last_name    text,
  birthdate    date,
  avatar_url   text,
  created_at   timestamptz not null default now(),
  updated_at   timestamptz not null default now()
);

create trigger trg_profiles_updated_at
  before update on public.profiles
  for each row execute function public.update_updated_at_column();

alter table public.profiles enable row level security;

create policy prof_select_self
  on public.profiles for select
  using (user_id = auth.uid());

create policy prof_upsert_self
  on public.profiles for insert
  with check (user_id = auth.uid());

create policy prof_update_self
  on public.profiles for update
  using (user_id = auth.uid())
  with check (user_id = auth.uid());

-- -------------------------------------------------------------------------
-- 6) Family Events
-- -------------------------------------------------------------------------
create table if not exists public.family_events (
  id          uuid primary key default gen_random_uuid(),
  family_id   uuid not null references public.families(id) on delete cascade,
  name        text not null,
  event_date  date not null,
  category_id uuid null references public.categories(id) on delete set null,
  created_by  uuid not null references auth.users(id) on delete set null,
  created_at  timestamptz not null default now(),
  updated_at  timestamptz not null default now()
);

create index if not exists idx_family_events_family on public.family_events(family_id);
create index if not exists idx_family_events_date on public.family_events(event_date);

create trigger trg_family_events_updated_at
  before update on public.family_events
  for each row execute function public.update_updated_at_column();

alter table public.family_events enable row level security;

create policy fe_select
  on public.family_events for select
  using (public.is_family_member(family_id));

create policy fe_insert
  on public.family_events for insert
  with check (public.is_family_member(family_id) and created_by = auth.uid());

create policy fe_update
  on public.family_events for update
  using (public.is_family_admin(family_id) or created_by = auth.uid())
  with check (public.is_family_admin(family_id) or created_by = auth.uid());

create policy fe_delete
  on public.family_events for delete
  using (public.is_family_admin(family_id) or created_by = auth.uid());

-- -------------------------------------------------------------------------
-- 7) Questions & Assignments
-- -------------------------------------------------------------------------
create table if not exists public.questions (
  id          uuid primary key default gen_random_uuid(),
  text        text not null,
  category_id uuid null references public.categories(id) on delete set null,
  source      text not null default 'custom' check (source in ('system','custom')),
  created_by  uuid not null references auth.users(id) on delete set null,
  created_at  timestamptz not null default now()
);

alter table public.questions enable row level security;

create policy q_select
  on public.questions for select
  using (true);

create policy q_insert
  on public.questions for insert
  with check (created_by = auth.uid());

create table if not exists public.question_assignments (
  id              uuid primary key default gen_random_uuid(),
  family_id       uuid not null references public.families(id) on delete cascade,
  question_id     uuid not null references public.questions(id) on delete cascade,
  assigned_to     uuid not null references public.family_members(id) on delete cascade,
  assigned_by     uuid not null references auth.users(id) on delete set null,
  status          text not null default 'assigned' check (status in ('assigned','answered','dismissed')),
  due_at          timestamptz null,
  answered_at     timestamptz null,
  answer_video_id uuid null references public.videos(id) on delete set null,
  metadata        jsonb default '{}'::jsonb,
  created_at      timestamptz not null default now(),
  updated_at      timestamptz not null default now(),
  constraint uq_q_assignment unique (question_id, assigned_to)
);

create index if not exists idx_qas_family on public.question_assignments(family_id);
create index if not exists idx_qas_assigned_to on public.question_assignments(assigned_to);
create index if not exists idx_qas_status on public.question_assignments(status);

create trigger trg_qas_updated_at
  before update on public.question_assignments
  for each row execute function public.update_updated_at_column();

alter table public.question_assignments enable row level security;

create policy qas_select
  on public.question_assignments for select
  using (public.is_family_member(family_id));

create policy qas_insert
  on public.question_assignments for insert
  with check (
    public.is_family_admin(family_id)
    or exists(
      select 1 from public.family_members fm
      where fm.id = assigned_to and fm.user_id = auth.uid() and coalesce(fm.status, 'active') = 'active'
    )
  );

create policy qas_update
  on public.question_assignments for update
  using (
    public.is_family_admin(family_id)
    or exists(
      select 1 from public.family_members fm
      where fm.id = question_assignments.assigned_to
        and fm.user_id = auth.uid()
        and coalesce(fm.status, 'active') = 'active'
    )
  )
  with check (
    public.is_family_admin(family_id)
    or exists(
      select 1 from public.family_members fm
      where fm.id = question_assignments.assigned_to
        and fm.user_id = auth.uid()
        and coalesce(fm.status, 'active') = 'active'
    )
  );

-- -------------------------------------------------------------------------
-- 8) Extend videos with family/event context
-- -------------------------------------------------------------------------
alter table public.videos
  add column if not exists family_id uuid null references public.families(id) on delete set null,
  add column if not exists event_id  uuid null references public.family_events(id) on delete set null;

create index if not exists idx_videos_family on public.videos(family_id);
create index if not exists idx_videos_event  on public.videos(event_id);

-- RLS: allow family members to read videos of their family
create policy vids_family_read
  on public.videos for select
  using (
    family_id is not null and public.is_family_member(family_id)
  );

-- Helper functions
create or replace function public.create_family_event(
  p_family_id uuid,
  p_name text,
  p_event_date date,
  p_category_id uuid default null
) returns uuid
language plpgsql security definer set search_path=public as $$
declare v_id uuid;
begin
  if not public.is_family_member(p_family_id) then
    raise exception 'Not allowed';
  end if;

  insert into public.family_events(family_id, name, event_date, category_id, created_by)
  values (p_family_id, p_name, p_event_date, p_category_id, auth.uid())
  returning id into v_id;

  return v_id;
end $$;