-- Enable realtime for videos table
ALTER PUBLICATION supabase_realtime ADD TABLE videos;

-- Create video processing recovery function
CREATE OR REPLACE FUNCTION public.trigger_video_recovery()
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $function$
DECLARE
  recovery_result jsonb;
BEGIN
  -- Call the video recovery function via HTTP
  SELECT net.http_post(
    url := 'https://fepcoqrfrkfiaftkkfht.supabase.co/functions/v1/video-recovery-agent',
    headers := jsonb_build_object(
      'Content-Type', 'application/json',
      'Authorization', 'Bearer ' || current_setting('app.supabase_service_role_key', true)
    ),
    body := jsonb_build_object(
      'action', 'recover_stuck_videos',
      'options', jsonb_build_object(
        'timeoutMinutes', 15,
        'batchSize', 5
      )
    )
  ) INTO recovery_result;
  
  RETURN recovery_result;
END;
$function$;

-- Create automated video status monitoring trigger
CREATE OR REPLACE FUNCTION public.check_video_processing_status()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $function$
BEGIN
  -- If video has been processing for more than 20 minutes, mark for recovery
  IF NEW.status = 'processing' AND 
     OLD.status = 'processing' AND 
     NEW.updated_at < NOW() - INTERVAL '20 minutes' THEN
    
    -- Log the stuck video
    INSERT INTO processing_logs (
      video_id,
      agent_name,
      stage,
      status,
      output_data
    ) VALUES (
      NEW.id,
      'auto-monitor',
      'stuck_detection',
      'warning',
      jsonb_build_object(
        'message', 'Video stuck in processing status',
        'duration_minutes', EXTRACT(EPOCH FROM (NOW() - NEW.updated_at)) / 60
      )
    );
  END IF;
  
  RETURN NEW;
END;
$function$;

-- Create trigger for monitoring video status changes
DROP TRIGGER IF EXISTS video_status_monitor ON videos;
CREATE TRIGGER video_status_monitor
  BEFORE UPDATE ON videos
  FOR EACH ROW
  EXECUTE FUNCTION check_video_processing_status();

-- Create index for faster video status queries
CREATE INDEX IF NOT EXISTS idx_videos_status_updated ON videos (status, updated_at);
CREATE INDEX IF NOT EXISTS idx_processing_logs_status_created ON processing_logs (status, created_at);