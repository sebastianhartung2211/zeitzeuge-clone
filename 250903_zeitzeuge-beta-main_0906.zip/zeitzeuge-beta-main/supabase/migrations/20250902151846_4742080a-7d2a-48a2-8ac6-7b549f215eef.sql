-- === MINIMAL FAMILY EXTENSION MIGRATION ====================================
-- Only adds essential missing columns and functions

-- Extensions
create extension if not exists "pgcrypto";

-- -------------------------------------------------------------------------
-- 1) Add missing columns to family_members (only if they don't exist)
-- -------------------------------------------------------------------------
do $$
begin
  -- Add columns individually with checks
  if not exists (select 1 from information_schema.columns where table_name = 'family_members' and column_name = 'email') then
    alter table public.family_members add column email text;
  end if;
  
  if not exists (select 1 from information_schema.columns where table_name = 'family_members' and column_name = 'first_name') then
    alter table public.family_members add column first_name text;
  end if;
  
  if not exists (select 1 from information_schema.columns where table_name = 'family_members' and column_name = 'last_name') then
    alter table public.family_members add column last_name text;
  end if;
  
  if not exists (select 1 from information_schema.columns where table_name = 'family_members' and column_name = 'birthdate') then
    alter table public.family_members add column birthdate date;
  end if;
  
  if not exists (select 1 from information_schema.columns where table_name = 'family_members' and column_name = 'status') then
    alter table public.family_members add column status text default 'active';
  end if;
  
  if not exists (select 1 from information_schema.columns where table_name = 'family_members' and column_name = 'invite_token') then
    alter table public.family_members add column invite_token uuid;
  end if;
end $$;

-- -------------------------------------------------------------------------
-- 2) Create helper functions for RLS (safe to overwrite)
-- -------------------------------------------------------------------------
create or replace function public.is_family_member(fid uuid)
returns boolean language sql security definer set search_path=public as $$
  select exists(
    select 1
    from public.family_members fm
    where fm.family_id = fid
      and fm.user_id = auth.uid()
      and coalesce(fm.status, 'active') = 'active'
  );
$$;

create or replace function public.is_family_admin(fid uuid)
returns boolean language sql security definer set search_path=public as $$
  select exists(
    select 1
    from public.family_members fm
    where fm.family_id = fid
      and fm.user_id = auth.uid()
      and coalesce(fm.status, 'active') = 'active'
      and fm.role = 'admin'
  );
$$;

-- -------------------------------------------------------------------------
-- 3) Add family/event columns to videos table (only if they don't exist)
-- -------------------------------------------------------------------------
do $$
begin
  if not exists (select 1 from information_schema.columns where table_name = 'videos' and column_name = 'family_id') then
    alter table public.videos add column family_id uuid null references public.families(id) on delete set null;
    create index idx_videos_family on public.videos(family_id);
  end if;
  
  if not exists (select 1 from information_schema.columns where table_name = 'videos' and column_name = 'event_id') then
    alter table public.videos add column event_id uuid null;
    -- Note: Can't reference family_events if table doesn't exist yet
    create index idx_videos_event on public.videos(event_id);
  end if;
end $$;

-- -------------------------------------------------------------------------
-- 4) Create profiles table only if it doesn't exist
-- -------------------------------------------------------------------------
do $$
begin
  if not exists (select 1 from information_schema.tables where table_name = 'profiles' and table_schema = 'public') then
    create table public.profiles (
      user_id     uuid primary key references auth.users(id) on delete cascade,
      display_name text,
      first_name   text,
      last_name    text,
      birthdate    date,
      avatar_url   text,
      created_at   timestamptz not null default now(),
      updated_at   timestamptz not null default now()
    );

    create trigger trg_profiles_updated_at
      before update on public.profiles
      for each row execute function public.update_updated_at_column();

    alter table public.profiles enable row level security;

    create policy profiles_own_data
      on public.profiles for all
      using (user_id = auth.uid())
      with check (user_id = auth.uid());
  end if;
end $$;

-- -------------------------------------------------------------------------
-- 5) Create questions table only if it doesn't exist
-- -------------------------------------------------------------------------
do $$
begin
  if not exists (select 1 from information_schema.tables where table_name = 'questions' and table_schema = 'public') then
    create table public.questions (
      id          uuid primary key default gen_random_uuid(),
      text        text not null,
      category_id uuid null references public.categories(id) on delete set null,
      source      text not null default 'custom' check (source in ('system','custom')),
      created_by  uuid not null references auth.users(id) on delete set null,
      created_at  timestamptz not null default now()
    );

    alter table public.questions enable row level security;

    create policy questions_public_read
      on public.questions for select
      using (true);

    create policy questions_own_create
      on public.questions for insert
      with check (created_by = auth.uid());
  end if;
end $$;

-- -------------------------------------------------------------------------
-- 6) Add video family access policy only if it doesn't exist
-- -------------------------------------------------------------------------
do $$
begin
  if not exists (select 1 from pg_policies where policyname = 'videos_family_access' and tablename = 'videos') then
    create policy videos_family_access
      on public.videos for select
      using (
        family_id is not null and public.is_family_member(family_id)
      );
  end if;
end $$;