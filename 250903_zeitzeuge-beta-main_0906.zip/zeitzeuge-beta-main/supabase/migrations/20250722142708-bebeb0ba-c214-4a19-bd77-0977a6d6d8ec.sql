-- Fix Storage RLS Policies für Video Upload
DROP POLICY IF EXISTS "Users can upload their own videos" ON storage.objects;
DROP POLICY IF EXISTS "Users can upload their own transcripts" ON storage.objects;

-- Korrekte INSERT Policies mit WITH CHECK
CREATE POLICY "Users can upload their own videos" 
ON storage.objects 
FOR INSERT 
WITH CHECK (
  bucket_id = 'videos' AND 
  auth.uid()::text = (storage.foldername(name))[1]
);

CREATE POLICY "Users can upload their own transcripts" 
ON storage.objects 
FOR INSERT 
WITH CHECK (
  bucket_id = 'transcripts' AND 
  auth.uid()::text = (storage.foldername(name))[1]
);