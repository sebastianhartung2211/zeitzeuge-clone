-- Create function to manually trigger video recovery
CREATE OR REPLACE FUNCTION public.trigger_video_status_recovery()
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = 'public'
AS $$
DECLARE
  recovery_result jsonb;
BEGIN
  -- Call the video status recovery function via HTTP
  SELECT net.http_post(
    url := 'https://fepcoqrfrkfiaftkkfht.supabase.co/functions/v1/video-status-recovery',
    headers := jsonb_build_object(
      'Content-Type', 'application/json',
      'Authorization', 'Bearer ' || current_setting('app.supabase_service_role_key', true)
    ),
    body := jsonb_build_object(
      'action', 'recover_failed_videos'
    )
  ) INTO recovery_result;
  
  RETURN recovery_result;
END;
$$;