import "https://deno.land/x/xhr@0.1.0/mod.ts";
import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    console.log('🎤 Enhanced Transcribe function called');
    
    const formData = await req.formData();
    const audioFile = formData.get('audio') as File;
    
    if (!audioFile) {
      throw new Error('No audio file provided');
    }

    console.log('🎵 Audio file received:', audioFile.type, audioFile.size);

    // Validate audio file
    if (audioFile.size === 0) {
      throw new Error('Audio file is empty');
    }

    if (audioFile.size > 25 * 1024 * 1024) { // 25MB limit
      throw new Error('Audio file too large (max 25MB)');
    }

    // Convert audio to array buffer
    const audioBlob = await audioFile.arrayBuffer();
    
    // Create form data for OpenAI Whisper API with enhanced settings
    const whisperFormData = new FormData();
    whisperFormData.append('file', new Blob([audioBlob], { type: 'audio/webm' }), 'audio.webm');
    whisperFormData.append('model', 'whisper-1');
    whisperFormData.append('language', 'de'); // Force German
    whisperFormData.append('response_format', 'verbose_json');
    whisperFormData.append('temperature', '0.1'); // Lower temperature for more consistent results

    console.log('🌐 Calling OpenAI Whisper API with enhanced settings...');

    const response = await fetch('https://api.openai.com/v1/audio/transcriptions', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${Deno.env.get('OPENAI_API_KEY')}`,
      },
      body: whisperFormData,
    });

    if (!response.ok) {
      const errorText = await response.text();
      console.error('❌ OpenAI API error:', response.status, errorText);
      throw new Error(`OpenAI API error: ${response.status} - ${errorText}`);
    }

    const result = await response.json();
    
    // Enhanced validation and processing
    let transcriptText = result.text || '';
    const confidence = result.confidence || 0.0;
    const language = result.language || 'de';
    
    console.log('📝 Raw transcription result:', {
      text: transcriptText.substring(0, 100) + '...',
      confidence,
      language,
      duration: result.duration
    });

    // Post-process transcript
    transcriptText = postProcessTranscript(transcriptText);
    
    // Validate transcript quality
    const quality = assessTranscriptQuality(transcriptText);
    
    if (quality.score < 0.3) {
      console.warn('⚠️ Low quality transcript detected:', quality);
      return new Response(JSON.stringify({ 
        text: transcriptText,
        success: true,
        warning: 'Transcript quality is low - please speak clearly and ensure good audio quality',
        quality: quality,
        confidence: confidence
      }), {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    console.log('✅ Enhanced transcription successful');
    
    return new Response(JSON.stringify({ 
      text: transcriptText,
      success: true,
      confidence: confidence,
      language: language,
      quality: quality,
      duration: result.duration,
      processing: {
        model: 'whisper-1',
        enhancedSettings: true,
        postProcessed: true
      }
    }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });

  } catch (error) {
    console.error('❌ Enhanced transcription error:', error);
    return new Response(JSON.stringify({ 
      error: error.message,
      success: false,
      errorType: error.name || 'TranscriptionError'
    }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
});

function postProcessTranscript(text: string): string {
  if (!text || typeof text !== 'string') {
    return '';
  }

  // Normalize whitespace and remove excessive repetitions
  let processed = text
    .replace(/\s+/g, ' ') // Normalize whitespace
    .replace(/\.{3,}/g, '...') // Normalize ellipsis
    .replace(/([.!?])\1{2,}/g, '$1') // Remove repeated punctuation
    .trim();

  // Remove common transcription artifacts
  processed = processed
    .replace(/\b(äh|ähm|ähem)\b/gi, '') // Remove filler words
    .replace(/\[.*?\]/g, '') // Remove bracketed content
    .replace(/\s+/g, ' ') // Re-normalize whitespace
    .trim();

  // Capitalize first letter
  if (processed.length > 0) {
    processed = processed.charAt(0).toUpperCase() + processed.slice(1);
  }

  return processed;
}

function assessTranscriptQuality(text: string): { score: number, issues: string[] } {
  const issues: string[] = [];
  let score = 1.0;

  if (!text || text.trim().length === 0) {
    return { score: 0, issues: ['Empty transcript'] };
  }

  // Check length
  if (text.length < 10) {
    score *= 0.3;
    issues.push('Very short transcript');
  } else if (text.length < 30) {
    score *= 0.6;
    issues.push('Short transcript');
  }

  // Check for excessive repetition
  const words = text.toLowerCase().split(/\s+/);
  const uniqueWords = new Set(words);
  const repetitionRatio = uniqueWords.size / words.length;
  
  if (repetitionRatio < 0.3) {
    score *= 0.4;
    issues.push('High repetition detected');
  } else if (repetitionRatio < 0.5) {
    score *= 0.7;
    issues.push('Some repetition detected');
  }

  // Check for nonsensical character patterns
  const nonsensePattern = /[^a-zA-ZäöüßÄÖÜ\s.,!?-]/g;
  const nonsenseMatches = text.match(nonsensePattern);
  if (nonsenseMatches && nonsenseMatches.length > text.length * 0.1) {
    score *= 0.5;
    issues.push('Contains unusual characters');
  }

  // Check word count vs character count ratio (detect gibberish)
  const avgWordLength = text.length / words.length;
  if (avgWordLength > 15 || avgWordLength < 2) {
    score *= 0.6;
    issues.push('Unusual word length distribution');
  }

  return { score: Math.max(0, score), issues };
}