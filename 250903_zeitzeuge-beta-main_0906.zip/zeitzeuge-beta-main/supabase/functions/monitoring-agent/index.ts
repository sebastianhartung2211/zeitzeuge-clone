import "https://deno.land/x/xhr@0.1.0/mod.ts";
import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.52.0";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  console.log('📊 Performance Monitoring Agent - Tracking system metrics');
  
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { action = 'collect_metrics', timeframe = '1h' } = await req.json();
    const supabase = createClient(
      Deno.env.get('SUPABASE_URL')!,
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!
    );

    const monitoringResults = {
      timestamp: new Date().toISOString(),
      action,
      timeframe,
      metrics: {},
      alerts: [],
      recommendations: []
    };

    switch (action) {
      case 'collect_metrics':
        monitoringResults.metrics = await collectPerformanceMetrics(supabase, timeframe);
        break;
      case 'analyze_trends':
        monitoringResults.metrics = await analyzeTrends(supabase, timeframe);
        break;
      case 'check_alerts':
        monitoringResults.alerts = await checkAlerts(supabase);
        break;
      default:
        monitoringResults.metrics = await collectPerformanceMetrics(supabase, timeframe);
        monitoringResults.alerts = await checkAlerts(supabase);
    }

    // Generate recommendations based on metrics
    monitoringResults.recommendations = generateRecommendations(monitoringResults.metrics, monitoringResults.alerts);

    console.log(`📈 Monitoring completed: ${monitoringResults.alerts.length} alerts, ${monitoringResults.recommendations.length} recommendations`);

    return new Response(
      JSON.stringify({ 
        success: true,
        monitoring: monitoringResults
      }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );

  } catch (error) {
    console.error('❌ Monitoring error:', error);
    
    return new Response(
      JSON.stringify({ 
        success: false, 
        error: error.message,
        timestamp: new Date().toISOString()
      }),
      { 
        status: 500,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
      }
    );
  }
});

async function collectPerformanceMetrics(supabase: any, timeframe: string) {
  console.log(`📊 Collecting performance metrics for ${timeframe}...`);
  
  const timeframeMins = parseTimeframe(timeframe);
  const cutoffTime = new Date(Date.now() - timeframeMins * 60 * 1000).toISOString();

  const metrics = {
    agent_performance: {},
    database_performance: {},
    conversation_quality: {},
    system_health: {},
    error_rates: {}
  };

  try {
    // Agent Performance Metrics
    const { data: agentLogs } = await supabase
      .from('processing_logs')
      .select('agent_name, status, processing_time_ms, created_at')
      .gte('created_at', cutoffTime)
      .not('video_id', 'is', null);

    if (agentLogs) {
      metrics.agent_performance = analyzeAgentPerformance(agentLogs);
    }

    // Conversation Quality Metrics
    const { data: conversations } = await supabase
      .from('conversations')
      .select('confidence_score, created_at, matched_video_id')
      .gte('created_at', cutoffTime);

    if (conversations) {
      metrics.conversation_quality = analyzeConversationQuality(conversations);
    }

    // Database Performance (basic metrics)
    const dbStartTime = Date.now();
    const { data: videoCount } = await supabase
      .from('videos')
      .select('count(*)')
      .single();
    
    const dbQueryTime = Date.now() - dbStartTime;
    
    metrics.database_performance = {
      avg_query_time: dbQueryTime,
      total_videos: videoCount?.count || 0,
      status: dbQueryTime < 500 ? 'good' : dbQueryTime < 1000 ? 'slow' : 'critical'
    };

    // System Health Indicators
    const { data: recentVideos } = await supabase
      .from('videos')
      .select('status, created_at')
      .gte('created_at', cutoffTime);

    if (recentVideos) {
      metrics.system_health = analyzeSystemHealth(recentVideos);
    }

    // Error Rate Analysis
    const { data: errors } = await supabase
      .from('processing_logs')
      .select('agent_name, error_message, created_at')
      .eq('status', 'failed')
      .gte('created_at', cutoffTime);

    if (errors) {
      metrics.error_rates = analyzeErrorRates(errors);
    }

  } catch (error) {
    console.error('Error collecting metrics:', error);
    metrics.collection_error = error.message;
  }

  return metrics;
}

async function checkAlerts(supabase: any) {
  console.log('🚨 Checking for system alerts...');
  
  const alerts = [];
  const last24h = new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString();

  try {
    // Check for failed processing
    const { data: failedProcesses } = await supabase
      .from('processing_logs')
      .select('agent_name, error_message, created_at')
      .eq('status', 'failed')
      .gte('created_at', last24h);

    if (failedProcesses && failedProcesses.length > 5) {
      alerts.push({
        type: 'error_rate',
        severity: 'high',
        message: `High error rate: ${failedProcesses.length} failed processes in 24h`,
        count: failedProcesses.length
      });
    }

    // Check for low confidence conversations
    const { data: lowConfidenceConvs } = await supabase
      .from('conversations')
      .select('confidence_score, created_at')
      .lt('confidence_score', 0.5)
      .gte('created_at', last24h);

    if (lowConfidenceConvs && lowConfidenceConvs.length > 10) {
      alerts.push({
        type: 'low_confidence',
        severity: 'medium',
        message: `${lowConfidenceConvs.length} low-confidence conversations in 24h`,
        count: lowConfidenceConvs.length
      });
    }

    // Check for stalled videos
    const oneHourAgo = new Date(Date.now() - 60 * 60 * 1000).toISOString();
    const { data: stalledVideos } = await supabase
      .from('videos')
      .select('id, title, created_at')
      .eq('status', 'processing')
      .lt('created_at', oneHourAgo);

    if (stalledVideos && stalledVideos.length > 0) {
      alerts.push({
        type: 'stalled_processing',
        severity: 'medium',
        message: `${stalledVideos.length} videos stuck in processing > 1h`,
        count: stalledVideos.length
      });
    }

    // Check for missing embeddings
    const { data: videosWithoutEmbeddings } = await supabase
      .from('videos')
      .select('id, title')
      .eq('status', 'completed')
      .not('id', 'in', '(SELECT DISTINCT video_id FROM transcript_chunks WHERE embedding_json IS NOT NULL)');

    if (videosWithoutEmbeddings && videosWithoutEmbeddings.length > 0) {
      alerts.push({
        type: 'missing_embeddings',
        severity: 'low',
        message: `${videosWithoutEmbeddings.length} completed videos missing embeddings`,
        count: videosWithoutEmbeddings.length
      });
    }

  } catch (error) {
    alerts.push({
      type: 'monitoring_error',
      severity: 'high',
      message: `Alert monitoring failed: ${error.message}`,
      error: error.message
    });
  }

  return alerts;
}

async function analyzeTrends(supabase: any, timeframe: string) {
  console.log(`📈 Analyzing trends over ${timeframe}...`);
  
  // Implementation for trend analysis would go here
  // For now, return basic trend indicators
  
  return {
    video_processing_trend: 'stable',
    conversation_quality_trend: 'improving', 
    error_rate_trend: 'decreasing',
    user_activity_trend: 'increasing'
  };
}

function analyzeAgentPerformance(logs: any[]) {
  const agentStats = {};
  
  logs.forEach(log => {
    if (!agentStats[log.agent_name]) {
      agentStats[log.agent_name] = {
        total_operations: 0,
        successful_operations: 0,
        failed_operations: 0,
        avg_processing_time: 0,
        processing_times: []
      };
    }
    
    const stats = agentStats[log.agent_name];
    stats.total_operations++;
    
    if (log.status === 'completed') {
      stats.successful_operations++;
    } else if (log.status === 'failed') {
      stats.failed_operations++;
    }
    
    if (log.processing_time_ms) {
      stats.processing_times.push(log.processing_time_ms);
    }
  });
  
  // Calculate averages
  Object.values(agentStats).forEach((stats: any) => {
    if (stats.processing_times.length > 0) {
      stats.avg_processing_time = stats.processing_times.reduce((a, b) => a + b, 0) / stats.processing_times.length;
    }
    stats.success_rate = stats.total_operations > 0 ? stats.successful_operations / stats.total_operations : 0;
  });
  
  return agentStats;
}

function analyzeConversationQuality(conversations: any[]) {
  const total = conversations.length;
  const highConfidence = conversations.filter(c => (c.confidence_score || 0) >= 0.8).length;
  const mediumConfidence = conversations.filter(c => (c.confidence_score || 0) >= 0.6 && (c.confidence_score || 0) < 0.8).length;
  const lowConfidence = conversations.filter(c => (c.confidence_score || 0) < 0.6).length;
  const noMatch = conversations.filter(c => !c.matched_video_id).length;
  
  const avgConfidence = total > 0 ? conversations.reduce((sum, c) => sum + (c.confidence_score || 0), 0) / total : 0;
  
  return {
    total_conversations: total,
    avg_confidence: avgConfidence,
    high_confidence_rate: total > 0 ? highConfidence / total : 0,
    medium_confidence_rate: total > 0 ? mediumConfidence / total : 0,
    low_confidence_rate: total > 0 ? lowConfidence / total : 0,
    no_match_rate: total > 0 ? noMatch / total : 0,
    quality_score: avgConfidence >= 0.8 ? 'excellent' : avgConfidence >= 0.6 ? 'good' : avgConfidence >= 0.4 ? 'fair' : 'poor'
  };
}

function analyzeSystemHealth(videos: any[]) {
  const total = videos.length;
  const completed = videos.filter(v => v.status === 'completed').length;
  const processing = videos.filter(v => v.status === 'processing').length;
  const failed = videos.filter(v => v.status === 'failed').length;
  
  return {
    total_videos: total,
    completion_rate: total > 0 ? completed / total : 0,
    processing_rate: total > 0 ? processing / total : 0,
    failure_rate: total > 0 ? failed / total : 0,
    health_status: failed / total > 0.1 ? 'critical' : processing / total > 0.2 ? 'degraded' : 'healthy'
  };
}

function analyzeErrorRates(errors: any[]) {
  const agentErrors = {};
  const total = errors.length;
  
  errors.forEach(error => {
    if (!agentErrors[error.agent_name]) {
      agentErrors[error.agent_name] = 0;
    }
    agentErrors[error.agent_name]++;
  });
  
  return {
    total_errors: total,
    errors_by_agent: agentErrors,
    error_rate_status: total < 5 ? 'low' : total < 20 ? 'medium' : 'high'
  };
}

function generateRecommendations(metrics: any, alerts: any[]) {
  const recommendations = [];
  
  // Check agent performance
  if (metrics.agent_performance) {
    Object.entries(metrics.agent_performance).forEach(([agentName, stats]: [string, any]) => {
      if (stats.success_rate < 0.8) {
        recommendations.push({
          type: 'performance',
          priority: 'high',
          message: `${agentName} has low success rate (${(stats.success_rate * 100).toFixed(1)}%). Review error handling.`
        });
      }
      
      if (stats.avg_processing_time > 5000) {
        recommendations.push({
          type: 'performance',
          priority: 'medium',
          message: `${agentName} has slow processing (${stats.avg_processing_time}ms). Consider optimization.`
        });
      }
    });
  }
  
  // Check conversation quality
  if (metrics.conversation_quality && metrics.conversation_quality.avg_confidence < 0.6) {
    recommendations.push({
      type: 'quality',
      priority: 'high',
      message: `Low conversation confidence (${(metrics.conversation_quality.avg_confidence * 100).toFixed(1)}%). Review matching algorithms.`
    });
  }
  
  // Check for high error rate alerts
  const errorAlerts = alerts.filter(a => a.type === 'error_rate');
  if (errorAlerts.length > 0) {
    recommendations.push({
      type: 'reliability',
      priority: 'critical',
      message: 'High error rate detected. Immediate investigation required.'
    });
  }
  
  // Check for missing embeddings
  const embeddingAlerts = alerts.filter(a => a.type === 'missing_embeddings');
  if (embeddingAlerts.length > 0) {
    recommendations.push({
      type: 'functionality',
      priority: 'medium',
      message: 'Videos missing embeddings. Run embedding generation for completed videos.'
    });
  }
  
  return recommendations;
}

function parseTimeframe(timeframe: string): number {
  const match = timeframe.match(/^(\d+)([hmd])$/);
  if (!match) return 60; // Default 1 hour
  
  const value = parseInt(match[1]);
  const unit = match[2];
  
  switch (unit) {
    case 'm': return value;
    case 'h': return value * 60;
    case 'd': return value * 24 * 60;
    default: return 60;
  }
}