import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'

// CORS headers for browser calls
const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

export const handler = async (req: Request): Promise<Response> => {
  // Handle CORS preflight
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders })
  }

  try {
    const SUPABASE_URL = Deno.env.get('SUPABASE_URL')
    const SUPABASE_SERVICE_ROLE_KEY = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')

    if (!SUPABASE_URL || !SUPABASE_SERVICE_ROLE_KEY) {
      return new Response(
        JSON.stringify({ error: 'Missing Supabase credentials' }),
        { status: 500, headers: { 'Content-Type': 'application/json', ...corsHeaders } }
      )
    }

    const supabase = createClient(SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY)

    if (req.method !== 'POST') {
      return new Response(JSON.stringify({ error: 'Only POST is supported' }), {
        status: 405,
        headers: { 'Content-Type': 'application/json', ...corsHeaders },
      })
    }

    const body = await req.json().catch(() => ({}))
    const { user_id }: { user_id?: string } = body || {}

    console.log('Recategorization started', { user_id })

    // Fetch videos (optionally for a specific user)
    let query = supabase
      .from('videos')
      .select('id, category, status, user_id')

    if (user_id) {
      query = query.eq('user_id', user_id)
    }

    const { data: videos, error: fetchError } = await query

    if (fetchError) {
      console.error('Error fetching videos:', fetchError)
      return new Response(JSON.stringify({ error: fetchError.message }), {
        status: 500,
        headers: { 'Content-Type': 'application/json', ...corsHeaders },
      })
    }

    if (!videos || videos.length === 0) {
      return new Response(JSON.stringify({ message: 'No videos found for recategorization' }), {
        status: 200,
        headers: { 'Content-Type': 'application/json', ...corsHeaders },
      })
    }

    let updated = 0
    let skipped = 0
    const details: Array<{ id: string; from?: string | null; to?: string | null; reason?: string }> = []

    for (const v of videos) {
      const current = (v.category || '').toLowerCase().trim()
      if (current === 'erforderlich' || current === 'required') {
        skipped++
        details.push({ id: v.id, from: v.category, reason: 'required video (keine Erlebnisse-Zuordnung)' })
        continue
      }

      // Call DB function to categorize based on tags
      const { data: cat, error: rpcError } = await supabase.rpc('categorize_video_by_tags', {
        video_id_param: v.id,
      })

      if (rpcError) {
        console.error('RPC error for video', v.id, rpcError)
        details.push({ id: v.id, from: v.category, reason: `rpc_error: ${rpcError.message}` })
        continue
      }

      // Update only if changed or empty
      if (cat && cat !== v.category) {
        const { error: updError } = await supabase
          .from('videos')
          .update({ category: cat })
          .eq('id', v.id)

        if (updError) {
          console.error('Update error for video', v.id, updError)
          details.push({ id: v.id, from: v.category, to: cat as string, reason: `update_error: ${updError.message}` })
          continue
        }

        updated++
        details.push({ id: v.id, from: v.category, to: cat as string })
      } else {
        skipped++
        details.push({ id: v.id, from: v.category, to: v.category, reason: 'unchanged' })
      }
    }

    const result = { updated, skipped, total: videos.length, details }
    console.log('Recategorization finished', result)

    return new Response(JSON.stringify(result), {
      status: 200,
      headers: { 'Content-Type': 'application/json', ...corsHeaders },
    })
  } catch (e) {
    console.error('Unexpected error in recategorization', e)
    return new Response(JSON.stringify({ error: 'Unexpected error' }), {
      status: 500,
      headers: { 'Content-Type': 'application/json', ...corsHeaders },
    })
  }
}

// Default export for Supabase Edge Function
Deno.serve(handler);
