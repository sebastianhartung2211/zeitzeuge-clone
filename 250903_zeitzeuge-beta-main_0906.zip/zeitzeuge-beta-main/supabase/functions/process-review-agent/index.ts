import "https://deno.land/x/xhr@0.1.0/mod.ts";
import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.52.0";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
const supabaseKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;

serve(async (req) => {
  console.log('🔍 Process Review Agent called');
  
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabase = createClient(supabaseUrl, supabaseKey);
    const requestBody = await req.json();
    const { videoId, agentName, stage, expectedOutput } = requestBody;
    
    // Input validation
    if (!videoId) {
      return new Response(JSON.stringify({ 
        error: 'Missing required parameter: videoId' 
      }), {
        status: 400,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }
    
    if (!agentName) {
      return new Response(JSON.stringify({ 
        error: 'Missing required parameter: agentName' 
      }), {
        status: 400,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    console.log(`📋 Reviewing ${agentName} - Stage: ${stage} for video: ${videoId}`);

    const startTime = Date.now();
    
    // Log process start
    await logProcessingStep(supabase, videoId, agentName, stage, 'started', { expectedOutput });

    const reviewResult = await performAgentReview(supabase, videoId, agentName, stage, expectedOutput);
    const processingTime = Date.now() - startTime;

    // Log completion
    await logProcessingStep(supabase, videoId, agentName, stage, 'completed', reviewResult, null, processingTime);

    // Create notification based on review result
    await createNotification(supabase, videoId, agentName, reviewResult);

    console.log(`✅ Review completed for ${agentName} - Status: ${reviewResult.status}`);

    return new Response(
      JSON.stringify({ 
        success: true, 
        reviewResult,
        processingTime 
      }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );

  } catch (error) {
    console.error('❌ Process Review Agent error:', error);
    
    return new Response(
      JSON.stringify({ 
        success: false, 
        error: error.message 
      }),
      { 
        status: 500,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
      }
    );
  }
});

async function performAgentReview(
  supabase: any, 
  videoId: string, 
  agentName: string, 
  stage: string,
  expectedOutput: any
) {
  console.log(`🔍 Performing review for agent: ${agentName}, stage: ${stage}`);

  switch (agentName) {
    case 'transcription-agent-v2':
    case 'transcription-agent-v3':
      return await reviewTranscriptionAgent(supabase, videoId, expectedOutput);
    
    case 'tagging-segmentation-agent':
      return await reviewTaggingSegmentationAgent(supabase, videoId, expectedOutput);
    
    case 'storage-agent':
      return await reviewStorageAgent(supabase, videoId, expectedOutput);
    
    case 'conversation-agent-v3':
      return await reviewConversationAgent(supabase, videoId, expectedOutput);
    
    default:
      return {
        status: 'warning',
        message: `Unknown agent: ${agentName}`,
        details: { agentName, stage },
        confidence: 0.5
      };
  }
}

async function reviewTranscriptionAgent(supabase: any, videoId: string, expectedOutput: any) {
  console.log('📝 Reviewing transcription output...');

  // Check if transcript exists
  const { data: transcripts, error } = await supabase
    .from('transcripts')
    .select('*')
    .eq('video_id', videoId);

  if (error || !transcripts || transcripts.length === 0) {
    return {
      status: 'error',
      message: 'No transcript found',
      details: { error: error?.message, videoId },
      confidence: 0.0
    };
  }

  const transcript = transcripts[0];
  
  // Quality checks
  const checks = {
    hasContent: transcript.content && transcript.content.length > 10,
    hasConfidence: transcript.confidence !== null && transcript.confidence >= 0,
    hasLanguage: transcript.language && transcript.language.length > 0,
    contentLength: transcript.content?.length || 0,
    minDuration: expectedOutput?.minDuration || 5
  };

  const passed = Object.values(checks).filter(Boolean).length;
  const confidence = passed / Object.keys(checks).length;

  if (confidence >= 0.8) {
    return {
      status: 'success',
      message: 'Transcription quality verified',
      details: { checks, transcript: { id: transcript.id, length: checks.contentLength } },
      confidence
    };
  } else if (confidence >= 0.5) {
    return {
      status: 'warning',
      message: 'Transcription has quality issues',
      details: { checks, issues: getFailedChecks(checks) },
      confidence
    };
  } else {
    return {
      status: 'error',
      message: 'Transcription failed quality checks',
      details: { checks, issues: getFailedChecks(checks) },
      confidence
    };
  }
}

async function reviewTaggingSegmentationAgent(supabase: any, videoId: string, expectedOutput: any) {
  console.log('🏷️ Reviewing tagging and segmentation...');

  // Check tags
  const { data: videoTags, error: tagsError } = await supabase
    .from('video_tags')
    .select('*, tags(*)')
    .eq('video_id', videoId);

  // Check segments
  const { data: segments, error: segmentsError } = await supabase
    .from('segments')
    .select('*')
    .eq('video_id', videoId);

  if (tagsError || segmentsError) {
    return {
      status: 'error',
      message: 'Failed to retrieve tags or segments',
      details: { tagsError: tagsError?.message, segmentsError: segmentsError?.message },
      confidence: 0.0
    };
  }

  const checks = {
    hasTags: videoTags && videoTags.length > 0,
    hasSegments: segments && segments.length > 0,
    tagsHaveCategories: videoTags?.every(vt => vt.tags?.category) || false,
    segmentsHaveContent: segments?.every(s => s.content && s.content.length > 10) || false,
    validTimeRanges: segments?.every(s => s.end_time > s.start_time) || false
  };

  const confidence = Object.values(checks).filter(Boolean).length / Object.keys(checks).length;

  if (confidence >= 0.8) {
    return {
      status: 'success',
      message: 'Tags and segments validated',
      details: { 
        checks, 
        tagCount: videoTags?.length || 0,
        segmentCount: segments?.length || 0 
      },
      confidence
    };
  } else {
    return {
      status: confidence >= 0.5 ? 'warning' : 'error',
      message: 'Issues found in tagging/segmentation',
      details: { checks, issues: getFailedChecks(checks) },
      confidence
    };
  }
}

async function reviewStorageAgent(supabase: any, videoId: string, expectedOutput: any) {
  console.log('💾 Reviewing storage operations...');

  // Check if video record is updated
  const { data: video, error } = await supabase
    .from('videos')
    .select('*')
    .eq('id', videoId)
    .single();

  if (error || !video) {
    return {
      status: 'error',
      message: 'Video record not found',
      details: { error: error?.message, videoId },
      confidence: 0.0
    };
  }

  const checks = {
    hasVideoUrl: video.video_url && video.video_url.length > 0,
    statusCompleted: video.status === 'completed',
    hasTitle: video.title && video.title.length > 0,
    hasCategory: video.category && video.category.length > 0
  };

  const confidence = Object.values(checks).filter(Boolean).length / Object.keys(checks).length;

  return {
    status: confidence >= 0.8 ? 'success' : confidence >= 0.5 ? 'warning' : 'error',
    message: `Storage validation ${confidence >= 0.8 ? 'passed' : 'failed'}`,
    details: { checks, video: { id: video.id, status: video.status } },
    confidence
  };
}

async function reviewConversationAgent(supabase: any, videoId: string, expectedOutput: any) {
  console.log('💬 Reviewing conversation agent response...');

  // Check if conversation was created
  const { data: conversations, error } = await supabase
    .from('conversations')
    .select('*')
    .eq('matched_video_id', videoId)
    .order('created_at', { ascending: false })
    .limit(1);

  if (error) {
    return {
      status: 'error',
      message: 'Failed to check conversations',
      details: { error: error.message },
      confidence: 0.0
    };
  }

  const recentConversation = conversations?.[0];
  
  const checks = {
    hasConversation: !!recentConversation,
    hasAnswer: recentConversation?.answer && recentConversation.answer.length > 10,
    hasConfidence: recentConversation?.confidence_score !== null,
    goodConfidence: (recentConversation?.confidence_score || 0) >= 0.6
  };

  const confidence = Object.values(checks).filter(Boolean).length / Object.keys(checks).length;

  return {
    status: confidence >= 0.8 ? 'success' : confidence >= 0.5 ? 'warning' : 'error',
    message: `Conversation agent ${confidence >= 0.8 ? 'validated' : 'has issues'}`,
    details: { 
      checks, 
      conversation: recentConversation ? {
        id: recentConversation.id,
        confidence: recentConversation.confidence_score
      } : null 
    },
    confidence
  };
}

function getFailedChecks(checks: Record<string, boolean>) {
  return Object.entries(checks)
    .filter(([_, passed]) => !passed)
    .map(([check, _]) => check);
}

async function logProcessingStep(
  supabase: any,
  videoId: string,
  agentName: string,
  stage: string,
  status: string,
  outputData: any = {},
  errorMessage: string | null = null,
  processingTime: number | null = null
) {
  const { error } = await supabase
    .from('processing_logs')
    .insert({
      video_id: videoId,
      agent_name: agentName,
      stage,
      status,
      output_data: outputData,
      error_message: errorMessage,
      processing_time_ms: processingTime
    });

  if (error) {
    console.error('Failed to log processing step:', error);
  }
}

async function createNotification(
  supabase: any,
  videoId: string,
  agentName: string,
  reviewResult: any
) {
  // Get video to find user_id
  const { data: video } = await supabase
    .from('videos')
    .select('user_id, title')
    .eq('id', videoId)
    .single();

  if (!video) return;

  const notificationType = reviewResult.status === 'success' ? 'success' : 
                          reviewResult.status === 'warning' ? 'warning' : 'error';

  const title = `${agentName} ${reviewResult.status === 'success' ? 'completed' : 'issue detected'}`;
  const message = `${reviewResult.message} for video: ${video.title}`;

  const { error } = await supabase
    .from('notifications')
    .insert({
      user_id: video.user_id,
      video_id: videoId,
      agent_name: agentName,
      notification_type: notificationType,
      title,
      message,
      metadata: {
        reviewResult,
        confidence: reviewResult.confidence
      }
    });

  if (error) {
    console.error('Failed to create notification:', error);
  }
}