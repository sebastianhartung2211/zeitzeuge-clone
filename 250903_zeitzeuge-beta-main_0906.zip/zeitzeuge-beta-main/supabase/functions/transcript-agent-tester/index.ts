import "https://deno.land/x/xhr@0.1.0/mod.ts";
import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { action = 'test_transcription', userId, audioBlob, language = 'de' } = await req.json();
    
    console.log('🧪 Transcript Agent Tester:', { action, userId, hasAudio: !!audioBlob });

    const supabase = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? '',
    );

    switch (action) {
      case 'test_transcription':
        return await testTranscriptionPipeline(supabase, audioBlob, language);
      case 'test_voice_to_text':
        return await testVoiceToText(audioBlob, language);
      case 'test_transcript_quality':
        return await testTranscriptQuality(supabase, userId);
      case 'test_full_pipeline':
        return await testFullTranscriptionPipeline(supabase, userId, audioBlob);
      default:
        return await testTranscriptionPipeline(supabase, audioBlob, language);
    }

  } catch (error) {
    console.error('❌ Transcript Agent Tester error:', error);
    return new Response(JSON.stringify({ 
      error: error.message,
      service: 'transcript-agent-tester',
      success: false
    }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
});

async function testTranscriptionPipeline(supabase: any, audioBlob?: string, language = 'de') {
  console.log('🎤 Testing transcription pipeline...');
  
  const results = {
    success: true,
    tests: [] as any[],
    summary: {
      total: 0,
      passed: 0,
      failed: 0
    }
  };

  // Test 1: Check if OpenAI API key is available
  const openaiKeyTest = {
    name: 'OpenAI API Key Check',
    passed: !!Deno.env.get('OPENAI_API_KEY'),
    message: Deno.env.get('OPENAI_API_KEY') ? 'OpenAI API key is available' : 'OpenAI API key is missing'
  };
  results.tests.push(openaiKeyTest);
  results.summary.total++;
  if (openaiKeyTest.passed) results.summary.passed++;
  else results.summary.failed++;

  // Test 2: Test transcribe-v2 function if audio is provided
  if (audioBlob) {
    try {
      console.log('🎵 Testing transcribe-v2 with real audio...');
      
      // Create a form data with the audio blob
      const audioData = atob(audioBlob);
      const audioBytes = new Uint8Array(audioData.length);
      for (let i = 0; i < audioData.length; i++) {
        audioBytes[i] = audioData.charCodeAt(i);
      }
      
      const formData = new FormData();
      formData.append('audio', new Blob([audioBytes], { type: 'audio/webm' }), 'test-audio.webm');
      
      const transcribeResult = await supabase.functions.invoke('transcribe-v2', {
        body: formData
      });

      const transcribeTest = {
        name: 'Transcribe-v2 Function Test',
        passed: !transcribeResult.error && transcribeResult.data?.success,
        message: transcribeResult.error 
          ? `Transcription failed: ${transcribeResult.error.message}`
          : `Transcription successful: ${transcribeResult.data?.text?.substring(0, 50)}...`,
        details: transcribeResult.data
      };
      results.tests.push(transcribeTest);
      results.summary.total++;
      if (transcribeTest.passed) results.summary.passed++;
      else results.summary.failed++;

    } catch (error) {
      const transcribeTest = {
        name: 'Transcribe-v2 Function Test',
        passed: false,
        message: `Transcription test failed: ${error.message}`,
        error: error.message
      };
      results.tests.push(transcribeTest);
      results.summary.total++;
      results.summary.failed++;
    }
  } else {
    results.tests.push({
      name: 'Transcribe-v2 Function Test',
      passed: null,
      message: 'Skipped - no audio data provided'
    });
  }

  // Test 3: Check database schema for transcript tables
  try {
    const { data: transcripts, error: transcriptsError } = await supabase
      .from('transcripts')
      .select('id')
      .limit(1);

    const schemaTest = {
      name: 'Database Schema Check',
      passed: !transcriptsError,
      message: transcriptsError 
        ? `Database schema error: ${transcriptsError.message}`
        : 'Transcript tables are accessible'
    };
    results.tests.push(schemaTest);
    results.summary.total++;
    if (schemaTest.passed) results.summary.passed++;
    else results.summary.failed++;

  } catch (error) {
    const schemaTest = {
      name: 'Database Schema Check',
      passed: false,
      message: `Schema check failed: ${error.message}`
    };
    results.tests.push(schemaTest);
    results.summary.total++;
    results.summary.failed++;
  }

  // Test 4: Test transcript chunks table
  try {
    const { data: chunks, error: chunksError } = await supabase
      .from('transcript_chunks')
      .select('id')
      .limit(1);

    const chunksTest = {
      name: 'Transcript Chunks Table Check',
      passed: !chunksError,
      message: chunksError 
        ? `Chunks table error: ${chunksError.message}`
        : 'Transcript chunks table is accessible'
    };
    results.tests.push(chunksTest);
    results.summary.total++;
    if (chunksTest.passed) results.summary.passed++;
    else results.summary.failed++;

  } catch (error) {
    const chunksTest = {
      name: 'Transcript Chunks Table Check',
      passed: false,
      message: `Chunks table check failed: ${error.message}`
    };
    results.tests.push(chunksTest);
    results.summary.total++;
    results.summary.failed++;
  }

  // Test 5: Test OpenAI Whisper API directly
  if (Deno.env.get('OPENAI_API_KEY') && audioBlob) {
    try {
      console.log('🌐 Testing OpenAI Whisper API directly...');
      
      const audioData = atob(audioBlob);
      const audioBytes = new Uint8Array(audioData.length);
      for (let i = 0; i < audioData.length; i++) {
        audioBytes[i] = audioData.charCodeAt(i);
      }
      
      const whisperFormData = new FormData();
      whisperFormData.append('file', new Blob([audioBytes], { type: 'audio/webm' }), 'test.webm');
      whisperFormData.append('model', 'whisper-1');
      whisperFormData.append('language', language);

      const whisperResponse = await fetch('https://api.openai.com/v1/audio/transcriptions', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${Deno.env.get('OPENAI_API_KEY')}`,
        },
        body: whisperFormData,
      });

      const whisperTest = {
        name: 'OpenAI Whisper API Direct Test',
        passed: whisperResponse.ok,
        message: whisperResponse.ok 
          ? 'OpenAI Whisper API is responding correctly'
          : `OpenAI API error: ${whisperResponse.status} ${whisperResponse.statusText}`,
        details: whisperResponse.ok ? await whisperResponse.json() : null
      };
      results.tests.push(whisperTest);
      results.summary.total++;
      if (whisperTest.passed) results.summary.passed++;
      else results.summary.failed++;

    } catch (error) {
      const whisperTest = {
        name: 'OpenAI Whisper API Direct Test',
        passed: false,
        message: `OpenAI API test failed: ${error.message}`
      };
      results.tests.push(whisperTest);
      results.summary.total++;
      results.summary.failed++;
    }
  }

  results.success = results.summary.failed === 0;
  
  console.log(`📊 Transcription pipeline test completed: ${results.summary.passed}/${results.summary.total} passed`);

  return new Response(JSON.stringify(results), {
    headers: { ...corsHeaders, 'Content-Type': 'application/json' },
  });
}

async function testVoiceToText(audioBlob?: string, language = 'de') {
  if (!audioBlob) {
    return new Response(JSON.stringify({
      error: 'No audio data provided for voice-to-text test',
      success: false
    }), {
      status: 400,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }

  console.log('🎤 Testing voice-to-text conversion...');

  try {
    // Process base64 audio data
    const audioData = atob(audioBlob);
    const audioBytes = new Uint8Array(audioData.length);
    for (let i = 0; i < audioData.length; i++) {
      audioBytes[i] = audioData.charCodeAt(i);
    }

    console.log(`🎵 Audio data size: ${audioBytes.length} bytes`);

    // Create form data for OpenAI Whisper
    const formData = new FormData();
    formData.append('file', new Blob([audioBytes], { type: 'audio/webm' }), 'voice-test.webm');
    formData.append('model', 'whisper-1');
    formData.append('language', language);
    formData.append('response_format', 'verbose_json');
    formData.append('temperature', '0.1');

    const response = await fetch('https://api.openai.com/v1/audio/transcriptions', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${Deno.env.get('OPENAI_API_KEY')}`,
      },
      body: formData,
    });

    if (!response.ok) {
      const errorText = await response.text();
      throw new Error(`OpenAI API error: ${response.status} - ${errorText}`);
    }

    const result = await response.json();
    
    const quality = assessTranscriptQuality(result.text || '');
    
    console.log('✅ Voice-to-text test completed successfully');
    
    return new Response(JSON.stringify({
      success: true,
      transcription: {
        text: result.text,
        language: result.language,
        duration: result.duration,
        confidence: result.confidence || 0.0
      },
      quality: quality,
      audioAnalysis: {
        sizeBytes: audioBytes.length,
        format: 'audio/webm'
      }
    }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });

  } catch (error) {
    console.error('❌ Voice-to-text test failed:', error);
    return new Response(JSON.stringify({
      error: error.message,
      success: false
    }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
}

async function testTranscriptQuality(supabase: any, userId: string) {
  console.log('📊 Testing transcript quality for user:', userId);

  try {
    // Get user's transcripts
    const { data: videos, error: videosError } = await supabase
      .from('videos')
      .select(`
        id,
        title,
        transcripts (id, content, confidence, language),
        transcript_chunks (id, content, embedding_json)
      `)
      .eq('user_id', userId)
      .eq('status', 'completed')
      .limit(10);

    if (videosError) throw videosError;

    const qualityReport = {
      totalVideos: videos?.length || 0,
      videosWithTranscripts: 0,
      videosWithChunks: 0,
      videosWithEmbeddings: 0,
      averageQuality: 0,
      qualityIssues: [] as string[],
      recommendations: [] as string[],
      details: [] as any[]
    };

    let totalQuality = 0;
    let qualityCount = 0;

    for (const video of videos || []) {
      const videoDetail = {
        id: video.id,
        title: video.title,
        hasTranscript: false,
        hasChunks: false,
        hasEmbeddings: false,
        quality: null as any,
        issues: [] as string[]
      };

      if (video.transcripts && video.transcripts.length > 0) {
        qualityReport.videosWithTranscripts++;
        videoDetail.hasTranscript = true;
        
        const transcript = video.transcripts[0];
        const quality = assessTranscriptQuality(transcript.content);
        videoDetail.quality = quality;
        totalQuality += quality.score;
        qualityCount++;

        if (quality.score < 0.5) {
          qualityReport.qualityIssues.push(`Low quality transcript in "${video.title}": ${quality.issues.join(', ')}`);
          videoDetail.issues = quality.issues;
        }
      }

      if (video.transcript_chunks && video.transcript_chunks.length > 0) {
        qualityReport.videosWithChunks++;
        videoDetail.hasChunks = true;
        
        const chunksWithEmbeddings = video.transcript_chunks.filter(chunk => chunk.embedding_json);
        if (chunksWithEmbeddings.length > 0) {
          qualityReport.videosWithEmbeddings++;
          videoDetail.hasEmbeddings = true;
        }
      }

      qualityReport.details.push(videoDetail);
    }

    qualityReport.averageQuality = qualityCount > 0 ? totalQuality / qualityCount : 0;

    // Generate recommendations
    if (qualityReport.videosWithTranscripts < qualityReport.totalVideos) {
      qualityReport.recommendations.push('Some videos are missing transcripts');
    }
    if (qualityReport.videosWithChunks < qualityReport.videosWithTranscripts) {
      qualityReport.recommendations.push('Some transcripts need to be chunked for better search');
    }
    if (qualityReport.videosWithEmbeddings < qualityReport.videosWithChunks) {
      qualityReport.recommendations.push('Some chunks are missing embeddings for semantic search');
    }
    if (qualityReport.averageQuality < 0.7) {
      qualityReport.recommendations.push('Overall transcript quality could be improved');
    }

    console.log('📊 Quality analysis completed');

    return new Response(JSON.stringify({
      success: true,
      qualityReport
    }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });

  } catch (error) {
    console.error('❌ Quality test failed:', error);
    return new Response(JSON.stringify({
      error: error.message,
      success: false
    }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
}

async function testFullTranscriptionPipeline(supabase: any, userId: string, audioBlob?: string) {
  console.log('🔄 Testing full transcription pipeline...');

  const pipelineResults = {
    success: true,
    stages: [] as any[],
    overallResult: 'unknown'
  };

  try {
    // Stage 1: Voice to Text
    if (audioBlob) {
      const voiceToTextResult = await testVoiceToText(audioBlob);
      const voiceData = await voiceToTextResult.json();
      
      pipelineResults.stages.push({
        stage: 'Voice to Text',
        success: voiceData.success,
        result: voiceData,
        message: voiceData.success ? 'Audio transcribed successfully' : voiceData.error
      });
    }

    // Stage 2: Transcript Quality Analysis
    const qualityResult = await testTranscriptQuality(supabase, userId);
    const qualityData = await qualityResult.json();
    
    pipelineResults.stages.push({
      stage: 'Quality Analysis',
      success: qualityData.success,
      result: qualityData.qualityReport,
      message: qualityData.success 
        ? `Analyzed ${qualityData.qualityReport?.totalVideos || 0} videos`
        : qualityData.error
    });

    // Stage 3: Test embedding generation capability
    try {
      const embeddingTest = await supabase.functions.invoke('embedding-generator', {
        body: {
          action: 'check_status',
          userId: userId
        }
      });

      pipelineResults.stages.push({
        stage: 'Embedding Generation',
        success: !embeddingTest.error,
        result: embeddingTest.data,
        message: embeddingTest.error 
          ? `Embedding test failed: ${embeddingTest.error.message}`
          : 'Embedding generation is functional'
      });

    } catch (error) {
      pipelineResults.stages.push({
        stage: 'Embedding Generation',
        success: false,
        result: null,
        message: `Embedding test error: ${error.message}`
      });
    }

    // Determine overall result
    const failedStages = pipelineResults.stages.filter(stage => !stage.success);
    if (failedStages.length === 0) {
      pipelineResults.overallResult = 'success';
    } else if (failedStages.length <= 1) {
      pipelineResults.overallResult = 'partial';
    } else {
      pipelineResults.overallResult = 'failed';
      pipelineResults.success = false;
    }

    console.log(`🏁 Full pipeline test completed: ${pipelineResults.overallResult}`);

    return new Response(JSON.stringify(pipelineResults), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });

  } catch (error) {
    console.error('❌ Full pipeline test failed:', error);
    return new Response(JSON.stringify({
      error: error.message,
      success: false
    }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
}

function assessTranscriptQuality(text: string): { score: number, issues: string[] } {
  const issues: string[] = [];
  let score = 1.0;

  if (!text || text.trim().length === 0) {
    return { score: 0, issues: ['Empty transcript'] };
  }

  // Check length
  if (text.length < 10) {
    score *= 0.3;
    issues.push('Very short transcript');
  } else if (text.length < 30) {
    score *= 0.6;
    issues.push('Short transcript');
  }

  // Check for excessive repetition
  const words = text.toLowerCase().split(/\s+/);
  const uniqueWords = new Set(words);
  const repetitionRatio = uniqueWords.size / words.length;
  
  if (repetitionRatio < 0.3) {
    score *= 0.4;
    issues.push('High repetition detected');
  } else if (repetitionRatio < 0.5) {
    score *= 0.7;
    issues.push('Some repetition detected');
  }

  // Check for nonsensical character patterns
  const nonsensePattern = /[^a-zA-ZäöüßÄÖÜ\s.,!?-]/g;
  const nonsenseMatches = text.match(nonsensePattern);
  if (nonsenseMatches && nonsenseMatches.length > text.length * 0.1) {
    score *= 0.5;
    issues.push('Contains unusual characters');
  }

  // Check word count vs character count ratio (detect gibberish)
  const avgWordLength = text.length / words.length;
  if (avgWordLength > 15 || avgWordLength < 2) {
    score *= 0.6;
    issues.push('Unusual word length distribution');
  }

  return { score: Math.max(0, score), issues };
}