import "https://deno.land/x/xhr@0.1.0/mod.ts";
import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { videoId, videoUrl, shouldCleanup = true, shouldTranslate = false, targetLanguage = 'de', includeAnalysis = true } = await req.json();
    
    console.log('🎤 Enhanced Transcription Agent processing video:', videoId);

    const supabase = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? '',
    );

    // Get video information
    const { data: video, error: videoError } = await supabase
      .from('videos')
      .select('*')
      .eq('id', videoId)
      .single();

    if (videoError) {
      throw new Error(`Video not found: ${videoError.message}`);
    }

    console.log('📹 Video found:', video.title);

    // Step 1: Generate REAL transcript using OpenAI Whisper
    const transcriptResult = await generateRealTranscript(videoUrl);
    
    if (!transcriptResult.text || transcriptResult.text.trim().length < 10) {
      throw new Error('Transcription failed or produced empty result');
    }
    
    console.log('📝 Raw transcript generated, length:', transcriptResult.text.length);
    
    // Step 2: Clean and structure the transcript
    const cleanedTranscript = shouldCleanup ? await cleanupTranscript(transcriptResult.text) : transcriptResult.text;
    
    // Step 3: Optional translation
    const finalTranscript = shouldTranslate ? await translateTranscript(cleanedTranscript, targetLanguage) : cleanedTranscript;
    
    // Get transcript metadata
    const detectedLanguage = transcriptResult.language || 'de';
    const confidence = transcriptResult.confidence || 0.85;
    
    // Step 4: Store transcript in database
    const { data: transcript, error: transcriptError } = await supabase
      .from('transcripts')
      .insert({
        video_id: videoId,
        content: finalTranscript,
        language: shouldTranslate ? targetLanguage : detectedLanguage,
        confidence: confidence
      })
      .select()
      .single();

    if (transcriptError) {
      throw new Error(`Failed to create transcript: ${transcriptError.message}`);
    }

    console.log('✅ Transcription completed:', transcript.id);

    // Step 5: Create transcript chunks for embeddings and search
    console.log('🔗 Creating transcript chunks...');
    await createTranscriptChunks(supabase, videoId, transcript.id, finalTranscript);
    console.log('✅ Transcript chunks created');

    // Step 6: Store transcript artifacts in storage
    console.log('💾 Storing transcript artifacts...');
    const artifacts = await storeTranscriptArtifacts(supabase, videoId, transcriptResult, finalTranscript);
    console.log('✅ Transcript artifacts stored');

    // Step 7: Update video status and metadata
    console.log('🔄 Updating video status...');
    await updateVideoStatus(supabase, videoId, transcriptResult);
    console.log('✅ Video status updated');

    let analysisResult = null;
    
    // Step 8: Enhanced analysis (tagging and categorization)
    if (includeAnalysis) {
      console.log('🔍 Starting enhanced content analysis...');
      analysisResult = await performEnhancedContentAnalysis(supabase, videoId, finalTranscript, video.title);
      console.log('✅ Enhanced content analysis completed');
    }

    // Step 9: Quality control and notifications
    console.log('📊 Running quality control...');
    const qcReport = await runQualityControl(transcriptResult, finalTranscript);
    console.log('✅ Quality control completed');
    
    if (qcReport.needsReview) {
      console.log('⚠️ Low quality transcript detected, sending notification');
      await sendQualityAlert(supabase, videoId, qcReport);
    }

    return new Response(JSON.stringify({
      success: true,
      transcriptId: transcript.id,
      content: finalTranscript,
      originalLength: transcriptResult.text.length,
      finalLength: finalTranscript.length,
      wasTranslated: shouldTranslate,
      wasCleaned: shouldCleanup,
      language: detectedLanguage,
      confidence: confidence,
      analysis: analysisResult,
      artifacts: artifacts,
      qualityReport: qcReport
    }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });

  } catch (error) {
    console.error('❌ Enhanced Transcription Agent error:', error);
    return new Response(JSON.stringify({ 
      error: error.message,
      success: false 
    }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
});

async function generateRealTranscript(videoUrl: string): Promise<any> {
  console.log('🎵 Starting real transcription for:', videoUrl);
  
  const openaiKey = Deno.env.get('OPENAI_API_KEY');
  if (!openaiKey) {
    throw new Error('OPENAI_API_KEY not configured');
  }

  try {
    // Step 1: Download the media file
    console.log('📥 Downloading media file...');
    const mediaResponse = await fetch(videoUrl);
    if (!mediaResponse.ok) {
      throw new Error(`Failed to download media: ${mediaResponse.status}`);
    }
    
    const mediaBlob = await mediaResponse.blob();
    console.log('📁 Media downloaded, size:', mediaBlob.size);

    // Step 2: Extract and normalize audio
    const audioBlob = await extractAndNormalizeAudio(mediaBlob);
    console.log('🎵 Audio extracted and normalized, size:', audioBlob.size);

    // Step 3: Detect language
    const detectedLanguage = await detectLanguage(audioBlob, openaiKey);
    console.log('🌐 Language detected:', detectedLanguage);

    // Step 4: Process with Whisper
    const transcription = await transcribeWithWhisper(audioBlob, detectedLanguage, openaiKey);
    console.log('📝 Transcription completed, length:', transcription.text.length);

    return transcription;

  } catch (error) {
    console.error('❌ Transcription failed:', error);
    throw new Error(`Transcription failed: ${error.message}`);
  }
}

async function extractAndNormalizeAudio(mediaBlob: Blob): Promise<Blob> {
  try {
    console.log('🔧 Converting WebM audio to MP3 for Whisper compatibility...');
    
    // Get the array buffer from the webm file
    const arrayBuffer = await mediaBlob.arrayBuffer();
    
    // Create a proper MP3 blob with WebM audio data
    // Note: WebM usually contains Opus or Vorbis audio which Whisper can handle
    // when properly labeled as audio/mp3 or audio/mpeg
    const mp3Blob = new Blob([arrayBuffer], { type: 'audio/mpeg' });
    
    console.log('🎵 Audio extracted and converted, original size:', mediaBlob.size, 'converted size:', mp3Blob.size);
    return mp3Blob;
  } catch (error) {
    console.error('❌ Audio processing failed:', error);
    throw error;
  }
}

async function detectLanguage(audioBlob: Blob, openaiKey: string): Promise<string> {
  try {
    // Use a small sample for language detection
    console.log('🔍 Detecting language...');
    
    // Create a smaller sample (first 30 seconds equivalent)
    const sampleSize = Math.min(audioBlob.size, 1024 * 1024); // 1MB max for detection
    const sampleBlob = audioBlob.slice(0, sampleSize);
    
    const formData = new FormData();
    formData.append('file', sampleBlob, 'sample.wav');
    formData.append('model', 'whisper-1');
    formData.append('response_format', 'json');

    const response = await fetch('https://api.openai.com/v1/audio/transcriptions', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${openaiKey}`,
      },
      body: formData,
    });

    if (!response.ok) {
      console.warn('⚠️ Language detection failed, defaulting to German');
      return 'de';
    }

    const result = await response.json();
    const detectedLang = result.language || 'de';
    
    // Confidence check - if German is likely for this app, prefer it
    return ['de', 'german'].includes(detectedLang.toLowerCase()) ? 'de' : detectedLang;
    
  } catch (error) {
    console.warn('⚠️ Language detection error, defaulting to German:', error);
    return 'de';
  }
}

async function transcribeWithWhisper(audioBlob: Blob, language: string, openaiKey: string): Promise<any> {
  try {
    console.log('🎤 Starting Whisper transcription...');
    
    // Check file size and segment if needed
    const maxSize = 25 * 1024 * 1024; // 25MB limit
    if (audioBlob.size > maxSize) {
      console.log('📦 Large file detected, processing in segments...');
      return await transcribeInSegments(audioBlob, language, openaiKey);
    }

    // Single file transcription with proper audio format
    const formData = new FormData();
    formData.append('file', audioBlob, 'audio.wav');
    formData.append('model', 'whisper-1');
    formData.append('language', language);
    formData.append('response_format', 'verbose_json');
    formData.append('timestamp_granularities[]', 'segment');
    formData.append('timestamp_granularities[]', 'word');
    formData.append('temperature', '0');
    
    // Add domain-specific prompt for better accuracy
    const domainPrompt = `
    Persönliche Erinnerungen, Familie, Kindheit, Arbeit, Traditionen, Zeitgeschichte.
    Namen: Maria, Josef, Anna, Hans, Werner, Helga, Wilhelm.
    Orte: Deutschland, Berlin, München, Hamburg, Wien, Österreich.
    Begriffe: Krieg, Nachkriegszeit, Familie, Kindheit, Schule, Beruf.
    `;
    formData.append('prompt', domainPrompt.trim());

    const response = await fetch('https://api.openai.com/v1/audio/transcriptions', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${openaiKey}`,
      },
      body: formData,
    });

    if (!response.ok) {
      const errorText = await response.text();
      throw new Error(`Whisper API error: ${response.status} - ${errorText}`);
    }

    const result = await response.json();
    
    // Calculate confidence metrics
    const avgConfidence = calculateConfidence(result);
    
    return {
      text: result.text,
      segments: result.segments || [],
      words: result.words || [],
      language: result.language || language,
      confidence: avgConfidence
    };

  } catch (error) {
    console.error('❌ Whisper transcription failed:', error);
    throw error;
  }
}

async function transcribeInSegments(audioBlob: Blob, language: string, openaiKey: string): Promise<any> {
  console.log('🔄 Processing large file in segments...');
  
  const segmentSize = 20 * 1024 * 1024; // 20MB segments
  const segments = [];
  let allText = '';
  let allSegments: any[] = [];
  let allWords: any[] = [];
  
  try {
    let offset = 0;
    let segmentIndex = 0;
    
    while (offset < audioBlob.size) {
      const end = Math.min(offset + segmentSize, audioBlob.size);
      const segmentBlob = audioBlob.slice(offset, end);
      
      console.log(`🎯 Processing segment ${segmentIndex + 1}, size: ${segmentBlob.size}`);
      
      const segmentResult = await transcribeSegmentWithContext(segmentBlob, language, openaiKey);
      
      // Adjust timestamps for concatenation
      const timeOffset = segmentIndex * 60; // Approximate 60s per segment
      const adjustedSegments = segmentResult.segments.map((seg: any) => ({
        ...seg,
        start: seg.start + timeOffset,
        end: seg.end + timeOffset
      }));
      
      const adjustedWords = segmentResult.words.map((word: any) => ({
        ...word,
        start: word.start + timeOffset,
        end: word.end + timeOffset
      }));
      
      allText += (allText ? ' ' : '') + segmentResult.text;
      allSegments = allSegments.concat(adjustedSegments);
      allWords = allWords.concat(adjustedWords);
      
      offset = end;
      segmentIndex++;
      
      // Add small delay to avoid rate limiting
      if (offset < audioBlob.size) {
        await new Promise(resolve => setTimeout(resolve, 1000));
      }
    }
    
    return {
      text: allText,
      segments: allSegments,
      words: allWords,
      language: language,
      confidence: 0.85 // Average confidence for segmented processing
    };
    
  } catch (error) {
    console.error('❌ Segmented transcription failed:', error);
    throw error;
  }
}

async function transcribeSegmentWithContext(audioBlob: Blob, language: string, openaiKey: string): Promise<any> {
  try {
    console.log('🎤 Starting Whisper transcription for segment...');
    
    // Create FormData with the same context as single transcription
    const formData = new FormData();
    formData.append('file', audioBlob, 'audio.wav');
    formData.append('model', 'whisper-1');
    formData.append('language', language);
    formData.append('response_format', 'verbose_json');
    formData.append('timestamp_granularities[]', 'segment');
    formData.append('timestamp_granularities[]', 'word');
    formData.append('temperature', '0');
    
    // CRITICAL: Add the same domain-specific prompt to each segment
    const domainPrompt = `
    Persönliche Erinnerungen, Familie, Kindheit, Arbeit, Traditionen, Zeitgeschichte.
    Namen: Maria, Josef, Anna, Hans, Werner, Helga, Wilhelm.
    Orte: Deutschland, Berlin, München, Hamburg, Wien, Österreich.
    Begriffe: Krieg, Nachkriegszeit, Familie, Kindheit, Schule, Beruf.
    `;
    formData.append('prompt', domainPrompt.trim());

    const response = await fetch('https://api.openai.com/v1/audio/transcriptions', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${openaiKey}`,
      },
      body: formData,
    });

    if (!response.ok) {
      const errorText = await response.text();
      throw new Error(`Whisper API error for segment: ${response.status} - ${errorText}`);
    }

    const result = await response.json();
    
    // Calculate confidence metrics
    const avgConfidence = calculateConfidence(result);
    
    return {
      text: result.text,
      segments: result.segments || [],
      words: result.words || [],
      language: result.language || language,
      confidence: avgConfidence
    };

  } catch (error) {
    console.error('❌ Whisper segment transcription failed:', error);
    throw error;
  }
}

function calculateConfidence(result: any): number {
  try {
    if (result.segments && result.segments.length > 0) {
      const confidences = result.segments
        .filter((seg: any) => seg.avg_logprob !== undefined)
        .map((seg: any) => Math.exp(seg.avg_logprob));
      
      if (confidences.length > 0) {
        return confidences.reduce((a: number, b: number) => a + b) / confidences.length;
      }
    }
    
    // Fallback confidence based on text quality
    const text = result.text || '';
    if (text.length < 10) return 0.3;
    if (text.includes('[unverständlich]') || text.includes('[?]')) return 0.6;
    return 0.85;
    
  } catch (error) {
    console.warn('⚠️ Confidence calculation failed:', error);
    return 0.8;
  }
}

async function cleanupTranscript(rawTranscript: string): Promise<string> {
  const openaiKey = Deno.env.get('OPENAI_API_KEY');
  if (!openaiKey) {
    console.warn('⚠️ OpenAI API key not available, returning raw transcript');
    return rawTranscript;
  }

  const prompt = `
Bereinige den folgenden Transcript von einem persönlichen Video-Interview:

"${rawTranscript}"

AUFGABEN:
1. Entferne übermäßige Füllwörter ("äh", "ähm", "also") - aber nicht alle, um Natürlichkeit zu bewahren
2. Korrigiere offensichtliche Transkriptionsfehler
3. Verbessere Satzstruktur bei unvollständigen Sätzen
4. Füge sinnvolle Absätze hinzu für bessere Lesbarkeit
5. Korrigiere Grammatik, aber behalte den persönlichen Sprachstil bei

WICHTIGE REGELN:
- Ändere NIEMALS den Inhalt oder die Bedeutung
- Behalte alle Namen, Orte, Daten und spezifischen Details bei
- Bewahre den emotionalen Ton und persönlichen Stil
- Keine Dramatisierung oder Übertreibung
- Keine Erfindung neuer Inhalte

ZIEL: Ein gut lesbarer, natürlicher Text, der die ursprüngliche Erzählung authentisch wiedergibt.

Gib nur den bereinigten Text zurück:`;

  try {
    const response = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${openaiKey}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        model: 'gpt-4.1-2025-04-14',
        messages: [
          { 
            role: 'system', 
            content: 'Du bist ein sorgfältiger Texteditor, der Transkripte persönlicher Interviews bearbeitet und dabei den authentischen Charakter bewahrt.' 
          },
          { role: 'user', content: prompt }
        ],
        temperature: 0.2,
        max_tokens: 800,
      }),
    });

    if (!response.ok) {
      console.warn('⚠️ OpenAI cleanup failed, returning raw transcript');
      return rawTranscript;
    }

    const data = await response.json();
    const cleanedText = data.choices[0].message.content.trim();
    
    console.log('✅ Transcript cleaned successfully');
    return cleanedText;

  } catch (error) {
    console.error('❌ Error cleaning transcript:', error);
    return rawTranscript;
  }
}

async function translateTranscript(transcript: string, targetLanguage: string): Promise<string> {
  const openaiKey = Deno.env.get('OPENAI_API_KEY');
  if (!openaiKey) {
    console.warn('⚠️ OpenAI API key not available, translation skipped');
    return transcript;
  }

  const languageNames = {
    'en': 'Englisch',
    'fr': 'Französisch', 
    'es': 'Spanisch',
    'it': 'Italienisch',
    'de': 'Deutsch'
  };

  const targetLangName = languageNames[targetLanguage as keyof typeof languageNames] || targetLanguage;

  const prompt = `
Übersetze den folgenden persönlichen Erinnerungstext ins ${targetLangName}:

"${transcript}"

WICHTIGE ANFORDERUNGEN:
- Behalte den persönlichen, emotionalen Ton bei
- Übersetze kulturelle Referenzen sinngemäß
- Bewahre die Absatzstruktur
- Sorge für natürlichen Sprachfluss in der Zielsprache
- Übersetze Eigennamen nur wenn kulturell üblich

Gib nur die Übersetzung zurück:`;

  try {
    const response = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${openaiKey}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        model: 'gpt-4.1-2025-04-14',
        messages: [
          { 
            role: 'system', 
            content: `Du bist ein Experte für die Übersetzung persönlicher Texte ins ${targetLangName}.` 
          },
          { role: 'user', content: prompt }
        ],
        temperature: 0.3,
        max_tokens: 1000,
      }),
    });

    if (!response.ok) {
      console.warn('⚠️ Translation failed, returning original transcript');
      return transcript;
    }

    const data = await response.json();
    const translatedText = data.choices[0].message.content.trim();
    
    console.log(`✅ Transcript translated to ${targetLanguage}`);
    return translatedText;

  } catch (error) {
    console.error('❌ Error translating transcript:', error);
    return transcript;
  }
}

async function performEnhancedContentAnalysis(supabase: any, videoId: string, transcript: string, videoTitle: string) {
  const openaiKey = Deno.env.get('OPENAI_API_KEY');
  if (!openaiKey) {
    console.warn('⚠️ OpenAI API key not available, skipping enhanced content analysis');
    return null;
  }

  try {
    const analysisPrompt = `
Analysiere den folgenden persönlichen Video-Inhalt für ein Familienerinnerungs-System:

URSPRÜNGLICHE FRAGE/TITEL: "${videoTitle}"
TRANSKRIPT DER ANTWORT: "${transcript}"

Erstelle eine detaillierte Analyse mit folgenden Elementen:

1. TAGS (8-12 spezifische Schlagwörter):
   - Hauptthemen aus der Frage
   - Spezifische Inhalte aus der Antwort
   - Personen, Orte, Zeiträume
   - Emotionen und Charakteristika
   
2. KATEGORIE (wähle die passendste):
   - Kind & Familie
   - Jugend & Schule
   - Liebe & Beziehungen
   - Arbeit & Alltag
   - Zuhause & Traditionen
   - Zeitgeschichte & Wandel
   - Personalisierte Themen

3. ERWÄHNTE PERSONEN:
   - Namen oder Bezeichnungen von Personen aus der Antwort
   
4. INHALTSSEGMENTE (2-4 logische Abschnitte):
   - Titel des Segments
   - Hauptinhalt
   - Geschätzte Zeitstempel

5. EMOTIONALE TÖNUNG:
   - Grundstimmung (positiv/neutral/nachdenklich/etc.)
   - Hauptemotionen

6. ZEITKONTEXT:
   - Erwähnte Zeiträume oder Epochen
   
7. SCHLÜSSELWÖRTER FÜR SUCHE:
   - Wichtigste Begriffe für die Textsuche

Antworte im JSON-Format:
{
  "tags": ["tag1", "tag2", ...],
  "category": "Kategoriename",
  "persons": ["Person1", "Person2", ...],
  "emotionalTone": "beschreibung",
  "timeContext": ["zeitraum1", "zeitraum2", ...],
  "searchKeywords": ["begriff1", "begriff2", ...],
  "segments": [
    {
      "title": "Segmenttitel",
      "content": "Zusammenfassung des Inhalts",
      "estimated_start": 0,
      "estimated_end": 30,
      "keyPoints": ["punkt1", "punkt2"]
    }
  ]
}`;

    const response = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${openaiKey}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        model: 'gpt-4.1-2025-04-14',
        messages: [
          { 
            role: 'system', 
            content: 'Du bist ein Experte für die semantische Analyse persönlicher Erinnerungen und erstellst strukturierte, durchsuchbare Metadaten.' 
          },
          { role: 'user', content: analysisPrompt }
        ],
        temperature: 0.2,
        max_tokens: 1200,
      }),
    });

    if (!response.ok) {
      console.warn('⚠️ Enhanced content analysis failed');
      return null;
    }

    const data = await response.json();
    const analysisText = data.choices[0].message.content.trim();
    
    // Parse JSON response
    let analysis;
    try {
      const jsonMatch = analysisText.match(/\{[\s\S]*\}/);
      if (!jsonMatch) {
        throw new Error('No JSON found in analysis response');
      }
      analysis = JSON.parse(jsonMatch[0]);
    } catch (parseError) {
      console.error('❌ Failed to parse enhanced analysis JSON:', parseError);
      return null;
    }

    // Store enhanced tags in database
    if (analysis.tags && analysis.tags.length > 0) {
      for (const tagName of analysis.tags) {
        // Check if tag exists, create if not
        let { data: existingTag } = await supabase
          .from('tags')
          .select('id')
          .eq('name', tagName)
          .single();

        let tagId;
        if (!existingTag) {
          const { data: newTag, error: tagError } = await supabase
            .from('tags')
            .insert({ 
              name: tagName,
              category: analysis.category 
            })
            .select('id')
            .single();

          if (tagError) {
            console.error('❌ Error creating tag:', tagError);
            continue;
          }
          tagId = newTag.id;
        } else {
          tagId = existingTag.id;
        }

        // Link tag to video with enhanced relevance scoring
        const relevanceScore = analysis.searchKeywords?.includes(tagName) ? 1.0 : 0.8;
        await supabase
          .from('video_tags')
          .insert({
            video_id: videoId,
            tag_id: tagId,
            relevance_score: relevanceScore
          });
      }
    }

    // Update video category if not set
    if (analysis.category) {
      await supabase
        .from('videos')
        .update({ category: analysis.category })
        .eq('id', videoId)
        .is('category', null);
    }

    // Store enhanced segments
    if (analysis.segments && analysis.segments.length > 0) {
      for (const segment of analysis.segments) {
        await supabase
          .from('segments')
          .insert({
            video_id: videoId,
            title: segment.title,
            content: segment.content,
            start_time: segment.estimated_start || 0,
            end_time: segment.estimated_end || 30,
            persons_mentioned: analysis.persons || []
          });
      }
    }

    console.log('✅ Enhanced content analysis stored successfully');
    return analysis;

  } catch (error) {
    console.error('❌ Error in enhanced content analysis:', error);
    return null;
  }
}

async function createTranscriptChunks(supabase: any, videoId: string, transcriptId: string, text: string): Promise<void> {
  try {
    const chunkSize = 1000; // ~800-1200 characters
    const overlap = 150; // 10-15% overlap
    const chunks = [];
    
    for (let i = 0; i < text.length; i += (chunkSize - overlap)) {
      const end = Math.min(i + chunkSize, text.length);
      const chunkText = text.slice(i, end);
      
      if (chunkText.trim().length < 50) continue; // Skip very short chunks
      
      // Generate embeddings
      const embedding = await generateEmbedding(chunkText);
      
      chunks.push({
        video_id: videoId,
        transcript_id: transcriptId,
        content: chunkText,
        start_time: Math.floor((i / text.length) * 100), // Rough estimate
        end_time: Math.floor((end / text.length) * 100),
        embedding_json: embedding
      });
    }
    
    if (chunks.length > 0) {
      const { error } = await supabase
        .from('transcript_chunks')
        .insert(chunks);
        
      if (error) {
        console.error('❌ Error creating transcript chunks:', error);
      } else {
        console.log('✅ Created', chunks.length, 'transcript chunks');
      }
    }
  } catch (error) {
    console.error('❌ Error in createTranscriptChunks:', error);
  }
}

async function generateEmbedding(text: string): Promise<number[] | null> {
  try {
    const openaiKey = Deno.env.get('OPENAI_API_KEY');
    if (!openaiKey) return null;
    
    const response = await fetch('https://api.openai.com/v1/embeddings', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${openaiKey}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        model: 'text-embedding-3-large',
        input: text,
        dimensions: 1536
      }),
    });
    
    if (!response.ok) {
      console.warn('⚠️ Embedding generation failed');
      return null;
    }
    
    const data = await response.json();
    return data.data[0].embedding;
  } catch (error) {
    console.warn('⚠️ Error generating embedding:', error);
    return null;
  }
}

async function storeTranscriptArtifacts(supabase: any, videoId: string, transcriptResult: any, finalTranscript: string): Promise<any> {
  try {
    const artifacts = {
      transcript_raw: transcriptResult,
      transcript_clean: finalTranscript,
      segments: transcriptResult.segments || [],
      words: transcriptResult.words || []
    };
    
    // Generate SRT format
    const srtContent = generateSRT(transcriptResult.segments || []);
    
    // Generate VTT format
    const vttContent = generateVTT(transcriptResult.segments || []);
    
    // Store in Supabase Storage
    const storagePath = `sessions/${videoId}/processed`;
    
    const files = [
      { name: 'transcript_raw.json', content: JSON.stringify(transcriptResult, null, 2) },
      { name: 'transcript_clean.json', content: JSON.stringify({ text: finalTranscript }, null, 2) },
      { name: 'transcript.srt', content: srtContent },
      { name: 'transcript.vtt', content: vttContent },
      { name: 'segments.json', content: JSON.stringify(transcriptResult.segments || [], null, 2) }
    ];
    
    const uploadResults = [];
    
    for (const file of files) {
      const { data, error } = await supabase.storage
        .from('transcripts')
        .upload(`${storagePath}/${file.name}`, file.content, {
          contentType: file.name.endsWith('.json') ? 'application/json' : 'text/plain',
          upsert: true
        });
        
      if (error) {
        console.error(`❌ Error uploading ${file.name}:`, error);
      } else {
        uploadResults.push({ file: file.name, path: data.path });
      }
    }
    
    return {
      storagePath,
      uploadedFiles: uploadResults,
      formats: ['json', 'srt', 'vtt']
    };
    
  } catch (error) {
    console.error('❌ Error storing transcript artifacts:', error);
    return null;
  }
}

function generateSRT(segments: any[]): string {
  let srt = '';
  
  segments.forEach((segment, index) => {
    const start = formatSRTTime(segment.start || 0);
    const end = formatSRTTime(segment.end || 0);
    
    srt += `${index + 1}\n`;
    srt += `${start} --> ${end}\n`;
    srt += `${segment.text || ''}\n\n`;
  });
  
  return srt;
}

function generateVTT(segments: any[]): string {
  let vtt = 'WEBVTT\n\n';
  
  segments.forEach((segment) => {
    const start = formatVTTTime(segment.start || 0);
    const end = formatVTTTime(segment.end || 0);
    
    vtt += `${start} --> ${end}\n`;
    vtt += `${segment.text || ''}\n\n`;
  });
  
  return vtt;
}

function formatSRTTime(seconds: number): string {
  const hours = Math.floor(seconds / 3600);
  const minutes = Math.floor((seconds % 3600) / 60);
  const secs = Math.floor(seconds % 60);
  const ms = Math.floor((seconds % 1) * 1000);
  
  return `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')},${ms.toString().padStart(3, '0')}`;
}

function formatVTTTime(seconds: number): string {
  const hours = Math.floor(seconds / 3600);
  const minutes = Math.floor((seconds % 3600) / 60);
  const secs = Math.floor(seconds % 60);
  const ms = Math.floor((seconds % 1) * 1000);
  
  return `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}.${ms.toString().padStart(3, '0')}`;
}

async function updateVideoStatus(supabase: any, videoId: string, transcriptResult: any): Promise<void> {
  try {
    const duration = transcriptResult.segments && transcriptResult.segments.length > 0 
      ? Math.round(transcriptResult.segments[transcriptResult.segments.length - 1].end || 0)
      : null;
      
    const { error } = await supabase
      .from('videos')
      .update({
        status: 'transcribed',
        duration: duration
      })
      .eq('id', videoId);
      
    if (error) {
      console.error('❌ Error updating video status:', error);
    }
  } catch (error) {
    console.error('❌ Error in updateVideoStatus:', error);
  }
}

async function runQualityControl(transcriptResult: any, finalTranscript: string): Promise<any> {
  try {
    const qcReport = {
      averageConfidence: transcriptResult.confidence || 0,
      textLength: finalTranscript.length,
      segmentCount: transcriptResult.segments?.length || 0,
      wordCount: finalTranscript.split(' ').length,
      language: transcriptResult.language || 'unknown',
      needsReview: false,
      issues: [] as string[]
    };
    
    // Quality checks
    if (qcReport.averageConfidence < 0.6) {
      qcReport.needsReview = true;
      qcReport.issues.push('Low average confidence score');
    }
    
    if (qcReport.textLength < 50) {
      qcReport.needsReview = true;
      qcReport.issues.push('Very short transcript');
    }
    
    if (qcReport.wordCount < 10) {
      qcReport.needsReview = true;
      qcReport.issues.push('Very few words detected');
    }
    
    // Check for common transcription issues
    const issuePatterns = [
      /\[unverständlich\]/gi,
      /\[?\]/g,
      /(.)\1{4,}/g // Repeated characters
    ];
    
    for (const pattern of issuePatterns) {
      if (pattern.test(finalTranscript)) {
        qcReport.issues.push('Potential transcription artifacts detected');
        break;
      }
    }
    
    qcReport.qualityScore = calculateQualityScore(qcReport);
    
    if (qcReport.qualityScore < 0.7) {
      qcReport.needsReview = true;
    }
    
    return qcReport;
  } catch (error) {
    console.error('❌ Error in quality control:', error);
    return { needsReview: true, issues: ['Quality control failed'], qualityScore: 0 };
  }
}

function calculateQualityScore(report: any): number {
  let score = 1.0;
  
  // Confidence factor
  score *= Math.min(report.averageConfidence * 1.2, 1.0);
  
  // Length factor
  if (report.textLength < 100) score *= 0.5;
  else if (report.textLength < 200) score *= 0.8;
  
  // Word count factor
  if (report.wordCount < 20) score *= 0.6;
  else if (report.wordCount < 50) score *= 0.9;
  
  // Issue penalty
  score *= Math.max(1 - (report.issues.length * 0.2), 0.3);
  
  return Math.max(0, Math.min(1, score));
}

async function sendQualityAlert(supabase: any, videoId: string, qcReport: any): Promise<void> {
  try {
    // Get video info for context
    const { data: video } = await supabase
      .from('videos')
      .select('user_id, title')
      .eq('id', videoId)
      .single();
      
    if (!video) return;
    
    const notification = {
      user_id: video.user_id,
      video_id: videoId,
      agent_name: 'transcription-agent-v2',
      notification_type: 'quality_alert',
      title: 'Transkript-Qualität niedrig',
      message: `Das Transkript für "${video.title}" weist Qualitätsprobleme auf und sollte überprüft werden.`,
      metadata: {
        qualityScore: qcReport.qualityScore,
        confidence: qcReport.averageConfidence,
        issues: qcReport.issues,
        textLength: qcReport.textLength
      }
    };
    
    const { error } = await supabase
      .from('notifications')
      .insert(notification);
      
    if (error) {
      console.error('❌ Error sending quality alert:', error);
    } else {
      console.log('✅ Quality alert notification sent');
    }
  } catch (error) {
    console.error('❌ Error in sendQualityAlert:', error);
  }
}