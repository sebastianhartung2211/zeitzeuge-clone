import "https://deno.land/x/xhr@0.1.0/mod.ts";
import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

interface TestCase {
  id: number;
  question: string;
  category: string;
  expectedVideoTitle?: string;
  expectedVideoTitles?: string[];
  expectedMatch?: boolean;
  minimumConfidence: number;
  description: string;
}

const PRODUCTION_TEST_DATASET: TestCase[] = [
  {
    id: 1,
    question: "Wie sah ein ganz normaler Tag in deiner Kindheit aus?",
    category: "Kind & Familie",
    expectedVideoTitle: "Wie sah ein ganz normaler Tag in deiner Kindheit aus?",
    minimumConfidence: 0.8,
    description: "Direct exact match test"
  },
  {
    id: 2,
    question: "Erzähl mir von deiner Kindheit",
    category: "Kind & Familie",
    expectedVideoTitles: [
      "Wie sah ein ganz normaler Tag in deiner Kindheit aus?",
      "Welche Spiele hast du als Kind am liebsten gespielt?",
      "Was haben deine Eltern dir beigebracht, das du nie vergessen hast?"
    ],
    minimumConfidence: 0.6,
    description: "Broader childhood question"
  },
  {
    id: 3,
    question: "Wie hast du deine große Liebe kennengelernt?",
    category: "Liebe & Beziehungen",
    expectedVideoTitle: "Wie hast du deine große Liebe kennengelernt?",
    minimumConfidence: 0.8,
    description: "Direct love question match"
  },
  {
    id: 4,
    question: "Was waren deine Lieblingsspiele als Kind?",
    category: "Kind & Familie",
    expectedVideoTitle: "Welche Spiele hast du als Kind am liebsten gespielt?",
    minimumConfidence: 0.7,
    description: "Similar phrasing test"
  },
  {
    id: 5,
    question: "Wie war die Schule früher?",
    category: "Jugend & Schule",
    expectedVideoTitle: "Wie war deine Schulzeit – gab es ein Lieblingsfach oder einen Lehrer, der dir besonders in Erinnerung geblieben ist?",
    minimumConfidence: 0.6,
    description: "School-related semantic match"
  },
  {
    id: 6,
    question: "Was denkst du über Quantenphysik?",
    category: "Irrelevant",
    expectedMatch: false,
    minimumConfidence: 0.0,
    description: "Irrelevant question - should reject"
  },
  {
    id: 7,
    question: "Wie alt bist du?",
    category: "Personal",
    expectedMatch: false,
    minimumConfidence: 0.3,
    description: "Personal info not in videos"
  },
  {
    id: 8,
    question: "Was hat sich in der Welt verändert?",
    category: "Zeitgeschichte & Wandel",
    expectedVideoTitle: "Welche Veränderungen in der Welt hast du erlebt, die dich besonders erstaunt haben?",
    minimumConfidence: 0.6,
    description: "Historical change question"
  },
  {
    id: 9,
    question: "Erzähl mir etwas Romantisches",
    category: "Liebe & Beziehungen",
    expectedVideoTitle: "Was war das romantischste, was du je erlebt hast?",
    minimumConfidence: 0.6,
    description: "Romance semantic match"
  },
  {
    id: 10,
    question: "Was vermisst du von früher?",
    category: "Zeitgeschichte & Wandel",
    expectedVideoTitle: "Was vermisst du von früher – und was findest du heute besser als damals?",
    minimumConfidence: 0.8,
    description: "Nostalgia exact match"
  }
];

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { userId, testType = 'full', runBaseline = false } = await req.json();
    
    console.log('🧪 Starting Production Evaluation:', { userId, testType, runBaseline });

    const supabase = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? '',
    );

    // Get baseline data first
    let baselineResults = null;
    if (runBaseline) {
      console.log('📊 Running baseline tests with old agent...');
      baselineResults = await runBaselineTests(supabase, userId);
    }

    // Run production tests with V3 agent
    console.log('🚀 Running production tests with V3 agent...');
    const productionResults = await runProductionTests(supabase, userId, testType);

    // Calculate comprehensive metrics
    const metrics = calculateComprehensiveMetrics(productionResults, baselineResults);

    // Store evaluation results
    await storeEvaluationResults(supabase, userId, productionResults, metrics);

    return new Response(JSON.stringify({
      success: true,
      evaluation: {
        timestamp: new Date().toISOString(),
        pipeline: 'production-v3',
        testType,
        baseline: baselineResults,
        production: productionResults,
        metrics,
        summary: {
          totalTests: productionResults.length,
          successRate: metrics.accuracy,
          avgConfidence: metrics.averageConfidence,
          avgResponseTime: metrics.averageResponseTime,
          improvement: baselineResults ? {
            accuracyDelta: metrics.accuracy - (baselineResults.successCount / baselineResults.tests.length),
            confidenceDelta: metrics.averageConfidence - baselineResults.averageConfidence
          } : null
        }
      }
    }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });

  } catch (error) {
    console.error('❌ Production evaluation error:', error);
    return new Response(JSON.stringify({ 
      success: false,
      error: error.message,
      pipeline: 'production-evaluation' 
    }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
});

async function runProductionTests(supabase: any, userId: string, testType: string) {
  const testCases = testType === 'quick' ? PRODUCTION_TEST_DATASET.slice(0, 5) : PRODUCTION_TEST_DATASET;
  const results = [];
  
  for (const testCase of testCases) {
    console.log(`\n🔍 Testing V3: "${testCase.question}"`);
    
    const startTime = Date.now();
    
    try {
      const response = await fetch(`${Deno.env.get('SUPABASE_URL')}/functions/v1/conversation-agent-v3`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          question: testCase.question,
          userId: userId,
          action: 'answer_question'
        })
      });

      const responseTime = Date.now() - startTime;
      
      if (!response.ok) {
        throw new Error(`HTTP ${response.status}: ${await response.text()}`);
      }

      const data = await response.json();
      const confidence = data.confidence || 0;
      const matchedTitle = data.videoTitle || null;
      
      // Evaluate success
      let success = false;
      let reason = '';
      
      if (testCase.expectedMatch === false) {
        success = confidence < 0.6;
        reason = success ? 'Correctly rejected irrelevant question' : 'False positive';
      } else if (testCase.expectedVideoTitle) {
        success = matchedTitle === testCase.expectedVideoTitle && confidence >= testCase.minimumConfidence;
        reason = success ? 'Exact title match' : `Expected "${testCase.expectedVideoTitle}", got "${matchedTitle}"`;
      } else if (testCase.expectedVideoTitles) {
        success = testCase.expectedVideoTitles.includes(matchedTitle) && confidence >= testCase.minimumConfidence;
        reason = success ? 'Valid title match' : `No expected title matched: ${matchedTitle}`;
      }

      results.push({
        testId: testCase.id,
        question: testCase.question,
        success,
        confidence,
        matchedVideoTitle: matchedTitle,
        expectedTitle: testCase.expectedVideoTitle,
        reasoning: data.debug?.reasoning || reason,
        responseTime,
        debug: data.debug,
        pipeline: 'v3'
      });

      console.log(`✅ V3 Result: ${success ? 'PASS' : 'FAIL'} (confidence: ${confidence.toFixed(2)}, time: ${responseTime}ms)`);
      
    } catch (error) {
      console.error(`❌ V3 Test ${testCase.id} failed:`, error);
      results.push({
        testId: testCase.id,
        question: testCase.question,
        success: false,
        confidence: 0,
        matchedVideoTitle: null,
        error: error.message,
        responseTime: Date.now() - startTime,
        pipeline: 'v3'
      });
    }
    
    // Rate limiting
    await new Promise(resolve => setTimeout(resolve, 500));
  }
  
  return results;
}

async function runBaselineTests(supabase: any, userId: string) {
  // Test with old conversation-agent for comparison
  const quickTests = PRODUCTION_TEST_DATASET.slice(0, 3);
  const results = [];
  
  for (const testCase of quickTests) {
    const startTime = Date.now();
    
    try {
      const response = await fetch(`${Deno.env.get('SUPABASE_URL')}/functions/v1/conversation-agent`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          question: testCase.question,
          userId: userId,
          action: 'answer_question'
        })
      });
      
      const data = await response.json();
      
      results.push({
        testId: testCase.id,
        question: testCase.question,
        confidence: data.confidence || 0,
        matchedTitle: data.videoTitle || null,
        responseTime: Date.now() - startTime,
        pipeline: 'baseline'
      });
      
    } catch (error) {
      results.push({
        testId: testCase.id,
        error: error.message,
        confidence: 0,
        responseTime: Date.now() - startTime,
        pipeline: 'baseline'
      });
    }
    
    await new Promise(resolve => setTimeout(resolve, 300));
  }
  
  return {
    tests: results,
    successCount: results.filter(r => r.confidence > 0.5).length,
    averageConfidence: results.reduce((sum, r) => sum + r.confidence, 0) / results.length,
    averageResponseTime: results.reduce((sum, r) => sum + r.responseTime, 0) / results.length
  };
}

function calculateComprehensiveMetrics(results: any[], baseline: any) {
  const totalTests = results.length;
  const successfulTests = results.filter(r => r.success).length;
  
  // Confusion matrix
  let truePositives = 0, falsePositives = 0, falseNegatives = 0, trueNegatives = 0;
  
  results.forEach(result => {
    const testCase = PRODUCTION_TEST_DATASET.find(t => t.id === result.testId);
    const shouldMatch = testCase?.expectedMatch !== false;
    const didMatch = result.confidence >= 0.6;
    
    if (shouldMatch && didMatch) truePositives++;
    else if (!shouldMatch && didMatch) falsePositives++;
    else if (shouldMatch && !didMatch) falseNegatives++;
    else if (!shouldMatch && !didMatch) trueNegatives++;
  });
  
  const precision = truePositives + falsePositives > 0 ? truePositives / (truePositives + falsePositives) : 0;
  const recall = truePositives + falseNegatives > 0 ? truePositives / (truePositives + falseNegatives) : 0;
  const f1Score = precision + recall > 0 ? 2 * (precision * recall) / (precision + recall) : 0;
  const accuracy = (truePositives + trueNegatives) / totalTests;
  
  const averageConfidence = results.reduce((sum, r) => sum + r.confidence, 0) / totalTests;
  const averageResponseTime = results.reduce((sum, r) => sum + r.responseTime, 0) / totalTests;
  
  // Quality metrics
  const highConfidenceMatches = results.filter(r => r.confidence > 0.8).length;
  const noAnswerRate = results.filter(r => r.confidence < 0.6).length / totalTests;
  
  return {
    accuracy,
    precision,
    recall,
    f1Score,
    averageConfidence,
    averageResponseTime,
    totalTests,
    successfulTests,
    highConfidenceMatches,
    noAnswerRate,
    confusionMatrix: { truePositives, falsePositives, falseNegatives, trueNegatives }
  };
}

async function storeEvaluationResults(supabase: any, userId: string, results: any[], metrics: any) {
  try {
    // Store in conversations as evaluation markers
    for (const result of results.slice(0, 3)) { // Store subset to avoid spam
      await supabase
        .from('conversations')
        .insert({
          user_id: userId,
          question: `[EVAL] ${result.question}`,
          answer: `Pipeline: ${result.pipeline}, Success: ${result.success}, Confidence: ${result.confidence.toFixed(3)}`,
          confidence_score: result.confidence,
          matched_video_id: null
        });
    }
    
    console.log('📊 Evaluation results stored');
  } catch (error) {
    console.error('❌ Error storing evaluation results:', error);
  }
}