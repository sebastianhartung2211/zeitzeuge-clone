import "https://deno.land/x/xhr@0.1.0/mod.ts";
import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.52.0";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  console.log('🧪 System Test Agent - Running comprehensive tests');
  
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { testType = 'full' } = await req.json();
    const supabase = createClient(
      Deno.env.get('SUPABASE_URL')!,
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!
    );

    const testResults = {
      timestamp: new Date().toISOString(),
      testType,
      results: {},
      summary: { passed: 0, failed: 0, warnings: 0 }
    };

    // Test 1: Database Schema Health
    console.log('🔍 Testing database schema...');
    testResults.results.schema = await testDatabaseSchema(supabase);
    updateSummary(testResults, testResults.results.schema);

    // Test 2: Video Data Integrity
    console.log('📹 Testing video data integrity...');
    testResults.results.videos = await testVideoIntegrity(supabase);
    updateSummary(testResults, testResults.results.videos);

    // Test 3: Agent Connectivity
    console.log('🤖 Testing agent connectivity...');
    testResults.results.agents = await testAgentConnectivity(supabase);
    updateSummary(testResults, testResults.results.agents);

    // Test 4: Conversation System
    console.log('💬 Testing conversation system...');
    testResults.results.conversation = await testConversationSystem(supabase);
    updateSummary(testResults, testResults.results.conversation);

    // Test 5: Notification System
    console.log('🔔 Testing notification system...');
    testResults.results.notifications = await testNotificationSystem(supabase);
    updateSummary(testResults, testResults.results.notifications);

    // Test 6: Performance Metrics
    if (testType === 'full' || testType === 'stress') {
      console.log('⚡ Running performance tests...');
      testResults.results.performance = await testPerformance(supabase);
      updateSummary(testResults, testResults.results.performance);
    }

    const overallStatus = testResults.summary.failed > 0 ? 'FAILED' : 
                         testResults.summary.warnings > 0 ? 'WARNING' : 'PASSED';

    console.log(`✅ System test completed: ${overallStatus}`);
    console.log(`📊 Summary: ${testResults.summary.passed} passed, ${testResults.summary.failed} failed, ${testResults.summary.warnings} warnings`);

    return new Response(
      JSON.stringify({ 
        success: true,
        overallStatus,
        testResults
      }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );

  } catch (error) {
    console.error('❌ System test error:', error);
    
    return new Response(
      JSON.stringify({ 
        success: false, 
        error: error.message,
        timestamp: new Date().toISOString()
      }),
      { 
        status: 500,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
      }
    );
  }
});

async function testDatabaseSchema(supabase: any) {
  const test = { name: 'Database Schema', status: 'PASSED', details: [], issues: [] };

  try {
    // Check required tables exist
    const requiredTables = ['videos', 'transcripts', 'transcript_chunks', 'notifications', 'processing_logs', 'video_tags', 'segments', 'tags', 'categories'];
    
    for (const table of requiredTables) {
      const { data, error } = await supabase
        .from(table)
        .select('count(*)')
        .limit(1);
      
      if (error) {
        test.issues.push(`Table ${table} not accessible: ${error.message}`);
      } else {
        test.details.push(`✅ Table ${table} accessible`);
      }
    }

    // Check RLS policies
    const { data: policies, error: policiesError } = await supabase
      .rpc('get_policies')
      .catch(() => ({ data: null, error: 'RPC not available' }));

    if (policiesError) {
      test.issues.push(`RLS policies check failed: ${policiesError}`);
    } else {
      test.details.push('✅ RLS policies accessible');
    }

    if (test.issues.length > 0) {
      test.status = 'FAILED';
    }

  } catch (error) {
    test.status = 'FAILED';
    test.issues.push(`Schema test error: ${error.message}`);
  }

  return test;
}

async function testVideoIntegrity(supabase: any) {
  const test = { name: 'Video Data Integrity', status: 'PASSED', details: [], issues: [] };

  try {
    // Check video completion rates
    const { data: videos, error } = await supabase
      .from('videos')
      .select('id, status, title, created_at')
      .limit(100);

    if (error) {
      test.status = 'FAILED';
      test.issues.push(`Video query failed: ${error.message}`);
      return test;
    }

    const totalVideos = videos.length;
    const completedVideos = videos.filter(v => v.status === 'completed').length;
    const failedVideos = videos.filter(v => v.status === 'failed').length;
    const processingVideos = videos.filter(v => v.status === 'processing').length;

    test.details.push(`📊 Total videos: ${totalVideos}`);
    test.details.push(`✅ Completed: ${completedVideos} (${((completedVideos/totalVideos)*100).toFixed(1)}%)`);
    test.details.push(`❌ Failed: ${failedVideos}`);
    test.details.push(`⏳ Processing: ${processingVideos}`);

    if (failedVideos > totalVideos * 0.1) { // More than 10% failure rate
      test.status = 'WARNING';
      test.issues.push(`High failure rate: ${failedVideos}/${totalVideos} videos failed`);
    }

    // Check for orphaned data
    const { data: orphanedTranscripts } = await supabase
      .from('transcripts')
      .select('id')
      .not('video_id', 'in', `(${videos.map(v => `'${v.id}'`).join(',')})`);

    if (orphanedTranscripts && orphanedTranscripts.length > 0) {
      test.status = 'WARNING';
      test.issues.push(`Found ${orphanedTranscripts.length} orphaned transcripts`);
    }

  } catch (error) {
    test.status = 'FAILED';
    test.issues.push(`Video integrity test error: ${error.message}`);
  }

  return test;
}

async function testAgentConnectivity(supabase: any) {
  const test = { name: 'Agent Connectivity', status: 'PASSED', details: [], issues: [] };

  const agents = [
    'conversation-agent-v3',
    'process-review-agent', 
    'tagging-segmentation-agent',
    'coordinator-agent',
    'transcription-agent-v2'
  ];

  for (const agent of agents) {
    try {
      const startTime = Date.now();
      
      // Test with minimal payload
      const result = await supabase.functions.invoke(agent, {
        body: { test: true, action: 'health_check' }
      });

      const responseTime = Date.now() - startTime;

      if (result.error) {
        test.issues.push(`❌ ${agent}: ${result.error.message}`);
      } else {
        test.details.push(`✅ ${agent}: ${responseTime}ms`);
      }

    } catch (error) {
      test.issues.push(`❌ ${agent}: Connection failed - ${error.message}`);
    }
  }

  if (test.issues.length > 0) {
    test.status = test.issues.length === agents.length ? 'FAILED' : 'WARNING';
  }

  return test;
}

async function testConversationSystem(supabase: any) {
  const test = { name: 'Conversation System', status: 'PASSED', details: [], issues: [] };

  try {
    // Check recent conversations
    const { data: conversations, error } = await supabase
      .from('conversations')
      .select('*')
      .order('created_at', { ascending: false })
      .limit(10);

    if (error) {
      test.status = 'FAILED';
      test.issues.push(`Conversation query failed: ${error.message}`);
      return test;
    }

    test.details.push(`📊 Recent conversations: ${conversations.length}`);

    // Analyze confidence scores
    const avgConfidence = conversations.reduce((sum, c) => sum + (c.confidence_score || 0), 0) / conversations.length;
    const highConfidenceCount = conversations.filter(c => (c.confidence_score || 0) >= 0.7).length;

    test.details.push(`🎯 Average confidence: ${avgConfidence.toFixed(2)}`);
    test.details.push(`✅ High confidence (≥0.7): ${highConfidenceCount}/${conversations.length}`);

    if (avgConfidence < 0.6) {
      test.status = 'WARNING';
      test.issues.push(`Low average confidence score: ${avgConfidence.toFixed(2)}`);
    }

    // Test conversation matching
    const testQuestion = "Wie war deine Kindheit?";
    const startTime = Date.now();
    
    const result = await supabase.functions.invoke('conversation-agent-v3', {
      body: { 
        question: testQuestion,
        userId: 'test-user-id',
        action: 'answer_question'
      }
    });

    const responseTime = Date.now() - startTime;

    if (result.error) {
      test.issues.push(`Conversation test failed: ${result.error.message}`);
    } else {
      test.details.push(`✅ Test query response: ${responseTime}ms`);
    }

  } catch (error) {
    test.status = 'FAILED';
    test.issues.push(`Conversation system test error: ${error.message}`);
  }

  return test;
}

async function testNotificationSystem(supabase: any) {
  const test = { name: 'Notification System', status: 'PASSED', details: [], issues: [] };

  try {
    // Check notification table
    const { data: notifications, error } = await supabase
      .from('notifications')
      .select('*')
      .limit(10);

    if (error) {
      test.status = 'FAILED';
      test.issues.push(`Notification query failed: ${error.message}`);
      return test;
    }

    test.details.push(`📊 Recent notifications: ${notifications.length}`);

    // Test notification creation
    const testNotification = {
      user_id: 'test-user-id',
      agent_name: 'system-test-agent',
      notification_type: 'success',
      title: 'System Test',
      message: 'Test notification from system test',
      metadata: { test: true }
    };

    const { error: insertError } = await supabase
      .from('notifications')
      .insert(testNotification);

    if (insertError) {
      test.issues.push(`Notification creation failed: ${insertError.message}`);
    } else {
      test.details.push(`✅ Notification creation successful`);
      
      // Clean up test notification
      await supabase
        .from('notifications')
        .delete()
        .eq('agent_name', 'system-test-agent');
    }

  } catch (error) {
    test.status = 'FAILED';
    test.issues.push(`Notification system test error: ${error.message}`);
  }

  return test;
}

async function testPerformance(supabase: any) {
  const test = { name: 'Performance Metrics', status: 'PASSED', details: [], issues: [] };

  try {
    // Test database query performance
    const dbTests = [
      { name: 'Video listing', query: () => supabase.from('videos').select('id, title, status').limit(50) },
      { name: 'Complex join', query: () => supabase.from('videos').select('*, transcripts(content), video_tags(*, tags(*))').limit(10) },
      { name: 'Conversation history', query: () => supabase.from('conversations').select('*').order('created_at', { ascending: false }).limit(20) }
    ];

    for (const dbTest of dbTests) {
      const startTime = Date.now();
      const { data, error } = await dbTest.query();
      const duration = Date.now() - startTime;

      if (error) {
        test.issues.push(`${dbTest.name} query failed: ${error.message}`);
      } else {
        test.details.push(`⚡ ${dbTest.name}: ${duration}ms (${data.length} records)`);
        
        if (duration > 2000) { // >2s is slow
          test.status = 'WARNING';
          test.issues.push(`Slow query: ${dbTest.name} took ${duration}ms`);
        }
      }
    }

    // Memory and connection test
    test.details.push(`🔗 Database connection: Active`);
    test.details.push(`💾 Test completed at: ${new Date().toISOString()}`);

  } catch (error) {
    test.status = 'FAILED';
    test.issues.push(`Performance test error: ${error.message}`);
  }

  return test;
}

function updateSummary(testResults: any, testResult: any) {
  switch (testResult.status) {
    case 'PASSED':
      testResults.summary.passed++;
      break;
    case 'WARNING':
      testResults.summary.warnings++;
      break;
    case 'FAILED':
      testResults.summary.failed++;
      break;
  }
}