import "https://deno.land/x/xhr@0.1.0/mod.ts";
import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  console.log('🔧 Video Status Recovery Agent called');
  
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabase = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? '',
    );

    const { action = 'recover_failed_videos' } = await req.json();
    
    console.log(`🔧 Video Recovery Agent called with action: ${action}`);

    switch (action) {
      case 'recover_failed_videos':
        return await recoverFailedVideos(supabase);
      case 'reprocess_video':
        const { videoId } = await req.json();
        return await reprocessSingleVideo(supabase, videoId);
      default:
        throw new Error(`Unknown action: ${action}`);
    }

  } catch (error) {
    console.error('❌ Video Recovery Agent error:', error);
    return new Response(JSON.stringify({ error: error.message }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
});

async function recoverFailedVideos(supabase: any) {
  console.log('🔍 Finding failed videos with transcripts...');
  
  // Find videos with status 'failed' but that have transcripts
  const { data: failedVideosWithTranscripts, error } = await supabase
    .from('videos')
    .select(`
      id,
      title,
      status,
      created_at,
      transcripts:transcripts(id, content)
    `)
    .eq('status', 'failed')
    .not('transcripts', 'is', null);

  if (error) {
    throw new Error(`Failed to query videos: ${error.message}`);
  }

  console.log(`📊 Found ${failedVideosWithTranscripts?.length || 0} failed videos with transcripts`);

  if (!failedVideosWithTranscripts || failedVideosWithTranscripts.length === 0) {
    return new Response(JSON.stringify({ 
      message: 'No failed videos with transcripts found',
      recovered: 0
    }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }

  let recovered = 0;
  const results = [];

  for (const video of failedVideosWithTranscripts) {
    try {
      console.log(`🔄 Attempting to recover video: ${video.id} - "${video.title}"`);
      
      // If video has transcript, mark as completed and run remaining pipeline
      if (video.transcripts && video.transcripts.length > 0) {
        // Update status to completed
        await supabase
          .from('videos')
          .update({ 
            status: 'completed',
            updated_at: new Date().toISOString()
          })
          .eq('id', video.id);

        // Try to run tagging if not already done
        const { data: existingTags } = await supabase
          .from('video_tags')
          .select('id')
          .eq('video_id', video.id)
          .limit(1);

        if (!existingTags || existingTags.length === 0) {
          console.log(`🏷️ Running tagging for recovered video: ${video.id}`);
          try {
            await supabase.functions.invoke('tagging-segmentation-agent', {
              body: { 
                videoId: video.id, 
                userId: video.user_id 
              }
            });
          } catch (taggingError) {
            console.warn(`⚠️ Tagging failed for recovered video ${video.id}:`, taggingError.message);
            // Set default category
            await supabase
              .from('videos')
              .update({ category: 'Personalisierte Themen' })
              .eq('id', video.id);
          }
        }

        // Try to run storage organization
        try {
          await supabase.functions.invoke('storage-agent', {
            body: { 
              videoId: video.id, 
              userId: video.user_id 
            }
          });
        } catch (storageError) {
          console.warn(`⚠️ Storage failed for recovered video ${video.id}:`, storageError.message);
        }

        recovered++;
        results.push({
          id: video.id,
          title: video.title,
          status: 'recovered'
        });
        
        console.log(`✅ Successfully recovered video: ${video.id}`);
      }
    } catch (error) {
      console.error(`❌ Failed to recover video ${video.id}:`, error.message);
      results.push({
        id: video.id,
        title: video.title,
        status: 'failed',
        error: error.message
      });
    }
  }

  console.log(`✅ Recovery completed: ${recovered} videos recovered`);

  return new Response(JSON.stringify({ 
    message: `Recovery completed: ${recovered} videos recovered`,
    recovered,
    total: failedVideosWithTranscripts.length,
    results
  }), {
    headers: { ...corsHeaders, 'Content-Type': 'application/json' },
  });
}

async function reprocessSingleVideo(supabase: any, videoId: string) {
  console.log(`🔄 Reprocessing single video: ${videoId}`);
  
  if (!videoId) {
    throw new Error('Missing videoId parameter');
  }

  // Get video details
  const { data: video, error: videoError } = await supabase
    .from('videos')
    .select('*')
    .eq('id', videoId)
    .single();

  if (videoError || !video) {
    throw new Error(`Video not found: ${videoError?.message || 'No video data'}`);
  }

  // Reset video status to processing
  await supabase
    .from('videos')
    .update({ 
      status: 'processing',
      updated_at: new Date().toISOString()
    })
    .eq('id', videoId);

  // Trigger coordinator agent to reprocess
  const coordinatorResponse = await supabase.functions.invoke('coordinator-agent', {
    body: {
      videoId: video.id,
      action: 'process_video',
      userId: video.user_id
    }
  });

  if (coordinatorResponse.error) {
    throw new Error(`Reprocessing failed: ${coordinatorResponse.error.message}`);
  }

  return new Response(JSON.stringify({ 
    message: `Video ${videoId} queued for reprocessing`,
    videoId,
    title: video.title
  }), {
    headers: { ...corsHeaders, 'Content-Type': 'application/json' },
  });
}