import "https://deno.land/x/xhr@0.1.0/mod.ts";
import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.52.0';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

// Fixed 8 categories with predefined questions
const CATEGORIES = {
  'Kind & Familie': [
    'Erzählen Sie von Ihrer Kindheit und Familie',
    'Welche Erinnerungen haben Sie an Ihre Eltern?',
    'Wie war das Familienleben früher?'
  ],
  'Jugend & Schule': [
    'Wie war Ihre Schulzeit?',
    'Was haben Sie in Ihrer Jugend gerne gemacht?',
    'Welche Freunde waren wichtig für Sie?'
  ],
  'Liebe & Beziehungen': [
    'Wie haben Sie Ihren Partner kennengelernt?',
    'Was bedeutet Liebe für Sie?',
    'Welche Beziehungen haben Sie geprägt?'
  ],
  'Arbeit & Alltag': [
    'Erzählen Sie von Ihrem Berufsleben',
    'Wie sah Ihr Alltag früher aus?',
    'Was war Ihre wichtigste Arbeitserfahrung?'
  ],
  'Zuhause & Traditionen': [
    'Wie war Ihr Zuhause gestaltet?',
    'Welche Traditionen waren wichtig?',
    'Was bedeutet Heimat für Sie?'
  ],
  'Zeitgeschichte & Wandel': [
    'Welche historischen Ereignisse haben Sie miterlebt?',
    'Wie hat sich die Welt verändert?',
    'Was war anders als heute?'
  ],
  'Personalisierte Themen': [
    'Was ist Ihnen besonders wichtig?',
    'Welche besonderen Erlebnisse hatten Sie?',
    'Was möchten Sie erzählen?'
  ],
  'Erforderlich': [
    'Gibt es etwas Wichtiges, das Sie mitteilen möchten?',
    'Was sollten andere wissen?',
    'Was ist Ihre wichtigste Botschaft?'
  ]
};

serve(async (req) => {
  console.log('🏷️ Tagging & Segmentation Agent called');
  
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    // Get environment variables
    const supabaseUrl = Deno.env.get('SUPABASE_URL');
    const supabaseKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY');
    const openAIApiKey = Deno.env.get('OPENAI_API_KEY');

    if (!openAIApiKey) {
      console.error('❌ OPENAI_API_KEY is not configured');
      return new Response(JSON.stringify({ 
        error: 'OpenAI API key not configured',
        details: 'Please configure OPENAI_API_KEY in environment variables'
      }), {
        status: 500,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    const supabase = createClient(supabaseUrl, supabaseKey);
    const requestBody = await req.json();
    const { videoId, userId } = requestBody;
    
    // Input validation
    if (!videoId) {
      return new Response(JSON.stringify({ 
        error: 'Missing required parameter: videoId' 
      }), {
        status: 400,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    console.log(`📝 Processing tags and segments for video: ${videoId}`);

    // Get video and transcript data
    const { data: video, error: videoError } = await supabase
      .from('videos')
      .select('*')
      .eq('id', videoId)
      .single();

    if (videoError || !video) {
      console.error('Video not found:', videoError?.message || 'No video data');
      return new Response(JSON.stringify({ 
        error: 'Video not found',
        videoId: videoId,
        details: videoError?.message || 'Video does not exist'
      }), {
        status: 404,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    const { data: transcripts, error: transcriptError } = await supabase
      .from('transcripts')
      .select('*')
      .eq('video_id', videoId);

    if (transcriptError || !transcripts || transcripts.length === 0) {
      throw new Error(`No transcript found: ${transcriptError?.message}`);
    }

    const transcript = transcripts[0];
    
    // Generate tags and segments using GPT-4.1
    const analysisResult = await analyzeContentWithGPT(video, transcript);
    
    // Store tags
    await storeTags(supabase, videoId, analysisResult.tags);
    
    // Store segments
    await storeSegments(supabase, videoId, analysisResult.segments);
    
    // Create transcript chunks with embeddings
    await createTranscriptChunks(supabase, videoId, transcript.id, analysisResult.segments);
    
    // Update video category
    const primaryCategory = analysisResult.primaryCategory;
    await supabase
      .from('videos')
      .update({ category: primaryCategory })
      .eq('id', videoId);

    console.log(`✅ Tagging and segmentation completed for video: ${videoId}`);
    
    return new Response(
      JSON.stringify({ 
        success: true,
        primaryCategory,
        tagsCount: analysisResult.tags.length,
        segmentsCount: analysisResult.segments.length
      }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );

  } catch (error) {
    console.error('❌ Tagging & Segmentation Agent error:', error);
    
    return new Response(
      JSON.stringify({ 
        success: false, 
        error: error.message 
      }),
      { 
        status: 500,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
      }
    );
  }
});

async function analyzeContentWithGPT(video: any, transcript: any, retryCount = 0) {
  console.log('🤖 Analyzing content with GPT-4.1...');

  const prompt = `You are an expert in analyzing German personal narratives and life stories.

CRITICAL: Respond ONLY with valid JSON. Do NOT wrap your response in markdown code blocks. Do NOT use \`\`\`json or \`\`\`. Your response must start with { and end with }.

Analyze this German video transcript:

Video Title: ${video.title}
Video Description: ${video.description || 'Not provided'}
Transcript: ${transcript.content}

Return a JSON object with exactly these keys:
{
  "tags": ["tag1", "tag2", ...], // 5-15 relevant German keywords
  "primaryCategory": "category", // Must be one of: ${Object.keys(CATEGORIES).join(', ')}
  "segments": [
    {
      "title": "segment title",
      "content": "content summary", 
      "start_time": 0,
      "end_time": 30,
      "persons_mentioned": ["person1", "person2"]
    }
  ]
}

Requirements:
- Segments should be 30-120 seconds each
- Focus on meaningful narrative chunks
- Use German cultural context
- Return pure JSON only - no markdown, no explanations`;

  // Exponential backoff retry logic
  const maxRetries = 3;
  const baseDelay = 1000;
  const timeout = 25000; // Reduced from 30s
  
  for (let attempt = 0; attempt <= maxRetries; attempt++) {
    try {
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), timeout);

      const response = await fetch('https://api.openai.com/v1/chat/completions', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${openAIApiKey}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          model: 'gpt-4.1-2025-04-14', // Use reliable GPT-4.1
          messages: [
            {
              role: 'system',
              content: 'You are a JSON response generator. Always return valid JSON without any markdown formatting or code blocks. Your response must be parseable JSON starting with { and ending with }.'
            },
            {
              role: 'user',
              content: prompt
            }
          ],
          temperature: 0.2, // Lower temperature for more consistent output
          max_tokens: 2000
        }),
        signal: controller.signal
      });

      clearTimeout(timeoutId);

      if (!response.ok) {
        throw new Error(`OpenAI API error: ${response.status} ${await response.text()}`);
      }

      const data = await response.json();
      let content = data.choices[0].message.content.trim();
      
      // Robust JSON extraction - handle markdown wrapped responses
      content = extractJsonFromResponse(content);
      
      const analysisResult = JSON.parse(content);
      
      // Validate structure
      if (!analysisResult.tags || !Array.isArray(analysisResult.tags)) {
        throw new Error('Invalid response: missing or invalid tags array');
      }
      
      if (!analysisResult.segments || !Array.isArray(analysisResult.segments)) {
        throw new Error('Invalid response: missing or invalid segments array');
      }
      
      // Validate and ensure primary category is one of the 8 fixed categories
      if (!Object.keys(CATEGORIES).includes(analysisResult.primaryCategory)) {
        console.warn(`Invalid category "${analysisResult.primaryCategory}", defaulting to "Personalisierte Themen"`);
        analysisResult.primaryCategory = 'Personalisierte Themen';
      }
      
      console.log(`✅ Successfully parsed GPT response with ${analysisResult.tags.length} tags and ${analysisResult.segments.length} segments`);
      return analysisResult;
      
    } catch (error) {
      console.error(`Attempt ${attempt + 1}/${maxRetries + 1} failed:`, error.message);
      
      if (attempt === maxRetries) {
        console.error('Final GPT response that failed:', data?.choices?.[0]?.message?.content);
        throw new Error(`GPT analysis failed after ${maxRetries + 1} attempts: ${error.message}`);
      }
      
      // Wait before retry with exponential backoff
      const delay = baseDelay * Math.pow(2, attempt);
      console.log(`Retrying in ${delay}ms...`);
      await new Promise(resolve => setTimeout(resolve, delay));
    }
  }
}

function extractJsonFromResponse(content: string): string {
  // Remove any markdown code block formatting
  content = content.replace(/```json\s*/gi, '').replace(/```\s*$/gi, '');
  
  // Find JSON object boundaries
  const firstBrace = content.indexOf('{');
  const lastBrace = content.lastIndexOf('}');
  
  if (firstBrace === -1 || lastBrace === -1 || firstBrace >= lastBrace) {
    throw new Error('No valid JSON object found in response');
  }
  
  return content.substring(firstBrace, lastBrace + 1);
}

async function storeTags(supabase: any, videoId: string, tags: string[]) {
  console.log(`💾 Storing ${tags.length} tags in parallel...`);

  // Process tags in parallel for better performance
  const tagPromises = tags.map(async (tagName) => {
    try {
      // Categorize tag
      const category = categorizeTag(tagName);
      
      // Find or create tag
      let { data: existingTag } = await supabase
        .from('tags')
        .select('id')
        .eq('name', tagName)
        .eq('category', category)
        .maybeSingle(); // Use maybeSingle to avoid errors when no tag exists

      let tagId;
      if (existingTag) {
        tagId = existingTag.id;
      } else {
        const { data: newTag, error } = await supabase
          .from('tags')
          .insert({ name: tagName, category })
          .select('id')
          .single();
        
        if (error) {
          console.error(`Failed to create tag "${tagName}":`, error);
          return null;
        }
        tagId = newTag.id;
      }

      // Link tag to video with relevance score
      const relevanceScore = calculateRelevanceScore(tagName, category);
      
      const { error: linkError } = await supabase
        .from('video_tags')
        .insert({
          video_id: videoId,
          tag_id: tagId,
          relevance_score: relevanceScore
        });

      if (linkError) {
        console.error(`Failed to link tag "${tagName}" to video:`, linkError);
        return null;
      }

      return { tagName, category, relevanceScore };
    } catch (error) {
      console.error(`Error processing tag "${tagName}":`, error);
      return null;
    }
  });

  // Wait for all tag operations to complete
  const results = await Promise.allSettled(tagPromises);
  const successful = results.filter(r => r.status === 'fulfilled' && r.value !== null).length;
  console.log(`✅ Successfully stored ${successful}/${tags.length} tags`);
}

function categorizeTag(tagName: string): string {
  const lowerTag = tagName.toLowerCase();
  
  // Category mapping based on keywords
  const categoryKeywords = {
    'Kind & Familie': ['familie', 'kind', 'eltern', 'mutter', 'vater', 'geschwister', 'baby', 'geburt'],
    'Jugend & Schule': ['schule', 'jugend', 'student', 'freunde', 'klassenkamerad', 'lehrer', 'ausbildung'],
    'Liebe & Beziehungen': ['liebe', 'partner', 'hochzeit', 'heirat', 'beziehung', 'romance', 'verlobung'],
    'Arbeit & Alltag': ['arbeit', 'beruf', 'job', 'karriere', 'alltag', 'routine', 'kollege'],
    'Zuhause & Traditionen': ['zuhause', 'tradition', 'heimat', 'kultur', 'fest', 'feier', 'brauch'],
    'Zeitgeschichte & Wandel': ['geschichte', 'krieg', 'politik', 'wandel', 'veränderung', 'historisch'],
  };

  for (const [category, keywords] of Object.entries(categoryKeywords)) {
    if (keywords.some(keyword => lowerTag.includes(keyword))) {
      return category;
    }
  }

  return 'Personalisierte Themen';
}

function calculateRelevanceScore(tagName: string, category: string): number {
  // Base score
  let score = 0.5;
  
  // Boost for category-specific keywords
  const categoryKeywords = {
    'Kind & Familie': ['familie', 'kind', 'eltern'],
    'Jugend & Schule': ['schule', 'jugend', 'freunde'],
    'Liebe & Beziehungen': ['liebe', 'partner', 'hochzeit'],
    'Arbeit & Alltag': ['arbeit', 'beruf', 'alltag'],
    'Zuhause & Traditionen': ['zuhause', 'tradition', 'heimat'],
    'Zeitgeschichte & Wandel': ['geschichte', 'krieg', 'politik'],
  };

  const keywords = categoryKeywords[category as keyof typeof categoryKeywords] || [];
  const matchCount = keywords.filter(keyword => 
    tagName.toLowerCase().includes(keyword)
  ).length;

  score += (matchCount * 0.2);
  
  return Math.min(1.0, score);
}

async function storeSegments(supabase: any, videoId: string, segments: any[]) {
  console.log(`📹 Storing ${segments.length} segments...`);

  for (const segment of segments) {
    const { error } = await supabase
      .from('segments')
      .insert({
        video_id: videoId,
        title: segment.title,
        content: segment.content,
        start_time: segment.start_time,
        end_time: segment.end_time,
        persons_mentioned: segment.persons_mentioned || []
      });

    if (error) {
      console.error('Failed to create segment:', error);
    }
  }
}

async function createTranscriptChunks(
  supabase: any, 
  videoId: string, 
  transcriptId: string, 
  segments: any[]
) {
  console.log('🧩 Creating transcript chunks with parallel embedding generation...');

  // Process embeddings in parallel batches for better performance
  const batchSize = 3; // Process 3 embeddings simultaneously to avoid rate limits
  const batches = [];
  
  for (let i = 0; i < segments.length; i += batchSize) {
    batches.push(segments.slice(i, i + batchSize));
  }

  let totalProcessed = 0;
  for (const batch of batches) {
    const chunkPromises = batch.map(async (segment) => {
      try {
        // Generate REAL embedding for segment content using OpenAI
        const embedding = await generateRealEmbedding(segment.content);
        
        const { error } = await supabase
          .from('transcript_chunks')
          .insert({
            video_id: videoId,
            transcript_id: transcriptId,
            start_time: segment.start_time,
            end_time: segment.end_time,
            content: segment.content,
            embedding_json: embedding // Store as JSONB array
          });

        if (error) {
          console.error('Failed to create transcript chunk:', error);
          return false;
        } else {
          console.log(`✅ Created chunk with embedding: ${segment.title}`);
          return true;
        }
      } catch (error) {
        console.error(`Error processing segment "${segment.title}":`, error);
        return false;
      }
    });

    // Wait for current batch to complete
    const results = await Promise.allSettled(chunkPromises);
    const successful = results.filter(r => r.status === 'fulfilled' && r.value === true).length;
    totalProcessed += successful;
    
    console.log(`📊 Batch processed: ${successful}/${batch.length} chunks successful`);
  }
  
  console.log(`✅ Total transcript chunks created: ${totalProcessed}/${segments.length}`);
}

async function generateRealEmbedding(text: string, retryCount = 0): Promise<number[]> {
  const maxRetries = 2;
  const timeout = 15000; // Reduced timeout to 15s
  
  try {
    console.log(`🔍 Generating embedding for text: ${text.substring(0, 50)}...`);
    
    const embeddingController = new AbortController();
    const embeddingTimeoutId = setTimeout(() => embeddingController.abort(), timeout);

    const response = await fetch('https://api.openai.com/v1/embeddings', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${openAIApiKey}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        model: 'text-embedding-3-small',
        input: text.trim().substring(0, 8000), // Limit input length to avoid oversized requests
        encoding_format: 'float'
      }),
      signal: embeddingController.signal
    });

    clearTimeout(embeddingTimeoutId);

    if (!response.ok) {
      const errorText = await response.text();
      console.error('OpenAI Embedding API error:', response.status, errorText);
      
      // Retry on rate limit or server errors
      if ((response.status === 429 || response.status >= 500) && retryCount < maxRetries) {
        const delay = Math.pow(2, retryCount) * 1000; // Exponential backoff
        console.log(`Retrying embedding generation in ${delay}ms... (attempt ${retryCount + 1}/${maxRetries})`);
        await new Promise(resolve => setTimeout(resolve, delay));
        return generateRealEmbedding(text, retryCount + 1);
      }
      
      throw new Error(`Embedding API failed: ${response.status} ${errorText}`);
    }

    const data = await response.json();
    const embedding = data.data[0].embedding;
    
    console.log(`✅ Generated embedding with ${embedding.length} dimensions`);
    return embedding;
    
  } catch (error) {
    console.error(`Failed to generate embedding (attempt ${retryCount + 1}):`, error);
    
    // Retry on network errors
    if (retryCount < maxRetries && (error.name === 'AbortError' || error.message.includes('network'))) {
      const delay = Math.pow(2, retryCount) * 1000;
      console.log(`Retrying embedding generation in ${delay}ms... (attempt ${retryCount + 1}/${maxRetries})`);
      await new Promise(resolve => setTimeout(resolve, delay));
      return generateRealEmbedding(text, retryCount + 1);
    }
    
    // Log performance for monitoring
    console.log('Performance Log:', {
      agent: 'tagging-segmentation-agent',
      operation: 'embedding_generation',
      success: false,
      error: error.message,
      text_length: text.length,
      retry_count: retryCount
    });
    
    // Return zero vector as fallback
    console.warn('Returning zero vector as fallback after all retries failed');
    return new Array(1536).fill(0);
  }
}