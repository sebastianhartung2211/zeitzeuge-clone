import "https://deno.land/x/xhr@0.1.0/mod.ts";
import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

// OPTIMIZED PRODUCTION CONFIGURATION
const CONFIG = {
  EMBEDDING_MODEL: 'text-embedding-3-small',
  SIMILARITY_THRESHOLD: 0.65,
  TOP_K_CANDIDATES: 25,
  RERANK_TOP_K: 12,
  MIN_CONFIDENCE: 0.65,
  CHUNK_SIZE: 512,
  CHUNK_OVERLAP: 0.15,
  LANGUAGE: 'de',
  
  // Enhanced hybrid search weights
  SEMANTIC_WEIGHT: 0.6,     // Vector similarity
  BM25_WEIGHT: 0.25,        // Keyword matching
  CATEGORY_WEIGHT: 0.15,    // Category/tag alignment
  
  // Quality thresholds
  MIN_TRANSCRIPT_LENGTH: 50,
  MIN_CHUNK_OVERLAP: 77,    // tokens (15% of 512)
  MAX_CHUNKS_PER_VIDEO: 10,
  
  // Advanced features
  QUERY_EXPANSION: true,
  INTENT_CLASSIFICATION: true,
  RESPONSE_VALIDATION: true,
  FEEDBACK_COLLECTION: true
};

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { question, userId, action = 'answer_question', feedback } = await req.json();
    
    console.log('🚀 Optimized Conversation Agent V4:', { question, userId, action });

    const supabase = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? '',
    );

    switch (action) {
      case 'answer_question':
        return await handleOptimizedQuestionAnswering(supabase, question, userId);
      case 'process_feedback':
        return await handleFeedbackProcessing(supabase, feedback, userId);
      case 'generate_embeddings':
        return await handleEmbeddingGeneration(supabase, userId);
      case 'evaluate':
        return await handleEvaluation(supabase, userId);
      default:
        return await handleOptimizedQuestionAnswering(supabase, question, userId);
    }

  } catch (error) {
    console.error('❌ Optimized Conversation Agent error:', error);
    return new Response(JSON.stringify({ 
      error: error.message,
      pipeline: 'optimized-v4',
      timestamp: new Date().toISOString()
    }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
});

async function handleOptimizedQuestionAnswering(supabase: any, question: string, userId: string) {
  const startTime = Date.now();
  console.log('🔎 Optimized question answering for:', question);

  // Step 1: Enhanced query preprocessing
  const processedQuery = await preprocessQuery(question);
  console.log('📝 Query preprocessing:', processedQuery);

  // Step 2: Load videos with enhanced data
  const videos = await loadVideosWithEnhancedData(supabase, userId);
  
  if (videos.length === 0) {
    const fallbackMessage = `Entschuldigung, ich konnte keine geeigneten Videos für Ihre Frage "${question}" finden. Bitte stellen Sie sicher, dass Sie Videos mit klaren Aufnahmen haben.`;
    
    await storeConversationWithMetadata(supabase, userId, question, fallbackMessage, null, 0.0, 'no_valid_videos', {
      preprocessing: processedQuery,
      totalVideos: 0
    });

    return createResponse(fallbackMessage, null, 0.0, { reason: 'No valid videos found' });
  }

  // Step 3: Generate real embeddings for question
  const questionEmbedding = await generateOptimizedEmbedding(processedQuery.enhancedQuery);
  
  // Step 4: Enhanced hybrid matching pipeline
  const matchingResult = await performEnhancedHybridMatching(processedQuery, videos, questionEmbedding);
  
  if (!matchingResult || matchingResult.confidence < CONFIG.MIN_CONFIDENCE) {
    const noMatchMessage = `Zu Ihrer Frage "${question}" konnte ich leider kein ausreichend passendes Video finden. Versuchen Sie es mit einer präziseren Frage oder einem anderen Thema.`;
    
    console.log(`❌ No sufficient match: confidence ${matchingResult?.confidence || 0} < ${CONFIG.MIN_CONFIDENCE}`);
    
    await storeConversationWithMetadata(supabase, userId, question, noMatchMessage, null, matchingResult?.confidence || 0.0, 'confidence_too_low', {
      preprocessing: processedQuery,
      matchingStages: matchingResult?.debug || {}
    });

    return createResponse(noMatchMessage, null, matchingResult?.confidence || 0.0, {
      reason: 'Confidence below threshold',
      confidence: matchingResult?.confidence,
      threshold: CONFIG.MIN_CONFIDENCE
    });
  }

  // Step 5: Generate contextual response with validation
  const response = await generateContextualResponse(processedQuery.originalQuery, matchingResult);
  const validatedResponse = await validateResponse(response, matchingResult);

  // Step 6: Store conversation with enhanced metadata
  await storeConversationWithMetadata(supabase, userId, question, validatedResponse.answer, matchingResult.video.id, matchingResult.confidence, 'success', {
    preprocessing: processedQuery,
    matching: matchingResult.debug,
    validation: validatedResponse.validation,
    responseTime: Date.now() - startTime
  });
  
  // Step 7: Trigger enhanced workflow processing
  await triggerEnhancedWorkflow(supabase, userId, question, matchingResult, validatedResponse);

  const responseTime = Date.now() - startTime;
  console.log(`✅ Optimized pipeline completed in ${responseTime}ms, confidence: ${matchingResult.confidence}`);

  return createResponse(validatedResponse.answer, matchingResult.video, matchingResult.confidence, {
    reasoning: matchingResult.reasoning,
    validation: validatedResponse.validation,
    responseTime,
    pipeline: 'optimized-v4'
  });
}

async function preprocessQuery(question: string) {
  console.log('📝 Preprocessing query with expansion and intent classification...');
  
  const originalQuery = question.trim();
  let enhancedQuery = originalQuery;
  let intent = 'general';
  let expandedTerms = [];
  
  if (CONFIG.QUERY_EXPANSION) {
    // Add synonyms and related terms for common topics
    const expansionMap = {
      'kindheit': ['jugend', 'jung', 'klein', 'familie', 'eltern'],
      'schule': ['lernen', 'bildung', 'klassenzimmer', 'lehrer'],
      'arbeit': ['beruf', 'job', 'arbeitsplatz', 'karriere'],
      'liebe': ['partnerschaft', 'beziehung', 'heirat', 'hochzeit'],
      'krieg': ['weltkrieg', 'konflikt', 'geschichte', 'zeitgeschichte'],
      'essen': ['kochen', 'rezept', 'küche', 'mahlzeit'],
      'reisen': ['urlaub', 'ausflug', 'besuch', 'fahrt']
    };
    
    for (const [key, synonyms] of Object.entries(expansionMap)) {
      if (originalQuery.toLowerCase().includes(key)) {
        expandedTerms = [...expandedTerms, ...synonyms];
        enhancedQuery += ' ' + synonyms.join(' ');
      }
    }
  }
  
  if (CONFIG.INTENT_CLASSIFICATION) {
    // Classify question intent
    const intentPatterns = {
      'biographical': /\b(wer|wie|geboren|aufgewachsen|familie|eltern)\b/i,
      'temporal': /\b(wann|damals|früher|heute|zeit|jahr)\b/i,
      'emotional': /\b(gefühl|traurig|glücklich|angst|freude)\b/i,
      'factual': /\b(was|wo|warum|weshalb|grund)\b/i,
      'comparative': /\b(unterschied|vergleich|früher.*heute|damals.*jetzt)\b/i
    };
    
    for (const [intentType, pattern] of Object.entries(intentPatterns)) {
      if (pattern.test(originalQuery)) {
        intent = intentType;
        break;
      }
    }
  }
  
  return {
    originalQuery,
    enhancedQuery,
    intent,
    expandedTerms,
    keywords: extractAdvancedKeywords(originalQuery)
  };
}

function extractAdvancedKeywords(text: string): string[] {
  // Enhanced keyword extraction with German stemming approximation
  const germanStopwords = new Set([
    'der', 'die', 'das', 'und', 'oder', 'aber', 'ist', 'war', 'hat', 'hatte',
    'ein', 'eine', 'ich', 'du', 'er', 'sie', 'es', 'wir', 'ihr', 'können',
    'sollte', 'würde', 'haben', 'sein', 'werden', 'über', 'unter', 'nach',
    'vor', 'bei', 'mit', 'ohne', 'durch', 'für', 'gegen', 'auf', 'an', 'in'
  ]);
  
  return text
    .toLowerCase()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .split(/\s+/)
    .filter(word => word.length > 2 && !germanStopwords.has(word))
    .map(word => {
      // Simple German stemming approximation
      if (word.endsWith('en') && word.length > 4) return word.slice(0, -2);
      if (word.endsWith('er') && word.length > 4) return word.slice(0, -2);
      if (word.endsWith('te') && word.length > 4) return word.slice(0, -2);
      return word;
    })
    .filter((word, index, arr) => arr.indexOf(word) === index); // Remove duplicates
}

async function loadVideosWithEnhancedData(supabase: any, userId: string) {
  console.log('📊 Loading videos with enhanced data structure...');
  
  // Load videos with all related data
  const { data: videos, error: videosError } = await supabase
    .from('videos')
    .select(`
      id,
      title,
      description,
      video_url,
      category,
      created_at,
      custom_date,
      transcripts!inner (
        id,
        content,
        confidence,
        language
      ),
      video_tags (
        relevance_score,
        tags (
          name,
          category
        )
      ),
      segments (
        title,
        content,
        persons_mentioned,
        start_time,
        end_time
      )
    `)
    .eq('user_id', userId)
    .eq('status', 'completed')
    .gte('transcripts.content', '');

  if (videosError) {
    console.error('❌ Error fetching videos:', videosError);
    throw new Error(`Error fetching videos: ${videosError.message}`);
  }

  // Load transcript chunks separately for better performance
  const videoIds = videos?.map(v => v.id) || [];
  let transcript_chunks = [];
  
  if (videoIds.length > 0) {
    const { data: chunks, error: chunksError } = await supabase
      .from('transcript_chunks')
      .select('*')
      .in('video_id', videoIds)
      .not('embedding_json', 'is', null);
      
    if (chunksError) {
      console.warn('⚠️ Error fetching transcript chunks:', chunksError);
    } else {
      transcript_chunks = chunks || [];
    }
  }

  // Merge and enhance video data
  const enhancedVideos = (videos || [])
    .map(video => ({
      ...video,
      transcript_chunks: transcript_chunks.filter(chunk => chunk.video_id === video.id),
      // Pre-compute metadata for faster matching
      hasEmbeddings: transcript_chunks.some(chunk => chunk.video_id === video.id && chunk.embedding_json),
      totalChunks: transcript_chunks.filter(chunk => chunk.video_id === video.id).length,
      avgRelevanceScore: video.video_tags?.length > 0 
        ? video.video_tags.reduce((sum: number, vt: any) => sum + (vt.relevance_score || 0), 0) / video.video_tags.length 
        : 0
    }))
    .filter(video => {
      const transcript = video.transcripts[0];
      return transcript && 
             transcript.content && 
             transcript.content.trim().length >= CONFIG.MIN_TRANSCRIPT_LENGTH &&
             !transcript.content.includes('[MOCK DATA]') &&
             !transcript.content.toLowerCase().includes('test transcript');
    });

  console.log(`📊 Loaded ${enhancedVideos.length} enhanced videos`);
  console.log(`📊 Videos with embeddings: ${enhancedVideos.filter(v => v.hasEmbeddings).length}`);
  
  return enhancedVideos;
}

async function generateOptimizedEmbedding(text: string): Promise<number[]> {
  console.log('🔍 Generating optimized embedding...');
  
  try {
    const response = await fetch('https://api.openai.com/v1/embeddings', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${Deno.env.get('OPENAI_API_KEY')}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        model: CONFIG.EMBEDDING_MODEL,
        input: text.substring(0, 8192), // Ensure we don't exceed token limits
        dimensions: 1536 // Consistent dimension size
      }),
    });

    if (!response.ok) {
      console.error('❌ OpenAI API error:', response.status, response.statusText);
      throw new Error(`Embedding API error: ${response.status}`);
    }

    const result = await response.json();
    const embedding = result.data[0]?.embedding;
    
    if (!embedding) {
      throw new Error('No embedding returned from API');
    }
    
    console.log(`✅ Generated embedding with ${embedding.length} dimensions`);
    return embedding;
    
  } catch (error) {
    console.error('❌ Error generating embedding:', error);
    // Return zero vector as fallback
    return new Array(1536).fill(0);
  }
}

async function performEnhancedHybridMatching(processedQuery: any, videos: any[], questionEmbedding: number[]) {
  console.log(`🔍 Starting enhanced hybrid matching with ${videos.length} videos`);
  
  // Stage 1: Multi-factor keyword and category matching
  const stage1Results = await performAdvancedKeywordMatching(videos, processedQuery);
  console.log(`📊 Stage 1 (Advanced Keywords): ${videos.length} → ${stage1Results.length} candidates`);
  
  if (stage1Results.length === 0) {
    return null;
  }
  
  // Stage 2: Semantic vector similarity with chunk analysis
  const stage2Results = await performSemanticVectorMatching(stage1Results, questionEmbedding, processedQuery);
  console.log(`🎯 Stage 2 (Semantic Vector): ${stage1Results.length} → ${stage2Results.length} candidates`);
  
  if (stage2Results.length === 0) {
    return {
      video: stage1Results[0],
      confidence: 0.45,
      reasoning: 'Nur Keyword-Match, keine semantische Ähnlichkeit gefunden',
      debug: { stage1Count: stage1Results.length, stage2Count: 0 }
    };
  }
  
  // Stage 3: Advanced LLM cross-encoder with context
  const finalResult = await performAdvancedCrossEncoderReranking(stage2Results, processedQuery);
  console.log(`🏆 Final enhanced result: confidence ${finalResult.confidence}`);
  
  finalResult.debug = {
    stage1Count: stage1Results.length,
    stage2Count: stage2Results.length,
    finalCount: 1,
    hasEmbeddings: stage2Results.filter(v => v.hasEmbeddings).length
  };
  
  return finalResult;
}

async function performAdvancedKeywordMatching(videos: any[], processedQuery: any) {
  console.log('🔍 Stage 1: Advanced keyword and category matching...');
  
  const scoredVideos = videos.map(video => {
    let score = 0;
    
    // Enhanced BM25 scoring with intent weighting
    const bm25Score = calculateEnhancedBM25(processedQuery, video);
    score += bm25Score * CONFIG.BM25_WEIGHT;
    
    // Category and intent alignment
    const categoryScore = calculateCategoryAlignment(processedQuery, video);
    score += categoryScore * CONFIG.CATEGORY_WEIGHT;
    
    // Tag relevance with weighted scores
    const tagScore = calculateWeightedTagScore(processedQuery, video);
    score += tagScore * 0.1;
    
    // Title and description matching
    const metadataScore = calculateMetadataScore(processedQuery, video);
    score += metadataScore * 0.15;
    
    // Temporal relevance (if date-related query)
    const temporalScore = calculateTemporalRelevance(processedQuery, video);
    score += temporalScore * 0.05;
    
    return { ...video, enhancedScore: score };
  });
  
  // Dynamic threshold based on score distribution
  const scores = scoredVideos.map(v => v.enhancedScore);
  const avgScore = scores.reduce((sum, score) => sum + score, 0) / scores.length;
  const threshold = Math.max(0.2, avgScore * 0.7);
  
  const filtered = scoredVideos
    .filter(video => video.enhancedScore >= threshold)
    .sort((a, b) => b.enhancedScore - a.enhancedScore)
    .slice(0, CONFIG.TOP_K_CANDIDATES);
    
  console.log(`📊 Enhanced scores: ${filtered.map(v => v.enhancedScore.toFixed(3)).slice(0, 5).join(', ')}`);
  return filtered;
}

function calculateEnhancedBM25(processedQuery: any, video: any): number {
  const transcript = video.transcripts[0]?.content || '';
  const keywords = processedQuery.keywords.concat(processedQuery.expandedTerms);
  
  // BM25 parameters optimized for German text
  const k1 = 1.2;
  const b = 0.75;
  const avgDocLength = 1000; // Estimated average transcript length
  
  let score = 0;
  const docLength = transcript.length;
  
  for (const keyword of keywords) {
    const tf = (transcript.toLowerCase().match(new RegExp(keyword.toLowerCase(), 'g')) || []).length;
    if (tf > 0) {
      const idf = Math.log(1 + 1 / Math.max(1, tf)); // Simplified IDF
      const numerator = tf * (k1 + 1);
      const denominator = tf + k1 * (1 - b + b * (docLength / avgDocLength));
      score += idf * (numerator / denominator);
    }
  }
  
  // Intent-based weighting
  if (processedQuery.intent === 'biographical' && video.category === 'Kind & Familie') score *= 1.3;
  if (processedQuery.intent === 'temporal' && video.category === 'Zeitgeschichte & Wandel') score *= 1.3;
  if (processedQuery.intent === 'emotional' && video.category === 'Liebe & Beziehungen') score *= 1.2;
  
  return Math.min(score, 5.0); // Cap score
}

function calculateCategoryAlignment(processedQuery: any, video: any): number {
  const categoryMap = {
    'kindheit': ['Kind & Familie'],
    'schule': ['Jugend & Schule'],
    'arbeit': ['Arbeit & Alltag'],
    'liebe': ['Liebe & Beziehungen'],
    'tradition': ['Zuhause & Traditionen'],
    'geschichte': ['Zeitgeschichte & Wandel']
  };
  
  let score = 0;
  const queryText = processedQuery.originalQuery.toLowerCase();
  
  for (const [keyword, categories] of Object.entries(categoryMap)) {
    if (queryText.includes(keyword) && categories.includes(video.category)) {
      score += 1.5;
    }
  }
  
  return Math.min(score, 2.0);
}

function calculateWeightedTagScore(processedQuery: any, video: any): number {
  if (!video.video_tags || video.video_tags.length === 0) return 0;
  
  let score = 0;
  const keywords = processedQuery.keywords;
  
  for (const videoTag of video.video_tags) {
    const tagName = videoTag.tags?.name || '';
    const relevanceScore = videoTag.relevance_score || 1.0;
    
    for (const keyword of keywords) {
      if (tagName.toLowerCase().includes(keyword.toLowerCase())) {
        score += relevanceScore;
      }
    }
  }
  
  return Math.min(score / video.video_tags.length, 2.0);
}

function calculateMetadataScore(processedQuery: any, video: any): number {
  let score = 0;
  const keywords = processedQuery.keywords;
  const title = (video.title || '').toLowerCase();
  const description = (video.description || '').toLowerCase();
  
  for (const keyword of keywords) {
    if (title.includes(keyword.toLowerCase())) score += 1.0;
    if (description.includes(keyword.toLowerCase())) score += 0.5;
  }
  
  return Math.min(score, 3.0);
}

function calculateTemporalRelevance(processedQuery: any, video: any): number {
  // Simple temporal relevance based on query patterns
  const temporalKeywords = ['früher', 'damals', 'heute', 'jetzt', 'zeit', 'jahr'];
  const queryText = processedQuery.originalQuery.toLowerCase();
  
  let hasTemporalContext = false;
  for (const keyword of temporalKeywords) {
    if (queryText.includes(keyword)) {
      hasTemporalContext = true;
      break;
    }
  }
  
  if (!hasTemporalContext) return 0;
  
  // Prefer videos with custom dates for temporal queries
  return video.custom_date ? 0.5 : 0.2;
}

async function performSemanticVectorMatching(candidates: any[], questionEmbedding: number[], processedQuery: any) {
  console.log('🎯 Stage 2: Semantic vector matching with chunk analysis...');
  
  const vectorScored = await Promise.all(candidates.map(async video => {
    let maxSimilarity = 0;
    let bestChunk = null;
    let totalSimilarity = 0;
    let chunkCount = 0;
    
    if (video.transcript_chunks && video.transcript_chunks.length > 0) {
      console.log(`🔍 Analyzing ${video.transcript_chunks.length} chunks for: ${video.title}`);
      
      for (const chunk of video.transcript_chunks) {
        if (chunk.embedding_json && Array.isArray(chunk.embedding_json)) {
          const similarity = calculateOptimizedCosineSimilarity(questionEmbedding, chunk.embedding_json);
          chunkCount++;
          totalSimilarity += similarity;
          
          if (similarity > maxSimilarity) {
            maxSimilarity = similarity;
            bestChunk = chunk;
          }
        }
      }
      
      // Calculate average similarity for better ranking
      const avgSimilarity = chunkCount > 0 ? totalSimilarity / chunkCount : 0;
      console.log(`✅ Video "${video.title}": max=${maxSimilarity.toFixed(3)}, avg=${avgSimilarity.toFixed(3)}, chunks=${chunkCount}`);
      
      return {
        ...video,
        vectorSimilarity: maxSimilarity,
        avgVectorSimilarity: avgSimilarity,
        bestChunk,
        chunksProcessed: chunkCount,
        // Combined score: max similarity with slight boost from average
        combinedVectorScore: maxSimilarity + (avgSimilarity * 0.1)
      };
    } else {
      // Fallback for videos without embeddings
      console.log(`⚠️ No embeddings for ${video.title}, using content-based fallback`);
      const fallbackScore = calculateContentBasedFallback(video, processedQuery);
      
      return {
        ...video,
        vectorSimilarity: fallbackScore,
        avgVectorSimilarity: fallbackScore,
        bestChunk: null,
        chunksProcessed: 0,
        combinedVectorScore: fallbackScore
      };
    }
  }));
  
  // Enhanced filtering with dynamic threshold
  const similarities = vectorScored.map(v => v.combinedVectorScore);
  const maxSim = Math.max(...similarities);
  const threshold = Math.max(0.3, maxSim * 0.4); // Adaptive threshold
  
  const filtered = vectorScored
    .filter(video => video.combinedVectorScore >= threshold)
    .sort((a, b) => b.combinedVectorScore - a.combinedVectorScore)
    .slice(0, CONFIG.RERANK_TOP_K);
    
  console.log(`🎯 Vector similarities: ${filtered.map(v => `${v.combinedVectorScore.toFixed(3)}(${v.chunksProcessed})`).join(', ')}`);
  return filtered;
}

function calculateOptimizedCosineSimilarity(vecA: number[], vecB: number[]): number {
  if (!vecA || !vecB || vecA.length !== vecB.length || vecA.length === 0) {
    return 0;
  }
  
  let dotProduct = 0;
  let normA = 0;
  let normB = 0;
  
  for (let i = 0; i < vecA.length; i++) {
    const a = Number(vecA[i]) || 0;
    const b = Number(vecB[i]) || 0;
    
    dotProduct += a * b;
    normA += a * a;
    normB += b * b;
  }
  
  if (normA === 0 || normB === 0) {
    return 0;
  }
  
  const similarity = dotProduct / (Math.sqrt(normA) * Math.sqrt(normB));
  
  // Enhanced similarity with normalization
  const normalizedSimilarity = (similarity + 1) / 2; // Map from [-1,1] to [0,1]
  return Math.max(0, Math.min(1, normalizedSimilarity));
}

function calculateContentBasedFallback(video: any, processedQuery: any): number {
  const transcript = video.transcripts[0]?.content || '';
  const keywords = processedQuery.keywords;
  
  let score = 0;
  let keywordMatches = 0;
  
  for (const keyword of keywords) {
    const matches = (transcript.toLowerCase().match(new RegExp(keyword.toLowerCase(), 'g')) || []).length;
    if (matches > 0) {
      keywordMatches += matches;
      score += Math.min(matches / 10, 0.2); // Diminishing returns
    }
  }
  
  // Content quality factors
  const lengthScore = Math.min(transcript.length / 2000, 0.2);
  const uniquenessScore = new Set(transcript.toLowerCase().split(/\s+/)).size / transcript.split(/\s+/).length;
  
  score += lengthScore + (uniquenessScore * 0.1);
  
  // Boost for videos with good metadata
  if (video.avgRelevanceScore > 0.7) score += 0.1;
  if (video.segments && video.segments.length > 2) score += 0.05;
  
  return Math.min(score, 0.6); // Cap fallback scores
}

async function performAdvancedCrossEncoderReranking(candidates: any[], processedQuery: any) {
  console.log('🤖 Stage 3: Advanced cross-encoder reranking...');
  
  if (candidates.length === 0) {
    return { video: null, confidence: 0.0, reasoning: 'Keine Kandidaten für Reranking', candidateCount: 0 };
  }
  
  if (candidates.length === 1) {
    return {
      video: candidates[0],
      confidence: Math.max(0.65, candidates[0].combinedVectorScore || 0.5),
      reasoning: 'Einzelner Kandidat, automatisch ausgewählt',
      candidateCount: 1
    };
  }
  
  try {
    return await performAdvancedLLMReranking(processedQuery, candidates);
  } catch (error) {
    console.error('Advanced reranking error:', error);
    return {
      video: candidates[0],
      confidence: 0.65,
      reasoning: 'Reranking-Fehler, verwende Vektor-Similarity-Ergebnis',
      candidateCount: candidates.length
    };
  }
}

async function performAdvancedLLMReranking(processedQuery: any, candidates: any[]) {
  const candidatesInfo = candidates.slice(0, 8).map((video, index) => {
    const transcript = video.transcripts[0]?.content || '';
    const tags = video.video_tags?.map((vt: any) => vt.tags?.name).filter(Boolean).join(', ') || '';
    const bestChunkContent = video.bestChunk?.content || '';
    
    return `Kandidat ${index}:
Titel: ${video.title}
Kategorie: ${video.category || 'Unbekannt'}
Kombinierter Score: ${(video.combinedVectorScore || 0).toFixed(3)}
Embedding-Chunks: ${video.chunksProcessed}
Intent-Match: ${getIntentMatch(processedQuery.intent, video.category)}
Tags: ${tags}
Beste Passage: ${bestChunkContent.substring(0, 200)}...
Volltext: ${transcript.substring(0, 300)}...`;
  }).join('\n\n');

  const prompt = `Du bist ein Experte für semantische Ähnlichkeitsanalyse in einem deutschsprachigen Familienerinnerungs-System.

NUTZER-FRAGE: "${processedQuery.originalQuery}"
VERARBEITETE ANFRAGE:
- Intent: ${processedQuery.intent}
- Keywords: ${processedQuery.keywords.join(', ')}
- Erweiterte Begriffe: ${processedQuery.expandedTerms.join(', ')}

VORSELEKTIERTE KANDIDATEN:
${candidatesInfo}

BEWERTUNGSKRITERIEN (gewichtet):
1. DIREKTE INHALTLICHE RELEVANZ (40%): Beantwortet das Video die Frage direkt?
2. SEMANTISCHE ÄHNLICHKEIT (30%): Passt das Thema zur Fragestellung?
3. KONTEXTUELLE PASSUNG (20%): Stimmen Intent und Kategorie überein?
4. QUALITÄT UND VOLLSTÄNDIGKEIT (10%): Ist der Inhalt aussagekräftig?

CONFIDENCE-SKALA:
- 0.90-1.00: Perfekte, direkte Antwort mit hoher Relevanz
- 0.75-0.89: Sehr gute thematische Übereinstimmung
- 0.60-0.74: Gute, verwandte Antwort mit Kontext
- 0.45-0.59: Mäßige Relevanz, tangentiale Beziehung
- 0.00-0.44: Unzureichende Übereinstimmung

WICHTIG: Antworte NUR mit reinem JSON, keine Markdown-Formatierung oder Code-Blöcke!

ANTWORT-FORMAT:
{
  "bestCandidateIndex": 0,
  "confidence": 0.82,
  "reasoning": "Detaillierte Begründung basierend auf den Bewertungskriterien",
  "relevantQuote": "Wichtigstes relevantes Zitat aus dem besten Chunk/Transkript",
  "qualityAssessment": "Bewertung der Antwortqualität und Vollständigkeit",
  "intentAlignment": "Bewertung der Intent-Passung"
}`;

  try {
    const response = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${Deno.env.get('OPENAI_API_KEY')}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        model: 'gpt-4o-mini',
        messages: [
          { 
            role: 'system', 
            content: 'Du bist ein Experte für semantische Ähnlichkeitsanalyse und Content-Matching. Antworte ausschließlich im JSON-Format mit präzisen, begründeten Bewertungen.' 
          },
          { role: 'user', content: prompt }
        ],
        temperature: 0.1,
        max_tokens: 500,
      }),
    });

    if (!response.ok) {
      throw new Error(`OpenAI API error: ${response.status}`);
    }

    const result = await response.json();
    const content = result.choices[0]?.message?.content;
    
    if (!content) {
      throw new Error('No content in OpenAI response');
    }

    // Clean the content to ensure it's valid JSON
    const cleanContent = content.trim().replace(/^```json\s*/, '').replace(/\s*```$/, '');
    const parsed = JSON.parse(cleanContent);
    const selectedIndex = Math.max(0, Math.min(parsed.bestCandidateIndex || 0, candidates.length - 1));
    const selectedVideo = candidates[selectedIndex];

    return {
      video: selectedVideo,
      confidence: Math.max(0.4, Math.min(1.0, parsed.confidence || 0.6)),
      reasoning: parsed.reasoning || 'Automatische Auswahl basierend auf Ähnlichkeit',
      relevantQuote: parsed.relevantQuote || '',
      qualityAssessment: parsed.qualityAssessment || '',
      intentAlignment: parsed.intentAlignment || '',
      candidateCount: candidates.length
    };

  } catch (error) {
    console.error('❌ LLM reranking failed:', error);
    return {
      video: candidates[0],
      confidence: 0.65,
      reasoning: 'LLM-Reranking fehlgeschlagen, verwende Vektor-Ähnlichkeit',
      candidateCount: candidates.length
    };
  }
}

function getIntentMatch(intent: string, category: string): string {
  const matches = {
    'biographical': category === 'Kind & Familie' ? 'Hoch' : 'Mittel',
    'temporal': category === 'Zeitgeschichte & Wandel' ? 'Hoch' : 'Niedrig',
    'emotional': category === 'Liebe & Beziehungen' ? 'Hoch' : 'Mittel',
    'factual': 'Mittel',
    'comparative': category === 'Zeitgeschichte & Wandel' ? 'Hoch' : 'Mittel'
  };
  
  return matches[intent as keyof typeof matches] || 'Unbekannt';
}

async function generateContextualResponse(question: string, matchingResult: any) {
  console.log('📝 Generating contextual response with validation...');
  
  const video = matchingResult.video;
  const transcript = video.transcripts[0]?.content || '';
  const bestChunk = matchingResult.video.bestChunk?.content || '';
  const tags = video.video_tags?.map((vt: any) => vt.tags?.name).filter(Boolean).join(', ') || '';
  
  const prompt = `Du bist ein einfühlsamer Familienhistoriker, der persönliche Erinnerungen vermittelt.

NUTZER-FRAGE: "${question}"

GEFUNDENES VIDEO:
Titel: ${video.title}
Kategorie: ${video.category}
Confidence: ${matchingResult.confidence}
Relevante Passage: ${bestChunk.substring(0, 400)}
Vollständiger Kontext: ${transcript.substring(0, 800)}
Tags: ${tags}

AUFGABE:
Formuliere eine warme, persönliche Antwort, die:
1. Die Frage direkt auf Basis des Video-Inhalts beantwortet
2. Relevante Details aus dem Transkript einbaut
3. Eine persönliche, familiäre Atmosphäre schafft
4. Zum Ansehen des Videos ermutigt

STIL:
- Herzlich und persönlich
- 2-4 Sätze
- Direkte Bezugnahme auf Video-Inhalte
- Deutsche Sprache, vertraut ("Du")

BEISPIEL:
"Das ist eine schöne Frage! In deinem Video '[Titel]' erzählst du genau davon - [spezifische Details]. Es ist faszinierend zu hören, wie [relevanter Aspekt]. Schau dir das Video gerne noch einmal an, um diese wertvolle Erinnerung zu erleben!"`;

  try {
    const response = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${Deno.env.get('OPENAI_API_KEY')}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        model: 'gpt-4o-mini',
        messages: [
          { 
            role: 'system', 
            content: 'Du bist ein empathischer Familienhistoriker, der persönliche Erinnerungen warmherzig und zugänglich vermittelt.' 
          },
          { role: 'user', content: prompt }
        ],
        temperature: 0.3,
        max_tokens: 300,
      }),
    });

    if (!response.ok) {
      throw new Error(`Response generation failed: ${response.status}`);
    }

    const result = await response.json();
    return result.choices[0]?.message?.content || 'Entschuldigung, ich konnte keine passende Antwort generieren.';

  } catch (error) {
    console.error('❌ Response generation failed:', error);
    return `Ich habe ein passendes Video zu deiner Frage gefunden: "${video.title}". Das Video behandelt das Thema ${video.category} und könnte deine Frage beantworten. Schau es dir gerne an!`;
  }
}

async function validateResponse(response: string, matchingResult: any) {
  if (!CONFIG.RESPONSE_VALIDATION) {
    return { answer: response, validation: { valid: true, score: 1.0 } };
  }

  console.log('✅ Validating response quality...');
  
  // Basic validation checks
  const validation = {
    valid: true,
    score: 1.0,
    issues: [] as string[],
    length: response.length,
    hasVideoReference: response.toLowerCase().includes('video'),
    hasPersonalTouch: response.includes('du') || response.includes('dein'),
    confidence: matchingResult.confidence
  };

  // Length validation
  if (response.length < 50) {
    validation.issues.push('Response too short');
    validation.score -= 0.2;
  }
  if (response.length > 500) {
    validation.issues.push('Response too long');
    validation.score -= 0.1;
  }

  // Content validation
  if (!validation.hasVideoReference) {
    validation.issues.push('No video reference');
    validation.score -= 0.3;
  }
  
  if (!validation.hasPersonalTouch) {
    validation.issues.push('Not personal enough');
    validation.score -= 0.2;
  }

  // Confidence-based adjustment
  if (matchingResult.confidence < 0.7) {
    validation.score *= 0.9;
  }

  validation.valid = validation.score >= 0.6 && validation.issues.length <= 2;
  validation.score = Math.max(0, Math.min(1, validation.score));

  return { answer: response, validation };
}

async function storeConversationWithMetadata(
  supabase: any, 
  userId: string, 
  question: string, 
  answer: string, 
  videoId: string | null, 
  confidence: number, 
  status: string,
  metadata: any = {}
) {
  try {
    const { error } = await supabase
      .from('conversations')
      .insert({
        user_id: userId,
        question: question,
        answer: answer,
        matched_video_id: videoId,
        confidence_score: confidence,
        metadata: {
          status,
          pipeline: 'optimized-v4',
          timestamp: new Date().toISOString(),
          ...metadata
        }
      });

    if (error) {
      console.error('❌ Error storing conversation:', error);
    } else {
      console.log('📝 Conversation stored with enhanced metadata');
    }
  } catch (error) {
    console.error('❌ Failed to store conversation:', error);
  }
}

async function triggerEnhancedWorkflow(supabase: any, userId: string, question: string, matchingResult: any, validatedResponse: any) {
  try {
    // Trigger monitoring agent
    const monitoringResponse = await supabase.functions.invoke('monitoring-agent', {
      body: {
        action: 'conversation_completed',
        userId,
        question,
        confidence: matchingResult.confidence,
        videoId: matchingResult.video.id,
        metadata: {
          pipeline: 'optimized-v4',
          validation: validatedResponse.validation,
          debug: matchingResult.debug
        }
      }
    });

    console.log('🔄 Enhanced workflow processing triggered');
    
    // Create notification for high-confidence matches
    if (matchingResult.confidence >= 0.8) {
      await supabase
        .from('notifications')
        .insert({
          user_id: userId,
          video_id: matchingResult.video.id,
          agent_name: 'conversation-agent-v4',
          notification_type: 'high_confidence_match',
          title: 'Exzellente Übereinstimmung gefunden',
          message: `Ihre Frage wurde mit hoher Genauigkeit (${(matchingResult.confidence * 100).toFixed(1)}%) beantwortet.`,
          metadata: {
            question,
            confidence: matchingResult.confidence,
            pipeline: 'optimized-v4'
          }
        });
    }

  } catch (error) {
    console.warn('⚠️ Workflow processing failed:', error);
  }
}

async function handleFeedbackProcessing(supabase: any, feedback: any, userId: string) {
  console.log('📊 Processing user feedback:', feedback);
  
  // Store feedback for model improvement
  try {
    const { error } = await supabase
      .from('conversation_feedback')
      .insert({
        user_id: userId,
        conversation_id: feedback.conversationId,
        rating: feedback.rating,
        feedback_text: feedback.text,
        feedback_type: feedback.type,
        metadata: {
          pipeline: 'optimized-v4',
          timestamp: new Date().toISOString(),
          ...feedback.metadata
        }
      });

    if (error) {
      console.error('❌ Error storing feedback:', error);
      throw error;
    }

    console.log('✅ Feedback stored successfully');
    
    return new Response(JSON.stringify({ 
      success: true,
      message: 'Feedback received and will be used to improve the system'
    }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });

  } catch (error) {
    console.error('❌ Feedback processing failed:', error);
    return new Response(JSON.stringify({ 
      error: error.message,
      pipeline: 'optimized-v4'
    }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
}

async function handleEmbeddingGeneration(supabase: any, userId: string) {
  console.log('🔧 Generating embeddings for user videos...');
  
  try {
    // Get videos without embeddings
    const { data: videos, error: videosError } = await supabase
      .from('videos')
      .select(`
        id,
        title,
        transcripts (id, content)
      `)
      .eq('user_id', userId)
      .eq('status', 'completed');

    if (videosError) throw videosError;

    let processed = 0;
    let created = 0;

    for (const video of videos || []) {
      if (!video.transcripts || video.transcripts.length === 0) continue;
      
      const transcript = video.transcripts[0];
      
      // Check if chunks already exist
      const { data: existingChunks } = await supabase
        .from('transcript_chunks')
        .select('id')
        .eq('video_id', video.id)
        .limit(1);

      if (existingChunks && existingChunks.length > 0) {
        console.log(`⏭️ Skipping ${video.title} - chunks already exist`);
        continue;
      }

      // Create optimized chunks
      const chunks = createOptimizedChunks(transcript.content, CONFIG.CHUNK_SIZE, CONFIG.CHUNK_OVERLAP);
      
      for (const chunk of chunks.slice(0, CONFIG.MAX_CHUNKS_PER_VIDEO)) {
        try {
          // Generate embedding
          const embedding = await generateOptimizedEmbedding(chunk.content);
          
          // Store chunk with embedding
          const { error: chunkError } = await supabase
            .from('transcript_chunks')
            .insert({
              video_id: video.id,
              transcript_id: transcript.id,
              content: chunk.content,
              start_time: chunk.startTime,
              end_time: chunk.endTime,
              embedding_json: embedding
            });

          if (chunkError) {
            console.error(`❌ Error storing chunk for ${video.title}:`, chunkError);
          } else {
            created++;
          }
          
          // Rate limiting
          await new Promise(resolve => setTimeout(resolve, 100));
          
        } catch (error) {
          console.error(`❌ Error processing chunk for ${video.title}:`, error);
        }
      }
      
      processed++;
      console.log(`✅ Processed ${video.title}: ${chunks.length} chunks`);
    }

    return new Response(JSON.stringify({ 
      success: true,
      processed,
      chunksCreated: created,
      message: `Generated embeddings for ${processed} videos with ${created} chunks`
    }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });

  } catch (error) {
    console.error('❌ Embedding generation failed:', error);
    return new Response(JSON.stringify({ 
      error: error.message,
      pipeline: 'optimized-v4'
    }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
}

function createOptimizedChunks(text: string, chunkSize: number, overlapRatio: number) {
  const sentences = text.split(/[.!?]+/).filter(s => s.trim().length > 0);
  const chunks = [];
  const overlapSize = Math.floor(chunkSize * overlapRatio);
  
  let currentChunk = '';
  let chunkStart = 0;
  let sentenceIndex = 0;
  
  for (const sentence of sentences) {
    const sentenceWithPunctuation = sentence.trim() + '.';
    
    if ((currentChunk + sentenceWithPunctuation).length > chunkSize && currentChunk.length > 0) {
      // Save current chunk
      chunks.push({
        content: currentChunk.trim(),
        startTime: chunkStart,
        endTime: sentenceIndex,
        wordCount: currentChunk.split(/\s+/).length
      });
      
      // Start new chunk with overlap
      const overlapWords = currentChunk.split(/\s+/).slice(-overlapSize);
      currentChunk = overlapWords.join(' ') + ' ' + sentenceWithPunctuation;
      chunkStart = sentenceIndex - overlapWords.length;
    } else {
      currentChunk += (currentChunk ? ' ' : '') + sentenceWithPunctuation;
    }
    
    sentenceIndex++;
  }
  
  // Add final chunk
  if (currentChunk.trim().length > 0) {
    chunks.push({
      content: currentChunk.trim(),
      startTime: chunkStart,
      endTime: sentenceIndex,
      wordCount: currentChunk.split(/\s+/).length
    });
  }
  
  return chunks.filter(chunk => chunk.wordCount >= 10); // Filter very small chunks
}

async function handleEvaluation(supabase: any, userId: string) {
  // Placeholder for evaluation functionality
  return new Response(JSON.stringify({ 
    message: 'Evaluation functionality not yet implemented',
    pipeline: 'optimized-v4'
  }), {
    headers: { ...corsHeaders, 'Content-Type': 'application/json' },
  });
}

function createResponse(answer: string, video: any, confidence: number, debug: any = {}) {
  return new Response(JSON.stringify({ 
    answer: answer,
    videoId: video?.id || null,
    videoUrl: video?.video_url || null,
    videoTitle: video?.title || null,
    confidence: confidence,
    debug: {
      pipeline: 'optimized-v4',
      timestamp: new Date().toISOString(),
      ...debug
    }
  }), {
    headers: { ...corsHeaders, 'Content-Type': 'application/json' },
  });
}