import "https://deno.land/x/xhr@0.1.0/mod.ts";
import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

interface TestCase {
  id: number;
  question: string;
  category: string;
  expectedKeywords: string[];
  expectedVideoTitle?: string;
  expectedVideoTitles?: string[];
  expectedMatch?: boolean;
  minimumConfidence: number;
  description: string;
}

const testDataset: TestCase[] = [
  {
    id: 1,
    question: "Wie sah ein ganz normaler Tag in deiner Kindheit aus?",
    category: "Kind & Familie",
    expectedKeywords: ["kindheit", "tag", "alltag", "familie", "schule"],
    expectedVideoTitle: "Wie sah ein ganz normaler Tag in deiner Kindheit aus?",
    minimumConfidence: 0.8,
    description: "Direct question match - should find exact video"
  },
  {
    id: 2,
    question: "Erzähl mir von deiner Kindheit",
    category: "Kind & Familie", 
    expectedKeywords: ["kindheit", "familie", "jung", "kind"],
    expectedVideoTitles: [
      "Wie sah ein ganz normaler Tag in deiner Kindheit aus?",
      "Welche Spiele hast du als Kind am liebsten gespielt?"
    ],
    minimumConfidence: 0.6,
    description: "Broader question - should match childhood-related videos"
  },
  {
    id: 3,
    question: "Was denkst du über Quantenphysik?",
    category: "Irrelevant",
    expectedKeywords: ["physik", "wissenschaft"],
    expectedMatch: false,
    minimumConfidence: 0.0,
    description: "Unrelated question - should not match any video"
  }
];

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { userId, runFullSuite = false } = await req.json();
    
    console.log('🧪 Starting evaluation test for user:', userId);

    const supabase = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? '',
    );

    const results = [];
    const testCases = runFullSuite ? testDataset : testDataset.slice(0, 3);
    
    for (const testCase of testCases) {
      console.log(`\n🔍 Testing: "${testCase.question}"`);
      
      const startTime = Date.now();
      
      try {
        // Call the enhanced conversation agent
        const response = await fetch(`${Deno.env.get('SUPABASE_URL')}/functions/v1/conversation-agent-v2`, {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')}`,
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            question: testCase.question,
            userId: userId,
            action: 'answer_question'
          })
        });

        const executionTime = Date.now() - startTime;
        
        if (!response.ok) {
          throw new Error(`HTTP ${response.status}: ${await response.text()}`);
        }

        const data = await response.json();
        const confidence = data.confidence || 0;
        const matchedTitle = data.videoTitle || null;
        
        // Determine success based on test case expectations
        let success = false;
        let reason = '';
        
        if (testCase.expectedMatch === false) {
          success = confidence < 0.6;
          reason = success ? 'Correctly rejected irrelevant question' : 'False positive - matched irrelevant question';
        } else if (testCase.expectedVideoTitle) {
          success = matchedTitle === testCase.expectedVideoTitle && confidence >= testCase.minimumConfidence;
          reason = success ? 'Exact title match with good confidence' : `Expected "${testCase.expectedVideoTitle}", got "${matchedTitle}"`;
        } else if (testCase.expectedVideoTitles) {
          success = testCase.expectedVideoTitles.includes(matchedTitle) && confidence >= testCase.minimumConfidence;
          reason = success ? 'Matched one of expected titles' : `None of expected titles matched: ${matchedTitle}`;
        }

        results.push({
          testId: testCase.id,
          question: testCase.question,
          success,
          confidence: confidence,
          matchedVideoTitle: matchedTitle,
          expectedTitle: testCase.expectedVideoTitle,
          reasoning: data.debug?.reasoning || reason,
          executionTime,
          debug: data.debug
        });

        console.log(`✅ Result: ${success ? 'PASS' : 'FAIL'} (confidence: ${confidence.toFixed(2)}, time: ${executionTime}ms)`);
        
      } catch (error) {
        console.error(`❌ Test ${testCase.id} failed:`, error);
        results.push({
          testId: testCase.id,
          question: testCase.question,
          success: false,
          confidence: 0,
          matchedVideoTitle: null,
          error: error.message,
          executionTime: Date.now() - startTime
        });
      }
      
      // Small delay between tests
      await new Promise(resolve => setTimeout(resolve, 500));
    }
    
    // Calculate summary metrics
    const totalTests = results.length;
    const successfulTests = results.filter(r => r.success).length;
    const averageConfidence = results.reduce((sum, r) => sum + r.confidence, 0) / totalTests;
    const averageExecutionTime = results.reduce((sum, r) => sum + r.executionTime, 0) / totalTests;
    
    const summary = {
      totalTests,
      successfulTests,
      accuracy: successfulTests / totalTests,
      averageConfidence,
      averageExecutionTime,
      timestamp: new Date().toISOString()
    };
    
    console.log('\n📊 EVALUATION SUMMARY:');
    console.log(`Accuracy: ${(summary.accuracy * 100).toFixed(1)}%`);
    console.log(`Average Confidence: ${summary.averageConfidence.toFixed(2)}`);
    console.log(`Average Response Time: ${summary.averageExecutionTime.toFixed(0)}ms`);

    return new Response(JSON.stringify({
      success: true,
      summary,
      results: results.map(r => ({
        testId: r.testId,
        question: r.question,
        success: r.success,
        confidence: parseFloat(r.confidence.toFixed(3)),
        matchedVideoTitle: r.matchedVideoTitle,
        reasoning: r.reasoning,
        executionTime: r.executionTime,
        error: r.error
      }))
    }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });

  } catch (error) {
    console.error('❌ Evaluation error:', error);
    return new Response(JSON.stringify({ 
      success: false,
      error: error.message 
    }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
});