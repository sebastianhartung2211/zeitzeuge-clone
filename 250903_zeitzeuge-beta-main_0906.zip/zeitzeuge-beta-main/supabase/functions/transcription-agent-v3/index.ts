import "https://deno.land/x/xhr@0.1.0/mod.ts";
import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

interface TranscriptionResult {
  text: string;
  confidence: number;
  segments: Array<{
    text: string;
    start: number;
    end: number;
    confidence: number;
  }>;
}

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  // FIXED: Declare videoId outside try-catch for proper scope
  let videoId: string;
  
  try {
    const requestData = await req.json();
    videoId = requestData.videoId;
    const { videoUrl, shouldCleanup = true, shouldTranslate = false, targetLanguage = 'de', includeAnalysis = true } = requestData;
    
    console.log('🎤 Enhanced Transcription Agent v3 processing video:', videoId);
    console.log('📹 Video URL:', videoUrl);

    const supabase = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? '',
    );

    // Get video information
    const { data: video, error: videoError } = await supabase
      .from('videos')
      .select('*')
      .eq('id', videoId)
      .single();

    if (videoError) {
      throw new Error(`Video not found: ${videoError.message}`);
    }

    console.log('📹 Video found:', video.title);

    // Step 1: Download and transcribe WebM file directly
    const transcriptResult = await transcribeWebMFile(videoUrl);
    
    if (!transcriptResult.text || transcriptResult.text.trim().length < 5) {
      throw new Error('Transcription failed or produced empty result');
    }
    
    console.log('📝 Transcription successful, length:', transcriptResult.text.length);
    
    // Step 2: Clean and structure the transcript
    const cleanedTranscript = shouldCleanup ? cleanupTranscript(transcriptResult.text) : transcriptResult.text;
    
    // Step 3: Optional translation (skip for German)
    let finalTranscript = cleanedTranscript;
    if (shouldTranslate && targetLanguage !== 'de') {
      finalTranscript = await translateTranscript(cleanedTranscript, targetLanguage);
    }
    
    // Step 4: Store transcript in database
    const { data: transcript, error: transcriptError } = await supabase
      .from('transcripts')
      .insert({
        video_id: videoId,
        content: finalTranscript,
        confidence: transcriptResult.confidence,
        language: targetLanguage
      })
      .select()
      .single();

    if (transcriptError) {
      throw new Error(`Failed to store transcript: ${transcriptError.message}`);
    }

    console.log('💾 Transcript stored with ID:', transcript.id);

    // Get user ID from video
    const { data: videoData } = await supabase
      .from('videos')
      .select('user_id')
      .eq('id', videoId)
      .single();

    if (!videoData) {
      throw new Error('Video not found');
    }

    // Step 5: Store detailed transcription with segments as JSON in user folder structure
    await storeTranscriptFile(supabase, videoId, transcript.id, {
      text: finalTranscript,
      confidence: transcriptResult.confidence,
      language: transcriptResult.language || 'de',
      segments: transcriptResult.segments
    }, videoData.user_id);

    // Step 6: Create transcript chunks
    await createTranscriptChunks(supabase, videoId, transcript.id, transcriptResult.segments);

    // Step 7: Update video status - FIXED: Use 'completed' instead of 'transcribed'
    const estimatedDuration = Math.max(...transcriptResult.segments.map(s => s.end));
    await updateVideoStatus(supabase, videoId, 'completed', estimatedDuration);

    console.log('✅ Enhanced transcription workflow completed successfully');

    return new Response(JSON.stringify({
      success: true,
      transcriptId: transcript.id,
      videoId: videoId,
      confidence: transcriptResult.confidence,
      segmentCount: transcriptResult.segments.length,
      segments: transcriptResult.segments,
      duration: estimatedDuration,
      processingMethod: 'direct-webm-transcription-with-segments',
      transcript: finalTranscript
    }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });

  } catch (error) {
    console.error('❌ Enhanced Transcription Agent v3 error:', error);
    
    // FIXED: Update video status to failed with proper error handling
    if (videoId) {
      try {
        const supabase = createClient(
          Deno.env.get('SUPABASE_URL') ?? '',
          Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? '',
        );
        await updateVideoStatus(supabase, videoId, 'failed', 0);
      } catch (updateError) {
        console.error('Failed to update video status:', updateError);
      }
    }

    return new Response(JSON.stringify({ 
      error: error.message,
      details: 'WebM transcription failed',
      videoId: videoId
    }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
});

async function transcribeWebMFile(videoUrl: string): Promise<TranscriptionResult> {
  console.log('🎵 Starting direct WebM transcription for:', videoUrl);
  
  const openaiKey = Deno.env.get('OPENAI_API_KEY');
  if (!openaiKey) {
    throw new Error('OPENAI_API_KEY not configured');
  }

  try {
    // Step 1: Download the WebM file with timeout
    console.log('📥 Downloading WebM file...');
    
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 30000); // 30 second timeout
    
    const mediaResponse = await fetch(videoUrl, {
      signal: controller.signal
    });
    
    clearTimeout(timeoutId);
    
    if (!mediaResponse.ok) {
      throw new Error(`Failed to download media: ${mediaResponse.status}`);
    }
    
    const mediaBlob = await mediaResponse.blob();
    console.log('📁 WebM downloaded, size:', mediaBlob.size);

    // Step 2: Send directly to Whisper API with timeout
    console.log('🎤 Sending WebM to Whisper API...');
    
    const formData = new FormData();
    formData.append('file', mediaBlob, 'audio.webm');
    formData.append('model', 'whisper-1');
    formData.append('language', 'de');
    formData.append('response_format', 'verbose_json');
    formData.append('temperature', '0.0');

    const whisperController = new AbortController();
    const whisperTimeoutId = setTimeout(() => whisperController.abort(), 60000); // 60 second timeout

    const response = await fetch('https://api.openai.com/v1/audio/transcriptions', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${openaiKey}`,
      },
      body: formData,
      signal: whisperController.signal
    });

    clearTimeout(whisperTimeoutId);

    if (!response.ok) {
      const errorText = await response.text();
      console.error('❌ Whisper API error:', response.status, errorText);
      throw new Error(`Whisper API error: ${response.status} - ${errorText}`);
    }

    const result = await response.json();
    console.log('✅ Whisper transcription successful');
    console.log('📝 Text length:', result.text?.length || 0);
    console.log('🔢 Segments:', result.segments?.length || 0);

    // Create segments from Whisper response
    const segments = result.segments?.map((segment: any) => ({
      text: segment.text || '',
      start: segment.start || 0,
      end: segment.end || 0,
      confidence: calculateSegmentConfidence(segment)
    })) || [];

    // If no segments, create one from the full text
    if (segments.length === 0 && result.text) {
      segments.push({
        text: result.text,
        start: 0,
        end: 60, // Default duration
        confidence: 0.8
      });
    }

    const averageConfidence = segments.length > 0 
      ? segments.reduce((sum, s) => sum + s.confidence, 0) / segments.length
      : 0.8;

    return {
      text: result.text || '',
      confidence: averageConfidence,
      segments: segments
    };

  } catch (error) {
    console.error('❌ WebM transcription failed:', error);
    
    // If it's an abort error, it's a timeout
    if (error.name === 'AbortError') {
      throw new Error(`Transcription timeout: ${error.message}`);
    }
    
    throw new Error(`WebM transcription failed: ${error.message}`);
  }
}

function calculateSegmentConfidence(segment: any): number {
  if (segment.avg_logprob !== undefined) {
    // Convert log probability to confidence (0-1)
    return Math.max(0, Math.min(1, Math.exp(segment.avg_logprob)));
  }
  return 0.8; // Default confidence
}

function cleanupTranscript(rawTranscript: string): string {
  console.log('🧹 Cleaning up transcript...');
  
  // Basic cleanup - remove extra whitespace and normalize
  let cleaned = rawTranscript.trim();
  cleaned = cleaned.replace(/\s+/g, ' '); // Multiple spaces to single space
  cleaned = cleaned.replace(/\n+/g, ' '); // Multiple newlines to single space
  
  return cleaned;
}

async function translateTranscript(transcript: string, targetLanguage: string): Promise<string> {
  console.log('🌐 Translation skipped - transcript already in German');
  return transcript;
}

async function storeTranscriptFile(supabase: any, videoId: string, transcriptId: string, transcriptData: any, userId: string): Promise<void> {
  console.log('💾 Storing transcript JSON file in user folder structure...');
  
  try {
    // Create user folder structure
    const timestamp = new Date().toISOString().split('T')[0]; // YYYY-MM-DD
    const fileName = `users/${userId}/sessions/${timestamp}/${videoId}/transcripts/transcript_${transcriptId}.json`;
    const jsonContent = JSON.stringify(transcriptData, null, 2);
    
    const { error: uploadError } = await supabase.storage
      .from('transcripts')
      .upload(fileName, new Blob([jsonContent], { type: 'application/json' }), {
        contentType: 'application/json',
        upsert: true
      });

    if (uploadError) {
      console.error('❌ Failed to store transcript file:', uploadError);
      throw new Error(`Failed to store transcript file: ${uploadError.message}`);
    }

    console.log('✅ Transcript JSON file stored:', fileName);
  } catch (error) {
    console.error('❌ Error storing transcript file:', error);
    throw error;
  }
}

async function createTranscriptChunks(supabase: any, videoId: string, transcriptId: string, segments: any[]): Promise<void> {
  console.log('📝 Creating transcript chunks...');
  
  const chunks = segments.map(segment => ({
    video_id: videoId,
    transcript_id: transcriptId,
    content: segment.text,
    start_time: Math.floor(segment.start),
    end_time: Math.floor(segment.end),
    embedding_json: null // Will be populated by embedding generator
  }));

  const { error } = await supabase
    .from('transcript_chunks')
    .insert(chunks);

  if (error) {
    throw new Error(`Failed to create transcript chunks: ${error.message}`);
  }

  console.log('✅ Created', chunks.length, 'transcript chunks');
}

async function updateVideoStatus(supabase: any, videoId: string, status: string, duration: number): Promise<void> {
  console.log('📊 Updating video status to:', status);
  
  // FIXED: Validate status and provide fallback
  const validStatuses = ['processing', 'completed', 'failed'];
  const validStatus = validStatuses.includes(status) ? status : 'failed';
  
  const updateData: any = { status: validStatus };
  
  // Only update duration if it's a valid number
  if (duration && duration > 0) {
    updateData.duration = Math.floor(duration);
  }
  
  const { error } = await supabase
    .from('videos')
    .update(updateData)
    .eq('id', videoId);

  if (error) {
    console.error('Database error details:', error);
    throw new Error(`Failed to update video status: ${error.message}`);
  }

  console.log('✅ Video status updated successfully to:', validStatus);
}