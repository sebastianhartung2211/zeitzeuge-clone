import "https://deno.land/x/xhr@0.1.0/mod.ts";
import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.52.0';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

interface VideoRecoveryOptions {
  maxRetries?: number;
  timeoutMinutes?: number;
  batchSize?: number;
}

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { action, videoId, options = {} } = await req.json();
    console.log(`🔧 Video Recovery Agent called with action: ${action}`);

    const supabase = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? '',
      {
        db: { schema: 'public' },
        global: { headers: { 'X-Client-Info': 'video-recovery-agent' } }
      }
    );

    switch (action) {
      case 'recover_stuck_videos':
        return await recoverStuckVideos(supabase, options);
      case 'retry_failed_video':
        return await retryFailedVideo(supabase, videoId, options);
      case 'health_check':
        return await performHealthCheck(supabase);
      case 'cleanup_orphaned_data':
        return await cleanupOrphanedData(supabase);
      default:
        throw new Error(`Unknown action: ${action}`);
    }

  } catch (error) {
    console.error('Error in video-recovery-agent:', error);
    return new Response(JSON.stringify({ 
      error: error.message,
      success: false 
    }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
});

async function recoverStuckVideos(supabase: any, options: VideoRecoveryOptions) {
  const { timeoutMinutes = 15, batchSize = 10 } = options;
  console.log(`🔍 Checking for videos stuck in processing for more than ${timeoutMinutes} minutes...`);

  // Find videos stuck in processing status
  const { data: stuckVideos, error } = await supabase
    .from('videos')
    .select('id, title, status, created_at, updated_at, user_id')
    .eq('status', 'processing')
    .lt('updated_at', new Date(Date.now() - timeoutMinutes * 60 * 1000).toISOString())
    .limit(batchSize);

  if (error) {
    throw new Error(`Failed to fetch stuck videos: ${error.message}`);
  }

  console.log(`📊 Found ${stuckVideos?.length || 0} stuck videos`);

  if (!stuckVideos || stuckVideos.length === 0) {
    return new Response(JSON.stringify({
      success: true,
      message: 'No stuck videos found',
      recoveredCount: 0
    }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }

  // Process stuck videos with retry logic
  const recoveryResults = await Promise.allSettled(
    stuckVideos.map(video => retryVideoProcessing(supabase, video))
  );

  const successCount = recoveryResults.filter(r => r.status === 'fulfilled').length;
  const failureCount = recoveryResults.filter(r => r.status === 'rejected').length;

  console.log(`✅ Recovery completed: ${successCount} successful, ${failureCount} failed`);

  return new Response(JSON.stringify({
    success: true,
    recoveredCount: successCount,
    failedCount: failureCount,
    totalProcessed: stuckVideos.length
  }), {
    headers: { ...corsHeaders, 'Content-Type': 'application/json' },
  });
}

async function retryVideoProcessing(supabase: any, video: any) {
  console.log(`🔄 Retrying processing for video: ${video.title} (${video.id})`);

  try {
    // Reset video status to processing with retry flag
    const { error: updateError } = await supabase
      .from('videos')
      .update({ 
        status: 'processing',
        updated_at: new Date().toISOString()
      })
      .eq('id', video.id);

    if (updateError) {
      throw new Error(`Failed to reset video status: ${updateError.message}`);
    }

    // Call coordinator agent to restart processing pipeline
    const coordinatorResponse = await fetch(
      `${Deno.env.get('SUPABASE_URL')}/functions/v1/coordinator-agent`,
      {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')}`,
        },
        body: JSON.stringify({
          videoId: video.id,
          action: 'process_video',
          userId: video.user_id,
          isRetry: true
        })
      }
    );

    if (!coordinatorResponse.ok) {
      throw new Error(`Coordinator agent failed: ${coordinatorResponse.status}`);
    }

    // Log recovery attempt
    await supabase
      .from('processing_logs')
      .insert({
        video_id: video.id,
        agent_name: 'video-recovery-agent',
        stage: 'retry_processing',
        status: 'completed',
        output_data: { retryReason: 'stuck_in_processing', originalStatus: video.status }
      });

    console.log(`✅ Successfully initiated retry for video: ${video.id}`);
    return { success: true, videoId: video.id };

  } catch (error) {
    console.error(`❌ Failed to retry video ${video.id}:`, error);

    // Mark video as failed with error details
    await supabase
      .from('videos')
      .update({ 
        status: 'failed',
        updated_at: new Date().toISOString()
      })
      .eq('id', video.id);

    await supabase
      .from('processing_logs')
      .insert({
        video_id: video.id,
        agent_name: 'video-recovery-agent',
        stage: 'retry_processing',
        status: 'failed',
        error_message: error.message
      });

    throw error;
  }
}

async function retryFailedVideo(supabase: any, videoId: string, options: VideoRecoveryOptions) {
  const { maxRetries = 3 } = options;
  console.log(`🔄 Retrying failed video: ${videoId} (max retries: ${maxRetries})`);

  // Get video and check retry count
  const { data: video, error } = await supabase
    .from('videos')
    .select('*, processing_logs(count)')
    .eq('id', videoId)
    .single();

  if (error || !video) {
    throw new Error(`Video not found: ${videoId}`);
  }

  const retryCount = video.processing_logs?.[0]?.count || 0;
  if (retryCount >= maxRetries) {
    throw new Error(`Maximum retry attempts (${maxRetries}) exceeded for video ${videoId}`);
  }

  return await retryVideoProcessing(supabase, video);
}

async function performHealthCheck(supabase: any) {
  console.log(`🏥 Performing video processing pipeline health check...`);

  try {
    // Check processing statistics
    const { data: stats, error: statsError } = await supabase
      .from('videos')
      .select('status')
      .gte('created_at', new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString()); // Last 24 hours

    if (statsError) {
      throw new Error(`Failed to fetch video stats: ${statsError.message}`);
    }

    const statusCounts = stats?.reduce((acc: any, video: any) => {
      acc[video.status] = (acc[video.status] || 0) + 1;
      return acc;
    }, {}) || {};

    // Check for stuck videos
    const { data: stuckVideos } = await supabase
      .from('videos')
      .select('count()')
      .eq('status', 'processing')
      .lt('updated_at', new Date(Date.now() - 15 * 60 * 1000).toISOString());

    const stuckCount = stuckVideos?.[0]?.count || 0;

    // Calculate health score
    const totalVideos = stats?.length || 1;
    const successRate = (statusCounts.completed || 0) / totalVideos;
    const healthScore = Math.max(0, Math.min(100, Math.round(
      (successRate * 70) + // 70% weight for success rate
      (Math.max(0, 1 - (stuckCount / totalVideos)) * 20) + // 20% weight for stuck videos
      (Math.max(0, 1 - ((statusCounts.failed || 0) / totalVideos)) * 10) // 10% weight for failed videos
    )));

    console.log(`📊 Health check completed - Score: ${healthScore}%`);

    return new Response(JSON.stringify({
      success: true,
      healthScore,
      statistics: {
        total: totalVideos,
        completed: statusCounts.completed || 0,
        processing: statusCounts.processing || 0,
        failed: statusCounts.failed || 0,
        stuck: stuckCount
      },
      recommendations: generateHealthRecommendations(healthScore, statusCounts, stuckCount)
    }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });

  } catch (error) {
    console.error('Health check failed:', error);
    throw error;
  }
}

async function cleanupOrphanedData(supabase: any) {
  console.log(`🧹 Cleaning up orphaned processing data...`);

  try {
    // Clean up old processing logs (older than 7 days)
    const { error: logsError } = await supabase
      .from('processing_logs')
      .delete()
      .lt('created_at', new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString());

    if (logsError) {
      console.error('Failed to cleanup processing logs:', logsError);
    }

    // Clean up orphaned transcript chunks
    const { error: chunksError } = await supabase
      .from('transcript_chunks')
      .delete()
      .not('video_id', 'in', `(SELECT id FROM videos)`);

    if (chunksError) {
      console.error('Failed to cleanup orphaned chunks:', chunksError);
    }

    console.log(`✅ Cleanup completed successfully`);

    return new Response(JSON.stringify({
      success: true,
      message: 'Cleanup completed successfully'
    }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });

  } catch (error) {
    console.error('Cleanup failed:', error);
    throw error;
  }
}

function generateHealthRecommendations(healthScore: number, statusCounts: any, stuckCount: number): string[] {
  const recommendations = [];

  if (healthScore < 70) {
    recommendations.push('Critical: System health is below acceptable threshold');
  }
  
  if (stuckCount > 0) {
    recommendations.push(`${stuckCount} videos are stuck in processing - run recovery`);
  }
  
  if ((statusCounts.failed || 0) > (statusCounts.completed || 1) * 0.1) {
    recommendations.push('High failure rate detected - investigate error patterns');
  }
  
  if (recommendations.length === 0) {
    recommendations.push('System is operating normally');
  }

  return recommendations;
}