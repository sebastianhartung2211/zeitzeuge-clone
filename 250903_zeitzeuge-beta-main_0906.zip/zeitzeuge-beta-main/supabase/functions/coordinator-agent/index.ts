import "https://deno.land/x/xhr@0.1.0/mod.ts";
import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const requestBody = await req.json();
    const { videoId, action, userId, questionContext } = requestBody;
    
    // Input validation
    if (!videoId) {
      return new Response(JSON.stringify({ 
        error: 'Missing required parameter: videoId' 
      }), {
        status: 400,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }
    
    if (!action) {
      return new Response(JSON.stringify({ 
        error: 'Missing required parameter: action' 
      }), {
        status: 400,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }
    
    console.log('Coordinator Agent received request:', { videoId, action, userId, questionContext });

    // Initialize Supabase client
    const supabase = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? '',
    );

    // Get video details
    const { data: video, error: videoError } = await supabase
      .from('videos')
      .select('*')
      .eq('id', videoId)
      .single();

    if (videoError || !video) {
      console.error('Video not found:', videoError?.message || 'No video data');
      return new Response(JSON.stringify({ 
        error: 'Video not found',
        videoId: videoId,
        details: videoError?.message || 'Video does not exist'
      }), {
        status: 404,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    console.log('Processing video:', video.title);

    // Coordinate the workflow based on action
    switch (action) {
      case 'process_video':
        await processVideoWorkflow(supabase, video, questionContext);
        break;
      case 'answer_question':
        const { question } = await req.json();
        const answer = await handleQuestionWorkflow(supabase, question, userId);
        return new Response(JSON.stringify({ answer }), {
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        });
      default:
        throw new Error(`Unknown action: ${action}`);
    }

    return new Response(JSON.stringify({ 
      success: true, 
      message: `Workflow ${action} completed for video ${videoId}` 
    }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });

  } catch (error) {
    console.error('Coordinator Agent error:', error);
    return new Response(JSON.stringify({ error: error.message }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
});

async function processVideoWorkflow(supabase: any, video: any, questionContext?: any) {
  console.log(`🎬 Starting enhanced video processing workflow for: ${video.id}`);
  
  try {
    // Step 1: VAD-based transcription with enhanced audio processing
    console.log('📝 Step 1: Calling transcription-agent-v3 (VAD-based)...');
    const transcriptionResult = await supabase.functions.invoke('transcription-agent-v3', {
      body: { 
        videoId: video.id, 
        videoUrl: video.video_url,
        userId: video.user_id,
        questionContext,
        shouldCleanup: true,
        includeAnalysis: true
      }
    });

    if (transcriptionResult.error) {
      throw new Error(`Transcription failed: ${transcriptionResult.error.message}`);
    }

    // Step 1.5: Process Review for transcription
    console.log('🔍 Step 1.5: Process review for transcription...');
    await supabase.functions.invoke('process-review-agent', {
      body: {
        videoId: video.id,
        agentName: 'transcription-agent-v3',
        stage: 'transcription',
        expectedOutput: { minDuration: 5 }
      }
    });

    // Step 2: Tagging and Segmentation (MANDATORY - Always try)
    console.log('🏷️ Step 2: Calling tagging-segmentation-agent...');
    let taggingSuccessful = true;
    let taggingAttempts = 0;
    const maxTaggingAttempts = 2;
    
    while (taggingAttempts < maxTaggingAttempts && !taggingSuccessful) {
      taggingAttempts++;
      console.log(`🔄 Tagging attempt ${taggingAttempts}/${maxTaggingAttempts}`);
      
      try {
        const taggingResult = await supabase.functions.invoke('tagging-segmentation-agent', {
          body: { 
            videoId: video.id, 
            userId: video.user_id,
            attempt: taggingAttempts
          }
        });

        if (taggingResult.error) {
          console.warn(`⚠️ Tagging attempt ${taggingAttempts} failed: ${taggingResult.error.message}`);
          if (taggingAttempts === maxTaggingAttempts) {
            console.error('❌ ALL tagging attempts failed - applying fallback');
            // Create fallback category assignment
            await supabase
              .from('videos')
              .update({ category: 'Personalisierte Themen' })
              .eq('id', video.id);
            taggingSuccessful = false;
          }
        } else {
          console.log('✅ Tagging completed successfully');
          taggingSuccessful = true;
        }
      } catch (taggingError) {
        console.warn(`⚠️ Tagging attempt ${taggingAttempts} error: ${taggingError.message}`);
        if (taggingAttempts === maxTaggingAttempts) {
          console.error('❌ ALL tagging attempts failed with errors');
          taggingSuccessful = false;
        }
      }
    }

    // Step 2.5: Process Review for tagging (only if successful)
    if (taggingSuccessful) {
      console.log('🔍 Step 2.5: Process review for tagging...');
      await supabase.functions.invoke('process-review-agent', {
        body: {
          videoId: video.id,
          agentName: 'tagging-segmentation-agent',
          stage: 'tagging',
          expectedOutput: { minTags: 3, minSegments: 1 }
        }
      });
    }

    // Step 3: Storage and organization (ALWAYS run)
    console.log('💾 Step 3: Calling storage-agent...');
    try {
      const storageResult = await supabase.functions.invoke('storage-agent', {
        body: { 
          videoId: video.id, 
          userId: video.user_id 
        }
      });

      if (storageResult.error) {
        console.warn(`⚠️ Storage warning: ${storageResult.error.message} - continuing anyway`);
      }
    } catch (storageError) {
      console.warn(`⚠️ Storage agent error: ${storageError.message} - continuing anyway`);
    }

    // Step 3.5: Process Review for storage (optional)
    console.log('🔍 Step 3.5: Process review for storage...');
    try {
      await supabase.functions.invoke('process-review-agent', {
        body: {
          videoId: video.id,
          agentName: 'storage-agent',
          stage: 'storage',
          expectedOutput: { statusCompleted: true }
        }
      });
    } catch (reviewError) {
      console.warn('Storage review failed:', reviewError.message);
    }

    // CRITICAL: Always mark video as completed if transcript exists
    const { data: transcripts } = await supabase
      .from('transcripts')
      .select('id')
      .eq('video_id', video.id);

    const finalStatus = transcripts && transcripts.length > 0 ? 'completed' : 'failed';
    
    await supabase
      .from('videos')
      .update({ 
        status: finalStatus,
        updated_at: new Date().toISOString()
      })
      .eq('id', video.id);

    console.log(`✅ Video processing completed with status: ${finalStatus} for video: ${video.id}`);

  } catch (error) {
    console.error(`❌ Video processing failed: ${error.message}`);
    
    // Update video status to failed
    await supabase
      .from('videos')
      .update({ 
        status: 'failed',
        updated_at: new Date().toISOString()
      })
      .eq('id', video.id);

    // Create error notification via process review
    try {
      await supabase.functions.invoke('process-review-agent', {
        body: {
          videoId: video.id,
          agentName: 'coordinator-agent',
          stage: 'workflow',
          expectedOutput: { error: error.message }
        }
      });
    } catch (reviewError) {
      console.error('Failed to create error notification:', reviewError);
    }

    throw error;
  }
}

async function handleQuestionWorkflow(supabase: any, question: string, userId: string) {
  console.log('Starting question workflow for:', question);

  // Call conversation agent to find matching video
  const conversationResponse = await fetch(`${Deno.env.get('SUPABASE_URL')}/functions/v1/conversation-agent`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${Deno.env.get('SUPABASE_ANON_KEY')}`,
    },
    body: JSON.stringify({ question, userId }),
  });

  if (!conversationResponse.ok) {
    throw new Error('Conversation processing failed');
  }

  const result = await conversationResponse.json();
  console.log('Question workflow completed');
  
  return result;
}