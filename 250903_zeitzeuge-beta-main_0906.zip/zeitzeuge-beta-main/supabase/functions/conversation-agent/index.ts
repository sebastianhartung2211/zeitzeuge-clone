import "https://deno.land/x/xhr@0.1.0/mod.ts";
import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { question, userId, action = 'answer_question' } = await req.json();
    
    console.log('Conversation Agent processing:', { question, userId, action });

    // Initialize Supabase client
    const supabase = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? '',
    );

    // Handle different conversation actions
    switch (action) {
      case 'answer_question':
        return await handleQuestionAnswering(supabase, question, userId);
      case 'process_follow_up':
        return await handleFollowUp(supabase, question, userId);
      case 'send_notification':
        return await handleNotification(supabase, userId, await req.json());
      case 'handle_error':
        return await handleConversationError(supabase, userId, await req.json());
      default:
        // Legacy support - default to question answering
        return await handleQuestionAnswering(supabase, question, userId);
    }

  } catch (error) {
    console.error('Conversation Agent error:', error);
    return new Response(JSON.stringify({ error: error.message }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
});

async function handleQuestionAnswering(supabase: any, question: string, userId: string) {
  console.log('Handling question answering for:', question);

  // Get all videos and transcripts for the user
  const { data: videos, error: videosError } = await supabase
    .from('videos')
    .select(`
      id,
      title,
      description,
      video_url,
      transcripts (
        content
      ),
      video_tags (
        tags (
          name,
          category
        )
      )
    `)
    .eq('user_id', userId)
    .eq('status', 'completed');

  if (videosError) {
    throw new Error(`Error fetching videos: ${videosError.message}`);
  }

  console.log(`Found ${videos.length} videos for user`);

  // Find the best matching video using AI
  const matchingVideo = await findBestMatch(question, videos);

  if (!matchingVideo) {
    // Store the conversation even if no match found
    await supabase
      .from('conversations')
      .insert({
        user_id: userId,
        question: question,
        answer: 'Entschuldigung, ich konnte kein passendes Video zu Ihrer Frage finden.',
        confidence_score: 0.0
      });

    return new Response(JSON.stringify({ 
      answer: 'Entschuldigung, ich konnte kein passendes Video zu Ihrer Frage finden.',
      videoId: null,
      confidence: 0.0
    }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }

  // Generate a natural language response
  const answer = await generateResponse(question, matchingVideo);

  // Store the conversation
  await supabase
    .from('conversations')
    .insert({
      user_id: userId,
      question: question,
      answer: answer,
      matched_video_id: matchingVideo.id,
      confidence_score: matchingVideo.confidence
    });

  console.log('Conversation completed, matched video:', matchingVideo.title);

  return new Response(JSON.stringify({ 
    answer: answer,
    videoId: matchingVideo.id,
    videoUrl: matchingVideo.video_url,
    videoTitle: matchingVideo.title,
    confidence: matchingVideo.confidence
  }), {
    headers: { ...corsHeaders, 'Content-Type': 'application/json' },
  });
}

async function handleFollowUp(supabase: any, input: string, userId: string) {
  console.log('Handling follow-up for user:', userId);
  
  // Get recent conversation history
  const { data: recentConversations } = await supabase
    .from('conversations')
    .select('*')
    .eq('user_id', userId)
    .order('created_at', { ascending: false })
    .limit(3);

  // Process follow-up with context
  const contextualAnswer = await generateContextualResponse(input, recentConversations);
  
  // Store follow-up conversation
  await supabase
    .from('conversations')
    .insert({
      user_id: userId,
      question: input,
      answer: contextualAnswer,
      confidence_score: 0.9,
      matched_video_id: null
    });

  return new Response(JSON.stringify({
    answer: contextualAnswer,
    type: 'follow_up',
    context: recentConversations?.length || 0
  }), {
    headers: { ...corsHeaders, 'Content-Type': 'application/json' },
  });
}

async function handleNotification(supabase: any, userId: string, notificationData: any) {
  console.log('Handling notification for user:', userId);
  
  return new Response(JSON.stringify({
    success: true,
    message: 'Notification handled',
    userId: userId
  }), {
    headers: { ...corsHeaders, 'Content-Type': 'application/json' },
  });
}

async function handleConversationError(supabase: any, userId: string, errorData: any) {
  console.log('Handling conversation error for user:', userId);
  
  const helpfulResponse = 'Es tut mir leid, da ist etwas schiefgelaufen. Lass uns das Gespräch einfach fortsetzen - was beschäftigt dich gerade?';
  
  return new Response(JSON.stringify({
    success: true,
    message: helpfulResponse,
    errorHandled: true
  }), {
    headers: { ...corsHeaders, 'Content-Type': 'application/json' },
  });
}

async function findBestMatch(question: string, videos: any[]): Promise<any> {
  console.log('Finding best match for question using AI');

  if (videos.length === 0) {
    return null;
  }

  const videosInfo = videos.map((video, index) => {
    const transcript = video.transcripts[0]?.content || '';
    const tags = video.video_tags.map((vt: any) => vt.tags.name).join(', ');
    
    return `Video ${index + 1}:
Titel: ${video.title}
Beschreibung: ${video.description || ''}
Tags: ${tags}
Inhalt: ${transcript.substring(0, 500)}...`;
  }).join('\n\n');

  const prompt = `
Frage des Nutzers: "${question}"

Verfügbare Videos:
${videosInfo}

Analysiere welches Video am besten zur Frage des Nutzers passt. Berücksichtige:
- Relevanz des Inhalts zur Frage
- Übereinstimmung mit Tags
- Kontext und Thema

Antworte nur mit einem JSON-Objekt im folgenden Format:
{"videoIndex": 0, "confidence": 0.85, "reasoning": "Kurze Begründung"}

videoIndex ist 0-basiert (0 für erstes Video, 1 für zweites, etc.)
confidence zwischen 0.0 und 1.0
Wenn kein Video gut passt, verwende confidence < 0.3
`;

  const response = await fetch('https://api.openai.com/v1/chat/completions', {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${Deno.env.get('OPENAI_API_KEY')}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      model: 'gpt-4o-mini',
      messages: [
        { role: 'system', content: 'Du bist ein Experte für das Matching von Fragen zu Video-Inhalten in einem Familienerinnerungs-System.' },
        { role: 'user', content: prompt }
      ],
      temperature: 0.1,
      max_tokens: 300,
    }),
  });

  if (!response.ok) {
    throw new Error('OpenAI API error during matching');
  }

  const result = await response.json();
  const content = result.choices[0].message.content;

  try {
    const jsonMatch = content.match(/\{.*\}/s);
    if (!jsonMatch) {
      throw new Error('No JSON found in matching response');
    }

    const matchResult = JSON.parse(jsonMatch[0]);
    
    if (matchResult.confidence < 0.3) {
      return null;
    }

    const selectedVideo = videos[matchResult.videoIndex];
    if (!selectedVideo) {
      return null;
    }

    return {
      ...selectedVideo,
      confidence: matchResult.confidence,
      reasoning: matchResult.reasoning
    };

  } catch (parseError) {
    console.error('Error parsing match result:', parseError);
    return null;
  }
}

async function generateResponse(question: string, matchingVideo: any): Promise<string> {
  console.log('Generating natural response');

  const transcript = matchingVideo.transcripts[0]?.content || '';
  const tags = matchingVideo.video_tags.map((vt: any) => vt.tags.name).join(', ');

  const prompt = `
Der Nutzer hat gefragt: "${question}"

Ich habe ein passendes Video gefunden:
Titel: ${matchingVideo.title}
Beschreibung: ${matchingVideo.description || ''}
Tags: ${tags}
Inhalt: ${transcript.substring(0, 800)}

Erstelle eine natürliche, freundliche Antwort auf Deutsch, die:
1. Die Frage des Nutzers direkt beantwortet
2. Erklärt, warum dieses Video relevant ist
3. Den Nutzer ermutigt, das Video anzuschauen
4. Warm und persönlich klingt, wie ein Familienmitglied

Halte die Antwort unter 150 Wörtern.
`;

  const response = await fetch('https://api.openai.com/v1/chat/completions', {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${Deno.env.get('OPENAI_API_KEY')}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      model: 'gpt-4o-mini',
      messages: [
        { role: 'system', content: 'Du bist ein hilfsamer Assistent für ein Familienerinnerungs-System. Antworte warm, persönlich und auf Deutsch.' },
        { role: 'user', content: prompt }
      ],
      temperature: 0.7,
      max_tokens: 200,
    }),
  });

  if (!response.ok) {
    throw new Error('OpenAI API error during response generation');
  }

  const result = await response.json();
  return result.choices[0].message.content;
}

async function generateContextualResponse(input: string, recentConversations: any[]): Promise<string> {
  const openaiKey = Deno.env.get('OPENAI_API_KEY');
  if (!openaiKey) {
    return 'Das ist eine interessante Nachfrage. Erzähl mir gerne mehr darüber!';
  }

  const conversationContext = recentConversations?.map(conv => 
    `Q: ${conv.question}\nA: ${conv.answer}`
  ).join('\n\n') || '';

  const prompt = `Du führst ein einfühlsames Gespräch über persönliche Erinnerungen.

Bisherige Unterhaltung:
${conversationContext}

Neue Eingabe: "${input}"

Antworte empathisch und stelle eine weiterführende Frage, die das Gespräch vertieft.`;

  const response = await fetch('https://api.openai.com/v1/chat/completions', {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${openaiKey}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      model: 'gpt-4o-mini',
      messages: [
        { role: 'system', content: 'Du führst einfühlsame Gespräche über persönliche Erinnerungen.' },
        { role: 'user', content: prompt }
      ],
      temperature: 0.8,
    }),
  });

  if (!response.ok) {
    return 'Das ist eine interessante Nachfrage. Erzähl mir gerne mehr darüber!';
  }

  const data = await response.json();
  return data.choices[0].message.content;
}
