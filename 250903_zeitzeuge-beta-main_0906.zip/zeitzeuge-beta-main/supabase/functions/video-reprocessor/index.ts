import "https://deno.land/x/xhr@0.1.0/mod.ts";
import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { action, videoId, forceRetranscribe = false } = await req.json();
    
    console.log('🔄 Video Reprocessor received request:', { action, videoId, forceRetranscribe });

    const supabase = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? '',
    );

    switch (action) {
      case 'reprocess_failed_videos':
        return await reprocessFailedVideos(supabase);
      
      case 'reprocess_single_video':
        if (!videoId) {
          throw new Error('videoId is required for single video reprocessing');
        }
        return await reprocessSingleVideo(supabase, videoId, forceRetranscribe);
      
      case 'analyze_all_videos':
        return await analyzeAllVideos(supabase);
      
      case 'retranscribe_all':
        return await retranscribeAllVideos(supabase);
      
      default:
        throw new Error(`Unknown action: ${action}`);
    }

  } catch (error) {
    console.error('❌ Video Reprocessor error:', error);
    return new Response(JSON.stringify({ error: error.message }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
});

async function reprocessFailedVideos(supabase: any) {
  console.log('🔍 Finding failed videos...');
  
  const { data: failedVideos, error } = await supabase
    .from('videos')
    .select('*')
    .eq('status', 'failed')
    .order('created_at', { ascending: false });

  if (error) {
    throw new Error(`Failed to get failed videos: ${error.message}`);
  }

  console.log(`Found ${failedVideos.length} failed videos`);
  
  const results = [];
  
  for (const video of failedVideos) {
    try {
      console.log(`🔄 Reprocessing video: ${video.id} - ${video.title}`);
      
      // Reset status to processing
      await supabase
        .from('videos')
        .update({ status: 'processing' })
        .eq('id', video.id);
      
      // Trigger coordinator agent
      const coordinatorResponse = await supabase.functions.invoke('coordinator-agent', {
        body: {
          videoId: video.id,
          action: 'process_video',
          userId: video.user_id
        }
      });
      
      if (coordinatorResponse.error) {
        console.error(`❌ Failed to reprocess ${video.id}:`, coordinatorResponse.error);
        results.push({
          id: video.id,
          title: video.title,
          status: 'failed',
          error: coordinatorResponse.error.message
        });
      } else {
        console.log(`✅ Successfully triggered reprocessing for ${video.id}`);
        results.push({
          id: video.id,
          title: video.title,
          status: 'processing',
          message: 'Reprocessing started'
        });
      }
      
      // Add delay to avoid overwhelming the system
      await new Promise(resolve => setTimeout(resolve, 2000));
      
    } catch (error) {
      console.error(`❌ Error reprocessing video ${video.id}:`, error);
      results.push({
        id: video.id,
        title: video.title,
        status: 'error',
        error: error.message
      });
    }
  }
  
  return new Response(JSON.stringify({
    success: true,
    message: `Reprocessed ${failedVideos.length} failed videos`,
    results: results,
    summary: {
      total: failedVideos.length,
      successful: results.filter(r => r.status === 'processing').length,
      failed: results.filter(r => r.status === 'failed' || r.status === 'error').length
    }
  }), {
    headers: { ...corsHeaders, 'Content-Type': 'application/json' },
  });
}

async function reprocessSingleVideo(supabase: any, videoId: string, forceRetranscribe: boolean) {
  console.log(`🔄 Reprocessing single video: ${videoId}`);
  
  // Get video details
  const { data: video, error: videoError } = await supabase
    .from('videos')
    .select('*')
    .eq('id', videoId)
    .single();

  if (videoError) {
    throw new Error(`Video not found: ${videoError.message}`);
  }

  // If force retranscribe, delete existing transcript
  if (forceRetranscribe) {
    console.log('🗑️ Deleting existing transcript for retranscription...');
    await supabase
      .from('transcripts')
      .delete()
      .eq('video_id', videoId);
      
    await supabase
      .from('transcript_chunks')
      .delete()
      .eq('video_id', videoId);
  }

  // Reset status to processing
  await supabase
    .from('videos')
    .update({ status: 'processing' })
    .eq('id', videoId);

  // Trigger coordinator agent
  const coordinatorResponse = await supabase.functions.invoke('coordinator-agent', {
    body: {
      videoId: video.id,
      action: 'process_video',
      userId: video.user_id
    }
  });

  if (coordinatorResponse.error) {
    throw new Error(`Reprocessing failed: ${coordinatorResponse.error.message}`);
  }

  return new Response(JSON.stringify({
    success: true,
    message: `Video ${videoId} reprocessing started`,
    video: {
      id: video.id,
      title: video.title,
      status: 'processing',
      forceRetranscribe: forceRetranscribe
    }
  }), {
    headers: { ...corsHeaders, 'Content-Type': 'application/json' },
  });
}

async function analyzeAllVideos(supabase: any) {
  console.log('📊 Analyzing all videos...');
  
  const { data: videos, error } = await supabase
    .from('videos')
    .select(`
      id, title, status, created_at, duration,
      transcripts (id, content, confidence, language),
      video_tags (relevance_score, tags (name, category))
    `)
    .order('created_at', { ascending: false });

  if (error) {
    throw new Error(`Failed to get videos: ${error.message}`);
  }

  const analysis = {
    totalVideos: videos.length,
    statusBreakdown: {},
    transcriptStatus: {
      withTranscripts: 0,
      withoutTranscripts: 0,
      lowConfidence: 0
    },
    taggingStatus: {
      withTags: 0,
      withoutTags: 0
    },
    problematicVideos: [],
    recommendations: []
  };

  // Analyze each video
  for (const video of videos) {
    // Status breakdown
    analysis.statusBreakdown[video.status] = (analysis.statusBreakdown[video.status] || 0) + 1;
    
    // Transcript analysis
    if (video.transcripts && video.transcripts.length > 0) {
      analysis.transcriptStatus.withTranscripts++;
      
      // Check confidence
      const avgConfidence = video.transcripts.reduce((sum: number, t: any) => sum + (t.confidence || 0), 0) / video.transcripts.length;
      if (avgConfidence < 0.7) {
        analysis.transcriptStatus.lowConfidence++;
        analysis.problematicVideos.push({
          id: video.id,
          title: video.title,
          issue: 'Low transcript confidence',
          confidence: avgConfidence
        });
      }
    } else {
      analysis.transcriptStatus.withoutTranscripts++;
      analysis.problematicVideos.push({
        id: video.id,
        title: video.title,
        issue: 'Missing transcript',
        status: video.status
      });
    }
    
    // Tagging analysis
    if (video.video_tags && video.video_tags.length > 0) {
      analysis.taggingStatus.withTags++;
    } else {
      analysis.taggingStatus.withoutTags++;
      if (video.transcripts && video.transcripts.length > 0) {
        analysis.problematicVideos.push({
          id: video.id,
          title: video.title,
          issue: 'Has transcript but missing tags'
        });
      }
    }
  }

  // Generate recommendations
  if (analysis.transcriptStatus.withoutTranscripts > 0) {
    analysis.recommendations.push(`${analysis.transcriptStatus.withoutTranscripts} videos need transcription`);
  }
  
  if (analysis.transcriptStatus.lowConfidence > 0) {
    analysis.recommendations.push(`${analysis.transcriptStatus.lowConfidence} videos have low-confidence transcripts and should be retranscribed`);
  }
  
  if (analysis.taggingStatus.withoutTags > 0) {
    analysis.recommendations.push(`${analysis.taggingStatus.withoutTags} videos need tagging`);
  }
  
  const failedCount = analysis.statusBreakdown['failed'] || 0;
  if (failedCount > 0) {
    analysis.recommendations.push(`${failedCount} failed videos need reprocessing`);
  }

  return new Response(JSON.stringify({
    success: true,
    analysis: analysis
  }), {
    headers: { ...corsHeaders, 'Content-Type': 'application/json' },
  });
}

async function retranscribeAllVideos(supabase: any) {
  console.log('🔄 Retranscribing all videos...');
  
  // Get all videos with transcripts that have low confidence or are missing
  const { data: videos, error } = await supabase
    .from('videos')
    .select(`
      id, title, status, video_url, user_id,
      transcripts (id, confidence)
    `)
    .in('status', ['completed', 'transcribed'])
    .order('created_at', { ascending: false });

  if (error) {
    throw new Error(`Failed to get videos: ${error.message}`);
  }

  const videosToRetranscribe = videos.filter(video => {
    // Retranscribe if no transcript or low confidence
    if (!video.transcripts || video.transcripts.length === 0) return true;
    
    const avgConfidence = video.transcripts.reduce((sum: number, t: any) => sum + (t.confidence || 0), 0) / video.transcripts.length;
    return avgConfidence < 0.8; // Retranscribe if confidence < 80%
  });

  console.log(`Found ${videosToRetranscribe.length} videos that need retranscription`);

  const results = [];

  for (const video of videosToRetranscribe) {
    try {
      console.log(`🎤 Retranscribing video: ${video.id} - ${video.title}`);
      
      // Delete existing transcript data
      await supabase.from('transcripts').delete().eq('video_id', video.id);
      await supabase.from('transcript_chunks').delete().eq('video_id', video.id);
      
      // Call transcription agent directly
      const transcriptionResult = await supabase.functions.invoke('transcription-agent-v2', {
        body: {
          videoId: video.id,
          videoUrl: video.video_url,
          userId: video.user_id,
          shouldCleanup: true,
          includeAnalysis: true
        }
      });
      
      if (transcriptionResult.error) {
        console.error(`❌ Retranscription failed for ${video.id}:`, transcriptionResult.error);
        results.push({
          id: video.id,
          title: video.title,
          status: 'failed',
          error: transcriptionResult.error.message
        });
      } else {
        console.log(`✅ Successfully retranscribed ${video.id}`);
        results.push({
          id: video.id,
          title: video.title,
          status: 'success',
          confidence: transcriptionResult.data?.confidence || 'unknown'
        });
      }
      
      // Add delay between requests
      await new Promise(resolve => setTimeout(resolve, 3000));
      
    } catch (error) {
      console.error(`❌ Error retranscribing video ${video.id}:`, error);
      results.push({
        id: video.id,
        title: video.title,
        status: 'error',
        error: error.message
      });
    }
  }

  return new Response(JSON.stringify({
    success: true,
    message: `Retranscription completed for ${videosToRetranscribe.length} videos`,
    results: results,
    summary: {
      total: videosToRetranscribe.length,
      successful: results.filter(r => r.status === 'success').length,
      failed: results.filter(r => r.status === 'failed' || r.status === 'error').length
    }
  }), {
    headers: { ...corsHeaders, 'Content-Type': 'application/json' },
  });
}