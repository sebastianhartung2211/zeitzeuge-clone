import "https://deno.land/x/xhr@0.1.0/mod.ts";
import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { videoId, videoUrl, shouldCleanup = true, shouldTranslate = false, targetLanguage = 'de', includeAnalysis = false } = await req.json();
    
    console.log('Transcription Agent processing video:', videoId);

    const supabase = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? '',
    );

    // Get video information
    const { data: video, error: videoError } = await supabase
      .from('videos')
      .select('*')
      .eq('id', videoId)
      .single();

    if (videoError) {
      throw new Error(`Video not found: ${videoError.message}`);
    }

    console.log('Video found:', video.title);

    // Step 1: Generate raw transcript (mock for now - in production use speech-to-text)
    const rawTranscript = await generateRawTranscript(videoUrl);
    
    // Step 2: Clean and structure the transcript
    const cleanedTranscript = shouldCleanup ? await cleanupTranscript(rawTranscript) : rawTranscript;
    
    // Step 3: Optional translation
    const finalTranscript = shouldTranslate ? await translateTranscript(cleanedTranscript, targetLanguage) : cleanedTranscript;
    
    // Step 4: Store transcript in database
    const { data: transcript, error: transcriptError } = await supabase
      .from('transcripts')
      .insert({
        video_id: videoId,
        content: finalTranscript,
        language: shouldTranslate ? targetLanguage : 'de',
        confidence: 0.95
      })
      .select()
      .single();

    if (transcriptError) {
      throw new Error(`Failed to create transcript: ${transcriptError.message}`);
    }

    console.log('Transcription completed:', transcript.id);

    let analysisResult = null;
    
    // Step 5: Enhanced analysis if requested (tagging and categorization)
    if (includeAnalysis) {
      console.log('Starting content analysis...');
      analysisResult = await performContentAnalysis(supabase, videoId, finalTranscript, video.title);
      console.log('Content analysis completed');
    }

    return new Response(JSON.stringify({
      success: true,
      transcriptId: transcript.id,
      content: finalTranscript,
      wasTranslated: shouldTranslate,
      wasCleaned: shouldCleanup,
      analysis: analysisResult
    }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });

  } catch (error) {
    console.error('Transcription Agent error:', error);
    return new Response(JSON.stringify({ error: error.message }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
});

async function generateRawTranscript(videoUrl: string): Promise<string> {
  // This is a mock implementation. In production, you would:
  // 1. Extract audio from video
  // 2. Use a speech-to-text service (OpenAI Whisper, Google Speech-to-Text, etc.)
  // 3. Return the raw transcript
  
  console.log('Generating raw transcript for:', videoUrl);
  
  // Mock transcript with typical speech-to-text artifacts
  return `Äh, hallo, also ich möchte heute über meine Kindheit erzählen. 
Das war so... äh... ich war damals, glaube ich, acht Jahre alt oder so. 
Meine Mutter hat immer gesagt äh dass ich sehr lebhaft war. 
Wir sind dann an den Strand gefahren, das war im Sommer neunzehnhundertzweiundachtzig oder so ähnlich. 
Äh, ja, das war wirklich schön. Mein Bruder war auch dabei und äh wir haben Sandburgen gebaut.
Das Wetter war super und äh ja das war ein toller Tag.`;
}

async function cleanupTranscript(rawTranscript: string): Promise<string> {
  const openaiKey = Deno.env.get('OPENAI_API_KEY');
  if (!openaiKey) {
    console.warn('OpenAI API key not available, returning raw transcript');
    return rawTranscript;
  }

  const prompt = `
Bereinige folgenden Transkript-Text von einem persönlichen Video:

"${rawTranscript}"

Aufgaben:
1. Entferne Füllwörter wie "äh", "ähm", "also" (aber nicht alle - behalte charakteristische bei)
2. Korrigiere offensichtliche Transkriptionsfehler
3. Verbessere die Satzstruktur, aber erhalte den persönlichen Ton
4. Vervollständige unvollständige Sätze
5. Behalte emotionale Ausdrücke und den natürlichen Sprachstil bei
6. Strukturiere in sinnvolle Absätze

Wichtig: 
- Ändere NICHT den Inhalt oder die Bedeutung
- Behalte alle Namen, Orte, Daten bei
- Der Text soll natürlich und persönlich bleiben
- Keine Dramatisierung oder Übertreibung

Gib nur den bereinigten Text zurück, ohne Kommentare.`;

  try {
    const response = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${openaiKey}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        model: 'gpt-4.1-2025-04-14',
        messages: [
          { 
            role: 'system', 
            content: 'Du bist ein sorgfältiger Texteditor, der Transkripte von persönlichen Erinnerungen bearbeitet, dabei aber den authentischen Charakter bewahrt.' 
          },
          { role: 'user', content: prompt }
        ],
        temperature: 0.2,
      }),
    });

    if (!response.ok) {
      console.warn('OpenAI cleanup failed, returning raw transcript');
      return rawTranscript;
    }

    const data = await response.json();
    const cleanedText = data.choices[0].message.content.trim();
    
    console.log('Transcript cleaned successfully');
    return cleanedText;

  } catch (error) {
    console.error('Error cleaning transcript:', error);
    return rawTranscript;
  }
}

async function translateTranscript(transcript: string, targetLanguage: string): Promise<string> {
  const openaiKey = Deno.env.get('OPENAI_API_KEY');
  if (!openaiKey) {
    console.warn('OpenAI API key not available, translation skipped');
    return transcript;
  }

  const languageNames = {
    'en': 'Englisch',
    'fr': 'Französisch', 
    'es': 'Spanisch',
    'it': 'Italienisch',
    'de': 'Deutsch'
  };

  const targetLangName = languageNames[targetLanguage as keyof typeof languageNames] || targetLanguage;

  const prompt = `
Übersetze folgenden persönlichen Erinnerungstext ins ${targetLangName}:

"${transcript}"

Wichtig:
- Behalte den persönlichen, emotionalen Ton bei
- Übersetze kulturelle Referenzen sinnvoll
- Behalte die Struktur und Absätze bei
- Achte auf natürlichen Sprachfluss in der Zielsprache
- Übersetze Namen nur wenn üblich (z.B. "München" → "Munich" für Englisch)

Gib nur die Übersetzung zurück, ohne Kommentare.`;

  try {
    const response = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${openaiKey}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        model: 'gpt-4.1-2025-04-14',
        messages: [
          { 
            role: 'system', 
            content: `Du bist ein Experte für die Übersetzung persönlicher Texte ins ${targetLangName}.` 
          },
          { role: 'user', content: prompt }
        ],
        temperature: 0.3,
      }),
    });

    if (!response.ok) {
      console.warn('Translation failed, returning original transcript');
      return transcript;
    }

    const data = await response.json();
    const translatedText = data.choices[0].message.content.trim();
    
    console.log(`Transcript translated to ${targetLanguage}`);
    return translatedText;

  } catch (error) {
    console.error('Error translating transcript:', error);
    return transcript;
  }
}

async function performContentAnalysis(supabase: any, videoId: string, transcript: string, videoTitle: string) {
  const openaiKey = Deno.env.get('OPENAI_API_KEY');
  if (!openaiKey) {
    console.warn('OpenAI API key not available, skipping content analysis');
    return null;
  }

  try {
    // Step 1: Generate tags and categorization using both video title and transcript
    const analysisPrompt = `
Analysiere folgenden persönlichen Video-Inhalt und erstelle strukturierte Metadaten:

URSPRÜNGLICHE FRAGE/TITEL: "${videoTitle}"
TRANSKRIPT DER ANTWORT: "${transcript}"

Erstelle basierend auf BEIDEN Informationen (Frage UND Antwort):

1. Tags (Schlagwörter): 5-10 relevante Tags, die sowohl die Frage als auch die Antwort beschreiben
   - Berücksichtige Themen aus der Frage
   - Berücksichtige spezifische Inhalte aus der Antwort
   - Verwende sowohl allgemeine als auch spezifische Tags

2. Kategorie: Eine Hauptkategorie aus folgenden Optionen:
   - Kind & Familie
   - Jugend & Schule  
   - Liebe & Beziehungen
   - Arbeit & Alltag
   - Zuhause & Traditionen
   - Zeitgeschichte & Wandel
   - Personalisierte Themen

3. Personen: Namen oder Bezeichnungen von erwähnten Personen (aus der Antwort)
4. Segmente: Teile den Antwort-Text in 2-4 logische Abschnitte mit Titel und Zeitstempel-Schätzung

Wichtig: 
- Die ursprüngliche Frage hilft dabei, den Kontext zu verstehen
- Tags sollten sowohl die Frage als auch die Antwort widerspiegeln
- Die Kategorisierung sollte sich primär nach dem Thema der Frage richten

Antworte im folgenden JSON-Format:
{
  "tags": ["tag1", "tag2", "tag3"],
  "category": "Kategoriename", 
  "persons": ["Person1", "Person2"],
  "segments": [
    {
      "title": "Segmenttitel",
      "content": "Segmentinhalt...",
      "estimated_start": 0,
      "estimated_end": 30
    }
  ]
}`;

    const response = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${openaiKey}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        model: 'gpt-4.1-2025-04-14',
        messages: [
          { 
            role: 'system', 
            content: 'Du bist ein Experte für die Analyse persönlicher Erinnerungen und erstellst strukturierte Metadaten.' 
          },
          { role: 'user', content: analysisPrompt }
        ],
        temperature: 0.3,
      }),
    });

    if (!response.ok) {
      console.warn('Content analysis failed');
      return null;
    }

    const data = await response.json();
    const analysisText = data.choices[0].message.content.trim();
    
    // Parse JSON response
    let analysis;
    try {
      analysis = JSON.parse(analysisText);
    } catch (parseError) {
      console.error('Failed to parse analysis JSON:', parseError);
      return null;
    }

    // Step 2: Store tags in database
    if (analysis.tags && analysis.tags.length > 0) {
      for (const tagName of analysis.tags) {
        // Check if tag exists, create if not
        let { data: existingTag } = await supabase
          .from('tags')
          .select('id')
          .eq('name', tagName)
          .single();

        let tagId;
        if (!existingTag) {
          const { data: newTag, error: tagError } = await supabase
            .from('tags')
            .insert({ 
              name: tagName,
              category: analysis.category 
            })
            .select('id')
            .single();

          if (tagError) {
            console.error('Error creating tag:', tagError);
            continue;
          }
          tagId = newTag.id;
        } else {
          tagId = existingTag.id;
        }

        // Link tag to video
        await supabase
          .from('video_tags')
          .insert({
            video_id: videoId,
            tag_id: tagId,
            relevance_score: 1.0
          });
      }
    }

    // Step 3: Update video category
    if (analysis.category) {
      await supabase
        .from('videos')
        .update({ category: analysis.category })
        .eq('id', videoId)
        .is('category', null);
    }

    // Step 4: Store segments
    if (analysis.segments && analysis.segments.length > 0) {
      for (const segment of analysis.segments) {
        await supabase
          .from('segments')
          .insert({
            video_id: videoId,
            title: segment.title,
            content: segment.content,
            start_time: segment.estimated_start || 0,
            end_time: segment.estimated_end || 30,
            persons_mentioned: analysis.persons || []
          });
      }
    }

    console.log('Content analysis stored successfully');
    return analysis;

  } catch (error) {
    console.error('Error in content analysis:', error);
    return null;
  }
}