import "https://deno.land/x/xhr@0.1.0/mod.ts";
import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { question, userId, action = 'answer_question' } = await req.json();
    
    console.log('🔍 Enhanced Conversation Agent processing:', { question, userId, action });

    const supabase = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? '',
    );

    switch (action) {
      case 'answer_question':
        return await handleEnhancedQuestionAnswering(supabase, question, userId);
      default:
        return await handleEnhancedQuestionAnswering(supabase, question, userId);
    }

  } catch (error) {
    console.error('❌ Enhanced Conversation Agent error:', error);
    return new Response(JSON.stringify({ error: error.message }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
});

async function handleEnhancedQuestionAnswering(supabase: any, question: string, userId: string) {
  console.log('🔎 Enhanced question answering for:', question);

  // Get all completed videos with transcripts for the user
  const { data: videos, error: videosError } = await supabase
    .from('videos')
    .select(`
      id,
      title,
      description,
      video_url,
      category,
      transcripts (
        content,
        confidence,
        language
      ),
      video_tags (
        relevance_score,
        tags (
          name,
          category
        )
      ),
      segments (
        title,
        content,
        persons_mentioned
      )
    `)
    .eq('user_id', userId)
    .eq('status', 'completed')
    .not('transcripts', 'is', null);

  if (videosError) {
    console.error('❌ Error fetching videos:', videosError);
    throw new Error(`Error fetching videos: ${videosError.message}`);
  }

  console.log(`📊 Found ${videos.length} videos with transcripts for user`);

  // Filter out videos without valid transcripts
  const validVideos = videos.filter(video => 
    video.transcripts && 
    video.transcripts.length > 0 && 
    video.transcripts[0].content && 
    video.transcripts[0].content.trim().length > 20
  );

  console.log(`✅ ${validVideos.length} videos have valid transcripts`);

  if (validVideos.length === 0) {
    await storeConversation(supabase, userId, question, 
      'Entschuldigung, ich konnte keine Videos mit auswertbaren Inhalten finden. Versuchen Sie es später erneut oder fügen Sie neue Videos hinzu.', 
      null, 0.0);

    return new Response(JSON.stringify({ 
      answer: 'Entschuldigung, ich konnte keine Videos mit auswertbaren Inhalten finden.',
      videoId: null,
      confidence: 0.0,
      debug: {
        totalVideos: videos.length,
        validVideos: validVideos.length,
        reason: 'No valid transcripts found'
      }
    }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }

  // Enhanced multi-stage matching
  const matchingResult = await findBestMatchEnhanced(question, validVideos);

  if (!matchingResult || matchingResult.confidence < 0.6) {
    const noMatchAnswer = `Entschuldigung, ich konnte kein gut passendes Video zu Ihrer Frage "${question}" finden. Die verfügbaren Videos behandeln andere Themen. Vielleicht können Sie Ihre Frage anders formulieren?`;
    
    await storeConversation(supabase, userId, question, noMatchAnswer, null, matchingResult?.confidence || 0.0);

    return new Response(JSON.stringify({ 
      answer: noMatchAnswer,
      videoId: null,
      confidence: matchingResult?.confidence || 0.0,
      debug: {
        reason: 'Confidence too low',
        confidence: matchingResult?.confidence,
        threshold: 0.6,
        candidates: matchingResult?.candidates || 0
      }
    }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }

  // Generate contextualized response
  const answer = await generateEnhancedResponse(question, matchingResult.video, matchingResult.reasoning);

  // Store conversation
  await storeConversation(supabase, userId, question, answer, matchingResult.video.id, matchingResult.confidence);

  console.log('✅ Enhanced conversation completed, matched video:', matchingResult.video.title, 'confidence:', matchingResult.confidence);

  return new Response(JSON.stringify({ 
    answer: answer,
    videoId: matchingResult.video.id,
    videoUrl: matchingResult.video.video_url,
    videoTitle: matchingResult.video.title,
    confidence: matchingResult.confidence,
    debug: {
      reasoning: matchingResult.reasoning,
      matchedContent: matchingResult.matchedContent?.substring(0, 200) + '...',
      category: matchingResult.video.category
    }
  }), {
    headers: { ...corsHeaders, 'Content-Type': 'application/json' },
  });
}

async function findBestMatchEnhanced(question: string, videos: any[]): Promise<any> {
  console.log('🎯 Enhanced matching with', videos.length, 'videos');

  // Stage 1: Semantic + Keyword Pre-filtering
  const semanticCandidates = await performSemanticPrefiltering(question, videos);
  console.log('📋 Semantic pre-filtering found', semanticCandidates.length, 'candidates');

  if (semanticCandidates.length === 0) {
    return null;
  }

  // Stage 2: LLM-based deep matching with context
  const finalMatch = await performLLMMatching(question, semanticCandidates);
  
  return finalMatch;
}

async function performSemanticPrefiltering(question: string, videos: any[]): Promise<any[]> {
  // Normalize question for keyword matching
  const questionNormalized = question.toLowerCase()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '') // Remove diacritics
    .replace(/[^\w\s]/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();

  const questionKeywords = questionNormalized.split(' ').filter(word => word.length > 2);
  
  // Score videos based on multiple factors
  const scoredVideos = videos.map(video => {
    let score = 0;
    const transcript = video.transcripts[0]?.content || '';
    const title = video.title || '';
    const category = video.category || '';
    
    // Normalize all text fields
    const transcriptNorm = transcript.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '');
    const titleNorm = title.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '');
    const categoryNorm = category.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '');
    
    // Title matching (highest weight)
    const titleWords = titleNorm.split(/\s+/);
    const titleMatches = questionKeywords.filter(keyword => 
      titleWords.some(word => word.includes(keyword) || keyword.includes(word))
    ).length;
    score += titleMatches * 10;
    
    // Exact phrase matching in title
    if (titleNorm.includes(questionNormalized)) {
      score += 50;
    }
    
    // Content matching
    const contentMatches = questionKeywords.filter(keyword => 
      transcriptNorm.includes(keyword)
    ).length;
    score += contentMatches * 3;
    
    // Category matching
    const categoryMatches = questionKeywords.filter(keyword => 
      categoryNorm.includes(keyword)
    ).length;
    score += categoryMatches * 5;
    
    // Tag matching
    if (video.video_tags && video.video_tags.length > 0) {
      const tagScore = video.video_tags.reduce((acc: number, vt: any) => {
        const tagName = (vt.tags?.name || '').toLowerCase();
        const tagMatches = questionKeywords.filter(keyword => 
          tagName.includes(keyword)
        ).length;
        return acc + (tagMatches * (vt.relevance_score || 1) * 2);
      }, 0);
      score += tagScore;
    }
    
    // Length penalty for very short transcripts (likely invalid)
    if (transcript.length < 50) {
      score *= 0.1;
    }
    
    return {
      ...video,
      matchScore: score,
      titleMatches,
      contentMatches,
      categoryMatches
    };
  });

  // Return top candidates with score > 0
  return scoredVideos
    .filter(video => video.matchScore > 0)
    .sort((a, b) => b.matchScore - a.matchScore)
    .slice(0, 8); // Top 8 candidates for LLM evaluation
}

async function performLLMMatching(question: string, candidates: any[]): Promise<any> {
  if (candidates.length === 0) {
    return null;
  }

  // If only one candidate, check if it's good enough
  if (candidates.length === 1) {
    const confidence = Math.min(0.9, candidates[0].matchScore / 20);
    if (confidence >= 0.6) {
      return {
        video: candidates[0],
        confidence: confidence,
        reasoning: 'Single strong candidate found',
        matchedContent: candidates[0].transcripts[0]?.content,
        candidates: 1
      };
    }
  }

  const candidatesInfo = candidates.map((video, index) => {
    const transcript = video.transcripts[0]?.content || '';
    const tags = video.video_tags?.map((vt: any) => vt.tags?.name).filter(Boolean).join(', ') || '';
    
    return `Kandidat ${index + 1}:
Titel: ${video.title}
Kategorie: ${video.category || 'Unbekannt'}
Tags: ${tags}
Vorab-Score: ${video.matchScore.toFixed(1)}
Inhalt: ${transcript.substring(0, 400)}...
`;
  }).join('\n\n');

  const prompt = `Du bist ein Experte für die Zuordnung von Nutzerfragen zu passenden Video-Antworten in einem Familienerinnerungs-System.

NUTZERFRAGE: "${question}"

KANDIDATEN-VIDEOS:
${candidatesInfo}

AUFGABE:
Analysiere, welches Video am besten zur Nutzerfrage passt. Berücksichtige:
1. Inhaltliche Relevanz - Beantwortet das Video die gestellte Frage?
2. Thematische Übereinstimmung - Passt das Thema des Videos zur Frage?
3. Spezifität - Wie gut adressiert der Videoinhalt die spezifische Frage?
4. Qualität des Inhalts - Ist der Transcript aussagekräftig und vollständig?

ANTWORT-FORMAT (NUR JSON):
{
  "bestCandidateIndex": 0,
  "confidence": 0.85,
  "reasoning": "Kurze präzise Begründung warum dieser Kandidat am besten passt",
  "relevantQuote": "Relevantes Zitat aus dem Transcript"
}

BEWERTUNGSSKALA:
- 0.9-1.0: Perfekte Übereinstimmung
- 0.7-0.9: Sehr gute Übereinstimmung  
- 0.6-0.7: Gute Übereinstimmung
- 0.4-0.6: Mäßige Übereinstimmung
- <0.4: Schlechte/keine Übereinstimmung

WICHTIG: 
- Wenn kein Video gut zur Frage passt, setze confidence < 0.6
- Bevorzuge Videos mit spezifischen, relevanten Inhalten
- Berücksichtige auch den Titel als wichtigen Indikator`;

  try {
    const response = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${Deno.env.get('OPENAI_API_KEY')}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        model: 'gpt-4.1-2025-04-14',
        messages: [
          { 
            role: 'system', 
            content: 'Du bist ein Experte für semantische Ähnlichkeit und Video-Matching. Antworte nur mit dem angeforderten JSON-Format.' 
          },
          { role: 'user', content: prompt }
        ],
        temperature: 0.1,
        max_tokens: 300,
      }),
    });

    if (!response.ok) {
      console.error('❌ OpenAI API error during enhanced matching');
      // Fallback to pre-filtering score
      return {
        video: candidates[0],
        confidence: Math.min(0.8, candidates[0].matchScore / 25),
        reasoning: 'Fallback to semantic pre-filtering score',
        matchedContent: candidates[0].transcripts[0]?.content,
        candidates: candidates.length
      };
    }

    const result = await response.json();
    const content = result.choices[0].message.content;

    const jsonMatch = content.match(/\{[^}]+\}/s);
    if (!jsonMatch) {
      throw new Error('No JSON found in LLM response');
    }

    const matchResult = JSON.parse(jsonMatch[0]);
    
    if (matchResult.bestCandidateIndex < 0 || matchResult.bestCandidateIndex >= candidates.length) {
      throw new Error('Invalid candidate index');
    }

    const selectedVideo = candidates[matchResult.bestCandidateIndex];
    
    return {
      video: selectedVideo,
      confidence: matchResult.confidence,
      reasoning: matchResult.reasoning,
      relevantQuote: matchResult.relevantQuote,
      matchedContent: selectedVideo.transcripts[0]?.content,
      candidates: candidates.length
    };

  } catch (error) {
    console.error('❌ Error in LLM matching:', error);
    // Fallback to highest scoring candidate
    return {
      video: candidates[0],
      confidence: Math.min(0.8, candidates[0].matchScore / 25),
      reasoning: 'Fallback: Highest pre-filtering score',
      matchedContent: candidates[0].transcripts[0]?.content,
      candidates: candidates.length
    };
  }
}

async function generateEnhancedResponse(question: string, matchingVideo: any, reasoning: string): Promise<string> {
  console.log('📝 Generating enhanced response');

  const transcript = matchingVideo.transcripts[0]?.content || '';
  const tags = matchingVideo.video_tags?.map((vt: any) => vt.tags?.name).filter(Boolean).join(', ') || '';
  const category = matchingVideo.category || '';

  const prompt = `Du erstellst eine persönliche, warmherzige Antwort für ein Familienerinnerungs-System.

NUTZERFRAGE: "${question}"

PASSENDES VIDEO:
Titel: ${matchingVideo.title}
Kategorie: ${category}
Tags: ${tags}
Inhalt: ${transcript.substring(0, 600)}

MATCHING-GRUND: ${reasoning}

AUFGABE:
Erstelle eine natürliche, persönliche Antwort (maximal 120 Wörter), die:
1. Die Frage direkt beantwortet/anspricht
2. Kurz erklärt, warum dieses Video relevant ist
3. Den Nutzer ermutigt, das Video anzuschauen
4. Warm und familiär klingt
5. Bezug zum gefundenen Inhalt nimmt

STIL:
- Warm und persönlich
- Wie ein Familienmitglied oder enger Freund
- Auf Deutsch
- Ermutigend und interessant
- Nicht zu technisch

Beispiel-Anfang: "Das ist eine schöne Frage! Ich habe ein Video gefunden, das..."`;

  try {
    const response = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${Deno.env.get('OPENAI_API_KEY')}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        model: 'gpt-4.1-2025-04-14',
        messages: [
          { 
            role: 'system', 
            content: 'Du bist ein warmherziger Assistent für ein Familienerinnerungs-System. Erstelle persönliche, einladende Antworten auf Deutsch.' 
          },
          { role: 'user', content: prompt }
        ],
        temperature: 0.7,
        max_tokens: 200,
      }),
    });

    if (!response.ok) {
      console.warn('⚠️ OpenAI response generation failed, using fallback');
      return `Das ist eine interessante Frage! Ich habe ein passendes Video gefunden: "${matchingVideo.title}". Es behandelt genau das Thema, nach dem Sie gesucht haben. Schauen Sie es sich gerne an - ich bin mir sicher, dass Sie interessante Einblicke und schöne Erinnerungen finden werden!`;
    }

    const result = await response.json();
    return result.choices[0].message.content.trim();

  } catch (error) {
    console.error('❌ Error generating enhanced response:', error);
    return `Ich habe ein passendes Video zu Ihrer Frage gefunden: "${matchingVideo.title}". Es passt gut zu dem, wonach Sie gesucht haben. Schauen Sie es sich gerne an!`;
  }
}

async function storeConversation(supabase: any, userId: string, question: string, answer: string, videoId: string | null, confidence: number) {
  try {
    await supabase
      .from('conversations')
      .insert({
        user_id: userId,
        question: question,
        answer: answer,
        matched_video_id: videoId,
        confidence_score: confidence
      });
  } catch (error) {
    console.error('❌ Error storing conversation:', error);
  }
}