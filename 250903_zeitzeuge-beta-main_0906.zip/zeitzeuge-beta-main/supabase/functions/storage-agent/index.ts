import "https://deno.land/x/xhr@0.1.0/mod.ts";
import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { videoId, userId } = await req.json();
    
    console.log('Storage Agent processing video:', videoId);

    const supabase = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? '',
    );

    // Create dedicated folder structure
    const folderStructure = await createFolderStructure(userId, videoId);
    
    // Organize and upload processed files
    const uploadResults = await organizeProcessedFiles(supabase, videoId, folderStructure);
    
    // Check for duplicates
    const duplicateCheck = await checkForDuplicates(supabase, videoId, userId);
    
    // Handle any storage errors
    await handleStorageErrors(supabase, uploadResults);
    
    console.log('Storage Agent completed processing');

    return new Response(JSON.stringify({
      success: true,
      folderStructure,
      uploadResults,
      duplicateCheck
    }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });

  } catch (error) {
    console.error('Storage Agent error:', error);
    return new Response(JSON.stringify({ error: error.message }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
});

async function createFolderStructure(userId: string, videoId: string): Promise<any> {
  const timestamp = new Date().toISOString().split('T')[0]; // YYYY-MM-DD
  
  const structure = {
    baseFolder: `users/${userId}`,
    sessionFolder: `users/${userId}/sessions/${timestamp}`,
    videoFolder: `users/${userId}/sessions/${timestamp}/${videoId}`,
    subFolders: {
      original: `users/${userId}/sessions/${timestamp}/${videoId}/original`,
      processed: `users/${userId}/sessions/${timestamp}/${videoId}/processed`, 
      transcripts: `users/${userId}/sessions/${timestamp}/${videoId}/transcripts`,
      segments: `users/${userId}/sessions/${timestamp}/${videoId}/segments`,
      metadata: `users/${userId}/sessions/${timestamp}/${videoId}/metadata`
    }
  };
  
  console.log('Created folder structure:', structure);
  return structure;
}

async function organizeProcessedFiles(supabase: any, videoId: string, folderStructure: any): Promise<any> {
  const uploadResults = {
    successful: [],
    failed: [],
    skipped: []
  };

  try {
    // Get video data
    const { data: video } = await supabase
      .from('videos')
      .select('*, transcripts(*), segments(*)')
      .eq('id', videoId)
      .single();

    if (!video) {
      throw new Error('Video not found');
    }

    // Check if original video file already exists in storage
    if (video.video_url) {
      console.log('Original video already in storage:', video.video_url);
      uploadResults.skipped.push({
        type: 'original_video',
        reason: 'already_exists',
        url: video.video_url
      });
    }

    // Process transcripts - check if they are already in user folder structure
    if (video.transcripts && video.transcripts.length > 0) {
      for (const transcript of video.transcripts) {
        try {
          const fileName = `transcript_${transcript.id}.json`;
          const filePath = `${folderStructure.subFolders.transcripts}/${fileName}`;
          
          // Check if transcript already exists in user folder structure
          const { data: existingFile } = await supabase.storage
            .from('transcripts')
            .list(folderStructure.subFolders.transcripts);

          const transcriptExists = existingFile?.some(file => file.name === fileName);

          if (transcriptExists) {
            uploadResults.skipped.push({
              type: 'transcript',
              id: transcript.id,
              path: filePath,
              reason: 'already_exists_in_user_folder'
            });
          } else {
            // Get detailed transcript with segments from storage
            const timestamp = new Date().toISOString().split('T')[0];
            const detailedTranscriptPath = `users/${video.user_id}/sessions/${timestamp}/${videoId}/transcripts/transcript_${transcript.id}.json`;
            
            const { data: detailedFile } = await supabase.storage
              .from('transcripts')
              .download(detailedTranscriptPath);

            if (detailedFile) {
              uploadResults.successful.push({
                type: 'transcript',
                id: transcript.id,
                path: detailedTranscriptPath,
                note: 'already_in_correct_location'
              });
            } else {
              uploadResults.failed.push({
                type: 'transcript',
                id: transcript.id,
                error: 'detailed_transcript_not_found'
              });
            }
          }
        } catch (error) {
          uploadResults.failed.push({
            type: 'transcript',
            id: transcript.id,
            error: error.message
          });
        }
      }
    }

    // Process segments
    if (video.segments && video.segments.length > 0) {
      const segmentsData = {
        videoId: videoId,
        segments: video.segments,
        created_at: new Date().toISOString()
      };

      try {
        const fileName = `segments_${videoId}.json`;
        const filePath = `${folderStructure.subFolders.segments}/${fileName}`;
        
        const { data, error } = await supabase.storage
          .from('transcripts') // Using transcripts bucket for now
          .upload(filePath, new Blob([JSON.stringify(segmentsData, null, 2)], { type: 'application/json' }), {
            cacheControl: '3600',
            upsert: true
          });

        if (error) {
          uploadResults.failed.push({
            type: 'segments',
            error: error.message
          });
        } else {
          uploadResults.successful.push({
            type: 'segments',
            path: filePath
          });
        }
      } catch (error) {
        uploadResults.failed.push({
          type: 'segments',
          error: error.message
        });
      }
    }

    // Create metadata file
    try {
      const metadataContent = {
        videoId: videoId,
        userId: video.user_id,
        title: video.title,
        description: video.description,
        category: video.category,
        custom_date: video.custom_date,
        duration: video.duration,
        status: video.status,
        processing_completed_at: new Date().toISOString(),
        folder_structure: folderStructure
      };

      const fileName = `metadata_${videoId}.json`;
      const filePath = `${folderStructure.subFolders.metadata}/${fileName}`;
      
      const { data, error } = await supabase.storage
        .from('transcripts')
        .upload(filePath, new Blob([JSON.stringify(metadataContent, null, 2)], { type: 'application/json' }), {
          cacheControl: '3600',
          upsert: true
        });

      if (error) {
        uploadResults.failed.push({
          type: 'metadata',
          error: error.message
        });
      } else {
        uploadResults.successful.push({
          type: 'metadata',
          path: filePath
        });
      }
    } catch (error) {
      uploadResults.failed.push({
        type: 'metadata',
        error: error.message
      });
    }

  } catch (error) {
    console.error('Error organizing files:', error);
    uploadResults.failed.push({
      type: 'general',
      error: error.message
    });
  }

  return uploadResults;
}

async function checkForDuplicates(supabase: any, videoId: string, userId: string): Promise<any> {
  try {
    // Get current video
    const { data: currentVideo } = await supabase
      .from('videos')
      .select('title, duration, created_at')
      .eq('id', videoId)
      .single();

    if (!currentVideo) {
      return { checked: false, error: 'Video not found' };
    }

    // Look for potential duplicates based on title similarity and duration
    const { data: potentialDuplicates } = await supabase
      .from('videos')
      .select('id, title, duration, created_at')
      .eq('user_id', userId)
      .neq('id', videoId);

    if (!potentialDuplicates || potentialDuplicates.length === 0) {
      return { 
        checked: true, 
        duplicates: [], 
        message: 'No potential duplicates found' 
      };
    }

    const duplicates = [];
    
    for (const video of potentialDuplicates) {
      let similarity = 0;
      
      // Check title similarity (simple approach)
      if (video.title && currentVideo.title) {
        const titleSimilarity = calculateSimpleSimilarity(
          video.title.toLowerCase(), 
          currentVideo.title.toLowerCase()
        );
        similarity += titleSimilarity * 0.6;
      }
      
      // Check duration similarity
      if (video.duration && currentVideo.duration) {
        const durationDiff = Math.abs(video.duration - currentVideo.duration);
        const durationSimilarity = Math.max(0, 1 - (durationDiff / Math.max(video.duration, currentVideo.duration)));
        similarity += durationSimilarity * 0.4;
      }
      
      // If similarity is high, consider it a potential duplicate
      if (similarity > 0.7) {
        duplicates.push({
          id: video.id,
          title: video.title,
          similarity: similarity,
          created_at: video.created_at
        });
      }
    }

    return {
      checked: true,
      duplicates: duplicates,
      message: duplicates.length > 0 ? `Found ${duplicates.length} potential duplicate(s)` : 'No duplicates found'
    };

  } catch (error) {
    console.error('Error checking duplicates:', error);
    return { 
      checked: false, 
      error: error.message 
    };
  }
}

function calculateSimpleSimilarity(str1: string, str2: string): number {
  const words1 = str1.split(' ');
  const words2 = str2.split(' ');
  const allWords = new Set([...words1, ...words2]);
  const intersection = words1.filter(word => words2.includes(word));
  
  return intersection.length / allWords.size;
}

async function handleStorageErrors(supabase: any, uploadResults: any): Promise<void> {
  if (uploadResults.failed && uploadResults.failed.length > 0) {
    console.warn('Storage errors detected:', uploadResults.failed);
    
    // Could implement retry logic here
    // Could send notifications about failed uploads
    // Could update video status to indicate partial success
    
    // For now, just log the errors
    for (const failure of uploadResults.failed) {
      console.error('Upload failed:', failure);
    }
  }
}