import 'jsr:@supabase/functions-js/edge-runtime.d.ts'
import { createClient } from 'jsr:@supabase/supabase-js@2'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

Deno.serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const SUPABASE_URL = Deno.env.get('SUPABASE_URL')!;
    const SUPABASE_ANON = Deno.env.get('SUPABASE_ANON_KEY')!;
    const SERVICE_ROLE = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;

    // Verify user from Authorization header
    const authHeader = req.headers.get('Authorization') ?? '';
    const supa = createClient(SUPABASE_URL, SUPABASE_ANON, { 
      global: { headers: { Authorization: authHeader } } 
    });
    
    const { data: { user }, error: userErr } = await supa.auth.getUser();
    if (userErr || !user) {
      console.error('Authentication failed:', userErr);
      return new Response(
        JSON.stringify({ error: 'Unauthorized' }), 
        { status: 401, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    console.log(`Authenticated user: ${user.id}`);

    const { bucket, objectKey, contentType } = await req.json();
    
    console.log(`Creating signed upload URL for ${bucket}/${objectKey}`);

    // Validate required parameters
    if (!bucket || !objectKey || !contentType) {
      return new Response(
        JSON.stringify({ error: 'Missing required parameters: bucket, objectKey, contentType' }), 
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Enforce prefix: user.id/
    if (!objectKey.startsWith(`${user.id}/`)) {
      console.error(`Invalid objectKey: ${objectKey}, must start with ${user.id}/`);
      return new Response(
        JSON.stringify({ error: 'Invalid objectKey - must be scoped to user' }), 
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Create signed upload URL using SERVICE_ROLE
    const res = await fetch(`${SUPABASE_URL}/storage/v1/object/sign/${bucket}/${objectKey}`, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${SERVICE_ROLE}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        method: 'PUT',
        expiresIn: 60 * 15, // 15 minutes
        contentType
      })
    });

    if (!res.ok) {
      const errorText = await res.text();
      console.error('Failed to create signed URL:', errorText);
      return new Response(
        JSON.stringify({ error: 'Failed to create signed upload URL' }), 
        { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const json = await res.json();
    
    const response = {
      url: json.signedUrl,
      headers: { 
        'Content-Type': contentType,
        'x-amz-acl': 'bucket-owner-full-control'
      }
    };

    console.log(`Successfully created signed upload URL for user ${user.id}`);
    
    return new Response(JSON.stringify(response), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' }
    });
    
  } catch (e) {
    console.error('Error in create-upload-url function:', e);
    return new Response(
      JSON.stringify({ error: String(e) }), 
      { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});