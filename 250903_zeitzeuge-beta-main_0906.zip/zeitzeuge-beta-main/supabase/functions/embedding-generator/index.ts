import "https://deno.land/x/xhr@0.1.0/mod.ts";
import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

const CONFIG = {
  EMBEDDING_MODEL: 'text-embedding-3-small',
  CHUNK_SIZE: 512,
  CHUNK_OVERLAP: 0.15,
  MAX_CHUNKS_PER_VIDEO: 10,
  BATCH_SIZE: 5,
  MIN_CHUNK_WORDS: 10
};

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { action = 'generate_embeddings', userId, videoIds } = await req.json();
    
    console.log('🔧 Embedding Generator:', { action, userId, videoIds });

    const supabase = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? '',
    );

    switch (action) {
      case 'generate_embeddings':
        return await handleEmbeddingGeneration(supabase, userId, videoIds);
      case 'regenerate_embeddings':
        return await handleEmbeddingRegeneration(supabase, userId, videoIds);
      case 'check_status':
        return await handleStatusCheck(supabase, userId);
      default:
        return await handleEmbeddingGeneration(supabase, userId, videoIds);
    }

  } catch (error) {
    console.error('❌ Embedding Generator error:', error);
    return new Response(JSON.stringify({ 
      error: error.message,
      service: 'embedding-generator'
    }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
});

async function handleEmbeddingGeneration(supabase: any, userId: string, videoIds?: string[]) {
  console.log('🔧 Starting embedding generation...');
  
  try {
    // Get videos to process
    let videosQuery = supabase
      .from('videos')
      .select(`
        id,
        title,
        transcripts (id, content)
      `)
      .eq('user_id', userId)
      .eq('status', 'completed')
      .not('transcripts', 'is', null);

    if (videoIds && videoIds.length > 0) {
      videosQuery = videosQuery.in('id', videoIds);
    }

    const { data: videos, error: videosError } = await videosQuery;

    if (videosError) throw videosError;

    let processed = 0;
    let chunksCreated = 0;
    let skipped = 0;
    let errors = 0;

    console.log(`📊 Processing ${videos?.length || 0} videos for embeddings`);

    for (const video of videos || []) {
      try {
        if (!video.transcripts || video.transcripts.length === 0) {
          console.log(`⏭️ Skipping ${video.title} - no transcript`);
          skipped++;
          continue;
        }
        
        const transcript = video.transcripts[0];
        
        // Check if chunks already exist
        const { data: existingChunks } = await supabase
          .from('transcript_chunks')
          .select('id')
          .eq('video_id', video.id)
          .limit(1);

        if (existingChunks && existingChunks.length > 0) {
          console.log(`⏭️ Skipping ${video.title} - chunks already exist`);
          skipped++;
          continue;
        }

        // Generate optimized chunks
        const chunks = createOptimizedChunks(transcript.content);
        console.log(`📝 Created ${chunks.length} chunks for "${video.title}"`);

        // Process chunks in batches
        const chunkBatches = [];
        for (let i = 0; i < chunks.length; i += CONFIG.BATCH_SIZE) {
          chunkBatches.push(chunks.slice(i, i + CONFIG.BATCH_SIZE));
        }

        let videoChunksCreated = 0;
        for (const batch of chunkBatches) {
          const batchResults = await Promise.allSettled(
            batch.map(chunk => processChunk(supabase, video.id, transcript.id, chunk))
          );

          for (const result of batchResults) {
            if (result.status === 'fulfilled' && result.value) {
              videoChunksCreated++;
              chunksCreated++;
            } else if (result.status === 'rejected') {
              console.error('Chunk processing error:', result.reason);
              errors++;
            }
          }

          // Rate limiting between batches
          await new Promise(resolve => setTimeout(resolve, 200));
        }

        console.log(`✅ Processed ${video.title}: ${videoChunksCreated}/${chunks.length} chunks`);
        processed++;

      } catch (error) {
        console.error(`❌ Error processing video ${video.title}:`, error);
        errors++;
      }
    }

    // Log performance metrics
    await logPerformanceMetrics(supabase, {
      operation: 'embedding_generation',
      videosProcessed: processed,
      chunksCreated,
      videosSkipped: skipped,
      errors,
      userId
    });

    const response = {
      success: true,
      processed,
      chunksCreated,
      skipped,
      errors,
      message: `Generated embeddings for ${processed} videos with ${chunksCreated} chunks`
    };

    console.log('📊 Embedding generation completed:', response);

    return new Response(JSON.stringify(response), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });

  } catch (error) {
    console.error('❌ Embedding generation failed:', error);
    return new Response(JSON.stringify({ 
      error: error.message,
      service: 'embedding-generator'
    }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
}

async function handleEmbeddingRegeneration(supabase: any, userId: string, videoIds?: string[]) {
  console.log('🔄 Starting embedding regeneration...');
  
  try {
    // Delete existing chunks first
    let deleteQuery = supabase
      .from('transcript_chunks')
      .delete();

    if (videoIds && videoIds.length > 0) {
      deleteQuery = deleteQuery.in('video_id', videoIds);
    } else {
      // Get user's video IDs first
      const { data: userVideos } = await supabase
        .from('videos')
        .select('id')
        .eq('user_id', userId);
      
      if (userVideos) {
        deleteQuery = deleteQuery.in('video_id', userVideos.map(v => v.id));
      }
    }

    const { error: deleteError } = await deleteQuery;
    if (deleteError) {
      console.warn('⚠️ Error deleting existing chunks:', deleteError);
    } else {
      console.log('🗑️ Deleted existing chunks for regeneration');
    }

    // Now generate new embeddings
    return await handleEmbeddingGeneration(supabase, userId, videoIds);

  } catch (error) {
    console.error('❌ Embedding regeneration failed:', error);
    return new Response(JSON.stringify({ 
      error: error.message,
      service: 'embedding-generator'
    }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
}

async function handleStatusCheck(supabase: any, userId: string) {
  try {
    // Get video and chunk counts
    const { data: videos } = await supabase
      .from('videos')
      .select('id, title')
      .eq('user_id', userId)
      .eq('status', 'completed');

    const videoIds = videos?.map(v => v.id) || [];
    
    const { data: chunks } = await supabase
      .from('transcript_chunks')
      .select('video_id, id')
      .in('video_id', videoIds);

    const chunksByVideo = chunks?.reduce((acc, chunk) => {
      acc[chunk.video_id] = (acc[chunk.video_id] || 0) + 1;
      return acc;
    }, {} as Record<string, number>) || {};

    const status = {
      totalVideos: videos?.length || 0,
      videosWithEmbeddings: Object.keys(chunksByVideo).length,
      totalChunks: chunks?.length || 0,
      avgChunksPerVideo: chunks?.length ? chunks.length / Object.keys(chunksByVideo).length : 0,
      videos: videos?.map(v => ({
        id: v.id,
        title: v.title,
        chunks: chunksByVideo[v.id] || 0,
        hasEmbeddings: !!chunksByVideo[v.id]
      })) || []
    };

    return new Response(JSON.stringify(status), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });

  } catch (error) {
    console.error('❌ Status check failed:', error);
    return new Response(JSON.stringify({ 
      error: error.message,
      service: 'embedding-generator'
    }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
}

function createOptimizedChunks(text: string) {
  if (!text || text.trim().length === 0) {
    return [];
  }

  // Split into sentences while preserving punctuation
  const sentences = text
    .split(/[.!?]+/)
    .map(s => s.trim())
    .filter(s => s.length > 0)
    .map(s => s + '.');

  const chunks = [];
  const chunkSize = CONFIG.CHUNK_SIZE;
  const overlapSize = Math.floor(chunkSize * CONFIG.CHUNK_OVERLAP);
  
  let currentChunk = '';
  let chunkStart = 0;
  let sentenceIndex = 0;
  
  for (const sentence of sentences) {
    const potentialChunk = currentChunk + (currentChunk ? ' ' : '') + sentence;
    
    if (potentialChunk.length > chunkSize && currentChunk.length > 0) {
      // Save current chunk
      const wordCount = currentChunk.split(/\s+/).length;
      if (wordCount >= CONFIG.MIN_CHUNK_WORDS) {
        chunks.push({
          content: currentChunk.trim(),
          startTime: chunkStart,
          endTime: sentenceIndex,
          wordCount: wordCount
        });
      }
      
      // Start new chunk with overlap
      const words = currentChunk.split(/\s+/);
      const overlapWords = words.slice(-Math.min(overlapSize, words.length));
      currentChunk = overlapWords.join(' ') + ' ' + sentence;
      chunkStart = Math.max(0, sentenceIndex - overlapWords.length);
    } else {
      currentChunk = potentialChunk;
    }
    
    sentenceIndex++;
  }
  
  // Add final chunk
  if (currentChunk.trim().length > 0) {
    const wordCount = currentChunk.split(/\s+/).length;
    if (wordCount >= CONFIG.MIN_CHUNK_WORDS) {
      chunks.push({
        content: currentChunk.trim(),
        startTime: chunkStart,
        endTime: sentenceIndex,
        wordCount: wordCount
      });
    }
  }
  
  // Limit chunks per video to avoid overconsumption
  return chunks.slice(0, CONFIG.MAX_CHUNKS_PER_VIDEO);
}

async function processChunk(supabase: any, videoId: string, transcriptId: string, chunk: any) {
  try {
    // Generate embedding
    const embedding = await generateEmbedding(chunk.content);
    
    if (!embedding || embedding.length === 0) {
      console.warn('⚠️ Empty embedding generated, skipping chunk');
      return false;
    }
    
    // Store chunk with embedding
    const { error } = await supabase
      .from('transcript_chunks')
      .insert({
        video_id: videoId,
        transcript_id: transcriptId,
        content: chunk.content,
        start_time: chunk.startTime,
        end_time: chunk.endTime,
        embedding_json: embedding
      });

    if (error) {
      console.error('❌ Error storing chunk:', error);
      return false;
    }
    
    return true;
    
  } catch (error) {
    console.error('❌ Error processing chunk:', error);
    return false;
  }
}

async function generateEmbedding(text: string): Promise<number[]> {
  try {
    const response = await fetch('https://api.openai.com/v1/embeddings', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${Deno.env.get('OPENAI_API_KEY')}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        model: CONFIG.EMBEDDING_MODEL,
        input: text.substring(0, 8192), // Ensure token limit compliance
        dimensions: 1536
      }),
    });

    if (!response.ok) {
      const errorText = await response.text();
      console.error('❌ OpenAI API error:', response.status, errorText);
      throw new Error(`Embedding API error: ${response.status} - ${errorText}`);
    }

    const result = await response.json();
    const embedding = result.data[0]?.embedding;
    
    if (!embedding || !Array.isArray(embedding)) {
      throw new Error('Invalid embedding response from API');
    }
    
    return embedding;
    
  } catch (error) {
    console.error('❌ Error generating embedding:', error);
    // Return zero vector as fallback
    return new Array(1536).fill(0);
  }
}

async function logPerformanceMetrics(supabase: any, metrics: any) {
  try {
    await supabase
      .from('processing_logs')
      .insert({
        video_id: null,
        agent_name: 'embedding-generator',
        stage: 'embedding_generation',
        status: 'completed',
        processing_time_ms: null,
        output_data: {
          ...metrics,
          timestamp: new Date().toISOString()
        }
      });
  } catch (error) {
    console.warn('⚠️ Failed to log performance metrics:', error);
  }
}