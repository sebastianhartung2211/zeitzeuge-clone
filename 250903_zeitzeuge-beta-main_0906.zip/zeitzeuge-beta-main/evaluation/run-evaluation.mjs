#!/usr/bin/env node

import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Configuration
const SUPABASE_URL = 'https://fepcoqrfrkfiaftkkfht.supabase.co';
const SUPABASE_ANON_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImZlcGNvcXJmcmtmaWFmdGtrZmh0Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTMxNDU4NjUsImV4cCI6MjA2ODcyMTg2NX0.EA3jUpmXSlnMh_YYGNo3yWtZEcBdZ7JkRDSlSjALGdc';
const USER_ID = 'e188dfde-b523-4b15-889a-8ba2d32e6aec';

async function runEvaluation() {
  console.log('🧪 Starting Pipeline Evaluation...');
  console.log('Timestamp:', new Date().toISOString());
  
  // Load testset
  const testsetPath = path.join(__dirname, 'testset.json');
  const testset = JSON.parse(fs.readFileSync(testsetPath, 'utf8'));
  
  const results = [];
  const csvLines = ['test_id,question,expected_video_id,predicted_video_id,score,hit@1,latency_ms,timestamp'];
  
  for (const testCase of testset) {
    const startTime = Date.now();
    
    try {
      console.log(`\n🔍 Testing: "${testCase.question}"`);
      
      const response = await fetch(`${SUPABASE_URL}/functions/v1/conversation-agent-v3`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${SUPABASE_ANON_KEY}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          question: testCase.question,
          userId: USER_ID,
          action: 'answer_question'
        })
      });
      
      const latency = Date.now() - startTime;
      const data = await response.json();
      
      const confidence = data.confidence || 0;
      const predictedTitle = data.videoTitle || null;
      
      // Evaluate hit@1
      let hit = 0;
      if (testCase.expected_match === false) {
        hit = confidence < 0.6 ? 1 : 0;
      } else if (testCase.expected_video_title) {
        hit = predictedTitle === testCase.expected_video_title ? 1 : 0;
      } else if (testCase.expected_video_titles) {
        hit = testCase.expected_video_titles.includes(predictedTitle) ? 1 : 0;
      }
      
      const result = {
        testId: testCase.id,
        question: testCase.question,
        expectedTitle: testCase.expected_video_title || 'NO_MATCH',
        predictedTitle: predictedTitle || 'NO_MATCH',
        confidence,
        hit,
        latency,
        timestamp: new Date().toISOString()
      };
      
      results.push(result);
      
      csvLines.push([
        testCase.id,
        `"${testCase.question}"`,
        `"${result.expectedTitle}"`,
        `"${result.predictedTitle}"`,
        confidence.toFixed(3),
        hit,
        latency,
        result.timestamp
      ].join(','));
      
      console.log(`✅ Result: ${hit ? 'HIT' : 'MISS'} (confidence: ${confidence.toFixed(2)}, ${latency}ms)`);
      
    } catch (error) {
      console.error(`❌ Test ${testCase.id} failed:`, error.message);
      
      const result = {
        testId: testCase.id,
        question: testCase.question,
        expectedTitle: testCase.expected_video_title || 'NO_MATCH',
        predictedTitle: 'ERROR',
        confidence: 0,
        hit: 0,
        latency: Date.now() - startTime,
        error: error.message,
        timestamp: new Date().toISOString()
      };
      
      results.push(result);
      
      csvLines.push([
        testCase.id,
        `"${testCase.question}"`,
        `"${result.expectedTitle}"`,
        'ERROR',
        '0.000',
        0,
        result.latency,
        result.timestamp
      ].join(','));
    }
    
    // Rate limiting
    await new Promise(resolve => setTimeout(resolve, 1000));
  }
  
  // Calculate metrics
  const totalTests = results.length;
  const hits = results.filter(r => r.hit === 1).length;
  const accuracy = hits / totalTests;
  const avgConfidence = results.reduce((sum, r) => sum + r.confidence, 0) / totalTests;
  const avgLatency = results.reduce((sum, r) => sum + r.latency, 0) / totalTests;
  const noAnswerRate = results.filter(r => r.confidence < 0.6).length / totalTests;
  
  // Calculate MRR@5 (simplified - since we only check top-1)
  let mrr = 0;
  results.forEach(result => {
    if (result.hit === 1) {
      mrr += 1.0; // Position 1
    }
  });
  mrr = mrr / totalTests;
  
  console.log('\n📊 EVALUATION RESULTS:');
  console.log(`Timestamp: ${new Date().toISOString()}`);
  console.log(`Total Tests: ${totalTests}`);
  console.log(`Top-1 Accuracy: ${(accuracy * 100).toFixed(1)}%`);
  console.log(`MRR@5: ${mrr.toFixed(3)}`);
  console.log(`No-Answer Rate: ${(noAnswerRate * 100).toFixed(1)}%`);
  console.log(`Avg Confidence: ${avgConfidence.toFixed(3)}`);
  console.log(`Avg Latency: ${avgLatency.toFixed(0)}ms`);
  
  // Write CSV output
  const csvPath = path.join(__dirname, `evaluation_results_${Date.now()}.csv`);
  fs.writeFileSync(csvPath, csvLines.join('\n'));
  console.log(`\n📁 Results saved to: ${csvPath}`);
  
  // Write summary JSON
  const summaryPath = path.join(__dirname, `evaluation_summary_${Date.now()}.json`);
  const summary = {
    timestamp: new Date().toISOString(),
    pipeline: 'production-v3',
    metrics: {
      totalTests,
      accuracy,
      mrr,
      noAnswerRate,
      avgConfidence,
      avgLatency
    },
    results
  };
  
  fs.writeFileSync(summaryPath, JSON.stringify(summary, null, 2));
  console.log(`📁 Summary saved to: ${summaryPath}`);
  
  return summary;
}

// Run if called directly
if (import.meta.url === `file://${process.argv[1]}`) {
  runEvaluation().catch(console.error);
}

export { runEvaluation };