import { createClient } from '@supabase/supabase-js';
import testDataset from './test-dataset.json';

interface TestResult {
  testId: number;
  question: string;
  success: boolean;
  confidence: number;
  matchedVideoTitle: string | null;
  expectedTitle?: string;
  reasoning?: string;
  error?: string;
  executionTime: number;
}

interface EvaluationSummary {
  totalTests: number;
  successfulMatches: number;
  falsePositives: number;
  falseNegatives: number;
  averageConfidence: number;
  averageExecutionTime: number;
  accuracy: number;
  precision: number;
  recall: number;
}

export class EvaluationRunner {
  private supabase: any;
  private userId: string;

  constructor(supabaseUrl: string, supabaseKey: string, userId: string) {
    this.supabase = createClient(supabaseUrl, supabaseKey);
    this.userId = userId;
  }

  async runEvaluation(): Promise<{ results: TestResult[], summary: EvaluationSummary }> {
    console.log('🧪 Starting evaluation with', testDataset.length, 'test cases...');
    
    const results: TestResult[] = [];
    
    for (const testCase of testDataset) {
      console.log(`\n🔍 Testing: "${testCase.question}"`);
      
      const startTime = Date.now();
      const result = await this.runSingleTest(testCase);
      result.executionTime = Date.now() - startTime;
      
      results.push(result);
      
      console.log(`✅ Result: ${result.success ? 'PASS' : 'FAIL'} (confidence: ${result.confidence.toFixed(2)}, time: ${result.executionTime}ms)`);
      
      // Add delay to avoid rate limiting
      await new Promise(resolve => setTimeout(resolve, 1000));
    }
    
    const summary = this.calculateSummary(results);
    
    console.log('\n📊 EVALUATION SUMMARY:');
    console.log(`Total Tests: ${summary.totalTests}`);
    console.log(`Accuracy: ${(summary.accuracy * 100).toFixed(1)}%`);
    console.log(`Precision: ${(summary.precision * 100).toFixed(1)}%`);
    console.log(`Recall: ${(summary.recall * 100).toFixed(1)}%`);
    console.log(`Average Confidence: ${summary.averageConfidence.toFixed(2)}`);
    console.log(`Average Response Time: ${summary.averageExecutionTime.toFixed(0)}ms`);
    
    return { results, summary };
  }

  private async runSingleTest(testCase: any): Promise<TestResult> {
    try {
      const response = await this.supabase.functions.invoke('conversation-agent-v2', {
        body: {
          question: testCase.question,
          userId: this.userId,
          action: 'answer_question'
        }
      });

      if (response.error) {
        return {
          testId: testCase.id,
          question: testCase.question,
          success: false,
          confidence: 0,
          matchedVideoTitle: null,
          error: response.error.message,
          executionTime: 0
        };
      }

      const { data } = response;
      const confidence = data.confidence || 0;
      const matchedTitle = data.videoTitle || null;
      
      // Determine success based on test case expectations
      let success = false;
      
      if (testCase.expectedMatch === false) {
        // Test expects no match - success if confidence is low
        success = confidence < 0.6;
      } else if (testCase.expectedVideoTitle) {
        // Test expects specific video - success if title matches and confidence is high enough
        success = matchedTitle === testCase.expectedVideoTitle && confidence >= testCase.minimumConfidence;
      } else if (testCase.expectedVideoTitles) {
        // Test expects one of several videos
        success = testCase.expectedVideoTitles.includes(matchedTitle) && confidence >= testCase.minimumConfidence;
      } else {
        // General success criteria
        success = confidence >= testCase.minimumConfidence;
      }

      return {
        testId: testCase.id,
        question: testCase.question,
        success,
        confidence,
        matchedVideoTitle: matchedTitle,
        expectedTitle: testCase.expectedVideoTitle,
        reasoning: data.debug?.reasoning,
        executionTime: 0
      };

    } catch (error) {
      return {
        testId: testCase.id,
        question: testCase.question,
        success: false,
        confidence: 0,
        matchedVideoTitle: null,
        error: error.message,
        executionTime: 0
      };
    }
  }

  private calculateSummary(results: TestResult[]): EvaluationSummary {
    const totalTests = results.length;
    const successfulMatches = results.filter(r => r.success).length;
    
    // Calculate confusion matrix elements
    let truePositives = 0;
    let falsePositives = 0;
    let falseNegatives = 0;
    let trueNegatives = 0;
    
    results.forEach(result => {
      const testCase = testDataset.find(t => t.id === result.testId);
      const shouldMatch = testCase?.expectedMatch !== false;
      const didMatch = result.confidence >= 0.6;
      
      if (shouldMatch && didMatch) truePositives++;
      else if (!shouldMatch && didMatch) falsePositives++;
      else if (shouldMatch && !didMatch) falseNegatives++;
      else if (!shouldMatch && !didMatch) trueNegatives++;
    });
    
    const precision = truePositives + falsePositives > 0 ? truePositives / (truePositives + falsePositives) : 0;
    const recall = truePositives + falseNegatives > 0 ? truePositives / (truePositives + falseNegatives) : 0;
    const accuracy = (truePositives + trueNegatives) / totalTests;
    
    const averageConfidence = results.reduce((sum, r) => sum + r.confidence, 0) / totalTests;
    const averageExecutionTime = results.reduce((sum, r) => sum + r.executionTime, 0) / totalTests;
    
    return {
      totalTests,
      successfulMatches,
      falsePositives,
      falseNegatives,
      averageConfidence,
      averageExecutionTime,
      accuracy,
      precision,
      recall
    };
  }

  async exportResults(results: TestResult[], summary: EvaluationSummary, filename?: string) {
    const timestamp = new Date().toISOString().split('T')[0];
    const exportData = {
      timestamp,
      summary,
      results: results.map(r => ({
        testId: r.testId,
        question: r.question,
        success: r.success,
        confidence: r.confidence.toFixed(3),
        matchedVideoTitle: r.matchedVideoTitle,
        expectedTitle: r.expectedTitle,
        reasoning: r.reasoning,
        executionTime: r.executionTime,
        error: r.error
      }))
    };
    
    console.log('\n📁 Evaluation Results:');
    console.log(JSON.stringify(exportData, null, 2));
    
    return exportData;
  }
}