# Store Preparation Guide - iOS & Android

## 📱 iOS App Store Vorbereitung

### 1. Info.plist Konfiguration
Die Datei `ios-store-config/Info.plist.additions.xml` enthält alle erforderlichen Einträge für:

**Purpose Strings (Pflicht für App Store):**
- `NSCameraUsageDescription` - Kamera-Zugriff für Videos
- `NSMicrophoneUsageDescription` - Mikrofon für Audio
- `NSPhotoLibraryUsageDescription` - Fotomediathek-Zugriff
- `NSPhotoLibraryAddUsageDescription` - Videos speichern

**Zusätzliche Konfigurationen:**
- URL-Scheme für Deep Links (`zeitzeuge://`)
- Background Modes für Push Notifications
- App Transport Security Settings
- Unterstützte Interface Orientations

### 2. App Icons & Assets
Erstellen Sie folgende Icon-Größen:
```
ios/App/App/Assets.xcassets/AppIcon.appiconset/
├── Icon-20.png (20x20)
├── Icon-20@2x.png (40x40)
├── Icon-20@3x.png (60x60)
├── Icon-29.png (29x29)
├── Icon-29@2x.png (58x58)
├── Icon-29@3x.png (87x87)
├── Icon-40.png (40x40)
├── Icon-40@2x.png (80x80)
├── Icon-40@3x.png (120x120)
├── Icon-60@2x.png (120x120)
├── Icon-60@3x.png (180x180)
├── Icon-76.png (76x76)
├── Icon-76@2x.png (152x152)
├── Icon-83.5@2x.png (167x167)
└── Icon-1024.png (1024x1024)
```

### 3. Launch Screen
Anpassen der `LaunchScreen.storyboard` mit Zeitzeuge Branding.

## 🤖 Android Play Store Vorbereitung

### 1. AndroidManifest.xml Konfiguration
Die Datei `android-store-config/AndroidManifest.additions.xml` enthält:

**Erforderliche Permissions:**
- `CAMERA` - Video-Aufnahme
- `RECORD_AUDIO` - Audio-Aufnahme  
- `INTERNET` - Online-Funktionen
- `FOREGROUND_SERVICE` - Background-Uploads
- `WRITE_EXTERNAL_STORAGE` - Lokale Speicherung

**Features:**
- Hardware-Features (Kamera, Mikrofon)
- Intent-Filter für Deep Links
- Firebase Messaging Service

### 2. App Icons & Adaptive Icons
Erstellen Sie folgende Icon-Größen:
```
android/app/src/main/res/
├── mipmap-hdpi/ (72x72)
├── mipmap-mdpi/ (48x48)
├── mipmap-xhdpi/ (96x96)
├── mipmap-xxhdpi/ (144x144)
├── mipmap-xxxhdpi/ (192x192)
└── mipmap-anydpi-v26/ (Adaptive Icons)
    ├── ic_launcher.xml
    ├── ic_launcher_background.xml
    └── ic_launcher_foreground.xml
```

### 3. Gradle Build Configuration
```gradle
// android/app/build.gradle
android {
    compileSdkVersion 34
    defaultConfig {
        applicationId "com.zeitzeuge.app"
        minSdkVersion 24
        targetSdkVersion 34
        versionCode 1
        versionName "1.0.0"
    }
}
```

## 🔒 Datenschutz & DSGVO Compliance

### 1. In-App Datenschutzerklärung
- ✅ `PrivacyPolicyComponent.tsx` implementiert
- ✅ Vollständige DSGVO-konforme Erklärung
- ✅ Benutzerrechte (Auskunft, Löschung, Berichtigung)
- ✅ Datenverwendung transparent erklärt

### 2. Store-Datenschutzangaben

**App Store Connect (iOS):**
```
Datentypen:
├── Kontaktdaten: E-Mail-Adresse
├── Benutzerinhalte: Videos, Audio-Aufnahmen
├── Nutzungsdaten: Anonymisierte App-Nutzung
├── Diagnose: Crash-Reports (ohne PII)
└── Andere Daten: Device-Token für Push
```

**Google Play Console (Android):**
```
Sicherheitsbogen:
├── Personenbezogene Daten: Ja (E-Mail)
├── Finanzielle Daten: Nein
├── Gesundheitsdaten: Nein
├── Standortdaten: Nein
├── Andere Daten: Videos, Audio (Benutzerinhalte)
```

### 3. DSGVO-Features implementiert
- ✅ Datenexport (Art. 15 DSGVO) - `DataExportDialog.tsx`
- ✅ Löschungsrecht - Über Konto-Einstellungen
- ✅ Transparent Privacy Policy
- ✅ Einwilligungsmanagement für Push-Notifications

## 📊 Analytics & Crash Reporting

### 1. Sentry Integration
- ✅ Crash Reporting ohne PII
- ✅ Performance Monitoring (10% Sample Rate)
- ✅ Error Tracking mit Context
- ✅ User-ID Hashing für Privacy

**Setup erforderlich:**
```bash
# Sentry DSN in .env setzen
VITE_SENTRY_DSN=https://your-sentry-dsn@sentry.io/project-id
```

### 2. Analytics Events (PII-frei)
```typescript
// Verwendung im Code
analytics.trackEvent('video_upload_started');
analytics.trackPageView('dashboard');
analytics.trackUserAction('button_click', 'record_video');
```

### 3. Performance Monitoring
- App-Start-Zeiten
- Video-Upload-Performance
- API-Response-Zeiten
- Crash-freie Sessions

## 🚀 Pre-Launch Checklist

### Funktionalität
- [ ] Video-Aufnahme funktioniert auf Zielgeräten
- [ ] Push-Notifications konfiguriert
- [ ] Deep Links funktionieren
- [ ] Offline-Modus getestet
- [ ] Background-Upload funktioniert

### Compliance
- [ ] Datenschutzerklärung in App verfügbar
- [ ] Store-Datenschutzangaben ausgefüllt
- [ ] App Store Screenshots erstellt
- [ ] App-Beschreibung übersetzt

### Technical
- [ ] Sentry DSN konfiguriert
- [ ] Firebase/FCM Setup (Android)
- [ ] APNS Setup (iOS)
- [ ] Icon-Sets vollständig
- [ ] Launch Screen angepasst

### Testing
- [ ] Device-Tests (iOS/Android)
- [ ] Store-Validierung durchgeführt
- [ ] Performance-Tests abgeschlossen
- [ ] Accessibility-Tests

## 📋 Store-Metadaten

### App-Titel
- **Deutsch:** Zeitzeuge - Digitale Erinnerungen
- **Englisch:** Zeitzeuge - Digital Memories

### Kurzbeschreibung (80 Zeichen)
"Bewahren Sie Ihre wertvollsten Lebenserinnerungen in digitaler Form"

### Beschreibung
```
Zeitzeuge hilft Ihnen dabei, Ihre wertvollen Lebenserinn­erungen zu bewahren, zu organisieren und mit Familie zu teilen.

✨ FEATURES:
• Video-Erinnerungen aufnehmen
• KI-gestützte Transkription
• Intelligente Kategorisierung
• Sichere Cloud-Speicherung
• Familienfreigabe
• Offline-Funktionalität

🔒 DATENSCHUTZ:
• Ende-zu-Ende-Verschlüsselung
• DSGVO-konform
• Server in Deutschland
• Keine Werbung

📱 PLATTFORMEN:
• Native iOS & Android Apps
• Progressive Web App
• Synchronisation zwischen Geräten
```

### Keywords
iOS: Erinnerungen, Familie, Video, Tagebuch, Geschichte, Generationen
Android: Erinnerungen, Familie, Video, Tagebuch, Geschichte, Generationen

### Screenshots
- Dashboard-Ansicht (Hell/Dunkel)
- Video-Aufnahme Interface
- Kategorien-Übersicht
- Gespräche-Feature
- Einstellungen/Privacy

## ⚠️ Wichtige Hinweise

1. **Permissions:** Nur anfordern was tatsächlich benötigt wird
2. **Privacy:** Alle Datenverwendung transparent kommunizieren
3. **Performance:** App muss auch auf älteren Geräten funktionieren
4. **Accessibility:** Unterstützung für Screen Reader etc.
5. **Localization:** Deutsche und englische Texte bereithalten

## 🔗 Nützliche Links

- [iOS Human Interface Guidelines](https://developer.apple.com/design/human-interface-guidelines/)
- [Android Design Guidelines](https://material.io/design)
- [App Store Review Guidelines](https://developer.apple.com/app-store/review/guidelines/)
- [Google Play Policy](https://play.google.com/about/developer-content-policy/)
- [DSGVO Compliance Guide](https://gdpr.eu/compliance/)