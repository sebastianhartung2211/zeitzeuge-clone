#!/usr/bin/env node

// Comprehensive Agentic System Test Runner
import { createClient } from '@supabase/supabase-js';

const SUPABASE_URL = 'https://fepcoqrfrkfiaftkkfht.supabase.co';
const SUPABASE_ANON_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImZlcGNvcXJmcmtmaWFmdGtrZmh0Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTMxNDU4NjUsImV4cCI6MjA2ODcyMTg2NX0.EA3jUpmXSlnMh_YYGNo3yWtZEcBdZ7JkRDSlSjALGdc';
const TEST_USER_ID = 'd71c52e8-fe67-40f5-a5db-ad6ca50e649e';

const supabase = createClient(SUPABASE_URL, SUPABASE_ANON_KEY);

interface TestResult {
  agent: string;
  test: string;
  status: 'PASS' | 'FAIL' | 'SKIP';
  duration?: number;
  error?: string;
  response?: any;
}

class AgenticSystemTester {
  private results: TestResult[] = [];

  async runAllTests(): Promise<void> {
    console.log('🧪 Starting Agentic System Functionality Tests...\n');
    
    // Test 1: Health Check Agent
    await this.testHealthCheckAgent();
    
    // Test 2: Monitoring Agent  
    await this.testMonitoringAgent();
    
    // Test 3: Conversation Agent V3
    await this.testConversationAgentV3();
    
    // Test 4: Coordinator Agent
    await this.testCoordinatorAgent();
    
    // Test 5: Database Functions
    await this.testDatabaseFunctions();
    
    // Test 6: Vector Similarity
    await this.testVectorSimilarity();
    
    this.printResults();
  }

  async testHealthCheckAgent(): Promise<void> {
    console.log('🏥 Testing Health Check Agent...');
    
    const startTime = Date.now();
    try {
      const { data, error } = await supabase.functions.invoke('health-check-agent', {
        body: { action: 'check_all' }
      });
      
      const duration = Date.now() - startTime;
      
      if (error) {
        this.results.push({
          agent: 'health-check-agent',
          test: 'check_all',
          status: 'FAIL',
          duration,
          error: error.message
        });
      } else {
        this.results.push({
          agent: 'health-check-agent',
          test: 'check_all',
          status: 'PASS',
          duration,
          response: data
        });
        console.log(`✅ Health check completed in ${duration}ms`);
      }
    } catch (error) {
      this.results.push({
        agent: 'health-check-agent',
        test: 'check_all',
        status: 'FAIL',
        error: (error as Error).message
      });
      console.log(`❌ Health check failed: ${(error as Error).message}`);
    }
  }

  async testMonitoringAgent(): Promise<void> {
    console.log('📊 Testing Monitoring Agent...');
    
    const startTime = Date.now();
    try {
      const { data, error } = await supabase.functions.invoke('monitoring-agent', {
        body: { action: 'system_check' }
      });
      
      const duration = Date.now() - startTime;
      
      if (error) {
        this.results.push({
          agent: 'monitoring-agent',
          test: 'system_check',
          status: 'FAIL',
          duration,
          error: error.message
        });
      } else {
        this.results.push({
          agent: 'monitoring-agent',
          test: 'system_check',
          status: 'PASS',
          duration,
          response: data
        });
        console.log(`✅ Monitoring check completed in ${duration}ms`);
      }
    } catch (error) {
      this.results.push({
        agent: 'monitoring-agent',
        test: 'system_check',
        status: 'FAIL',
        error: (error as Error).message
      });
      console.log(`❌ Monitoring check failed: ${(error as Error).message}`);
    }
  }

  async testConversationAgentV3(): Promise<void> {
    console.log('🤖 Testing Conversation Agent V3...');
    
    const testQuestion = "Was ist deine schönste Kindheitserinnerung?";
    const startTime = Date.now();
    
    try {
      const { data, error } = await supabase.functions.invoke('conversation-agent-v3', {
        body: {
          question: testQuestion,
          userId: TEST_USER_ID,
          action: 'answer_question'
        }
      });
      
      const duration = Date.now() - startTime;
      
      if (error) {
        this.results.push({
          agent: 'conversation-agent-v3',
          test: 'answer_question',
          status: 'FAIL',
          duration,
          error: error.message
        });
      } else {
        this.results.push({
          agent: 'conversation-agent-v3',
          test: 'answer_question',
          status: 'PASS',
          duration,
          response: { confidence: data?.confidence, videoTitle: data?.videoTitle }
        });
        console.log(`✅ Conversation agent responded in ${duration}ms with confidence: ${data?.confidence}`);
      }
    } catch (error) {
      this.results.push({
        agent: 'conversation-agent-v3',
        test: 'answer_question',
        status: 'FAIL',
        error: (error as Error).message
      });
      console.log(`❌ Conversation agent failed: ${(error as Error).message}`);
    }
  }

  async testCoordinatorAgent(): Promise<void> {
    console.log('🎯 Testing Coordinator Agent...');
    
    const startTime = Date.now();
    try {
      const { data, error } = await supabase.functions.invoke('coordinator-agent', {
        body: {
          action: 'answer_question',
          userId: TEST_USER_ID,
          questionContext: "Test workflow coordination"
        }
      });
      
      const duration = Date.now() - startTime;
      
      if (error) {
        this.results.push({
          agent: 'coordinator-agent',
          test: 'workflow_coordination',
          status: 'FAIL',
          duration,
          error: error.message
        });
      } else {
        this.results.push({
          agent: 'coordinator-agent',
          test: 'workflow_coordination',
          status: 'PASS',
          duration,
          response: data
        });
        console.log(`✅ Coordinator agent responded in ${duration}ms`);
      }
    } catch (error) {
      this.results.push({
        agent: 'coordinator-agent',
        test: 'workflow_coordination',
        status: 'FAIL',
        error: (error as Error).message
      });
      console.log(`❌ Coordinator agent failed: ${(error as Error).message}`);
    }
  }

  async testDatabaseFunctions(): Promise<void> {
    console.log('🗄️  Testing Database Functions...');
    
    // Test log_agent_performance function
    const startTime = Date.now();
    try {
      const { data, error } = await supabase.rpc('log_agent_performance', {
        agent_name_param: 'test-agent',
        operation_param: 'functionality-test',
        duration_ms_param: 100,
        success_param: true,
        metadata_param: { test: true }
      });
      
      const duration = Date.now() - startTime;
      
      if (error) {
        this.results.push({
          agent: 'database',
          test: 'log_agent_performance',
          status: 'FAIL',
          duration,
          error: error.message
        });
      } else {
        this.results.push({
          agent: 'database',
          test: 'log_agent_performance',
          status: 'PASS',
          duration,
          response: { logId: data }
        });
        console.log(`✅ Database function test completed in ${duration}ms`);
      }
    } catch (error) {
      this.results.push({
        agent: 'database',
        test: 'log_agent_performance',
        status: 'FAIL',
        error: (error as Error).message
      });
      console.log(`❌ Database function test failed: ${(error as Error).message}`);
    }
  }

  async testVectorSimilarity(): Promise<void> {
    console.log('🔍 Testing Vector Similarity...');
    
    const embedding1 = [0.1, 0.2, 0.3, 0.4, 0.5];
    const embedding2 = [0.1, 0.2, 0.3, 0.4, 0.5];
    
    const startTime = Date.now();
    try {
      const { data, error } = await supabase.rpc('calculate_vector_similarity', {
        embedding1: embedding1,
        embedding2: embedding2
      });
      
      const duration = Date.now() - startTime;
      
      if (error) {
        this.results.push({
          agent: 'vector-search',
          test: 'similarity_calculation',
          status: 'FAIL',
          duration,
          error: error.message
        });
      } else {
        this.results.push({
          agent: 'vector-search',
          test: 'similarity_calculation',
          status: 'PASS',
          duration,
          response: { similarity: data }
        });
        console.log(`✅ Vector similarity test completed in ${duration}ms, similarity: ${data}`);
      }
    } catch (error) {
      this.results.push({
        agent: 'vector-search',
        test: 'similarity_calculation',
        status: 'FAIL',
        error: (error as Error).message
      });
      console.log(`❌ Vector similarity test failed: ${(error as Error).message}`);
    }
  }

  printResults(): void {
    console.log('\n📋 TEST RESULTS SUMMARY');
    console.log('=' .repeat(60));
    
    const passed = this.results.filter(r => r.status === 'PASS').length;
    const failed = this.results.filter(r => r.status === 'FAIL').length;
    const skipped = this.results.filter(r => r.status === 'SKIP').length;
    
    console.log(`Total Tests: ${this.results.length}`);
    console.log(`✅ Passed: ${passed}`);
    console.log(`❌ Failed: ${failed}`);
    console.log(`⏭️  Skipped: ${skipped}`);
    console.log(`Success Rate: ${((passed / this.results.length) * 100).toFixed(1)}%\n`);
    
    // Detailed results
    this.results.forEach((result, index) => {
      const status = result.status === 'PASS' ? '✅' : result.status === 'FAIL' ? '❌' : '⏭️';
      console.log(`${index + 1}. ${status} ${result.agent} - ${result.test}`);
      if (result.duration) {
        console.log(`   Duration: ${result.duration}ms`);
      }
      if (result.error) {
        console.log(`   Error: ${result.error}`);
      }
      if (result.response && result.status === 'PASS') {
        console.log(`   Response: ${JSON.stringify(result.response, null, 2)}`);
      }
      console.log('');
    });
    
    // Recommendations
    console.log('🔧 RECOMMENDATIONS:');
    if (failed > 0) {
      console.log('- Fix failed tests before deploying to production');
      console.log('- Check agent logs for detailed error information');
      console.log('- Verify network connectivity and API keys');
    } else {
      console.log('- All tests passed! System is ready for production');
      console.log('- Consider adding performance monitoring');
      console.log('- Set up automated health checks');
    }
  }
}

// Run tests if called directly
if (require.main === module) {
  const tester = new AgenticSystemTester();
  tester.runAllTests().catch(console.error);
}

export { AgenticSystemTester };