# App Store Assets

## 📱 App Icons Required

### iOS App Store Icons
Alle Icons müssen ohne Alpha-Kanal (keine Transparenz) erstellt werden:

```
Icon Sizes Needed:
├── 1024x1024px - App Store Connect
├── 180x180px - iPhone 6 Plus/6s Plus/7 Plus/8 Plus
├── 167x167px - iPad Pro
├── 152x152px - iPad 2/Mini
├── 120x120px - iPhone 6/6s/7/8/X/XS/11/12
├── 87x87px - iPhone Settings
├── 80x80px - iPad Settings
├── 76x76px - iPad
├── 60x60px - iPhone Notification
├── 58x58px - iPhone Settings
├── 40x40px - iPad Notification
├── 29x29px - Settings
└── 20x20px - Notification
```

### Android Play Store Icons
```
Launcher Icons:
├── 512x512px - Google Play Store (ohne Schatten/Effekte)
├── 192x192px - xxxhdpi
├── 144x144px - xxhdpi  
├── 96x96px - xhdpi
├── 72x72px - hdpi
└── 48x48px - mdpi

Adaptive Icons (Android 8.0+):
├── ic_launcher_foreground.xml (108x108dp safe area)
├── ic_launcher_background.xml (Vollfarbe oder Gradient)
└── ic_launcher.xml (Container)
```

## 📸 Screenshots Required

### iPhone Screenshots
Erforderlich für App Store Connect:

```
iPhone 6.7" Display (iPhone 14 Pro Max):
├── 1290 x 2796 pixels
└── Mindestens 3 Screenshots

iPhone 6.5" Display (iPhone 11 Pro Max):
├── 1242 x 2688 pixels  
└── Mindestens 3 Screenshots

iPhone 5.5" Display (iPhone 8 Plus):
├── 1242 x 2208 pixels
└── Optional für ältere Geräte
```

### Android Screenshots
Für Google Play Console:

```
Phone Screenshots:
├── 1080 x 1920 pixels (minimum)
├── 1080 x 2340 pixels (empfohlen)
└── Mindestens 2 Screenshots

7-inch Tablet:
├── 1200 x 1920 pixels
└── Optional

10-inch Tablet:  
├── 1920 x 1200 pixels
└── Optional
```

## 🎨 Design Guidelines

### App Icon Design
**Zeitzeuge Brand Colors:**
- Primary: #FF6B35 (Coral)
- Secondary: #4A90E2 (Blue)  
- Accent: #F7931E (Orange)
- Background: White/Light gradient

**Icon Concept:**
- Kamera/Video-Symbol + Zeit-Element (Uhrzeiger, Kreis)
- Warme, einladende Farben
- Klare, erkennbare Silhouette
- Funktioniert in kleinen Größen

### Screenshot Content
**Zeigen Sie folgende Features:**

1. **Dashboard/Hauptbildschirm**
   - Video-Timeline
   - Kategorien-Navigation
   - Saubere, intuitive UI

2. **Video-Aufnahme**
   - Aufnahme-Interface
   - Benutzerfreundliche Bedienung
   - Qualitäts-Indikator

3. **KI-Features**
   - Transkription-Ansicht
   - Kategorisierung
   - Intelligente Vorschläge

4. **Gespräche/Chat**
   - Konversations-Interface
   - KI-Interaktion
   - Erinnerungs-Abfrage

5. **Einstellungen/Privatsphäre**
   - DSGVO-Compliance
   - Datenschutz-Features
   - Benutzerkontrollen

### Text Overlays (Optional)
- Deutsche und englische Versionen
- Maximal 2-3 Worte pro Overlay
- Zeitzeuge-Branding subtil integriert

## 🎬 App Preview Videos (Optional)

### iOS App Preview
```
Spezifikationen:
├── Länge: 15-30 Sekunden
├── Format: .mov, .mp4, .m4v
├── Auflösung: Je nach Zielgerät
├── Orientierung: Portrait
└── Dateigröße: Max 500MB
```

### Android Feature Graphic
```
Spezifikationen:
├── 1024 x 500 pixels
├── JPG oder PNG
├── Keine Alpha-Kanal
└── Zeitzeuge-Branding prominent
```

## 📝 Asset Checklist

### Vor Upload prüfen:
- [ ] Alle Icon-Größen vorhanden
- [ ] Icons ohne Transparenz (iOS)
- [ ] Screenshots verschiedene Gerätegrößen
- [ ] Text in Screenshots lesbar
- [ ] Brand-Guidelines befolgt
- [ ] Keine Placeholder-Inhalte
- [ ] DSGVO-konforme Darstellung
- [ ] Qualitätsprüfung abgeschlossen

### Store-Metadaten:
- [ ] App-Name finalisiert
- [ ] Beschreibung übersetzt (DE/EN)
- [ ] Keywords recherchiert
- [ ] Kategorie festgelegt
- [ ] Altersfreigabe definiert
- [ ] Support-URL bereitgestellt

## 🛠 Tools & Resources

### Design Tools:
- Figma (Collaborative Design)
- Sketch (Mac-only)
- Adobe Illustrator/Photoshop
- Canva (Templates)

### Icon Generators:
- [App Icon Generator](https://appicon.co)
- [MakeAppIcon](https://makeappicon.com)
- [Icon Kitchen](https://icon.kitchen) (Android)

### Screenshot Tools:
- Device Frame Generator
- Simulator Screenshots (Xcode/Android Studio)
- [Screenshot Builder](https://theapplaunchpad.com/screenshot-builder/)

### Asset Validation:
- Xcode Asset Catalog Validation
- Android Asset Studio
- [App Store Screenshot Checker](https://appstorescreen.com)

## 📐 Technical Specifications

### iOS Technical Requirements:
- RGB color space
- No alpha channel for app icons
- High resolution (@2x, @3x versions)
- PNG format for icons
- sRGB color profile recommended

### Android Technical Requirements:
- RGBA for adaptive icons (with alpha)
- Vector drawables preferred
- Multiple density support
- WebP format supported (but PNG safer)
- Material Design compliance

### File Naming Convention:
```
iOS:
├── icon-1024.png
├── icon-180.png
├── screenshot-iphone-6.7-1.png
└── screenshot-iphone-6.7-2.png

Android:
├── ic_launcher-512.png
├── ic_launcher-192.png  
├── screenshot-phone-1.png
└── feature-graphic.png
```