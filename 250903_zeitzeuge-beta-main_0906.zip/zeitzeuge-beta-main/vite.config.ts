import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react-swc';
import path from 'path';
import { componentTagger } from 'lovable-tagger';

export default defineConfig(({ mode }) => ({
  appType: 'spa', // 404 -> index.html im Preview/Hosting
  server: {
    host: '::',
    port: 8080,
  },
  preview: {
    port: 8080,
    strictPort: true,
    headers: { 'Cache-Control': 'no-store' }, // kein Preview-Cache
  },
  plugins: [
    react(),
    mode === 'development' && componentTagger(),
  ].filter(Boolean),
  resolve: {
    alias: {
      '@': path.resolve(__dirname, './src'),
    },
  },
  build: {
    sourcemap: true,
  },
}));
