// einfacher, deterministischer Hash (ohne Node 'crypto')
function hashStr(s: string) {
  let h = 5381;
  for (let i = 0; i < s.length; i++) h = ((h << 5) + h) ^ s.charCodeAt(i);
  return Math.abs(h >>> 0);
}

// verteilt stabil innerhalb eines Jahres (Monat 1..12, Tag 1..28)
export function spreadWithinYear(stableId: string, year: number) {
  const h = hashStr(stableId);
  const month = (h % 12) + 1;
  const day = ((h >> 4) % 28) + 1;
  return new Date(Date.UTC(year, month - 1, day)).toISOString();
}

// --- NEU: Kategorien -> Jahrzehnte-Ranges (inkl. deiner Vorgaben) ---
type Range = [number, number]; // inklusiv: [startYear, endYear]
const CATEGORY_DECADES: Record<string, Range[]> = {
  "Kindheit & Familie":      [[1950, 1969]],
  "Liebe & Beziehungen":     [[1970, 1989]],
  "Jugend & Schule":         [[1970, 1979]],
  "Zuhause & Traditionen":   [[1980, 1999]],
  "Arbeit & Alltag":         [[1990, 2009]],
  "Zeitgeschichte & Wandel": [[1950, 2029]],
};

// wählt für eine ID stabil ein Jahr in den angegebenen Ranges
function pickStableYearForRanges(id: string, ranges: Range[]): number {
  const totalYears = ranges.reduce((acc, [a, b]) => acc + (b - a + 1), 0);
  if (totalYears <= 0) return 2000;
  const idx = hashStr(id) % totalYears;

  let offset = idx;
  for (const [a, b] of ranges) {
    const span = b - a + 1;
    if (offset < span) return a + offset;
    offset -= span;
  }
  return 2000;
}

// --- ANGEPASST: getApproxDate nutzt jetzt (1) exaktes Datum, (2) Jahr, (3) Kategorie-Mapping ---
export function getApproxDate(video: { id: string; date?: string; year?: number; category?: string }) {
  if (video.date) return video.date;
  if (typeof video.year === "number") return spreadWithinYear(video.id, video.year);

  if (video.category && CATEGORY_DECADES[video.category]) {
    const year = pickStableYearForRanges(video.id, CATEGORY_DECADES[video.category]);
    return spreadWithinYear(video.id, year);
  }

  // Fallback falls Kategorie unbekannt: in den 2000ern verteilen
  return spreadWithinYear(video.id, 2000 + (hashStr(video.id) % 20));
}

export function yearsBetween(birthISO: string, dateISO: string) {
  const a = new Date(birthISO).getTime();
  const b = new Date(dateISO).getTime();
  return (b - a) / (365.25 * 24 * 3600 * 1000);
}