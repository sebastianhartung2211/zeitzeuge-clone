export type FamilyPerson = {
  id: string;
  displayName: string;
  birthDate?: string;
  userEmail?: string;
  avatarUrl?: string;
};

const dicebear = (seed: string) =>
  // croodles liefert bewusst "witzige" Gesichter; mood=happy erzwingt Lächeln
  `https://api.dicebear.com/7.x/croodles/svg?seed=${encodeURIComponent(
    seed
  )}&mood=happy&backgroundType=gradientLinear&backgroundColors=b6e3f4,c0aede,ffd5dc&scale=100`;

export const familyPeople: FamilyPerson[] = [
  { id: "p_ingrid", displayName: "Ingrid", userEmail: "ingrid@zeitzeuge.eu", birthDate: "1958-06-01", avatarUrl: dicebear("Ingrid") },
  { id: "p_karlheinz", displayName: "Karl-Heinz", birthDate: "1956-02-12", avatarUrl: dicebear("Karl-Heinz") },
  { id: "p_oma", displayName: "Oma", birthDate: "1935-03-15", avatarUrl: dicebear("Oma") },
  { id: "p_opa", displayName: "Opa", birthDate: "1933-11-09", avatarUrl: dicebear("Opa") },
  { id: "p_tante", displayName: "Tante", birthDate: "1962-05-20", avatarUrl: dicebear("Tante") },
  { id: "p_cousin", displayName: "Cousin", birthDate: "1988-07-01", avatarUrl: dicebear("Cousin") },
  { id: "p_bruder", displayName: "Bruder", birthDate: "1985-01-25", avatarUrl: dicebear("Bruder") },
];

// sanfte, moderne Farben für Personen-Hintergründe (statt Dunkelgrün)
export const personTheme: Record<
  string,
  { bg: string; ring: string }
> = {
  p_ingrid:    { bg: "#F0F9FF", ring: "#38BDF8" },
  p_karlheinz: { bg: "#F5F3FF", ring: "#A78BFA" },
  p_oma:       { bg: "#FFF7ED", ring: "#FB923C" },
  p_opa:       { bg: "#ECFDF5", ring: "#34D399" },
  p_tante:     { bg: "#FEF2F2", ring: "#F87171" },
  p_cousin:    { bg: "#EFF6FF", ring: "#60A5FA" },
  p_bruder:    { bg: "#FDF2F8", ring: "#F472B6" },
};

// Kategorien → Farben (Legend & Punkte)
export const categoryColor: Record<string, string> = {
  "Kindheit & Familie": "#fbbf24",
  "Jugend & Schule": "#3b82f6",
  "Liebe & Beziehungen": "#ef4444",
  "Arbeit & Alltag": "#22c55e",
  "Zuhause & Traditionen": "#8b5cf6",
  "Essen & Genuss": "#f59e0b",
  "Besondere Ereignisse": "#0ea5e9",
  "Erfolge & Herausforderungen": "#14b8a6",
  "Werte & Lebensweisheiten": "#64748b",
  "Träume & Wünsche": "#a3e635",
  // ggf. weitere aus deinen Daten:
  "Zeitgeschichte & Wandel": "#06b6d4",
  "Erforderlich": "#94a3b8",
  "Personalisierte Themen": "#a78bfa",
};