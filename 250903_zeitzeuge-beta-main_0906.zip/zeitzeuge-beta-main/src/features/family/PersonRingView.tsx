import React, { useMemo, useState, useEffect } from "react";
import { motion, useReducedMotion } from "framer-motion";
import HoneycombBackground from "./HoneycombBackground";
import CategoryLegend from "./CategoryLegend";
import VideoDetailsModal from "@/components/video/VideoDetailsModal";
import { getApproxDate, yearsBetween } from "./dateUtils";
import { categoryColor, familyPeople } from "./family.config";
import type { VideoData } from "@/hooks/useVideos";

function hashStr(s: string) {
  let h = 5381; for (let i = 0; i < s.length; i++) h = ((h << 5) + h) ^ s.charCodeAt(i);
  return Math.abs(h >>> 0);
}

function textColorFor(bg: string) {
  // sehr einfache Heuristik
  try {
    const c = bg.replace("#",""); const r = parseInt(c.substr(0,2),16), g=parseInt(c.substr(2,2),16), b=parseInt(c.substr(4,2),16);
    const luminance = 0.299*r + 0.587*g + 0.114*b;
    return luminance > 160 ? "#111827" : "#ffffff";
  } catch { return "#ffffff"; }
}

// Kategorien → Sektor-Mitte (Grad). Nahe beieinander, etwas Überlappung.
const categoryAngleCenter: Record<string, number> = {
  "Kindheit & Familie": 220,
  "Jugend & Schule": 250,
  "Liebe & Beziehungen": 20,
  "Arbeit & Alltag": 350,
  "Besondere Ereignisse": 310,
  "Zuhause & Traditionen": 280,
  "Essen & Genuss": 60,
  "Erfolge & Herausforderungen": 100,
  "Werte & Lebensweisheiten": 140,
  "Träume & Wünsche": 180,
};

function angleFor(video: any) {
  const base = categoryAngleCenter[video.category] ?? 0;
  const h = hashStr(video.id);
  const jitter = (h % 41) - 20; // -20°..+20°
  return base + jitter;
}

// verteile Videos zusätzlich „zufällig" auf Ringe (spinnenartig)
function ringIndexFor(video: any, ringCount: number) {
  const h = hashStr(video.id);
  return (h % Math.max(1, ringCount)) | 0;
}

// Größe 6..12 je nach (optional) Dauer oder Hash
function bubbleSize(video: any) {
  const base = video.duration ? Math.min(12, 6 + Math.round(video.duration / 30)) : 6 + (hashStr(video.id) % 7);
  return Math.max(6, Math.min(12, base));
}

type Props = {
  personName: string;
  birthDate?: string;
  videos: VideoData[];   // echte Ingrid-Videos
  onBack?: () => void;
};

// Jahre pro Ring
const SPAN = 10;

// Geometrie (etwas größer und luftiger)
const BASE = 140;               // Innenradius (Avatar-Ring)
const GAP  = 34;                // Abstand zwischen Linienringen
const START = -90;
const RING_STROKE = 2;

// Zeitleiste (fixer unterer Anker für Beta)
const TIMELINE_MIN_YEAR = 1950;                         // außen
const TIMELINE_MAX_YEAR = Math.max(new Date().getUTCFullYear(), 2029); // innen ~ heute

function polar(cx: number, cy: number, r: number, deg: number) {
  const rad = (deg * Math.PI) / 180;
  return { x: cx + r * Math.cos(rad), y: cy + r * Math.sin(rad) };
}

export default function PersonRingView({ personName, birthDate, videos, onBack }: Props) {
  const [hoverId, setHoverId] = useState<string | null>(null);
  const [selected, setSelected] = useState<VideoData | null>(null);
  const [selectedCat, setSelectedCat] = useState<string | null>(null);
  const [scale, setScale] = useState(1);
  const [offset, setOffset] = useState({ x: 0, y: 0 });
  const reduce = useReducedMotion();

  const prepared = useMemo(() => {
    return videos
      .map(v => ({ ...v, approx: getApproxDate(v) })) // verteilt Jahr → Datum
      .sort((a, b) => +new Date(a.approx!) - +new Date(b.approx!));
  }, [videos]);

  const ringCount = useMemo(() => {
    if (birthDate && prepared.length) {
      const maxAge = Math.max(
        ...prepared.map(v => Math.floor(Math.max(0, yearsBetween(birthDate, v.approx!))))
      );
      return Math.max(1, Math.floor(maxAge / SPAN) + 1);
    }
    // Fallback ohne Geburtsdatum: Anzahl unterschiedlicher Jahre
    const years = [...new Set(prepared.map(v => new Date(v.approx!).getUTCFullYear()))];
    return Math.max(1, years.length || 1);
  }, [prepared, birthDate]);

  const size = 900, cx = size / 2, cy = size / 2;

  // Zentrum: Avatar der Person
  const avatarUrl = familyPeople.find(p => p.displayName === personName)?.avatarUrl;

  // Auto-Zoom Effect
  useEffect(() => {
    if (!selectedCat) { setScale(1); setOffset({ x: 0, y: 0 }); return; }

    // Punkte der aktiven Kategorie sammeln
    const pts: {x:number;y:number}[] = [];
    prepared.forEach((v) => {
      if (v.category !== selectedCat) return;
      const yr = new Date(v.approx!).getUTCFullYear();
      const idx = Math.max(0, Math.floor((TIMELINE_MAX_YEAR - yr) / SPAN));
      const r = BASE + idx * GAP;
      const ang = angleFor(v);
      const { x, y } = polar(cx, cy, r, ang);
      pts.push({ x, y });
    });

    if (!pts.length) { setScale(1); setOffset({ x: 0, y: 0 }); return; }

    const minX = Math.min(...pts.map(p => p.x));
    const maxX = Math.max(...pts.map(p => p.x));
    const minY = Math.min(...pts.map(p => p.y));
    const maxY = Math.max(...pts.map(p => p.y));

    const boxW = maxX - minX;
    const boxH = maxY - minY;

    // gewünschte Füllung ~70% des Viewports
    const vw = 900, vh = 900;
    const s = Math.min(3, Math.max(1.2, 0.7 * Math.min(vw / boxW, vh / boxH)));

    // Mittelpunkt der Box ins Zentrum bewegen
    const cxBox = (minX + maxX) / 2;
    const cyBox = (minY + maxY) / 2;
    const dx = (vw / 2 - cxBox) * s;
    const dy = (vh / 2 - cyBox) * s;

    setScale(s);
    setOffset({ x: dx - (vw/2)*(s-1), y: dy - (vh/2)*(s-1) });
  }, [selectedCat, prepared, birthDate]);

  const grouped = useMemo(() => {
    const map = new Map<number, typeof prepared>();
    prepared.forEach(v => {
      let idx = 0;
      if (birthDate) {
        const age = Math.max(0, Math.floor(yearsBetween(birthDate, v.approx!)));
        idx = Math.floor(age / SPAN);
      } else {
        const baseYear = new Date(prepared[0]?.approx || new Date()).getUTCFullYear();
        idx = new Date(v.approx!).getUTCFullYear() - baseYear;
      }
      if (!map.has(idx)) map.set(idx, []);
      map.get(idx)!.push(v);
    });
    return map;
  }, [prepared, birthDate]);

  return (
    <div className="relative w-full h-[85vh] min-h-[680px] bg-white rounded-2xl shadow">
      <HoneycombBackground />
      <CategoryLegend
        selected={selectedCat}
        onToggle={(name) => setSelectedCat(prev => (prev === name || !name ? null : name))}
      />
      <div className="absolute left-4 top-4 z-10 flex gap-2">
        {onBack && (
          <button onClick={onBack} className="px-3 py-1.5 rounded-lg bg-gray-100 hover:bg-gray-200 text-sm">
            ← Familie
          </button>
        )}
        <div className="px-3 py-1.5 rounded-lg bg-gray-50 text-gray-600 text-sm">{personName}</div>
      </div>

      <svg viewBox={`0 0 ${size} ${size}`} className="w-full h-full">
        {/* Zentrum: Avatar der Person */}
        {avatarUrl && (
          <>
            <clipPath id="centerClip">
              <circle cx={cx} cy={cy} r={BASE - 12} />
            </clipPath>
            <image
              href={avatarUrl}
              x={cx - (BASE - 12)}
              y={cy - (BASE - 12)}
              width={(BASE - 12) * 2}
              height={(BASE - 12) * 2}
              clipPath="url(#centerClip)"
              preserveAspectRatio="xMidYMid slice"
            />
            <circle cx={cx} cy={cy} r={BASE - 12} fill="transparent" stroke="#e5e7eb" strokeWidth="1.5" />
          </>
        )}

        {/* Ringe als dünne Linien */}
        {(() => {
          const ringCount = Math.floor((TIMELINE_MAX_YEAR - TIMELINE_MIN_YEAR) / SPAN) + 1;
          return new Array(ringCount).fill(0).map((_, i) => {
            const r = BASE + i * GAP; // i=0 innen (neu)
            return <circle key={i} cx={cx} cy={cy} r={r} fill="none" stroke="#e5e7eb" strokeWidth={RING_STROKE} />;
          });
        })()}

        {/* Zoom-Gruppe (für Filter-Zoom) */}
        <motion.g animate={{ scale, x: offset.x, y: offset.y }} transition={{ duration: 0.45, ease: "easeInOut" }}>
          {(() => {
            const dots: JSX.Element[] = [];
            const rc = ringCount;

            prepared.forEach((v) => {
              // aus prepared[] das Jahr holen
              const yr = new Date(v.approx!).getUTCFullYear();
              // Index: 0 = innerster Ring (neueste Jahre)
              const idx = Math.max(0, Math.floor((TIMELINE_MAX_YEAR - yr) / SPAN));
              const r = BASE + idx * GAP;

              // Winkel: Kategoriezentrum + jitter → spiderartig
              const ang = angleFor(v);
              const { x, y } = polar(cx, cy, r, ang);

              const col = categoryColor[v.category || "Besondere Ereignisse"] || "#0ea5e9";
              const isHover = v.id === hoverId;
              const h = hashStr(v.id);
              const dx = (h % 3) - 1;   // -1..+1 px Drift
              const dy = ((h >> 3) % 3) - 1;

              // größere Bubbles
              const size = Math.max(12, bubbleSize(v) + 6);

              // Filter-Hervorhebung
              const dim = selectedCat && v.category !== selectedCat;

              dots.push(
                <g key={v.id}>
                  <motion.circle
                    cx={x} cy={y}
                    r={isHover ? size + 2 : size}
                    fill={col}
                    style={{ opacity: dim ? 0.2 : 1 }}
                    initial={false}
                    animate={{ x: [0, dx, 0], y: [0, dy, 0], scale: isHover ? 1.1 : 1 }}
                    transition={{ duration: 4 + (h % 3), repeat: Infinity, ease: "easeInOut" }}
                    onMouseEnter={() => setHoverId(v.id)}
                    onMouseLeave={() => setHoverId(null)}
                    onClick={() => setSelected(v)}
                  />
                  {/* Jahr im Kreis */}
                  <text
                    x={x} y={y + 1} textAnchor="middle" dominantBaseline="middle"
                    fontSize={Math.max(9, size / 1.5)} fontWeight={600}
                    style={{ pointerEvents: "none", opacity: dim ? 0.35 : 1, fill: textColorFor(col) }}
                  >
                    {yr}
                  </text>
                </g>
              );
            });

            return dots;
          })()}
        </motion.g>
      </svg>

      {selected && (
        <VideoDetailsModal
          video={selected}
          onClose={() => setSelected(null)}
        />
      )}
    </div>
  );
}