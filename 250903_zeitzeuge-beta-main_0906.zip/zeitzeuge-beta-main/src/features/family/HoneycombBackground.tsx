import { motion, useReducedMotion } from "framer-motion";

export default function HoneycombBackground() {
  const reduce = useReducedMotion();
  return (
    <div className="pointer-events-none absolute inset-0 overflow-hidden">
      <motion.div
        aria-hidden
        className="absolute inset-0 opacity-25"
        style={{
          backgroundImage:
            "radial-gradient(circle at 1px 1px, rgba(0,0,0,0.06) 1px, transparent 1px)",
          backgroundSize: "18px 18px",
        }}
        animate={reduce ? {} : { x: [0, 2, 0], y: [0, 2, 0] }}
        transition={reduce ? {} : { duration: 12, repeat: Infinity, ease: "easeInOut" }}
      />
    </div>
  );
}