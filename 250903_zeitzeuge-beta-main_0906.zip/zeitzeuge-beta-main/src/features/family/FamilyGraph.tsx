import React, { useMemo, useState } from "react";
import { motion, useReducedMotion } from "framer-motion";
import HoneycombBackground from "./HoneycombBackground";
import CategoryLegend from "./CategoryLegend";
import { familyPeople, personTheme } from "./family.config";
import type { FamilyPerson } from "./family.config";

type EventLite = { id: string; title: string; date: string; peopleInvolved: string[] };

type Props = {
  people: FamilyPerson[];
  events: EventLite[];                // später echt aggregieren
  onPersonClick: (personId: string) => void;
};

// ---------- Helpers: deterministische, kollisionsarme Verteilung im Kreis ----------
function hashStr(s: string) {
  let h = 5381; for (let i = 0; i < s.length; i++) h = ((h << 5) + h) ^ s.charCodeAt(i);
  return Math.abs(h >>> 0);
}

// einfacher, deterministischer RNG (xorshift32)
function makeRng(seedStr: string) {
  let s = (hashStr(seedStr) || 1) >>> 0;
  return function rand() {
    s ^= s << 13; s ^= s >>> 17; s ^= s << 5;
    return (s >>> 0) / 4294967296;
  };
}

// zufälliger Punkt im Kreis (gleichmäßig verteilt)
function randomPointInCircle(rand: () => number, cx: number, cy: number, radius: number) {
  const t = 2 * Math.PI * rand();
  const u = rand() + rand();
  const r = (u > 1 ? 2 - u : u) * radius; // trianguliert → besser als sqrt(u)
  return { x: cx + r * Math.cos(t), y: cy + r * Math.sin(t) };
}

// "Best Candidate" Placement: pro Event mehrere Kandidaten → wähle den mit größtem Mindestabstand
function placeEventsInsideCircle(
  items: { id: string; radius: number }[],
  cx: number, cy: number, innerRadius: number,
  gap = 6,             // Mindestabstand zwischen Bubbles
  candidates = 32      // Qualität der Verteilung
) {
  // Größere zuerst platzieren (Packing verbessert)
  const sorted = [...items].sort((a, b) => b.radius - a.radius);
  const rng = makeRng(sorted.map(i => i.id).join("|"));
  const placed: { id: string; x: number; y: number; radius: number }[] = [];

  for (const it of sorted) {
    let best = { x: cx, y: cy, score: -Infinity };

    for (let k = 0; k < candidates; k++) {
      const p = randomPointInCircle(rng, cx, cy, innerRadius - it.radius - gap);
      // Mindestabstand zu bereits platzierten Punkten
      let minDist = Infinity;
      for (const q of placed) {
        const dx = p.x - q.x, dy = p.y - q.y;
        const d = Math.sqrt(dx*dx + dy*dy) - (q.radius + it.radius + gap);
        if (d < minDist) minDist = d;
      }
      // Nähe zum Rand (bevorzugt nicht am Rand kleben)
      const dc = Math.hypot(p.x - cx, p.y - cy);
      const boundaryClearance = (innerRadius - it.radius - gap) - dc; // >= 0 im gültigen Bereich
      const score = Math.min(minDist, boundaryClearance * 0.75);      // leicht Richtung Mitte gewichten

      if (score > best.score) best = { ...p, score };
    }
    placed.push({ id: it.id, x: best.x, y: best.y, radius: it.radius });
  }

  // Zurück in Originalreihenfolge mappen
  const map = new Map(placed.map(p => [p.id, p]));
  return items.map(i => ({ id: i.id, x: map.get(i.id)!.x, y: map.get(i.id)!.y, radius: i.radius }));
}

function polar(cx: number, cy: number, r: number, deg: number) {
  const rad = (deg * Math.PI) / 180;
  return { x: cx + r * Math.cos(rad), y: cy + r * Math.sin(rad) };
}

export default function FamilyGraph({ people, events, onPersonClick }: Props) {
  const [hEvent, setHEvent] = useState<string | null>(null);
  const [hPerson, setHPerson] = useState<string | null>(null);
  const reduce = useReducedMotion();

  const size = 900; const cx = size/2; const cy = size/2;
  const personRadius = 320;

  const pPos = useMemo(() => {
    const step = 360 / people.length;
    return people.map((p, i) => ({ id: p.id, ...polar(cx, cy, personRadius, -90 + i * step) }));
  }, [people]);

  // Bereich definieren: Events sicher innerhalb des Personen-Kreises platzieren
  const safeMargin = 70;                   // Abstand zu den Personen
  const innerRadius = personRadius - safeMargin;

  // Größe je Event (mehr Beteiligte → größer)
  const eventsWithRadius = useMemo(
    () => events.map(e => ({
      id: e.id,
      title: e.title,
      radius: Math.min(30, 16 + e.peopleInvolved.length * 3) // 16..30px
    })),
    [events]
  );

  // Kollisionsarmes Packing (deterministisch, stabil zwischen Renders)
  const eventsPos = useMemo(() => {
    const items = eventsWithRadius.map(e => ({ id: e.id, radius: e.radius }));
    return placeEventsInsideCircle(items, cx, cy, innerRadius, 8, 36);
  }, [eventsWithRadius, cx, cy, innerRadius]);

  const find = (id: string, arr: {id: string; x: number; y: number}[]) => arr.find(n => n.id === id)!;

  return (
    <div className="relative w-full h-[75vh] min-h-[560px] bg-white rounded-2xl shadow">
      <HoneycombBackground />
      <CategoryLegend />
      <svg viewBox={`0 0 ${size} ${size}`} className="w-full h-full">
        {eventsPos.map(e => {
          const ev = events.find(x => x.id === e.id)!;
          const layout = eventsPos.find(p => p.id === e.id)!;
          return ev.peopleInvolved.map(pid => {
            const p = find(pid, pPos);
            const active = hEvent === e.id || hPerson === pid || (hEvent === null && hPerson === null);
            return (
              <motion.line
                key={`${e.id}-${pid}`} x1={layout.x} y1={layout.y} x2={p.x} y2={p.y}
                stroke="#cbd5e1" strokeWidth={active ? 2 : 1}
                initial={{ pathLength: 0, opacity: 0.4 }}
                animate={reduce ? {} : { pathLength: active ? 1 : 0.6, opacity: active ? 1 : 0.4 }}
                transition={{ duration: 0.18 }}
              />
            );
          });
        })}

        {eventsPos.map(e => {
          const active = hEvent === e.id;
          const ev = events.find(x => x.id === e.id)!;
          const layout = eventsPos.find(p => p.id === e.id)!;
          const size = layout.radius;
          return (
            <g key={e.id} onMouseEnter={() => setHEvent(e.id)} onMouseLeave={() => setHEvent(null)}>
              <motion.circle
                cx={layout.x}
                cy={layout.y}
                r={active ? size + 2 : size}
                fill="#3b82f6"
                initial={false}
                animate={reduce ? {} : { scale: active ? 1.06 : 1, y: [0, 1.5, 0] }}
                transition={{ type: "spring", stiffness: 300, damping: 28, repeat: Infinity, duration: 5 }}
              />
              <text x={layout.x} y={layout.y + size + 22} textAnchor="middle" className="fill-gray-700 text-sm">
                {ev.title}
              </text>
            </g>
          );
        })}

        {pPos.map(p => {
          const active = hPerson === p.id;
          const person = people.find(x => x.id === p.id)!;
          const theme = personTheme[p.id] ?? { bg: "#F3F4F6", ring: "#9CA3AF" };
          const r = active ? 26 : 24;

          return (
            <g
              key={p.id}
              onMouseEnter={() => setHPerson(p.id)}
              onMouseLeave={() => setHPerson(null)}
              onClick={() => onPersonClick(p.id)}
              style={{ cursor: "pointer" }}
            >
              {/* Hintergrund-Kreis (farbig) */}
              <motion.circle
                cx={p.x}
                cy={p.y}
                r={r}
                fill={theme.bg}
                stroke={theme.ring}
                strokeWidth={2}
                initial={false}
                animate={reduce ? {} : { scale: active ? 1.05 : 1 }}
                transition={{ type: "spring", stiffness: 300, damping: 28 }}
              />
              {/* Avatar-Bild im Kreis */}
              {person.avatarUrl && (
                <>
                  <clipPath id={`clip-${p.id}`}>
                    <circle cx={p.x} cy={p.y} r={r - 3} />
                  </clipPath>
                  <image
                    href={person.avatarUrl}
                    x={p.x - (r - 3)}
                    y={p.y - (r - 3)}
                    width={(r - 3) * 2}
                    height={(r - 3) * 2}
                    clipPath={`url(#clip-${p.id})`}
                    preserveAspectRatio="xMidYMid slice"
                  />
                </>
              )}
              {/* Name darunter */}
              <text x={p.x} y={p.y + (r + 18)} textAnchor="middle" className="fill-gray-700 text-sm">
                {person.displayName}
              </text>
            </g>
          );
        })}
      </svg>
    </div>
  );
}