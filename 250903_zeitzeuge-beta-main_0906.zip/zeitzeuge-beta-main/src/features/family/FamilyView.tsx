import React, { useMemo, useState } from "react";
import { familyPeople } from "./family.config";
import FamilyGraph from "./FamilyGraph";
import PersonRingView from "./PersonRingView";
import { useVideos } from "@/hooks/useVideos";
import { useAuth } from "@/hooks/useAuth";

// Minimal-Events ersetzen durch umfangreiche Beispiele:
const seededEvents = [
  // single-person
  { id: "e_in_grid_1", title: "Erster Schultag", date: "1965-09-01", peopleInvolved: ["p_ingrid"] },
  { id: "e_karl_job",  title: "Neuer Job",       date: "1979-03-01", peopleInvolved: ["p_karlheinz"] },
  // multi-person (n:m)
  { id: "e_hochzeit80", title: "Hochzeit 1980", date: "1980-06-20", peopleInvolved: ["p_ingrid", "p_karlheinz", "p_oma", "p_opa"] },
  { id: "e_geburt85",   title: "Geburt 1985",   date: "1985-04-02", peopleInvolved: ["p_ingrid", "p_oma"] },
  { id: "e_umzug90",    title: "Umzug 1990",    date: "1990-08-15", peopleInvolved: ["p_ingrid", "p_karlheinz", "p_bruder"] },
  { id: "e_feier92",    title: "Silvester 1992",date: "1992-12-31", peopleInvolved: ["p_ingrid", "p_tante", "p_cousin", "p_bruder"] },
  { id: "e_reise95",    title: "Familienreise", date: "1995-07-12", peopleInvolved: ["p_ingrid", "p_karlheinz", "p_oma", "p_opa", "p_tante"] },
  { id: "e_jubi00",     title: "Jubiläum",      date: "2000-05-20", peopleInvolved: ["p_oma", "p_opa", "p_ingrid"] },
  { id: "e_geburt00",   title: "Geburt Cousin", date: "2000-10-02", peopleInvolved: ["p_tante", "p_cousin", "p_ingrid"] },
  { id: "e_hochzeit10", title: "Hochzeit Bruder",date:"2010-06-19", peopleInvolved: ["p_bruder", "p_ingrid", "p_karlheinz"] },
  { id: "e_fest12",     title: "Sommerfest",    date: "2012-08-01", peopleInvolved: ["p_ingrid", "p_cousin"] },
  { id: "e_geburt13",   title: "Geburt Nichte", date: "2013-03-05", peopleInvolved: ["p_bruder", "p_ingrid", "p_tante"] },
  { id: "e_reunion15",  title: "Familientreffen",date:"2015-09-10", peopleInvolved: ["p_ingrid","p_karlheinz","p_oma","p_opa","p_tante","p_cousin","p_bruder"] },
  { id: "e_reise18",    title: "Italienreise",  date: "2018-06-22", peopleInvolved: ["p_ingrid","p_karlheinz"] },
  { id: "e_geburt19",   title: "Enkel geboren", date: "2019-11-01", peopleInvolved: ["p_ingrid","p_oma"] },
  { id: "e_silvester",  title: "Silvester",     date: "2022-12-31", peopleInvolved: ["p_ingrid","p_karlheinz","p_tante","p_cousin"] },
];

type Mode = "family" | "person";

export default function FamilyView() {
  const [mode, setMode] = useState<Mode>("family");
  const [personId, setPersonId] = useState<string | null>(null);

  const { user } = useAuth();
  const { videos } = useVideos(); // lädt Videos des eingeloggten Users

  const selected = useMemo(
    () => (personId ? familyPeople.find(p => p.id === personId) || null : null),
    [personId]
  );

  const onPersonClick = (id: string) => {
    setPersonId(id);
    setMode("person");
  };

  if (mode === "family") {
    return <FamilyGraph people={familyPeople} events={seededEvents} onPersonClick={onPersonClick} />;
  }

  if (!selected) return null;

  // Ingrid => echte Videos (gleiche Mail); andere => (vorerst) leer
  const personVideos =
    selected.userEmail && user?.email && selected.userEmail.toLowerCase() === user.email.toLowerCase()
      ? videos
      : [];

  return (
    <PersonRingView
      personName={selected.displayName}
      birthDate={selected.birthDate}
      videos={personVideos}
      onBack={() => setMode("family")}
    />
  );
}