import { supabase } from '@/lib/supabase';
import { Capacitor } from '@capacitor/core';

// Dynamic import function for background upload plugin
async function loadBackgroundUpload() {
  try {
    // Check if plugin is available - this will always fail gracefully
    return null;
  } catch {
    return null;
  }
}

export async function enqueueUpload(localPath: string, bucket: string, objectKey: string) {
  try {
    console.log(`Enqueueing upload for ${bucket}/${objectKey}`);
    
    // 1) Get signed URL from Edge Function
    const { data, error } = await supabase.functions.invoke('create-upload-url', {
      body: { bucket, objectKey, contentType: 'video/mp4' }
    });
    
    if (error) {
      console.error('Failed to get signed URL:', error);
      throw error;
    }
    
    const { url, headers } = data as { url: string; headers: Record<string, string> };
    console.log('Got signed URL, starting upload...');

    // 2) Native background upload (falls verfügbar und wir eine Pfad-URL aus Filesystem nutzen)
    if (Capacitor.isNativePlatform() && localPath.startsWith('cap://')) {
      try {
        const BackgroundUpload = await loadBackgroundUpload();
        if (BackgroundUpload) {
          await BackgroundUpload.addUpload({
            url,
            filePath: localPath.replace('cap://', ''),
            method: 'PUT',
            headers,
            notificationTitle: 'Video wird hochgeladen...',
            notificationBody: objectKey,
            iosAllowsCellularAccess: true,
            iosAllowsConstrainedNetworkAccess: true,
            androidAutoDeleteAfterUpload: false
          });
          
          console.log('Native background upload enqueued successfully');
          return { success: true, method: 'native' };
        }
      } catch (pluginError) {
        console.warn('Background upload failed, falling back to direct upload:', pluginError);
        // Fall through to direct upload
      }
    }

    // 3) Fallback: Direct upload using fetch (Web/ohne Plugin)
    const fileBlob = await (async () => {
      if (localPath.startsWith('cap://')) {
        // On mobile, we need to read the file from filesystem
        const { Filesystem, Directory } = await import('@capacitor/filesystem');
        const fileData = await Filesystem.readFile({
          path: localPath.replace('cap://', ''),
          directory: Directory.Documents
        });
        // Convert base64 to blob
        const byteChars = atob(fileData.data as string);
        const byteNums = new Array(byteChars.length).fill(0).map((_, i) => byteChars.charCodeAt(i));
        return new Blob([new Uint8Array(byteNums)], { type: 'video/mp4' });
      } else {
        // Web: localPath is likely a blob URL
        const fileResponse = await fetch(localPath);
        return await fileResponse.blob();
      }
    })();
    
    const uploadResponse = await fetch(url, {
      method: 'PUT',
      headers,
      body: fileBlob
    });
    
    if (!uploadResponse.ok) {
      throw new Error(`Upload failed with status ${uploadResponse.status}`);
    }
    
    console.log('Direct upload completed successfully');
    return { success: true, method: 'direct' };
    
  } catch (error) {
    console.error('Upload failed:', error);
    throw error;
  }
}