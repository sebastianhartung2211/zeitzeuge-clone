import { PushNotifications } from '@capacitor/push-notifications';
import { supabase } from '@/lib/supabase';
import { Capacitor } from '@capacitor/core';

export async function registerForPush() {
  // Only register on mobile platforms
  if (!Capacitor.isNativePlatform()) {
    console.log('Push notifications only supported on native platforms');
    return false;
  }

  try {
    console.log('Checking push notification permissions...');
    
    // Check current permissions
    let permissions = await PushNotifications.checkPermissions();
    console.log('Current permissions:', permissions);
    
    // Request permissions if needed
    if (permissions.receive === 'prompt') {
      permissions = await PushNotifications.requestPermissions();
      console.log('Requested permissions:', permissions);
    }
    
    if (permissions.receive !== 'granted') {
      console.warn('Push notification permissions not granted');
      return false;
    }

    // Register for push notifications
    await PushNotifications.register();
    console.log('Registered for push notifications');

    // Set up token registration listener
    PushNotifications.addListener('registration', async (token) => {
      console.log('Push registration token received:', token.value);
      
      try {
        const user = (await supabase.auth.getUser()).data.user;
        if (!user) {
          console.error('No authenticated user found');
          return;
        }

        // Get platform info
        const platform = Capacitor.getPlatform();
        const deviceInfo = {
          platform,
          userAgent: navigator.userAgent,
          timestamp: new Date().toISOString()
        };

        // Store token in database
        const { error } = await supabase
          .from('push_tokens')
          .upsert({
            user_id: user.id,
            token: token.value,
            platform,
            device_info: deviceInfo,
            is_active: true
          });

        if (error) {
          console.error('Failed to store push token:', error);
        } else {
          console.log('Push token stored successfully');
        }
      } catch (error) {
        console.error('Error storing push token:', error);
      }
    });

    // Set up error listener
    PushNotifications.addListener('registrationError', (error) => {
      console.error('Push registration error:', error);
    });

    // Set up notification received listener
    PushNotifications.addListener('pushNotificationReceived', (notification) => {
      console.log('Push notification received:', notification);
    });

    // Set up notification action performed listener
    PushNotifications.addListener('pushNotificationActionPerformed', (action) => {
      console.log('Push notification action performed:', action);
    });

    return true;
    
  } catch (error) {
    console.error('Failed to register for push notifications:', error);
    return false;
  }
}