import { Workbox } from 'workbox-window';

let wb: Workbox | null = null;
let installPrompt: any = null;

const pwaEnabled =
  import.meta.env.PROD && import.meta.env.VITE_ENABLE_PWA === 'true';

export const initializePWA = async () => {
  if (!pwaEnabled) return;
  if (!('serviceWorker' in navigator)) return;

  try {
    wb = new Workbox('/sw.js', { scope: '/' });

    wb.addEventListener('controlling', () => {
      console.log('[PWA] SW controlling – reloading page');
      window.location.reload();
    });

    wb.addEventListener('waiting', async () => {
      try {
        console.log('[PWA] SW waiting – skipWaiting');
        // @ts-ignore
        await wb?.messageSkipWaiting?.();
      } catch (e) {
        console.warn('[PWA] skipWaiting failed', e);
      }
    });

    await wb.register();
    console.log('[PWA] SW registered');
  } catch (error) {
    console.error('[PWA] SW registration failed:', error);
  }
};

export const setupInstallPrompt = () => {
  if (!pwaEnabled) return;
  window.addEventListener('beforeinstallprompt', (e: any) => {
    e.preventDefault();
    installPrompt = e;
  });
};

export const promptInstall = async () => {
  if (!pwaEnabled || !installPrompt) return false;
  try {
    await installPrompt.prompt();
    const choice = await installPrompt.userChoice;
    installPrompt = null;
    return choice?.outcome === 'accepted';
  } catch (error) {
    console.error('[PWA] Install prompt failed:', error);
    return false;
  }
};

export const isPWAInstalled = (): boolean =>
  window.matchMedia('(display-mode: standalone)').matches ||
  (navigator as any).standalone === true;

export const isPWAInstallAvailable = (): boolean => !!installPrompt;