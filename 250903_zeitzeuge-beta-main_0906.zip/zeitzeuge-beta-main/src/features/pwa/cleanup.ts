// src/features/pwa/cleanup.ts
export const cleanupSW = async () => {
  // Nur wenn PWA explizit NICHT aktiviert ist
  if (import.meta.env.VITE_ENABLE_PWA === 'true') return;

  // 1) Service Worker deregistrieren
  if ('serviceWorker' in navigator) {
    try {
      const regs = await navigator.serviceWorker.getRegistrations();
      await Promise.all(regs.map(r => r.unregister()));
      console.info('[PWA] Service worker unregistered');
    } catch (e) {
      console.warn('[PWA] SW unregister failed', e);
    }
  }

  // 2) Caches löschen
  if ('caches' in window) {
    try {
      const keys = await caches.keys();
      await Promise.all(keys.map(k => caches.delete(k)));
      console.info('[PWA] caches cleared');
    } catch (e) {
      console.warn('[PWA] cache clear failed', e);
    }
  }
};