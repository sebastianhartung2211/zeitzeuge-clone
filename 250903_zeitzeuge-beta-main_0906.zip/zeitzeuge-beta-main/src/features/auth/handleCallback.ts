import { supabase } from '@/lib/supabase';

export async function handleDeepLink(url: string) {
  // Beispiel: zeitzeuge://auth-callback#access_token=...
  await supabase.auth.exchangeCodeForSession(url);
}