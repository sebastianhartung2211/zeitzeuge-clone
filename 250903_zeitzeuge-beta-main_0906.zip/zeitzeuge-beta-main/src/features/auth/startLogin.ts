import { Browser } from '@capacitor/browser';
import { supabase } from '@/lib/supabase';

const isMobile = typeof window !== 'undefined' && !!(window as any).Capacitor;
const redirectTo = isMobile ? 'zeitzeuge://auth-callback' : window.location.origin;

export async function startLogin() {
  const { data, error } = await supabase.auth.signInWithOAuth({
    provider: 'google', // oder github/… wie konfiguriert
    options: { redirectTo }
  });
  if (error) throw error;
  if (isMobile && data?.url) await Browser.open({ url: data.url });
}