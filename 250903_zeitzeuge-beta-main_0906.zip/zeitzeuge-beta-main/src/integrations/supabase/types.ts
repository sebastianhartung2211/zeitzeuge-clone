export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "12.2.3 (519615d)"
  }
  public: {
    Tables: {
      categories: {
        Row: {
          created_at: string
          description: string | null
          id: string
          name: string
        }
        Insert: {
          created_at?: string
          description?: string | null
          id?: string
          name: string
        }
        Update: {
          created_at?: string
          description?: string | null
          id?: string
          name?: string
        }
        Relationships: []
      }
      conversation_feedback: {
        Row: {
          conversation_id: string | null
          created_at: string
          feedback_text: string | null
          feedback_type: string
          id: string
          metadata: Json | null
          rating: number | null
          user_id: string
        }
        Insert: {
          conversation_id?: string | null
          created_at?: string
          feedback_text?: string | null
          feedback_type?: string
          id?: string
          metadata?: Json | null
          rating?: number | null
          user_id: string
        }
        Update: {
          conversation_id?: string | null
          created_at?: string
          feedback_text?: string | null
          feedback_type?: string
          id?: string
          metadata?: Json | null
          rating?: number | null
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "conversation_feedback_conversation_id_fkey"
            columns: ["conversation_id"]
            isOneToOne: false
            referencedRelation: "conversations"
            referencedColumns: ["id"]
          },
        ]
      }
      conversations: {
        Row: {
          answer: string | null
          confidence_score: number | null
          created_at: string
          id: string
          matched_video_id: string | null
          metadata: Json | null
          question: string
          user_id: string
        }
        Insert: {
          answer?: string | null
          confidence_score?: number | null
          created_at?: string
          id?: string
          matched_video_id?: string | null
          metadata?: Json | null
          question: string
          user_id: string
        }
        Update: {
          answer?: string | null
          confidence_score?: number | null
          created_at?: string
          id?: string
          matched_video_id?: string | null
          metadata?: Json | null
          question?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "conversations_matched_video_id_fkey"
            columns: ["matched_video_id"]
            isOneToOne: false
            referencedRelation: "family_event_member_videos"
            referencedColumns: ["video_id"]
          },
          {
            foreignKeyName: "conversations_matched_video_id_fkey"
            columns: ["matched_video_id"]
            isOneToOne: false
            referencedRelation: "videos"
            referencedColumns: ["id"]
          },
        ]
      }
      families: {
        Row: {
          created_at: string
          created_by: string
          description: string | null
          id: string
          invite_code: string
          name: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          created_by: string
          description?: string | null
          id?: string
          invite_code: string
          name: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          created_by?: string
          description?: string | null
          id?: string
          invite_code?: string
          name?: string
          updated_at?: string
        }
        Relationships: []
      }
      family_events: {
        Row: {
          category_id: string | null
          created_at: string
          created_by: string
          event_date: string
          family_id: string
          id: string
          name: string
          updated_at: string
        }
        Insert: {
          category_id?: string | null
          created_at?: string
          created_by: string
          event_date: string
          family_id: string
          id?: string
          name: string
          updated_at?: string
        }
        Update: {
          category_id?: string | null
          created_at?: string
          created_by?: string
          event_date?: string
          family_id?: string
          id?: string
          name?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "family_events_category_id_fkey"
            columns: ["category_id"]
            isOneToOne: false
            referencedRelation: "categories"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "family_events_family_id_fkey"
            columns: ["family_id"]
            isOneToOne: false
            referencedRelation: "families"
            referencedColumns: ["id"]
          },
        ]
      }
      family_invitations: {
        Row: {
          created_at: string
          expires_at: string
          family_id: string
          id: string
          invite_token: string
          invited_by: string
          invited_email: string
          invited_name: string
          relationship: string | null
          status: string
        }
        Insert: {
          created_at?: string
          expires_at?: string
          family_id: string
          id?: string
          invite_token: string
          invited_by: string
          invited_email: string
          invited_name: string
          relationship?: string | null
          status?: string
        }
        Update: {
          created_at?: string
          expires_at?: string
          family_id?: string
          id?: string
          invite_token?: string
          invited_by?: string
          invited_email?: string
          invited_name?: string
          relationship?: string | null
          status?: string
        }
        Relationships: []
      }
      family_members: {
        Row: {
          avatar_color: string | null
          birthdate: string | null
          consent_data_processing: boolean | null
          consent_given_at: string | null
          consent_public_display: boolean | null
          display_name: string
          email: string | null
          family_id: string
          first_name: string | null
          id: string
          invite_token: string | null
          joined_at: string
          last_name: string | null
          relationship: string | null
          role: string
          status: string | null
          user_id: string
        }
        Insert: {
          avatar_color?: string | null
          birthdate?: string | null
          consent_data_processing?: boolean | null
          consent_given_at?: string | null
          consent_public_display?: boolean | null
          display_name: string
          email?: string | null
          family_id: string
          first_name?: string | null
          id?: string
          invite_token?: string | null
          joined_at?: string
          last_name?: string | null
          relationship?: string | null
          role?: string
          status?: string | null
          user_id: string
        }
        Update: {
          avatar_color?: string | null
          birthdate?: string | null
          consent_data_processing?: boolean | null
          consent_given_at?: string | null
          consent_public_display?: boolean | null
          display_name?: string
          email?: string | null
          family_id?: string
          first_name?: string | null
          id?: string
          invite_token?: string | null
          joined_at?: string
          last_name?: string | null
          relationship?: string | null
          role?: string
          status?: string | null
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "family_members_family_id_fkey"
            columns: ["family_id"]
            isOneToOne: false
            referencedRelation: "families"
            referencedColumns: ["id"]
          },
        ]
      }
      notifications: {
        Row: {
          agent_name: string
          created_at: string
          id: string
          is_read: boolean
          message: string
          metadata: Json | null
          notification_type: string
          title: string
          user_id: string
          video_id: string | null
        }
        Insert: {
          agent_name: string
          created_at?: string
          id?: string
          is_read?: boolean
          message: string
          metadata?: Json | null
          notification_type: string
          title: string
          user_id: string
          video_id?: string | null
        }
        Update: {
          agent_name?: string
          created_at?: string
          id?: string
          is_read?: boolean
          message?: string
          metadata?: Json | null
          notification_type?: string
          title?: string
          user_id?: string
          video_id?: string | null
        }
        Relationships: []
      }
      processing_logs: {
        Row: {
          agent_name: string
          created_at: string
          error_message: string | null
          id: string
          input_data: Json | null
          output_data: Json | null
          processing_time_ms: number | null
          stage: string
          status: string
          video_id: string
        }
        Insert: {
          agent_name: string
          created_at?: string
          error_message?: string | null
          id?: string
          input_data?: Json | null
          output_data?: Json | null
          processing_time_ms?: number | null
          stage: string
          status: string
          video_id: string
        }
        Update: {
          agent_name?: string
          created_at?: string
          error_message?: string | null
          id?: string
          input_data?: Json | null
          output_data?: Json | null
          processing_time_ms?: number | null
          stage?: string
          status?: string
          video_id?: string
        }
        Relationships: []
      }
      profiles: {
        Row: {
          avatar_url: string | null
          birthdate: string | null
          created_at: string
          display_name: string | null
          first_name: string | null
          last_name: string | null
          updated_at: string
          user_id: string
        }
        Insert: {
          avatar_url?: string | null
          birthdate?: string | null
          created_at?: string
          display_name?: string | null
          first_name?: string | null
          last_name?: string | null
          updated_at?: string
          user_id: string
        }
        Update: {
          avatar_url?: string | null
          birthdate?: string | null
          created_at?: string
          display_name?: string | null
          first_name?: string | null
          last_name?: string | null
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      push_tokens: {
        Row: {
          created_at: string
          device_info: Json | null
          id: string
          is_active: boolean
          platform: string
          token: string
          updated_at: string
          user_id: string
        }
        Insert: {
          created_at?: string
          device_info?: Json | null
          id?: string
          is_active?: boolean
          platform?: string
          token: string
          updated_at?: string
          user_id: string
        }
        Update: {
          created_at?: string
          device_info?: Json | null
          id?: string
          is_active?: boolean
          platform?: string
          token?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      question_assignments: {
        Row: {
          answer_video_id: string | null
          answered_at: string | null
          assigned_by: string
          assigned_to: string
          created_at: string
          due_at: string | null
          family_id: string
          id: string
          metadata: Json | null
          question_id: string
          status: string
          updated_at: string
        }
        Insert: {
          answer_video_id?: string | null
          answered_at?: string | null
          assigned_by: string
          assigned_to: string
          created_at?: string
          due_at?: string | null
          family_id: string
          id?: string
          metadata?: Json | null
          question_id: string
          status?: string
          updated_at?: string
        }
        Update: {
          answer_video_id?: string | null
          answered_at?: string | null
          assigned_by?: string
          assigned_to?: string
          created_at?: string
          due_at?: string | null
          family_id?: string
          id?: string
          metadata?: Json | null
          question_id?: string
          status?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "question_assignments_answer_video_id_fkey"
            columns: ["answer_video_id"]
            isOneToOne: false
            referencedRelation: "family_event_member_videos"
            referencedColumns: ["video_id"]
          },
          {
            foreignKeyName: "question_assignments_answer_video_id_fkey"
            columns: ["answer_video_id"]
            isOneToOne: false
            referencedRelation: "videos"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "question_assignments_assigned_to_fkey"
            columns: ["assigned_to"]
            isOneToOne: false
            referencedRelation: "family_event_member_videos"
            referencedColumns: ["family_member_id"]
          },
          {
            foreignKeyName: "question_assignments_assigned_to_fkey"
            columns: ["assigned_to"]
            isOneToOne: false
            referencedRelation: "family_members"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "question_assignments_family_id_fkey"
            columns: ["family_id"]
            isOneToOne: false
            referencedRelation: "families"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "question_assignments_question_id_fkey"
            columns: ["question_id"]
            isOneToOne: false
            referencedRelation: "questions"
            referencedColumns: ["id"]
          },
        ]
      }
      questions: {
        Row: {
          category_id: string | null
          created_at: string
          created_by: string
          id: string
          source: string
          text: string
        }
        Insert: {
          category_id?: string | null
          created_at?: string
          created_by: string
          id?: string
          source?: string
          text: string
        }
        Update: {
          category_id?: string | null
          created_at?: string
          created_by?: string
          id?: string
          source?: string
          text?: string
        }
        Relationships: [
          {
            foreignKeyName: "questions_category_id_fkey"
            columns: ["category_id"]
            isOneToOne: false
            referencedRelation: "categories"
            referencedColumns: ["id"]
          },
        ]
      }
      segments: {
        Row: {
          content: string | null
          created_at: string
          end_time: number
          id: string
          persons_mentioned: string[] | null
          start_time: number
          title: string
          updated_at: string
          video_id: string
        }
        Insert: {
          content?: string | null
          created_at?: string
          end_time: number
          id?: string
          persons_mentioned?: string[] | null
          start_time: number
          title: string
          updated_at?: string
          video_id: string
        }
        Update: {
          content?: string | null
          created_at?: string
          end_time?: number
          id?: string
          persons_mentioned?: string[] | null
          start_time?: number
          title?: string
          updated_at?: string
          video_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "segments_video_id_fkey"
            columns: ["video_id"]
            isOneToOne: false
            referencedRelation: "family_event_member_videos"
            referencedColumns: ["video_id"]
          },
          {
            foreignKeyName: "segments_video_id_fkey"
            columns: ["video_id"]
            isOneToOne: false
            referencedRelation: "videos"
            referencedColumns: ["id"]
          },
        ]
      }
      tags: {
        Row: {
          category: string | null
          created_at: string
          id: string
          name: string
        }
        Insert: {
          category?: string | null
          created_at?: string
          id?: string
          name: string
        }
        Update: {
          category?: string | null
          created_at?: string
          id?: string
          name?: string
        }
        Relationships: []
      }
      transcript_chunks: {
        Row: {
          content: string
          created_at: string
          embedding_json: Json | null
          end_time: number
          id: string
          start_time: number
          transcript_id: string
          updated_at: string
          video_id: string
        }
        Insert: {
          content: string
          created_at?: string
          embedding_json?: Json | null
          end_time: number
          id?: string
          start_time: number
          transcript_id: string
          updated_at?: string
          video_id: string
        }
        Update: {
          content?: string
          created_at?: string
          embedding_json?: Json | null
          end_time?: number
          id?: string
          start_time?: number
          transcript_id?: string
          updated_at?: string
          video_id?: string
        }
        Relationships: []
      }
      transcripts: {
        Row: {
          confidence: number | null
          content: string
          created_at: string
          id: string
          language: string | null
          updated_at: string
          video_id: string
        }
        Insert: {
          confidence?: number | null
          content: string
          created_at?: string
          id?: string
          language?: string | null
          updated_at?: string
          video_id: string
        }
        Update: {
          confidence?: number | null
          content?: string
          created_at?: string
          id?: string
          language?: string | null
          updated_at?: string
          video_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "transcripts_video_id_fkey"
            columns: ["video_id"]
            isOneToOne: false
            referencedRelation: "family_event_member_videos"
            referencedColumns: ["video_id"]
          },
          {
            foreignKeyName: "transcripts_video_id_fkey"
            columns: ["video_id"]
            isOneToOne: false
            referencedRelation: "videos"
            referencedColumns: ["id"]
          },
        ]
      }
      video_interactions: {
        Row: {
          created_at: string
          id: string
          interaction_type: string | null
          metadata: Json | null
          user_id: string
          video_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          interaction_type?: string | null
          metadata?: Json | null
          user_id: string
          video_id: string
        }
        Update: {
          created_at?: string
          id?: string
          interaction_type?: string | null
          metadata?: Json | null
          user_id?: string
          video_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "video_interactions_video_id_fkey"
            columns: ["video_id"]
            isOneToOne: false
            referencedRelation: "family_event_member_videos"
            referencedColumns: ["video_id"]
          },
          {
            foreignKeyName: "video_interactions_video_id_fkey"
            columns: ["video_id"]
            isOneToOne: false
            referencedRelation: "videos"
            referencedColumns: ["id"]
          },
        ]
      }
      video_permissions: {
        Row: {
          created_at: string
          family_id: string
          id: string
          shared_by: string
          video_id: string
        }
        Insert: {
          created_at?: string
          family_id: string
          id?: string
          shared_by: string
          video_id: string
        }
        Update: {
          created_at?: string
          family_id?: string
          id?: string
          shared_by?: string
          video_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "video_permissions_family_id_fkey"
            columns: ["family_id"]
            isOneToOne: false
            referencedRelation: "families"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "video_permissions_video_id_fkey"
            columns: ["video_id"]
            isOneToOne: false
            referencedRelation: "family_event_member_videos"
            referencedColumns: ["video_id"]
          },
          {
            foreignKeyName: "video_permissions_video_id_fkey"
            columns: ["video_id"]
            isOneToOne: false
            referencedRelation: "videos"
            referencedColumns: ["id"]
          },
        ]
      }
      video_tags: {
        Row: {
          created_at: string
          id: string
          relevance_score: number | null
          tag_id: string
          video_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          relevance_score?: number | null
          tag_id: string
          video_id: string
        }
        Update: {
          created_at?: string
          id?: string
          relevance_score?: number | null
          tag_id?: string
          video_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "video_tags_tag_id_fkey"
            columns: ["tag_id"]
            isOneToOne: false
            referencedRelation: "tags"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "video_tags_video_id_fkey"
            columns: ["video_id"]
            isOneToOne: false
            referencedRelation: "family_event_member_videos"
            referencedColumns: ["video_id"]
          },
          {
            foreignKeyName: "video_tags_video_id_fkey"
            columns: ["video_id"]
            isOneToOne: false
            referencedRelation: "videos"
            referencedColumns: ["id"]
          },
        ]
      }
      videos: {
        Row: {
          category: string | null
          created_at: string
          custom_date: string | null
          description: string | null
          duration: number | null
          event_id: string | null
          family_id: string | null
          id: string
          status: string
          thumbnail_url: string | null
          title: string
          updated_at: string
          user_id: string
          video_url: string
          visibility: string | null
        }
        Insert: {
          category?: string | null
          created_at?: string
          custom_date?: string | null
          description?: string | null
          duration?: number | null
          event_id?: string | null
          family_id?: string | null
          id?: string
          status?: string
          thumbnail_url?: string | null
          title: string
          updated_at?: string
          user_id: string
          video_url: string
          visibility?: string | null
        }
        Update: {
          category?: string | null
          created_at?: string
          custom_date?: string | null
          description?: string | null
          duration?: number | null
          event_id?: string | null
          family_id?: string | null
          id?: string
          status?: string
          thumbnail_url?: string | null
          title?: string
          updated_at?: string
          user_id?: string
          video_url?: string
          visibility?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "videos_event_id_fkey"
            columns: ["event_id"]
            isOneToOne: false
            referencedRelation: "family_event_member_videos"
            referencedColumns: ["event_id"]
          },
          {
            foreignKeyName: "videos_event_id_fkey"
            columns: ["event_id"]
            isOneToOne: false
            referencedRelation: "family_events"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "videos_family_id_fkey"
            columns: ["family_id"]
            isOneToOne: false
            referencedRelation: "families"
            referencedColumns: ["id"]
          },
        ]
      }
    }
    Views: {
      family_event_member_videos: {
        Row: {
          event_date: string | null
          event_id: string | null
          event_name: string | null
          family_id: string | null
          family_member_id: string | null
          first_name: string | null
          last_name: string | null
          member_user_id: string | null
          video_created_at: string | null
          video_id: string | null
          video_owner_id: string | null
        }
        Relationships: [
          {
            foreignKeyName: "family_events_family_id_fkey"
            columns: ["family_id"]
            isOneToOne: false
            referencedRelation: "families"
            referencedColumns: ["id"]
          },
        ]
      }
      family_question_status: {
        Row: {
          answer_video_id: string | null
          answered_at: string | null
          assignment_id: string | null
          due_at: string | null
          family_id: string | null
          family_member_id: string | null
          first_name: string | null
          last_name: string | null
          member_user_id: string | null
          question_id: string | null
          question_text: string | null
          status: string | null
        }
        Relationships: [
          {
            foreignKeyName: "question_assignments_answer_video_id_fkey"
            columns: ["answer_video_id"]
            isOneToOne: false
            referencedRelation: "family_event_member_videos"
            referencedColumns: ["video_id"]
          },
          {
            foreignKeyName: "question_assignments_answer_video_id_fkey"
            columns: ["answer_video_id"]
            isOneToOne: false
            referencedRelation: "videos"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "question_assignments_assigned_to_fkey"
            columns: ["family_member_id"]
            isOneToOne: false
            referencedRelation: "family_event_member_videos"
            referencedColumns: ["family_member_id"]
          },
          {
            foreignKeyName: "question_assignments_assigned_to_fkey"
            columns: ["family_member_id"]
            isOneToOne: false
            referencedRelation: "family_members"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "question_assignments_family_id_fkey"
            columns: ["family_id"]
            isOneToOne: false
            referencedRelation: "families"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "question_assignments_question_id_fkey"
            columns: ["question_id"]
            isOneToOne: false
            referencedRelation: "questions"
            referencedColumns: ["id"]
          },
        ]
      }
    }
    Functions: {
      accept_family_invitation: {
        Args: { accepting_user_id: string; invitation_token: string }
        Returns: Json
      }
      binary_quantize: {
        Args: { "": string } | { "": unknown }
        Returns: unknown
      }
      calculate_vector_similarity: {
        Args: { embedding1: Json; embedding2: Json }
        Returns: number
      }
      categorize_video_by_tags: {
        Args: { video_id_param: string }
        Returns: string
      }
      check_family_membership: {
        Args: { family_id_param: string; user_id_param: string }
        Returns: boolean
      }
      create_family_event: {
        Args: {
          p_category_id?: string
          p_event_date: string
          p_family_id: string
          p_name: string
        }
        Returns: string
      }
      generate_invite_code: {
        Args: Record<PropertyKey, never>
        Returns: string
      }
      generate_secure_token: {
        Args: Record<PropertyKey, never>
        Returns: string
      }
      get_average_feedback_rating: {
        Args: { days_back?: number; user_id_param: string }
        Returns: number
      }
      get_feedback_statistics: {
        Args: { user_id_param: string }
        Returns: Json
      }
      get_profile_picture_url: {
        Args: { filename?: string; user_id_param: string }
        Returns: string
      }
      get_user_notifications: {
        Args: { user_id_param: string }
        Returns: {
          agent_name: string
          created_at: string
          id: string
          is_read: boolean
          message: string
          metadata: Json
          notification_type: string
          title: string
          video_id: string
        }[]
      }
      halfvec_avg: {
        Args: { "": number[] }
        Returns: unknown
      }
      halfvec_out: {
        Args: { "": unknown }
        Returns: unknown
      }
      halfvec_send: {
        Args: { "": unknown }
        Returns: string
      }
      halfvec_typmod_in: {
        Args: { "": unknown[] }
        Returns: number
      }
      hnsw_bit_support: {
        Args: { "": unknown }
        Returns: unknown
      }
      hnsw_halfvec_support: {
        Args: { "": unknown }
        Returns: unknown
      }
      hnsw_sparsevec_support: {
        Args: { "": unknown }
        Returns: unknown
      }
      hnswhandler: {
        Args: { "": unknown }
        Returns: unknown
      }
      is_family_admin: {
        Args: { fid: string }
        Returns: boolean
      }
      is_family_member: {
        Args: { fid: string }
        Returns: boolean
      }
      is_valid_uuid: {
        Args: { input_text: string }
        Returns: boolean
      }
      ivfflat_bit_support: {
        Args: { "": unknown }
        Returns: unknown
      }
      ivfflat_halfvec_support: {
        Args: { "": unknown }
        Returns: unknown
      }
      ivfflathandler: {
        Args: { "": unknown }
        Returns: unknown
      }
      join_family_by_invite_code: {
        Args: {
          code: string
          member_name: string
          member_relationship?: string
        }
        Returns: Json
      }
      l2_norm: {
        Args: { "": unknown } | { "": unknown }
        Returns: number
      }
      l2_normalize: {
        Args: { "": string } | { "": unknown } | { "": unknown }
        Returns: string
      }
      log_agent_performance: {
        Args: {
          agent_name_param: string
          duration_ms_param: number
          metadata_param?: Json
          operation_param: string
          success_param: boolean
        }
        Returns: string
      }
      mark_all_notifications_read: {
        Args: { user_id_param: string }
        Returns: number
      }
      mark_notification_read: {
        Args: { notification_id: string }
        Returns: boolean
      }
      process_pending_videos_batch: {
        Args: Record<PropertyKey, never>
        Returns: Json
      }
      sparsevec_out: {
        Args: { "": unknown }
        Returns: unknown
      }
      sparsevec_send: {
        Args: { "": unknown }
        Returns: string
      }
      sparsevec_typmod_in: {
        Args: { "": unknown[] }
        Returns: number
      }
      trigger_manual_transcription: {
        Args: { folder_path_param: string }
        Returns: Json
      }
      trigger_storage_processing: {
        Args: { storage_path_param: string; user_id_param: string }
        Returns: Json
      }
      trigger_video_recovery: {
        Args: Record<PropertyKey, never>
        Returns: Json
      }
      trigger_video_status_recovery: {
        Args: Record<PropertyKey, never>
        Returns: Json
      }
      upsert_tag: {
        Args: { tag_category?: string; tag_name: string }
        Returns: string
      }
      vector_avg: {
        Args: { "": number[] }
        Returns: string
      }
      vector_dims: {
        Args: { "": string } | { "": unknown }
        Returns: number
      }
      vector_norm: {
        Args: { "": string }
        Returns: number
      }
      vector_out: {
        Args: { "": string }
        Returns: unknown
      }
      vector_send: {
        Args: { "": string }
        Returns: string
      }
      vector_typmod_in: {
        Args: { "": unknown[] }
        Returns: number
      }
    }
    Enums: {
      [_ in never]: never
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {},
  },
} as const
