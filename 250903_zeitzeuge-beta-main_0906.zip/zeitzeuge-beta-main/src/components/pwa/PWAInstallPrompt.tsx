import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Download, X, Smartphone } from 'lucide-react';
import { promptInstall, isPWAInstalled, isPWAInstallAvailable } from '@/features/pwa/pwaService';

export const PWAInstallPrompt = () => {
  const [showPrompt, setShowPrompt] = useState(false);
  const [isInstalling, setIsInstalling] = useState(false);

  useEffect(() => {
    // Check initial state
    if (!isPWAInstalled() && isPWAInstallAvailable()) {
      setShowPrompt(true);
    }

    // Listen for install availability
    const handleInstallAvailable = () => {
      if (!isPWAInstalled()) {
        setShowPrompt(true);
      }
    };

    const handleInstalled = () => {
      setShowPrompt(false);
    };

    window.addEventListener('pwa-install-available', handleInstallAvailable);
    window.addEventListener('pwa-installed', handleInstalled);

    return () => {
      window.removeEventListener('pwa-install-available', handleInstallAvailable);
      window.removeEventListener('pwa-installed', handleInstalled);
    };
  }, []);

  const handleInstall = async () => {
    setIsInstalling(true);
    try {
      const success = await promptInstall();
      if (success) {
        setShowPrompt(false);
      }
    } catch (error) {
      console.error('Install failed:', error);
    } finally {
      setIsInstalling(false);
    }
  };

  const handleDismiss = () => {
    setShowPrompt(false);
    // Hide for 7 days
    localStorage.setItem('pwa-install-dismissed', Date.now().toString());
  };

  // Don't show if recently dismissed
  const dismissedTime = localStorage.getItem('pwa-install-dismissed');
  if (dismissedTime && Date.now() - parseInt(dismissedTime) < 7 * 24 * 60 * 60 * 1000) {
    return null;
  }

  if (!showPrompt) {
    return null;
  }

  return (
    <Card className="fixed bottom-4 left-4 right-4 z-50 mx-auto max-w-md border-[hsl(var(--coral))]/20 bg-white/95 backdrop-blur-sm shadow-lg">
      <CardHeader className="pb-3">
        <div className="flex items-start justify-between">
          <div className="flex items-center gap-2">
            <Smartphone className="w-5 h-5 text-[hsl(var(--coral))]" />
            <CardTitle className="text-base">App installieren</CardTitle>
          </div>
          <Button
            variant="ghost"
            size="sm"
            onClick={handleDismiss}
            className="h-6 w-6 p-0 text-muted-foreground hover:text-foreground"
          >
            <X className="w-4 h-4" />
          </Button>
        </div>
        <CardDescription className="text-sm">
          Installieren Sie Zeitzeuge für ein besseres Erlebnis mit Offline-Unterstützung
        </CardDescription>
      </CardHeader>
      <CardContent className="pt-0">
        <div className="flex gap-2">
          <Button
            onClick={handleInstall}
            disabled={isInstalling}
            className="flex-1 bg-[hsl(var(--coral))] text-white hover:bg-[hsl(var(--coral))]/90"
            size="sm"
          >
            <Download className="w-4 h-4 mr-2" />
            {isInstalling ? 'Installiere...' : 'Installieren'}
          </Button>
          <Button
            variant="outline"
            onClick={handleDismiss}
            className="flex-1"
            size="sm"
          >
            Später
          </Button>
        </div>
      </CardContent>
    </Card>
  );
};