import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Smartphone, Wifi, WifiOff, Download } from 'lucide-react';
import { isPWAInstalled, promptInstall, isPWAInstallAvailable } from '@/features/pwa/pwaService';

export const PWAStatus = () => {
  const [isInstalled, setIsInstalled] = useState(false);
  const [isOnline, setIsOnline] = useState(navigator.onLine);
  const [canInstall, setCanInstall] = useState(false);

  useEffect(() => {
    // Check PWA installation status
    setIsInstalled(isPWAInstalled());
    setCanInstall(isPWAInstallAvailable());

    // Listen for online/offline events
    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);
    
    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    // Listen for PWA events
    const handleInstallAvailable = () => setCanInstall(true);
    const handleInstalled = () => {
      setIsInstalled(true);
      setCanInstall(false);
    };

    window.addEventListener('pwa-install-available', handleInstallAvailable);
    window.addEventListener('pwa-installed', handleInstalled);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
      window.removeEventListener('pwa-install-available', handleInstallAvailable);
      window.removeEventListener('pwa-installed', handleInstalled);
    };
  }, []);

  const handleInstall = async () => {
    try {
      await promptInstall();
    } catch (error) {
      console.error('Installation failed:', error);
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Smartphone className="w-5 h-5" />
          App Status
        </CardTitle>
        <CardDescription>
          Progressive Web App Funktionen und Online-Status
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="flex items-center justify-between">
          <span className="text-sm font-medium">Installation:</span>
          <Badge variant={isInstalled ? "default" : "secondary"}>
            {isInstalled ? 'Installiert' : 'Web Version'}
          </Badge>
        </div>
        
        <div className="flex items-center justify-between">
          <span className="text-sm font-medium">Verbindung:</span>
          <Badge variant={isOnline ? "default" : "destructive"} className="flex items-center gap-1">
            {isOnline ? <Wifi className="w-3 h-3" /> : <WifiOff className="w-3 h-3" />}
            {isOnline ? 'Online' : 'Offline'}
          </Badge>
        </div>

        <div className="flex items-center justify-between">
          <span className="text-sm font-medium">Offline Modus:</span>
          <Badge variant="default">
            Verfügbar
          </Badge>
        </div>

        {canInstall && !isInstalled && (
          <div className="pt-2 border-t">
            <Button 
              onClick={handleInstall}
              className="w-full bg-[hsl(var(--coral))] text-white hover:bg-[hsl(var(--coral))]/90"
              size="sm"
            >
              <Download className="w-4 h-4 mr-2" />
              App installieren
            </Button>
          </div>
        )}

        {isInstalled && (
          <div className="text-xs text-muted-foreground pt-2 border-t">
            ✓ Offline-Unterstützung aktiv<br />
            ✓ Hintergrund-Synchronisation verfügbar<br />
            ✓ Push-Benachrichtigungen möglich
          </div>
        )}
      </CardContent>
    </Card>
  );
};