import React, { useState, useEffect } from 'react';
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { 
  RefreshCw, 
  Zap, 
  CheckCircle, 
  AlertCircle, 
  BarChart3,
  Database
} from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/components/ui/use-toast";

interface EmbeddingStatus {
  totalVideos: number;
  videosWithEmbeddings: number;
  totalChunks: number;
  avgChunksPerVideo: number;
  videos: Array<{
    id: string;
    title: string;
    chunks: number;
    hasEmbeddings: boolean;
  }>;
}

export const EmbeddingManager: React.FC = () => {
  const [status, setStatus] = useState<EmbeddingStatus | null>(null);
  const [isGenerating, setIsGenerating] = useState(false);
  const [isChecking, setIsChecking] = useState(false);
  const [progress, setProgress] = useState(0);
  const [generationStats, setGenerationStats] = useState<any>(null);
  
  const { user } = useAuth();
  const { toast } = useToast();

  useEffect(() => {
    if (user) {
      checkEmbeddingStatus();
    }
  }, [user]);

  const checkEmbeddingStatus = async () => {
    if (!user) return;
    
    setIsChecking(true);
    try {
      const { data, error } = await supabase.functions.invoke('embedding-generator', {
        body: {
          action: 'check_status',
          userId: user.id
        }
      });

      if (error) throw error;
      
      setStatus(data);
      console.log('Embedding status:', data);
      
    } catch (error) {
      console.error('Error checking embedding status:', error);
      toast({
        title: "Fehler beim Statuscheck",
        description: "Status der Embeddings konnte nicht abgerufen werden.",
        variant: "destructive",
      });
    } finally {
      setIsChecking(false);
    }
  };

  const generateEmbeddings = async (regenerate = false) => {
    if (!user) return;
    
    setIsGenerating(true);
    setProgress(0);
    setGenerationStats(null);
    
    try {
      const action = regenerate ? 'regenerate_embeddings' : 'generate_embeddings';
      
      toast({
        title: regenerate ? "Embeddings werden neu generiert..." : "Embeddings werden generiert...",
        description: "Dies kann einige Minuten dauern. Bitte warten Sie.",
      });

      const { data, error } = await supabase.functions.invoke('embedding-generator', {
        body: {
          action,
          userId: user.id
        }
      });

      if (error) throw error;
      
      setGenerationStats(data);
      
      toast({
        title: "Embeddings erfolgreich generiert",
        description: `${data.chunksCreated} Chunks für ${data.processed} Videos erstellt.`,
      });
      
      // Refresh status
      await checkEmbeddingStatus();
      
    } catch (error) {
      console.error('Error generating embeddings:', error);
      toast({
        title: "Fehler bei der Generierung",
        description: "Embeddings konnten nicht generiert werden.",
        variant: "destructive",
      });
    } finally {
      setIsGenerating(false);
      setProgress(0);
    }
  };

  const getCompletionPercentage = () => {
    if (!status) return 0;
    return status.totalVideos > 0 
      ? Math.round((status.videosWithEmbeddings / status.totalVideos) * 100)
      : 0;
  };

  const getStatusColor = () => {
    const percentage = getCompletionPercentage();
    if (percentage === 100) return 'text-green-600';
    if (percentage >= 70) return 'text-yellow-600';
    return 'text-red-600';
  };

  const getStatusIcon = () => {
    const percentage = getCompletionPercentage();
    if (percentage === 100) return <CheckCircle className="h-5 w-5 text-green-600" />;
    return <AlertCircle className="h-5 w-5 text-yellow-600" />;
  };

  if (!user) {
    return (
      <Card>
        <CardContent className="p-6">
          <p className="text-center text-gray-500">
            Bitte melden Sie sich an, um Embeddings zu verwalten.
          </p>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      {/* Status Overview */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Database className="h-5 w-5" />
            Embedding-Status
            {getStatusIcon()}
          </CardTitle>
        </CardHeader>
        <CardContent>
          {isChecking ? (
            <div className="flex items-center gap-2">
              <RefreshCw className="h-4 w-4 animate-spin" />
              Status wird überprüft...
            </div>
          ) : status ? (
            <div className="space-y-4">
              {/* Overall Progress */}
              <div>
                <div className="flex justify-between text-sm mb-2">
                  <span>Fortschritt</span>
                  <span className={getStatusColor()}>
                    {status.videosWithEmbeddings} von {status.totalVideos} Videos
                  </span>
                </div>
                <Progress value={getCompletionPercentage()} className="h-2" />
              </div>

              {/* Statistics */}
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <div className="text-center">
                  <div className="text-2xl font-bold text-blue-600">
                    {status.totalVideos}
                  </div>
                  <div className="text-sm text-gray-500">Gesamt Videos</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-green-600">
                    {status.videosWithEmbeddings}
                  </div>
                  <div className="text-sm text-gray-500">Mit Embeddings</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-purple-600">
                    {status.totalChunks}
                  </div>
                  <div className="text-sm text-gray-500">Chunks</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-orange-600">
                    {status.avgChunksPerVideo.toFixed(1)}
                  </div>
                  <div className="text-sm text-gray-500">Ø Chunks/Video</div>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex gap-2 pt-2">
                <Button
                  onClick={() => generateEmbeddings(false)}
                  disabled={isGenerating}
                  className="flex items-center gap-2"
                >
                  {isGenerating ? (
                    <RefreshCw className="h-4 w-4 animate-spin" />
                  ) : (
                    <Zap className="h-4 w-4" />
                  )}
                  Fehlende Embeddings generieren
                </Button>
                
                <Button
                  onClick={() => generateEmbeddings(true)}
                  disabled={isGenerating}
                  variant="outline"
                  className="flex items-center gap-2"
                >
                  <RefreshCw className="h-4 w-4" />
                  Alle neu generieren
                </Button>

                <Button
                  onClick={checkEmbeddingStatus}
                  disabled={isChecking}
                  variant="outline"
                  size="sm"
                >
                  <BarChart3 className="h-4 w-4" />
                </Button>
              </div>
            </div>
          ) : (
            <div className="text-center py-4">
              <Button onClick={checkEmbeddingStatus} variant="outline">
                Status laden
              </Button>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Generation Progress */}
      {isGenerating && (
        <Card>
          <CardContent className="p-6">
            <div className="space-y-4">
              <div className="flex items-center gap-2">
                <RefreshCw className="h-4 w-4 animate-spin" />
                <span className="font-medium">Embeddings werden generiert...</span>
              </div>
              <Progress value={progress} className="h-2" />
              <p className="text-sm text-gray-500">
                Dies kann je nach Anzahl der Videos einige Minuten dauern.
              </p>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Generation Results */}
      {generationStats && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <CheckCircle className="h-5 w-5 text-green-600" />
              Generierung Abgeschlossen
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <div className="text-center">
                <div className="text-xl font-bold text-green-600">
                  {generationStats.processed}
                </div>
                <div className="text-sm text-gray-500">Verarbeitet</div>
              </div>
              <div className="text-center">
                <div className="text-xl font-bold text-blue-600">
                  {generationStats.chunksCreated}
                </div>
                <div className="text-sm text-gray-500">Chunks erstellt</div>
              </div>
              <div className="text-center">
                <div className="text-xl font-bold text-yellow-600">
                  {generationStats.skipped}
                </div>
                <div className="text-sm text-gray-500">Übersprungen</div>
              </div>
              <div className="text-center">
                <div className="text-xl font-bold text-red-600">
                  {generationStats.errors || 0}
                </div>
                <div className="text-sm text-gray-500">Fehler</div>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Video Details */}
      {status && status.videos.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle>Video Details</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2 max-h-64 overflow-y-auto">
              {status.videos.map((video) => (
                <div
                  key={video.id}
                  className="flex items-center justify-between p-2 border rounded-lg"
                >
                  <div className="flex-1">
                    <div className="font-medium text-sm">{video.title}</div>
                    <div className="text-xs text-gray-500">
                      {video.chunks} Chunks
                    </div>
                  </div>
                  <Badge
                    variant={video.hasEmbeddings ? "default" : "secondary"}
                    className={
                      video.hasEmbeddings
                        ? "bg-green-100 text-green-800"
                        : "bg-gray-100 text-gray-600"
                    }
                  >
                    {video.hasEmbeddings ? "✓ Bereit" : "Fehlend"}
                  </Badge>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
};