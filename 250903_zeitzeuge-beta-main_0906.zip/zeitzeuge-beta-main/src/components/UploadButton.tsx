import { media } from '@/platform';
import { enqueueUpload } from '@/features/upload/enqueueUpload';
import { useAuth } from '@/hooks/useAuth';

export function UploadButton() {
  const { user } = useAuth();

  return (
    <button
      className="inline-flex items-center rounded-xl px-4 py-3 shadow bg-[hsl(var(--coral))] text-white hover:bg-[hsl(var(--coral))]/90 transition-colors"
      onClick={async () => {
        if (!user) {
          console.error('User not authenticated');
          return;
        }
        
        try {
          const file = await media.pickVideo();
          const localPath = await media.saveLocal(file as Blob, 'clip.mp4'); // cap://… auf Mobile, blob-URL auf Web
          const result = await enqueueUpload(localPath, 'videos', `${user.id}/user-${Date.now()}.mp4`);
          console.log('Upload result:', result);
        } catch (error) {
          console.error('Upload failed:', error);
        }
      }}
    >
      Upload video
    </button>
  );
}