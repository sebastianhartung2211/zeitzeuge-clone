import React, { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from '@/components/ui/alert-dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Trash2, Calendar, Edit } from 'lucide-react';
import { RecordedStory, useStories } from '@/hooks/useStories';
import { useToast } from '@/hooks/use-toast';
import { supabase } from '@/integrations/supabase/client';

interface StoryHoverCardProps {
  story: RecordedStory;
  isOpen: boolean;
  onClose: () => void;
}

export const StoryHoverCard: React.FC<StoryHoverCardProps> = ({ story, isOpen, onClose }) => {
  const [newYear, setNewYear] = useState((story.year || new Date().getFullYear()).toString());
  const [isDeleting, setIsDeleting] = useState(false);
  const { deleteStory, moveStoryToYear } = useStories();
  const { toast } = useToast();

  const handleDelete = async () => {
    setIsDeleting(true);
    try {
      // If this story has a video, also delete it from the videos table
      if (story.videoUrl) {
        const { error: videoDeleteError } = await supabase
          .from('videos')
          .delete()
          .eq('video_url', story.videoUrl);
        
        if (videoDeleteError) {
          console.error('Error deleting video:', videoDeleteError);
          toast({
            title: "Fehler",
            description: "Video konnte nicht gelöscht werden.",
            variant: "destructive",
          });
          setIsDeleting(false);
          return;
        }
      }

      deleteStory(story.id);
      toast({
        title: "Story gelöscht",
        description: "Die Story wurde erfolgreich entfernt.",
      });
      onClose();
    } catch (error) {
      console.error('Error deleting story:', error);
      toast({
        title: "Fehler",
        description: "Story konnte nicht gelöscht werden.",
        variant: "destructive",
      });
    } finally {
      setIsDeleting(false);
    }
  };

  const handleMoveToYear = () => {
    const year = parseInt(newYear);
    if (year && year !== story.year) {
      moveStoryToYear(story.id, year);
      toast({
        title: "Story verschoben",
        description: `Die Story wurde zu ${year} verschoben.`,
      });
      onClose();
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Edit className="h-5 w-5" />
            Story bearbeiten
          </DialogTitle>
        </DialogHeader>
        
        <div className="space-y-6">
          {/* Video Preview */}
          {story.videoUrl && (
            <div className="aspect-video rounded-lg overflow-hidden bg-muted">
              <video
                src={story.videoUrl}
                controls
                className="w-full h-full object-cover"
              />
            </div>
          )}
          
          {/* Story Info */}
          <div className="space-y-4">
            <div>
              <h3 className="font-semibold text-lg">{story.title}</h3>
              <p className="text-muted-foreground text-sm">{story.description}</p>
            </div>
            
            <div className="grid grid-cols-2 gap-4 text-sm">
              <div>
                <span className="font-medium">Datum:</span> {story.date}
              </div>
              <div>
                <span className="font-medium">Ort:</span> {story.location || 'Nicht angegeben'}
              </div>
            </div>
            
            {story.questions && (
              <div>
                <span className="font-medium text-sm">Beantwortete Frage:</span>
                <p className="text-sm text-muted-foreground mt-1">{story.questions[0]}</p>
              </div>
            )}
          </div>
          
          {/* Move to Year */}
          <div className="space-y-2">
            <Label htmlFor="year" className="flex items-center gap-2">
              <Calendar className="h-4 w-4" />
              Jahr ändern
            </Label>
            <div className="flex gap-2">
              <Input
                id="year"
                type="number"
                value={newYear}
                onChange={(e) => setNewYear(e.target.value)}
                placeholder="Jahr eingeben"
                min="1980"
                max="2030"
              />
              <Button 
                onClick={handleMoveToYear}
                variant="outline"
                disabled={!newYear || parseInt(newYear) === story.year}
              >
                Verschieben
              </Button>
            </div>
          </div>
          
          {/* Actions */}
          <div className="flex justify-between pt-4 border-t">
            <AlertDialog>
              <AlertDialogTrigger asChild>
                <Button
                  variant="destructive"
                  className="flex items-center gap-2"
                  disabled={isDeleting}
                >
                  <Trash2 className="h-4 w-4" />
                  {isDeleting ? 'Wird gelöscht...' : 'Story löschen'}
                </Button>
              </AlertDialogTrigger>
              <AlertDialogContent>
                <AlertDialogHeader>
                  <AlertDialogTitle>Video löschen?</AlertDialogTitle>
                  <AlertDialogDescription>
                    Möchtest du dieses Video wirklich löschen? Diese Aktion kann nicht rückgängig gemacht werden.
                  </AlertDialogDescription>
                </AlertDialogHeader>
                <AlertDialogFooter>
                  <AlertDialogCancel>Nein</AlertDialogCancel>
                  <AlertDialogAction 
                    onClick={handleDelete} 
                    className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
                    disabled={isDeleting}
                  >
                    Ja, löschen
                  </AlertDialogAction>
                </AlertDialogFooter>
              </AlertDialogContent>
            </AlertDialog>
            
            <Button onClick={onClose}>
              Schließen
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};