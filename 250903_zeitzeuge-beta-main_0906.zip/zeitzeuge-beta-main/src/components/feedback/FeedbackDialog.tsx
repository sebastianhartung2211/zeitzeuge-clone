import React, { useState } from 'react';
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Textarea } from "@/components/ui/textarea";
import { Star, ThumbsUp, ThumbsDown } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/components/ui/use-toast";

interface FeedbackDialogProps {
  isOpen: boolean;
  onClose: () => void;
  conversationId: string;
  question: string;
  answer: string;
  videoTitle?: string;
}

export const FeedbackDialog: React.FC<FeedbackDialogProps> = ({
  isOpen,
  onClose,
  conversationId,
  question,
  answer,
  videoTitle
}) => {
  const [rating, setRating] = useState<number>(0);
  const [feedbackText, setFeedbackText] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const { toast } = useToast();

  const handleRatingClick = (value: number) => {
    setRating(value);
  };

  const handleSubmit = async () => {
    if (rating === 0) {
      toast({
        title: "Bewertung erforderlich",
        description: "Bitte geben Sie eine Sterne-Bewertung ab.",
        variant: "destructive",
      });
      return;
    }

    setIsSubmitting(true);
    
    try {
      const { error } = await supabase.functions.invoke('conversation-agent-v4', {
        body: {
          action: 'process_feedback',
          feedback: {
            conversationId,
            rating,
            text: feedbackText,
            type: 'quality_rating',
            metadata: {
              question,
              hasAnswer: !!answer,
              videoTitle,
              timestamp: new Date().toISOString()
            }
          }
        }
      });

      if (error) {
        throw error;
      }

      toast({
        title: "Feedback gespeichert",
        description: "Vielen Dank für Ihr Feedback! Es hilft uns, das System zu verbessern.",
      });

      onClose();
      setRating(0);
      setFeedbackText('');
      
    } catch (error) {
      console.error('Error submitting feedback:', error);
      toast({
        title: "Fehler beim Speichern",
        description: "Ihr Feedback konnte nicht gespeichert werden. Bitte versuchen Sie es erneut.",
        variant: "destructive",
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
      <Card className="bg-white/95 backdrop-blur-md p-6 max-w-md w-full">
        <h3 className="text-lg font-semibold mb-4" style={{ color: '#243058' }}>
          Wie hilfreich war diese Antwort?
        </h3>
        
        <div className="space-y-4">
          {/* Question Preview */}
          <div className="p-3 bg-gray-50 rounded-lg">
            <p className="text-sm text-gray-600 mb-1">Ihre Frage:</p>
            <p className="text-sm font-medium">{question}</p>
            {videoTitle && (
              <p className="text-xs text-gray-500 mt-1">Video: {videoTitle}</p>
            )}
          </div>

          {/* Star Rating */}
          <div className="flex items-center gap-2">
            <span className="text-sm font-medium">Bewertung:</span>
            <div className="flex gap-1">
              {[1, 2, 3, 4, 5].map((star) => (
                <button
                  key={star}
                  onClick={() => handleRatingClick(star)}
                  className="p-1 hover:scale-110 transition-transform"
                >
                  <Star
                    className={`h-6 w-6 ${
                      star <= rating
                        ? 'fill-yellow-400 text-yellow-400'
                        : 'text-gray-300'
                    }`}
                  />
                </button>
              ))}
            </div>
          </div>

          {/* Quick Feedback Buttons */}
          <div className="flex gap-2">
            <Button
              variant="outline"
              size="sm"
              onClick={() => setRating(rating === 5 ? 0 : 5)}
              className={rating === 5 ? 'bg-green-50 border-green-200' : ''}
            >
              <ThumbsUp className="h-4 w-4 mr-1" />
              Sehr hilfreich
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={() => setRating(rating === 1 ? 0 : 1)}
              className={rating === 1 ? 'bg-red-50 border-red-200' : ''}
            >
              <ThumbsDown className="h-4 w-4 mr-1" />
              Nicht hilfreich
            </Button>
          </div>

          {/* Optional Text Feedback */}
          <div>
            <label className="text-sm font-medium mb-2 block">
              Zusätzliches Feedback (optional):
            </label>
            <Textarea
              value={feedbackText}
              onChange={(e) => setFeedbackText(e.target.value)}
              placeholder="Was können wir verbessern? Was hat besonders gut funktioniert?"
              rows={3}
              className="text-sm"
            />
          </div>

          {/* Action Buttons */}
          <div className="flex justify-end gap-2 pt-2">
            <Button
              variant="outline"
              onClick={onClose}
              disabled={isSubmitting}
            >
              Abbrechen
            </Button>
            <Button
              onClick={handleSubmit}
              disabled={isSubmitting || rating === 0}
              className="bg-[hsl(var(--coral))] hover:bg-[hsl(var(--coral))]/90"
              style={{ color: '#243058' }}
            >
              {isSubmitting ? 'Wird gespeichert...' : 'Feedback senden'}
            </Button>
          </div>
        </div>
      </Card>
    </div>
  );
};