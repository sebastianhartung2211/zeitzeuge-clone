import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { useToast } from '@/hooks/use-toast';
import { supabase } from '@/integrations/supabase/client';
import { PlayCircle, Loader2, CheckCircle, XCircle } from 'lucide-react';

interface TaggingResult {
  videoId: string;
  title: string;
  status: 'success' | 'failed';
  error?: string;
  tagsCount?: number;
  segmentsCount?: number;
}

const ManualTaggingTool = () => {
  const [isProcessing, setIsProcessing] = useState(false);
  const [videoId, setVideoId] = useState('');
  const [results, setResults] = useState<TaggingResult[]>([]);
  const { toast } = useToast();

  const handleTagSingleVideo = async () => {
    if (!videoId.trim()) {
      toast({
        title: "Video ID erforderlich",
        description: "Bitte geben Sie eine Video ID ein",
        variant: "destructive",
      });
      return;
    }

    setIsProcessing(true);
    try {
      console.log('🏷️ Starting manual tagging for video:', videoId);

      // Call tagging-segmentation-agent directly
      const { data, error } = await supabase.functions.invoke('tagging-segmentation-agent', {
        body: { 
          videoId: videoId.trim(),
          manual: true
        }
      });

      if (error) {
        throw new Error(error.message);
      }

      const result: TaggingResult = {
        videoId: videoId.trim(),
        title: data?.title || 'Unknown',
        status: 'success',
        tagsCount: data?.tagsCount || 0,
        segmentsCount: data?.segmentsCount || 0
      };

      setResults(prev => [result, ...prev]);

      toast({
        title: "Tagging erfolgreich",
        description: `Video getaggt: ${data?.tagsCount || 0} Tags, ${data?.segmentsCount || 0} Segmente`,
      });

    } catch (error: any) {
      console.error('Manual tagging failed:', error);
      
      const failedResult: TaggingResult = {
        videoId: videoId.trim(),
        title: 'Failed',
        status: 'failed',
        error: error.message
      };

      setResults(prev => [failedResult, ...prev]);

      toast({
        title: "Tagging fehlgeschlagen",
        description: error.message,
        variant: "destructive",
      });
    } finally {
      setIsProcessing(false);
      setVideoId('');
    }
  };

  const handleBulkTagging = async () => {
    setIsProcessing(true);
    try {
      console.log('🏷️ Starting bulk tagging for completed videos without tags');

      // Find completed videos without tags
      const { data: videos, error: videosError } = await supabase
        .from('videos')
        .select(`
          id, title, 
          video_tags!left(id)
        `)
        .eq('status', 'completed')
        .is('video_tags.id', null)
        .limit(10);

      if (videosError) {
        throw new Error(`Failed to fetch videos: ${videosError.message}`);
      }

      if (!videos || videos.length === 0) {
        toast({
          title: "Keine Videos gefunden",
          description: "Alle abgeschlossenen Videos haben bereits Tags",
        });
        return;
      }

      console.log(`Found ${videos.length} videos without tags`);

      const bulkResults: TaggingResult[] = [];

      // Process videos sequentially to avoid API rate limits
      for (const video of videos) {
        try {
          const { data, error } = await supabase.functions.invoke('tagging-segmentation-agent', {
            body: { 
              videoId: video.id,
              manual: true
            }
          });

          if (error) {
            throw new Error(error.message);
          }

          bulkResults.push({
            videoId: video.id,
            title: video.title,
            status: 'success',
            tagsCount: data?.tagsCount || 0,
            segmentsCount: data?.segmentsCount || 0
          });

        } catch (error: any) {
          bulkResults.push({
            videoId: video.id,
            title: video.title,
            status: 'failed',
            error: error.message
          });
        }

        // Small delay to avoid rate limits
        await new Promise(resolve => setTimeout(resolve, 500));
      }

      setResults(prev => [...bulkResults, ...prev]);

      const successful = bulkResults.filter(r => r.status === 'success').length;
      const failed = bulkResults.filter(r => r.status === 'failed').length;

      toast({
        title: "Bulk Tagging abgeschlossen",
        description: `${successful} erfolgreich, ${failed} fehlgeschlagen`,
      });

    } catch (error: any) {
      console.error('Bulk tagging failed:', error);
      toast({
        title: "Bulk Tagging fehlgeschlagen",
        description: error.message,
        variant: "destructive",
      });
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle>Manual Tagging Tool</CardTitle>
        <CardDescription>
          Tag einzelne Videos oder führe Bulk-Tagging für alle abgeschlossenen Videos ohne Tags durch
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Single Video Tagging */}
        <div className="space-y-4">
          <h3 className="text-lg font-semibold">Einzelnes Video taggen</h3>
          <div className="flex gap-2">
            <Input
              placeholder="Video ID eingeben..."
              value={videoId}
              onChange={(e) => setVideoId(e.target.value)}
              disabled={isProcessing}
            />
            <Button 
              onClick={handleTagSingleVideo}
              disabled={isProcessing || !videoId.trim()}
              className="min-w-[120px]"
            >
              {isProcessing ? (
                <Loader2 className="w-4 h-4 animate-spin" />
              ) : (
                <PlayCircle className="w-4 h-4" />
              )}
              Tag Video
            </Button>
          </div>
        </div>

        {/* Bulk Tagging */}
        <div className="space-y-4 border-t pt-4">
          <h3 className="text-lg font-semibold">Bulk Tagging</h3>
          <div className="flex gap-2">
            <Button 
              onClick={handleBulkTagging}
              disabled={isProcessing}
              className="min-w-[180px]"
              variant="secondary"
            >
              {isProcessing ? (
                <Loader2 className="w-4 h-4 animate-spin" />
              ) : (
                <PlayCircle className="w-4 h-4" />
              )}
              Alle Videos taggen
            </Button>
          </div>
          <p className="text-sm text-muted-foreground">
            Taggt alle abgeschlossenen Videos ohne Tags (max. 10 pro Durchgang)
          </p>
        </div>

        {/* Results */}
        {results.length > 0 && (
          <div className="space-y-4 border-t pt-4">
            <h3 className="text-lg font-semibold">Ergebnisse</h3>
            <div className="space-y-2 max-h-80 overflow-y-auto">
              {results.map((result, index) => (
                <div
                  key={`${result.videoId}-${index}`}
                  className={`p-3 rounded-lg border ${
                    result.status === 'success' 
                      ? 'bg-green-50 border-green-200' 
                      : 'bg-red-50 border-red-200'
                  }`}
                >
                  <div className="flex items-center gap-2">
                    {result.status === 'success' ? (
                      <CheckCircle className="w-4 h-4 text-green-600" />
                    ) : (
                      <XCircle className="w-4 h-4 text-red-600" />
                    )}
                    <span className="font-mono text-sm">{result.videoId}</span>
                    <span className="text-sm">{result.title}</span>
                  </div>
                  {result.status === 'success' ? (
                    <p className="text-sm text-green-700 mt-1">
                      {result.tagsCount} Tags, {result.segmentsCount} Segmente erstellt
                    </p>
                  ) : (
                    <p className="text-sm text-red-700 mt-1">{result.error}</p>
                  )}
                </div>
              ))}
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
};

export default ManualTaggingTool;