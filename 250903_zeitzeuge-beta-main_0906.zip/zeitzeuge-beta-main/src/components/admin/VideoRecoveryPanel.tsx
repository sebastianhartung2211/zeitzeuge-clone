import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { RefreshCw, Play, AlertTriangle } from 'lucide-react';
import { toast } from 'sonner';
import { supabase } from '@/integrations/supabase/client';
import ManualTaggingTool from './ManualTaggingTool';

export const VideoRecoveryPanel = () => {
  const [isRecovering, setIsRecovering] = useState(false);
  const [recoveryResults, setRecoveryResults] = useState<any>(null);

  const handleRecoverFailedVideos = async () => {
    setIsRecovering(true);
    try {
      console.log('🔧 Starting video recovery process...');
      
      const { data, error } = await supabase.functions.invoke('video-status-recovery', {
        body: { action: 'recover_failed_videos' }
      });

      if (error) {
        throw new Error(error.message);
      }

      setRecoveryResults(data);
      
      if (data.recovered > 0) {
        toast.success(`${data.recovered} Videos erfolgreich wiederhergestellt!`);
      } else {
        toast.info('Keine Videos zum Wiederherstellen gefunden.');
      }
      
      console.log('✅ Recovery completed:', data);
    } catch (error) {
      console.error('❌ Recovery failed:', error);
      toast.error(`Recovery fehlgeschlagen: ${error.message}`);
    } finally {
      setIsRecovering(false);
    }
  };

  return (
    <div className="space-y-6 w-full max-w-4xl">
      {/* Video Recovery Panel */}
      <Card className="w-full">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <RefreshCw className="h-5 w-5" />
            Video Recovery Panel
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center gap-4">
            <Button 
              onClick={handleRecoverFailedVideos}
              disabled={isRecovering}
              className="flex items-center gap-2"
            >
              {isRecovering ? (
                <RefreshCw className="h-4 w-4 animate-spin" />
              ) : (
                <Play className="h-4 w-4" />
              )}
              {isRecovering ? 'Wiederherstellen...' : 'Failed Videos Wiederherstellen'}
            </Button>
          </div>

          {recoveryResults && (
            <div className="space-y-3">
              <div className="flex items-center gap-2">
                <Badge variant="outline">
                  Wiederhergestellt: {recoveryResults.recovered}
                </Badge>
                <Badge variant="outline">
                  Gesamt: {recoveryResults.total}
                </Badge>
              </div>

              {recoveryResults.results && recoveryResults.results.length > 0 && (
                <div className="space-y-2">
                  <h4 className="font-medium text-sm">Details:</h4>
                  {recoveryResults.results.map((result: any, index: number) => (
                    <div
                      key={index}
                      className={`p-2 rounded text-xs ${
                        result.status === 'recovered' 
                          ? 'bg-green-50 border border-green-200' 
                          : 'bg-red-50 border border-red-200'
                      }`}
                    >
                      <div className="flex items-center gap-2">
                        {result.status === 'recovered' ? (
                          <Badge variant="default" className="text-xs">✅</Badge>
                        ) : (
                          <Badge variant="destructive" className="text-xs">❌</Badge>
                        )}
                        <span className="font-medium">{result.title}</span>
                      </div>
                      {result.error && (
                        <div className="text-red-600 mt-1">{result.error}</div>
                      )}
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          <div className="text-xs text-muted-foreground bg-muted p-3 rounded">
            <div className="flex items-start gap-2">
              <AlertTriangle className="h-4 w-4 text-amber-500 flex-shrink-0 mt-0.5" />
              <div>
                <div className="font-medium mb-1">Was macht diese Funktion?</div>
                <ul className="space-y-1">
                  <li>• Findet Videos mit Status "failed" die aber Transkripte haben</li>
                  <li>• Setzt Status auf "completed" und läuft Tagging/Storage nach</li>
                  <li>• Erstellt korrekte Ordnerstruktur im transcripts Bucket</li>
                  <li>• Kategorisiert Videos richtig für "Erlebnisse"-Seite</li>
                </ul>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Manual Tagging Tool */}
      <ManualTaggingTool />
    </div>
  );
};