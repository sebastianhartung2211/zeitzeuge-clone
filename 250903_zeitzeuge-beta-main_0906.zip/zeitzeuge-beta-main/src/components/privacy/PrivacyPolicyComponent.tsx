import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Separator } from '@/components/ui/separator';
import { Shield, Database, Camera, Mic, Bell, Cloud, Eye, Lock } from 'lucide-react';

export const PrivacyPolicyComponent = () => {
  return (
    <div className="max-w-4xl mx-auto p-6 space-y-8">
      <div className="text-center mb-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-2">Datenschutzerklärung</h1>
        <p className="text-gray-600">
          Zeitzeuge - Ihre Privatsphäre ist uns wichtig
        </p>
        <p className="text-sm text-gray-500 mt-2">
          Letzte Aktualisierung: {new Date().toLocaleDateString('de-DE')}
        </p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Shield className="w-5 h-5 text-[hsl(var(--coral))]" />
            Übersicht
          </CardTitle>
          <CardDescription>
            Zeitzeuge hilft Ihnen dabei, Ihre wertvollen Lebenserinn­erungen zu bewahren und zu teilen. 
            Diese Datenschutzerklärung erklärt, welche Daten wir erheben und wie wir sie verwenden.
          </CardDescription>
        </CardHeader>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Database className="w-5 h-5 text-[hsl(var(--coral))]" />
            Welche Daten wir erheben
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid gap-4 md:grid-cols-2">
            <div className="border rounded-lg p-4">
              <div className="flex items-center gap-2 mb-2">
                <Camera className="w-4 h-4" />
                <h4 className="font-medium">Video- und Audiodaten</h4>
              </div>
              <p className="text-sm text-gray-600">
                Ihre aufgenommenen Videos und Audioaufnahmen werden sicher in Ihrem persönlichen Bereich gespeichert.
              </p>
            </div>
            
            <div className="border rounded-lg p-4">
              <div className="flex items-center gap-2 mb-2">
                <Eye className="w-4 h-4" />
                <h4 className="font-medium">Nutzungsdaten</h4>
              </div>
              <p className="text-sm text-gray-600">
                Anonymisierte Informationen über die App-Nutzung zur Verbesserung unserer Dienste.
              </p>
            </div>
            
            <div className="border rounded-lg p-4">
              <div className="flex items-center gap-2 mb-2">
                <Bell className="w-4 h-4" />
                <h4 className="font-medium">Benachrichtigungsdaten</h4>
              </div>
              <p className="text-sm text-gray-600">
                Device-Token für Push-Benachrichtigungen (nur bei Zustimmung).
              </p>
            </div>
            
            <div className="border rounded-lg p-4">
              <div className="flex items-center gap-2 mb-2">
                <Lock className="w-4 h-4" />
                <h4 className="font-medium">Authentifizierungsdaten</h4>
              </div>
              <p className="text-sm text-gray-600">
                E-Mail-Adresse und verschlüsselte Anmeldedaten für Ihr Konto.
              </p>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Cloud className="w-5 h-5 text-[hsl(var(--coral))]" />
            Wie wir Ihre Daten verwenden
          </CardTitle>
        </CardHeader>
        <CardContent>
          <ul className="space-y-3">
            <li className="flex items-start gap-2">
              <div className="w-2 h-2 bg-[hsl(var(--coral))] rounded-full mt-2 flex-shrink-0"></div>
              <div>
                <strong>Speicherung Ihrer Erinnerungen:</strong> Videos und Audioaufnahmen werden verschlüsselt in Ihrem persönlichen Cloud-Speicher abgelegt.
              </div>
            </li>
            <li className="flex items-start gap-2">
              <div className="w-2 h-2 bg-[hsl(var(--coral))] rounded-full mt-2 flex-shrink-0"></div>
              <div>
                <strong>KI-gestützte Verarbeitung:</strong> Transkription und Kategorisierung Ihrer Inhalte zur besseren Auffindbarkeit.
              </div>
            </li>
            <li className="flex items-start gap-2">
              <div className="w-2 h-2 bg-[hsl(var(--coral))] rounded-full mt-2 flex-shrink-0"></div>
              <div>
                <strong>Benachrichtigungen:</strong> Informationen über neue Features oder wichtige Updates (nur bei Zustimmung).
              </div>
            </li>
            <li className="flex items-start gap-2">
              <div className="w-2 h-2 bg-[hsl(var(--coral))] rounded-full mt-2 flex-shrink-0"></div>
              <div>
                <strong>Verbesserung der App:</strong> Anonymisierte Nutzungsstatistiken zur Optimierung der Benutzererfahrung.
              </div>
            </li>
          </ul>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Ihre Rechte (DSGVO)</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid gap-3 md:grid-cols-2">
            <div>
              <h4 className="font-medium mb-2">✓ Auskunftsrecht</h4>
              <p className="text-sm text-gray-600">Sie können jederzeit Auskunft über Ihre gespeicherten Daten verlangen.</p>
            </div>
            <div>
              <h4 className="font-medium mb-2">✓ Löschungsrecht</h4>
              <p className="text-sm text-gray-600">Sie können die Löschung Ihrer Daten und Ihres Kontos beantragen.</p>
            </div>
            <div>
              <h4 className="font-medium mb-2">✓ Berichtigungsrecht</h4>
              <p className="text-sm text-gray-600">Unrichtige Daten können Sie jederzeit korrigieren lassen.</p>
            </div>
            <div>
              <h4 className="font-medium mb-2">✓ Widerspruchsrecht</h4>
              <p className="text-sm text-gray-600">Sie können der Verarbeitung Ihrer Daten widersprechen.</p>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Mic className="w-5 h-5 text-[hsl(var(--coral))]" />
            App-Berechtigungen
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="border-l-4 border-[hsl(var(--coral))] pl-4">
              <h4 className="font-medium">Kamera & Mikrofon</h4>
              <p className="text-sm text-gray-600">
                Erforderlich für die Aufnahme Ihrer Video-Erinnerungen. Zugriff erfolgt nur bei aktiver Nutzung.
              </p>
            </div>
            <div className="border-l-4 border-[hsl(var(--coral))] pl-4">
              <h4 className="font-medium">Fotomediathek</h4>
              <p className="text-sm text-gray-600">
                Zum Speichern aufgenommener Videos und Zugriff auf vorhandene Medien.
              </p>
            </div>
            <div className="border-l-4 border-[hsl(var(--coral))] pl-4">
              <h4 className="font-medium">Push-Benachrichtigungen</h4>
              <p className="text-sm text-gray-600">
                Optional - für wichtige Updates und Erinnerungen. Kann jederzeit deaktiviert werden.
              </p>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Datensicherheit</CardTitle>
        </CardHeader>
        <CardContent>
          <ul className="space-y-2 text-sm">
            <li>• Ende-zu-Ende-Verschlüsselung für alle Ihre Daten</li>
            <li>• Sichere Übertragung über HTTPS/TLS</li>
            <li>• Regelmäßige Sicherheitsaudits</li>
            <li>• Keine Weitergabe an Dritte ohne Ihre Zustimmung</li>
            <li>• Server-Standort: Deutschland/EU</li>
          </ul>
        </CardContent>
      </Card>

      <Separator />

      <div className="text-center text-sm text-gray-500">
        <p>
          Bei Fragen zum Datenschutz erreichen Sie uns unter:{' '}
          <a href="mailto:privacy@zeitzeuge.app" className="text-[hsl(var(--coral))] hover:underline">
            privacy@zeitzeuge.app
          </a>
        </p>
        <p className="mt-2">
          Zeitzeuge GmbH • Musterstraße 123 • 12345 Berlin • Deutschland
        </p>
      </div>
    </div>
  );
};