import { useState } from 'react';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Download, FileText, Database, Loader2 } from 'lucide-react';
import { useAuth } from '@/hooks/useAuth';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';

export const DataExportDialog = () => {
  const [isExporting, setIsExporting] = useState(false);
  const [open, setOpen] = useState(false);
  const { user } = useAuth();
  const { toast } = useToast();

  const handleExportData = async () => {
    if (!user) return;

    setIsExporting(true);
    try {
      // Fetch user's data from various tables
      const [videosResponse, conversationsResponse, notificationsResponse] = await Promise.all([
        supabase.from('videos').select('*').eq('user_id', user.id),
        supabase.from('conversations').select('*').eq('user_id', user.id),
        supabase.from('notifications').select('*').eq('user_id', user.id)
      ]);

      const exportData = {
        exportDate: new Date().toISOString(),
        userId: user.id,
        userEmail: user.email,
        data: {
          videos: videosResponse.data || [],
          conversations: conversationsResponse.data || [],
          notifications: notificationsResponse.data || []
        },
        metadata: {
          totalVideos: videosResponse.data?.length || 0,
          totalConversations: conversationsResponse.data?.length || 0,
          totalNotifications: notificationsResponse.data?.length || 0
        }
      };

      // Create and download JSON file
      const dataStr = JSON.stringify(exportData, null, 2);
      const dataBlob = new Blob([dataStr], { type: 'application/json' });
      const url = URL.createObjectURL(dataBlob);
      
      const link = document.createElement('a');
      link.href = url;
      link.download = `zeitzeuge-data-export-${new Date().toISOString().split('T')[0]}.json`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);

      toast({
        title: 'Datenexport erfolgreich',
        description: 'Ihre Daten wurden erfolgreich heruntergeladen.',
      });

      setOpen(false);
    } catch (error) {
      console.error('Export failed:', error);
      toast({
        title: 'Export fehlgeschlagen',
        description: 'Es gab einen Fehler beim Exportieren Ihrer Daten.',
        variant: 'destructive',
      });
    } finally {
      setIsExporting(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button variant="outline" className="flex items-center gap-2">
          <Download className="w-4 h-4" />
          Daten exportieren
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Database className="w-5 h-5" />
            Datenexport (DSGVO-Auskunftsrecht)
          </DialogTitle>
          <DialogDescription>
            Laden Sie alle Ihre bei Zeitzeuge gespeicherten Daten herunter.
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="text-base">Was wird exportiert?</CardTitle>
              <CardDescription>
                Ihr Export enthält alle personenbezogenen Daten, die wir über Sie gespeichert haben:
              </CardDescription>
            </CardHeader>
            <CardContent>
              <ul className="space-y-2 text-sm">
                <li className="flex items-center gap-2">
                  <FileText className="w-4 h-4" />
                  Alle Ihre Video-Erinnerungen und Metadaten
                </li>
                <li className="flex items-center gap-2">
                  <FileText className="w-4 h-4" />
                  Ihre Gespräche und Frage-Antwort-Historie
                </li>
                <li className="flex items-center gap-2">
                  <FileText className="w-4 h-4" />
                  Benachrichtigungen und Systemereignisse
                </li>
                <li className="flex items-center gap-2">
                  <FileText className="w-4 h-4" />
                  Konto-Informationen und Einstellungen
                </li>
              </ul>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-base">Dateiformat</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground">
                Die Daten werden als JSON-Datei bereitgestellt, die mit jedem Texteditor 
                oder durch JSON-Viewer-Tools lesbar ist. Die Datei enthält strukturierte 
                Daten in einem standardisierten, maschinenlesbaren Format.
              </p>
            </CardContent>
          </Card>

          <div className="bg-orange-50 border border-orange-200 rounded-lg p-4">
            <p className="text-sm text-orange-800">
              <strong>Hinweis:</strong> Dieser Export enthält Ihre Videodateien nicht direkt, 
              sondern nur die Metadaten und URLs. Um Ihre Videos herunterzuladen, 
              nutzen Sie bitte die Download-Funktion in der App.
            </p>
          </div>

          <div className="flex justify-end gap-3 pt-4">
            <Button variant="outline" onClick={() => setOpen(false)}>
              Abbrechen
            </Button>
            <Button 
              onClick={handleExportData}
              disabled={isExporting}
              className="bg-[hsl(var(--coral))] text-white hover:bg-[hsl(var(--coral))]/90"
            >
              {isExporting ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Exportiere...
                </>
              ) : (
                <>
                  <Download className="w-4 h-4 mr-2" />
                  Daten herunterladen
                </>
              )}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};