
import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { 
  Shield, 
  Lock, 
  Eye, 
  Download, 
  Trash2, 
  AlertTriangle,
  CheckCircle,
  FileText
} from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

const PrivacySettings = () => {
  const { toast } = useToast();
  const [settings, setSettings] = useState({
    profileVisibility: true,
    videoSharing: true,
    dataCollection: false,
    emailNotifications: true,
    cookieConsent: true,
    analyticsTracking: false,
    thirdPartySharing: false
  });

  const handleSettingChange = (setting: string, value: boolean) => {
    setSettings(prev => ({ ...prev, [setting]: value }));
    toast({
      title: "Einstellung aktualisiert",
      description: "Ihre Datenschutzeinstellungen wurden gespeichert.",
    });
  };

  const handleDataExport = () => {
    toast({
      title: "Datenexport angefordert",
      description: "Sie erhalten eine E-Mail mit Ihren Daten innerhalb von 48 Stunden.",
    });
  };

  const handleAccountDeletion = () => {
    toast({
      title: "Konto-Löschung angefordert",
      description: "Ihre Anfrage wird bearbeitet. Sie erhalten eine Bestätigung per E-Mail.",
      variant: "destructive",
    });
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold text-gray-900">Datenschutz & Sicherheit</h1>
        <p className="text-gray-600 mt-1">Verwalten Sie Ihre Privatsphäre und DSGVO-Einstellungen</p>
      </div>

      {/* GDPR Compliance Status */}
      <Card className="border-green-200 bg-green-50">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-green-800">
            <CheckCircle className="h-5 w-5" />
            DSGVO-Konformität
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex items-center justify-between">
            <div>
              <p className="text-green-700 font-medium">Ihre Daten sind vollständig DSGVO-konform geschützt</p>
              <p className="text-green-600 text-sm mt-1">
                Alle Ihre persönlichen Daten werden gemäß den europäischen Datenschutzbestimmungen verarbeitet
              </p>
            </div>
            <Badge className="bg-green-600 text-white">
              ✓ Konform
            </Badge>
          </div>
        </CardContent>
      </Card>

      {/* Privacy Settings */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Shield className="h-5 w-5" />
            Datenschutzeinstellungen
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <Label className="text-base font-medium">Profil-Sichtbarkeit</Label>
                <p className="text-sm text-gray-600">Anderen Familienmitgliedern erlauben, Ihr Profil zu sehen</p>
              </div>
              <Switch
                checked={settings.profileVisibility}
                onCheckedChange={(value) => handleSettingChange('profileVisibility', value)}
              />
            </div>

            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <Label className="text-base font-medium">Video-Freigabe automatisch</Label>
                <p className="text-sm text-gray-600">Neue Videos automatisch mit der Familie teilen</p>
              </div>
              <Switch
                checked={settings.videoSharing}
                onCheckedChange={(value) => handleSettingChange('videoSharing', value)}
              />
            </div>

            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <Label className="text-base font-medium">E-Mail-Benachrichtigungen</Label>
                <p className="text-sm text-gray-600">Benachrichtigungen über neue Aktivitäten erhalten</p>
              </div>
              <Switch
                checked={settings.emailNotifications}
                onCheckedChange={(value) => handleSettingChange('emailNotifications', value)}
              />
            </div>

            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <Label className="text-base font-medium">Cookie-Einverständnis</Label>
                <p className="text-sm text-gray-600">Notwendige Cookies für die App-Funktionalität</p>
              </div>
              <Switch
                checked={settings.cookieConsent}
                onCheckedChange={(value) => handleSettingChange('cookieConsent', value)}
              />
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Data Collection Settings */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Eye className="h-5 w-5" />
            Datensammlung
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between">
            <div className="space-y-0.5">
              <Label className="text-base font-medium">Anonyme Analytics</Label>
              <p className="text-sm text-gray-600">Helfen Sie uns, die App zu verbessern (DSGVO-konform)</p>
            </div>
            <Switch
              checked={settings.analyticsTracking}
              onCheckedChange={(value) => handleSettingChange('analyticsTracking', value)}
            />
          </div>

          <div className="flex items-center justify-between">
            <div className="space-y-0.5">
              <Label className="text-base font-medium">Datenfreigabe an Dritte</Label>
              <p className="text-sm text-gray-600">Ihre Daten niemals an Dritte weitergeben</p>
            </div>
            <Switch
              checked={settings.thirdPartySharing}
              onCheckedChange={(value) => handleSettingChange('thirdPartySharing', value)}
              disabled={true}
            />
          </div>
        </CardContent>
      </Card>

      {/* GDPR Rights */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <FileText className="h-5 w-5" />
            Ihre Rechte nach DSGVO
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <Button
              variant="outline"
              onClick={handleDataExport}
              className="flex items-center gap-2 h-auto p-4"
            >
              <Download className="h-5 w-5" />
              <div className="text-left">
                <div className="font-medium">Daten exportieren</div>
                <div className="text-sm text-gray-600">Alle Ihre Daten herunterladen</div>
              </div>
            </Button>

            <Button
              variant="outline"
              className="flex items-center gap-2 h-auto p-4"
            >
              <Lock className="h-5 w-5" />
              <div className="text-left">
                <div className="font-medium">Datenübersicht</div>
                <div className="text-sm text-gray-600">Sehen Sie, welche Daten wir haben</div>
              </div>
            </Button>

            <Button
              variant="outline"
              className="flex items-center gap-2 h-auto p-4"
            >
              <Shield className="h-5 w-5" />
              <div className="text-left">
                <div className="font-medium">Daten korrigieren</div>
                <div className="text-sm text-gray-600">Falsche Informationen berichtigen</div>
              </div>
            </Button>

            <Button
              variant="outline"
              onClick={handleAccountDeletion}
              className="flex items-center gap-2 h-auto p-4 text-red-600 hover:text-red-700 border-red-200 hover:border-red-300"
            >
              <Trash2 className="h-5 w-5" />
              <div className="text-left">
                <div className="font-medium">Konto löschen</div>
                <div className="text-sm text-gray-600">Alle Daten permanent entfernen</div>
              </div>
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Security Information */}
      <Card className="border-blue-200 bg-blue-50">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-blue-800">
            <AlertTriangle className="h-5 w-5" />
            Sicherheitshinweise
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3 text-blue-700">
            <div className="flex items-start gap-2">
              <div className="w-2 h-2 bg-blue-500 rounded-full mt-2 flex-shrink-0"></div>
              <p className="text-sm">Alle Daten werden verschlüsselt übertragen und gespeichert</p>
            </div>
            <div className="flex items-start gap-2">
              <div className="w-2 h-2 bg-blue-500 rounded-full mt-2 flex-shrink-0"></div>
              <p className="text-sm">Server befinden sich in Deutschland und unterliegen der DSGVO</p>
            </div>
            <div className="flex items-start gap-2">
              <div className="w-2 h-2 bg-blue-500 rounded-full mt-2 flex-shrink-0"></div>
              <p className="text-sm">Regelmäßige Sicherheitsüberprüfungen und Updates</p>
            </div>
            <div className="flex items-start gap-2">
              <div className="w-2 h-2 bg-blue-500 rounded-full mt-2 flex-shrink-0"></div>
              <p className="text-sm">Keine Weitergabe von Daten an Dritte ohne Ihre Einwilligung</p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default PrivacySettings;
