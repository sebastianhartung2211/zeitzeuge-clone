import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { VideoData } from '@/hooks/useVideos';
import { useCategories } from '@/hooks/useCategories';
import { VideoEditDialog } from './VideoEditDialog';
import { Clock, Play, Calendar, Edit, MapPin, Users, Grid } from 'lucide-react';
import { getCategoryThumbnail } from '@/utils/categoryThumbnails';
import { Link } from 'react-router-dom';

interface CategoryViewProps {
  videos: VideoData[];
  onVideoClick: (video: VideoData) => void;
  onVideoUpdated: () => void;
}

const CategoryView: React.FC<CategoryViewProps> = ({ videos, onVideoClick, onVideoUpdated }) => {
  const { categories } = useCategories();
  const [editingVideo, setEditingVideo] = useState<VideoData | null>(null);
  const [selectedVideo, setSelectedVideo] = useState<VideoData | null>(null);

  // Filter out "Erforderlich" videos from display
  const displayVideos = videos.filter(video => video.category !== 'Erforderlich');

  // Group videos by category
  const videosByCategory = categories.reduce((acc, category) => {
    acc[category.name] = displayVideos.filter(video => video.category === category.name);
    return acc;
  }, {} as Record<string, VideoData[]>);

  // Add uncategorized videos (excluding Erforderlich)
  const uncategorizedVideos = displayVideos.filter(video => 
    !video.category || !categories.find(cat => cat.name === video.category)
  );
  if (uncategorizedVideos.length > 0) {
    videosByCategory['Uncategorized'] = uncategorizedVideos;
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'completed':
        return 'bg-green-100 text-green-800 border-green-200';
      case 'processing':
        return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      case 'failed':
        return 'bg-red-100 text-red-800 border-red-200';
      default:
        return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  const formatDuration = (duration?: number) => {
    if (!duration) return null;
    const minutes = Math.floor(duration / 60);
    const seconds = duration % 60;
    return `${minutes}:${seconds.toString().padStart(2, '0')}`;
  };

  return (
    <div className="space-y-6 sm:space-y-8 pt-0 sm:pt-8 px-4 sm:px-0">
      <div className="text-center mb-2 sm:mb-8">
        <h1 className="mt-0 text-2xl sm:text-3xl md:text-4xl font-bold text-foreground mb-1 sm:mb-2">Erlebnisse nach Kategorien</h1>
        <p className="text-sm sm:text-base text-muted-foreground">
          Deine Videos organisiert nach Lebensthemen
        </p>
      </div>

      {/* View Toggle - Link to Familie timeline */}
      <div className="mb-6 sm:mb-8 flex justify-start">
        <div className="bg-muted rounded-lg p-1 flex w-auto">
          <Button variant="default" size="sm" className="flex items-center gap-1 sm:gap-2 rounded-md text-xs sm:text-sm px-2 sm:px-3">
            <Grid className="w-3 h-3 sm:w-4 sm:h-4" />
            <span>Kategorien</span>
          </Button>
          <Link to="/family">
            <Button variant="ghost" size="sm" className="flex items-center gap-1 sm:gap-2 rounded-md text-xs sm:text-sm px-2 sm:px-3">
              <Clock className="w-3 h-3 sm:w-4 sm:h-4" />
              <span>Timeline</span>
            </Button>
          </Link>
        </div>
      </div>

      {Object.entries(videosByCategory).map(([categoryName, categoryVideos]) => {
        if (categoryVideos.length === 0) return null;
        
        const category = categories.find(cat => cat.name === categoryName);
        
        return (
          <div key={categoryName} className="space-y-3 sm:space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center gap-2 sm:gap-3">
              <h2 className="text-xl sm:text-2xl font-semibold text-foreground">
                {categoryName}
              </h2>
              <Badge variant="secondary" className="text-xs sm:text-sm w-fit">
                {categoryVideos.length} {categoryVideos.length === 1 ? 'Video' : 'Videos'}
              </Badge>
            </div>
            
            {category?.description && (
              <p className="text-muted-foreground text-xs sm:text-sm mb-3 sm:mb-4">
                {category.description}
              </p>
            )}

            <div className="grid grid-cols-6 sm:grid-cols-12 gap-2 sm:gap-4 auto-rows-[120px] sm:auto-rows-[200px]">
              {categoryVideos.map((video, index) => {
                // Bento Box layout patterns - mobile-responsive
                const getCardSize = (idx: number) => {
                  const mobilePatterns = [
                    "col-span-3 row-span-1", // Half width on mobile
                    "col-span-3 row-span-1", // Half width on mobile
                    "col-span-6 row-span-1", // Full width on mobile
                    "col-span-3 row-span-1", // Half width on mobile
                    "col-span-3 row-span-1", // Half width on mobile
                    "col-span-6 row-span-1", // Full width on mobile
                  ];
                  const desktopPatterns = [
                    "sm:col-span-3 sm:row-span-1", // Small on desktop
                    "sm:col-span-3 sm:row-span-1", // Small on desktop
                    "sm:col-span-6 sm:row-span-1", // Wide on desktop
                    "sm:col-span-4 sm:row-span-1", // Medium on desktop
                    "sm:col-span-4 sm:row-span-1", // Medium on desktop
                    "sm:col-span-4 sm:row-span-1", // Medium on desktop
                  ];
                  return `${mobilePatterns[idx % mobilePatterns.length]} ${desktopPatterns[idx % desktopPatterns.length]}`;
                };

                // Color patterns - no coral, with proper text colors
                const getCardColor = (idx: number) => {
                  const colors = [
                    { bg: "#B6D7E8", text: "#384785" }, // Light Blue bg, dark text
                    { bg: "#F8EBB4", text: "#384785" }, // Light Yellow bg, dark text
                    { bg: "#384785", text: "#B6D7E8" }, // Dark Blue bg, light text
                  ];
                  return colors[idx % colors.length];
                };

                const cardSize = getCardSize(index);
                const cardColor = getCardColor(index);
                
                // Add image tile every 3 videos
                const shouldAddImage = (index + 1) % 3 === 0;
                
                return (
                  <div key={video.id} className="contents">
                    <div 
                      className={`${cardSize} cursor-pointer group transform hover:scale-105 transition-all duration-300 rounded-xl sm:rounded-2xl overflow-hidden shadow-sm hover:shadow-lg flex items-center justify-center p-3 sm:p-6 relative`}
                      style={{ backgroundColor: cardColor.bg }}
                      onClick={() => setSelectedVideo(video)}
                    >
                      <div className="text-center w-full">
                        <h3 className="font-semibold text-sm sm:text-lg leading-tight sm:leading-relaxed" style={{ color: cardColor.text }}>
                          {video.title}
                        </h3>
                        <div className="mt-1 sm:mt-2 opacity-60">
                          <p className="text-xs" style={{ color: cardColor.text }}>
                            {new Date(video.date).toLocaleDateString('de-DE')}
                          </p>
                        </div>
                        <Button
                          variant="ghost"
                          size="sm"
                          className="absolute top-1 right-1 sm:top-2 sm:right-2 opacity-0 group-hover:opacity-100 transition-opacity bg-white/20 hover:bg-white/30 h-6 w-6 sm:h-8 sm:w-8"
                          onClick={(e) => {
                            e.stopPropagation();
                            setEditingVideo(video);
                          }}
                        >
                          <Edit className="w-3 h-3 sm:w-4 sm:h-4" style={{ color: cardColor.text }} />
                        </Button>
                      </div>
                    </div>
                    
                    {/* Add image tile every 3 videos */}
                    {shouldAddImage && (
                      <div 
                        className="col-span-3 sm:col-span-3 row-span-1 rounded-xl sm:rounded-2xl overflow-hidden shadow-sm"
                        style={{ backgroundColor: "#F8EBB4" }}
                      >
                        <img 
                          src={getCategoryThumbnail(categoryName, Math.floor(index / 3))} 
                          alt={categoryName}
                          className="w-full h-full object-cover"
                        />
                      </div>
                    )}
                  </div>
                );
              })}
              
              {/* Add image tile if more than 3 videos */}
              {categoryVideos.length > 3 && (
                <div 
                  className="col-span-3 sm:col-span-3 row-span-1 rounded-xl sm:rounded-2xl overflow-hidden shadow-sm"
                  style={{ backgroundColor: "#B6D7E8" }}
                >
                  <img 
                    src={getCategoryThumbnail(categoryName, Math.floor(categoryVideos.length / 3) + 1)} 
                    alt={categoryName}
                    className="w-full h-full object-cover"
                  />
                </div>
              )}
            </div>
          </div>
        );
      })}

      {Object.keys(videosByCategory).length === 0 && (
        <div className="text-center py-8 sm:py-12">
          <p className="text-muted-foreground text-base sm:text-lg">
            Noch keine Videos verfügbar
          </p>
          <p className="text-muted-foreground text-xs sm:text-sm mt-2">
            Nehme dein erstes Video auf, um es hier zu sehen
          </p>
        </div>
      )}

      {/* Video Player Dialog */}
      {selectedVideo && (
        <Dialog open={!!selectedVideo} onOpenChange={() => setSelectedVideo(null)}>
          <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto mx-2 sm:mx-0">
            <DialogHeader>
              <DialogTitle className="text-lg sm:text-xl md:text-2xl font-bold text-foreground mb-2">
                {selectedVideo.title}
              </DialogTitle>
            </DialogHeader>
            
            <div className="space-y-6">
              {/* Video Player */}
              {selectedVideo.video_url && (
                <div className="rounded-2xl overflow-hidden shadow-lg bg-muted">
                  <video
                    src={selectedVideo.video_url}
                    controls
                    className="w-full max-h-[60vh] object-contain"
                    preload="metadata"
                  />
                </div>
              )}

              {/* Video Details */}
              <div className="flex flex-wrap gap-2 sm:gap-3">
                <Badge variant="secondary" className="bg-primary/10 text-primary font-medium text-xs sm:text-sm">
                  <Calendar className="h-3 w-3 mr-1" />
                  {new Date(selectedVideo.date).toLocaleDateString('de-DE')}
                </Badge>
                
                {selectedVideo.duration && (
                  <Badge variant="secondary" className="bg-secondary/20 text-secondary-foreground font-medium text-xs sm:text-sm">
                    <Clock className="h-3 w-3 mr-1" />
                    {formatDuration(selectedVideo.duration)}
                  </Badge>
                )}
                
                {selectedVideo.category && (
                  <Badge variant="secondary" className="bg-accent/20 text-accent-foreground font-medium text-xs sm:text-sm">
                    {selectedVideo.category}
                  </Badge>
                )}
                
                <Badge 
                  variant="outline" 
                  className={`${getStatusColor(selectedVideo.status)} font-medium text-xs sm:text-sm`}
                >
                  {selectedVideo.status === 'completed' ? 'Fertig' : 
                   selectedVideo.status === 'processing' ? 'Verarbeitung' : 'Fehler'}
                </Badge>
              </div>

              {/* Description */}
              {selectedVideo.description && (
                <div className="space-y-2">
                  <h4 className="font-semibold text-foreground">Beschreibung</h4>
                  <p className="text-muted-foreground leading-relaxed">
                    {selectedVideo.description}
                  </p>
                </div>
              )}


              {/* Action Buttons */}
              <div className="flex flex-col sm:flex-row gap-2 sm:gap-3 pt-4">
                <Button
                  variant="outline"
                  onClick={(e) => {
                    e.stopPropagation();
                    setEditingVideo(selectedVideo);
                  }}
                  className="flex items-center gap-2 text-sm sm:text-base"
                >
                  <Edit className="w-4 h-4" />
                  Video bearbeiten
                </Button>
                <Button
                  variant="outline"
                  onClick={() => setSelectedVideo(null)}
                  className="text-sm sm:text-base"
                >
                  Schließen
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      )}

      <VideoEditDialog
        video={editingVideo}
        isOpen={!!editingVideo}
        onClose={() => setEditingVideo(null)}
        onVideoUpdated={onVideoUpdated}
      />
    </div>
  );
};

export default CategoryView;