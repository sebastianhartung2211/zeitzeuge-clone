import React, { useState } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Badge } from '@/components/ui/badge';
import { Calendar, MapPin, Users, Play, FileText, Image as ImageIcon, Loader2, AlertCircle, Clock } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useAuth } from '../../hooks/useAuth';
import { useNavigate } from 'react-router-dom';
import { useStories, RecordedStory } from '@/hooks/useStories';
import { useVideos, VideoData } from '@/hooks/useVideos';
import { StoryHoverCard } from '../timeline/StoryHoverCard';

import FloatingElements from '../ui/floating-elements';
import ProcessingPlaceholder from '../ui/processing-placeholder';
import { getImageWithFallback, handleImageError } from '@/utils/imageFallbacks';

const getContentIcon = (type: string) => {
  switch (type) {
    case 'video':
      return <Play className="h-4 w-4 text-white" />;
    case 'text':
      return <FileText className="h-4 w-4 text-white" />;
    case 'image':
      return <ImageIcon className="h-4 w-4 text-white" />;
    default:
      return null;
  }
};

const FamilyTimeline = () => {
  const [selectedYear, setSelectedYear] = useState<number | null>(null);
  const [selectedStory, setSelectedStory] = useState<any>(null);
  const [hoveredStory, setHoveredStory] = useState<RecordedStory | null>(null);
  const navigate = useNavigate();
  const { user } = useAuth();
  const { userStories } = useStories();
  const { videos, loading, error, reload } = useVideos();

  // Family Timeline data flow debugging
  React.useEffect(() => {
    console.log('👨‍👩‍👧‍👦 [FAMILY DEBUG] Component mounted/updated:', {
      userExists: !!user,
      userStoriesCount: userStories?.length || 0,
      videosCount: videos?.length || 0,
      loading,
      error,
      timestamp: new Date().toISOString()
    });
  }, [user, userStories, videos, loading, error]);

  // Show loading state
  if (loading && !user) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-center">
          <Loader2 className="h-8 w-8 animate-spin mx-auto mb-4 text-[hsl(var(--coral))]" />
          <p className="text-gray-600">Lade Videos...</p>
        </div>
      </div>
    );
  }

  // Show authentication message if not logged in
  if (!user) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-center">
          <AlertCircle className="h-12 w-12 mx-auto mb-4 text-amber-500" />
          <h2 className="text-2xl font-bold text-[hsl(var(--navy))] mb-2">
            Anmeldung erforderlich
          </h2>
          <p className="text-gray-600 mb-4">
            Melden Sie sich an, um Ihre persönlichen Videos zu sehen
          </p>
          <Button onClick={() => navigate('/login')} className="bg-gradient-to-r from-violet-500 via-purple-500 to-indigo-500 hover:from-violet-600 hover:via-purple-600 hover:to-indigo-600 rounded-2xl">
            Anmelden
          </Button>
        </div>
      </div>
    );
  }

  // Show error state
  if (error) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-center">
          <AlertCircle className="h-12 w-12 mx-auto mb-4 text-red-500" />
          <h2 className="text-2xl font-bold text-[hsl(var(--navy))] mb-2">
            Fehler beim Laden
          </h2>
          <p className="text-gray-600 mb-4">{error}</p>
          <Button onClick={() => window.location.reload()} variant="outline" className="rounded-2xl">
            Neu laden
          </Button>
        </div>
      </div>
    );
  }

  // Combine user stories and real videos for family timeline
  const isRequiredVideo = (v: VideoData) => {
    const cat = (v.category || '').toLowerCase().trim();
    return cat === 'erforderlich' || cat === 'required';
  };
  
  const filteredVideos = videos.filter(v => !isRequiredVideo(v));

  // Data processing debugging
  React.useEffect(() => {
    console.log('📊 [DATA DEBUG] Raw videos data:', {
      totalVideos: videos.length,
      videoCategories: videos.map(v => ({ id: v.id, category: v.category, title: v.title })),
      filteredVideosCount: filteredVideos.length,
      requiredVideosCount: videos.filter(isRequiredVideo).length,
      timestamp: new Date().toISOString()
    });
  }, [videos, filteredVideos]);
  const allStoriesData: { [year: number]: any[] } = {};

  // Add local user stories
  userStories.forEach(story => {
    if (!allStoriesData[story.year]) {
      allStoriesData[story.year] = [];
    }
    const existsInYear = allStoriesData[story.year].some(existingStory => existingStory.id === story.id);
    if (!existsInYear) {
      allStoriesData[story.year].push(story);
    }
  });

  // Add real videos from Supabase
  filteredVideos.forEach(video => {
    if (!allStoriesData[video.year]) {
      allStoriesData[video.year] = [];
    }
    const existsInYear = allStoriesData[video.year].some(existingStory => existingStory.id === video.id);
    if (!existsInYear) {
      const videoAsStory = {
        id: video.id,
        type: 'video' as const,
        title: video.title,
        date: video.date,
        location: undefined,
        participants: undefined,
        description: video.description,
        videoUrl: video.video_url,
        previewImage: video.thumbnail_url || video.video_url,
        isUserGenerated: true,
        status: video.status,
        questions: video.tags?.map(tag => tag.name) || []
      };
      allStoriesData[video.year].push(videoAsStory);
    }
  });

  const years = Object.keys(allStoriesData).map(Number).sort((a, b) => b - a);

  // Final data structure debugging
  React.useEffect(() => {
    console.log('📅 [YEARS DEBUG] Combined stories data:', {
      years,
      allStoriesData,
      yearCount: years.length,
      storiesPerYear: Object.entries(allStoriesData).map(([year, stories]) => ({
        year,
        count: stories.length,
        stories: stories.map(s => ({ id: s.id, title: s.title, type: s.type }))
      })),
      timestamp: new Date().toISOString()
    });
  }, [years, allStoriesData]);
  
  const handleVideoClick = (video: any) => {
    if (video.isUserGenerated) {
      setHoveredStory(video as RecordedStory);
    } else {
      setSelectedStory(video);
    }
  };

  return (
    <div className="min-h-screen bg-background relative overflow-hidden">
      {/* Floating Elements - Background Layer */}
      <div className="motion-background absolute inset-0">
        <FloatingElements />
      </div>

      {/* Timeline Line - Left Side */}
      <div className="hidden md:block fixed left-16 top-20 bottom-0 w-px bg-[hsl(var(--coral))]/30 z-10"></div>

      {/* Main Content */}
      <div className="px-2 sm:px-4 md:pl-40 md:pr-16 py-4 sm:py-8 md:py-16 content-layer">
        {/* Family Timeline Header */}
        <div className="text-center mb-6 sm:mb-8">
          <h1 className="text-2xl sm:text-3xl md:text-4xl font-bold text-foreground mb-2">Familiengeschichte</h1>
          <p className="text-sm sm:text-base text-muted-foreground">
            Entdecke deine Lebensgeschichte in chronologischer Reihenfolge
          </p>
        </div>

        {years.map((year, yearIndex) => (
          <div key={year} className="mb-8 sm:mb-12 md:mb-16 lg:mb-32">
            {/* Year Header with Timeline Dot */}
            <div className="relative mb-6 sm:mb-8 md:mb-16">
              {/* Timeline Dot - Hidden on mobile */}
              <div className="hidden md:block absolute -left-[152px] top-2">
                <div className="w-6 h-6 bg-[hsl(var(--coral))] rounded-full flex items-center justify-center shadow-sm">
                  <div className="w-2 h-2 bg-white rounded-full"></div>
                </div>
              </div>
              
              {/* Year Display - Mobile optimized */}
              <div className="md:absolute md:-left-[120px] md:top-0 mb-4 md:mb-0">
                <div className="text-xl sm:text-2xl md:text-3xl font-bold text-[hsl(var(--navy))] text-center md:text-left">
                  {year}
                </div>
              </div>
            </div>

            {/* Content Grid - Bento Box Layout */}
            <div className="grid grid-cols-6 sm:grid-cols-12 gap-2 sm:gap-4 auto-rows-[120px] sm:auto-rows-[200px]">
              {allStoriesData[year]?.map((item, index) => {
                const isUserStory = 'isUserGenerated' in item ? item.isUserGenerated : false;
                
                // Bento Box layout patterns - mobile-responsive
                const getCardSize = (idx: number) => {
                  const mobilePatterns = [
                    "col-span-3 row-span-1", // Half width on mobile
                    "col-span-3 row-span-1", // Half width on mobile
                    "col-span-6 row-span-1", // Full width on mobile
                    "col-span-3 row-span-1", // Half width on mobile
                    "col-span-3 row-span-1", // Half width on mobile
                    "col-span-6 row-span-1", // Full width on mobile
                  ];
                  const desktopPatterns = [
                    "sm:col-span-3 sm:row-span-1", // Small on desktop
                    "sm:col-span-3 sm:row-span-1", // Small on desktop
                    "sm:col-span-6 sm:row-span-1", // Wide on desktop
                    "sm:col-span-4 sm:row-span-1", // Medium on desktop
                    "sm:col-span-4 sm:row-span-1", // Medium on desktop
                    "sm:col-span-4 sm:row-span-1", // Medium on desktop
                  ];
                  return `${mobilePatterns[idx % mobilePatterns.length]} ${desktopPatterns[idx % desktopPatterns.length]}`;
                };

                // Color patterns
                const getCardColor = (idx: number) => {
                  const colors = [
                    { bg: "#B6D7E8", text: "#384785" }, // Light Blue bg, dark text
                    { bg: "#F8EBB4", text: "#384785" }, // Light Yellow bg, dark text
                    { bg: "#384785", text: "#B6D7E8" }, // Dark Blue bg, light text
                  ];
                  return colors[idx % colors.length];
                };

                const cardSize = getCardSize(index);
                const cardColor = getCardColor(index);

                // Handle processing videos with placeholder
                if (item.status === 'processing') {
                  return (
                    <div key={item.id} className={`${cardSize} contents`}>
                      <ProcessingPlaceholder 
                        question={item.title}
                        status="processing"
                        className={cardSize}
                      />
                    </div>
                  );
                }

                return (
                  <div key={item.id} className="contents">
                    <Dialog>
                      <DialogTrigger asChild>
                        <div 
                          className={`${cardSize} cursor-pointer group transform hover:scale-105 transition-all duration-300 rounded-xl sm:rounded-2xl overflow-hidden shadow-sm hover:shadow-lg flex items-center justify-center p-3 sm:p-6 relative`}
                          style={{ backgroundColor: cardColor.bg }}
                          onClick={e => {
                            if (isUserStory) {
                              e.preventDefault();
                              setHoveredStory(item as RecordedStory);
                            }
                          }}
                        >
                          <div className="text-center w-full">
                            <h3 className="font-semibold text-sm sm:text-lg leading-tight sm:leading-relaxed" style={{ color: cardColor.text }}>
                              {item.title}
                            </h3>
                            <div className="mt-1 sm:mt-2 opacity-60">
                              <p className="text-xs" style={{ color: cardColor.text }}>
                                {new Date(item.date).toLocaleDateString('de-DE')}
                              </p>
                              {item.location && (
                                <p className="text-xs mt-1 hidden sm:block" style={{ color: cardColor.text }}>
                                  {item.location}
                                </p>
                              )}
                            </div>
                            <div className="absolute top-2 sm:top-3 right-2 sm:right-3 opacity-30">
                              {item.type === 'video' && <Play className="h-3 w-3 sm:h-4 sm:w-4" style={{ color: cardColor.text }} />}
                              {item.type === 'text' && <FileText className="h-3 w-3 sm:h-4 sm:w-4" style={{ color: cardColor.text }} />}
                              {item.type === 'image' && <ImageIcon className="h-3 w-3 sm:h-4 sm:w-4" style={{ color: cardColor.text }} />}
                            </div>
                            {isUserStory && (
                              <div className="absolute top-2 sm:top-3 left-2 sm:left-3">
                                <div className="w-2 h-2 bg-yellow-500 rounded-full"></div>
                              </div>
                            )}
                          </div>
                        </div>
                      </DialogTrigger>
                      
                      <DialogContent className="max-w-2xl rounded-2xl sm:rounded-3xl border-0 shadow-2xl mx-2 sm:mx-0">
                        <DialogHeader>
                          <DialogTitle className="text-lg sm:text-xl md:text-2xl font-bold flex items-center gap-2 sm:gap-3 text-[hsl(var(--navy))]">
                            {getContentIcon(item.type)}
                            <span className="truncate">{item.title}</span>
                          </DialogTitle>
                        </DialogHeader>
                        <div className="space-y-4 sm:space-y-6">
                          <div className="flex flex-wrap gap-2 sm:gap-3">
                            <Badge variant="secondary" className="bg-[hsl(var(--light-blue))] text-[hsl(var(--navy))] font-medium text-xs sm:text-sm">
                              <Calendar className="h-3 w-3 mr-1" />
                              {new Date(item.date).toLocaleDateString('de-DE')}
                            </Badge>
                            {item.location && (
                              <Badge variant="secondary" className="bg-[hsl(var(--yellow))] text-[hsl(var(--navy))] font-medium text-xs sm:text-sm">
                                <MapPin className="h-3 w-3 mr-1" />
                                <span className="truncate max-w-[120px] sm:max-w-none">{item.location}</span>
                              </Badge>
                            )}
                            {item.participants && (
                              <Badge variant="secondary" className="bg-[hsl(var(--coral))]/20 text-[hsl(var(--navy))] font-medium text-xs sm:text-sm">
                                <Users className="h-3 w-3 mr-1" />
                                <span className="truncate max-w-[120px] sm:max-w-none">{item.participants.join(', ')}</span>
                              </Badge>
                            )}
                          </div>
                          {item.description && <p className="text-gray-700 leading-relaxed text-sm sm:text-base">{item.description}</p>}
                          {item.videoUrl && (
                            <div className="rounded-lg sm:rounded-2xl overflow-hidden shadow-lg">
                              <video 
                                src={item.videoUrl} 
                                controls 
                                className="w-full h-48 sm:h-64 object-cover"
                                poster={getImageWithFallback(item.previewImage, 'video')}
                              >
                                Ihr Browser unterstützt keine Videos.
                              </video>
                            </div>
                          )}
                        </div>
                      </DialogContent>
                    </Dialog>
                  </div>
                );
              })}
            </div>
          </div>
        ))}

        {/* Hover Card for User Stories */}
        {hoveredStory && (
          <StoryHoverCard 
            story={hoveredStory}
            isOpen={!!hoveredStory}
            onClose={() => setHoveredStory(null)} 
          />
        )}
      </div>
    </div>
  );
};

export default FamilyTimeline;