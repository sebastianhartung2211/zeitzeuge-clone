import React, { useState } from 'react';
import { useAuth } from '../../hooks/useAuth';
import { useNavigate } from 'react-router-dom';
import { useStories, RecordedStory } from '@/hooks/useStories';
import { useVideos, VideoData } from '@/hooks/useVideos';
import { StoryHoverCard } from '../timeline/StoryHoverCard';

import CategoryView from './CategoryView';
import FloatingElements from '../ui/floating-elements';
import { Button } from '@/components/ui/button';
import { Loader2, AlertCircle } from 'lucide-react';

const Timeline = () => {
  const [hoveredStory, setHoveredStory] = useState<RecordedStory | null>(null);
  const navigate = useNavigate();
  const { user } = useAuth();
  const { userStories } = useStories();
  const { videos, loading, error, reload } = useVideos();

  // Filter out required calibration videos
  const isRequiredVideo = (v: VideoData) => {
    const cat = (v.category || '').toLowerCase().trim();
    return cat === 'erforderlich' || cat === 'required';
  };
  const filteredVideos = videos.filter(v => !isRequiredVideo(v));

  // Show loading state
  if (loading && !user) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-center">
          <Loader2 className="h-8 w-8 animate-spin mx-auto mb-4 text-[hsl(var(--coral))]" />
          <p className="text-gray-600">Lade Videos...</p>
        </div>
      </div>
    );
  }

  // Show authentication message if not logged in
  if (!user) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-center">
          <AlertCircle className="h-12 w-12 mx-auto mb-4 text-amber-500" />
          <h2 className="text-2xl font-bold text-[hsl(var(--navy))] mb-2">
            Anmeldung erforderlich
          </h2>
          <p className="text-gray-600 mb-4">
            Melden Sie sich an, um Ihre persönlichen Videos zu sehen
          </p>
          <Button onClick={() => navigate('/login')} className="bg-gradient-to-r from-violet-500 via-purple-500 to-indigo-500 hover:from-violet-600 hover:via-purple-600 hover:to-indigo-600 rounded-2xl">
            Anmelden
          </Button>
        </div>
      </div>
    );
  }

  // Show error state
  if (error) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-center">
          <AlertCircle className="h-12 w-12 mx-auto mb-4 text-red-500" />
          <h2 className="text-2xl font-bold text-[hsl(var(--navy))] mb-2">
            Fehler beim Laden
          </h2>
          <p className="text-gray-600 mb-4">{error}</p>
          <Button onClick={() => window.location.reload()} variant="outline" className="rounded-2xl">
            Neu laden
          </Button>
        </div>
      </div>
    );
  }

  const handleVideoClick = (video: any) => {
    if (video.isUserGenerated) {
      setHoveredStory(video as RecordedStory);
    }
  };

  return (
    <div className="min-h-screen bg-background relative overflow-hidden">
      {/* Floating Elements - Background Layer */}
      <div className="motion-background absolute inset-0">
        <FloatingElements />
      </div>

      {/* Main Content */}
      <div className="px-2 sm:px-4 md:px-16 py-4 sm:py-8 md:py-16 content-layer">
        {/* Always show categories */}
        <CategoryView 
          videos={filteredVideos} 
          onVideoClick={handleVideoClick} 
          onVideoUpdated={reload} 
        />
      </div>
      
      {/* User Story Hover Card */}
      {hoveredStory && <StoryHoverCard story={hoveredStory} isOpen={!!hoveredStory} onClose={() => setHoveredStory(null)} />}
    </div>
  );
};

export default Timeline;