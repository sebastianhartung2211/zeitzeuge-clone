import React, { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { VideoData } from '@/hooks/useVideos';
import { useCategories } from '@/hooks/useCategories';
import { useTags } from '@/hooks/useTags';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';
import { X, Trash2 } from 'lucide-react';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from '@/components/ui/alert-dialog';

interface VideoEditDialogProps {
  video: VideoData | null;
  isOpen: boolean;
  onClose: () => void;
  onVideoUpdated: () => void;
}

export const VideoEditDialog: React.FC<VideoEditDialogProps> = ({
  video,
  isOpen,
  onClose,
  onVideoUpdated,
}) => {
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('none');
  const [selectedTags, setSelectedTags] = useState<string[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [isDeleting, setIsDeleting] = useState(false);
  
  const { categories } = useCategories();
  const { tags } = useTags();
  const { toast } = useToast();

  useEffect(() => {
    if (video) {
      setTitle(video.title);
      setDescription(video.description || '');
      setSelectedCategory(video.category || 'none');
      setSelectedTags(video.tags?.map(tag => tag.name) || []);
    }
  }, [video]);

  const handleSave = async () => {
    if (!video) return;

    setIsLoading(true);
    try {
      // Update video basic info
      const { error: videoError } = await supabase
        .from('videos')
        .update({
          title,
          description,
          category: selectedCategory === 'none' ? null : selectedCategory,
        })
        .eq('id', video.id);

      if (videoError) throw videoError;

      // Remove existing video tags first
      await supabase
        .from('video_tags')
        .delete()
        .eq('video_id', video.id);

      // Add new video tags
      if (selectedTags.length > 0) {
        const tagIds = selectedTags
          .map(tagName => tags.find(tag => tag.name === tagName)?.id)
          .filter(Boolean);

        if (tagIds.length > 0) {
          const { error: insertTagsError } = await supabase
            .from('video_tags')
            .insert(
              tagIds.map(tagId => ({
                video_id: video.id,
                tag_id: tagId,
              }))
            );

          if (insertTagsError) throw insertTagsError;
        }
      }

      toast({
        title: 'Video updated',
        description: 'Your video has been successfully updated.',
      });

      onVideoUpdated();
      onClose();
    } catch (error: any) {
      console.error('Error updating video:', error);
      toast({
        title: 'Error',
        description: 'Failed to update video. Please try again.',
        variant: 'destructive',
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleTagToggle = (tagName: string) => {
    setSelectedTags(prev => 
      prev.includes(tagName) 
        ? prev.filter(t => t !== tagName)
        : [...prev, tagName]
    );
  };

  const removeTag = (tagName: string) => {
    setSelectedTags(prev => prev.filter(t => t !== tagName));
  };

  const handleDelete = async () => {
    if (!video) return;

    setIsDeleting(true);
    try {
      // Get current user for storage path
      const { data: { user } } = await supabase.auth.getUser();
      
      // Delete from storage first
      if (video.video_url && user) {
        const videoPath = video.video_url.split('/').pop();
        if (videoPath) {
          const { error: storageError } = await supabase.storage
            .from('videos')
            .remove([`${user.id}/${videoPath}`]);
          
          if (storageError) {
            console.error('Error deleting video from storage:', storageError);
          }
        }
      }

      // Delete video record from database (cascade will handle related records)
      const { error: deleteError } = await supabase
        .from('videos')
        .delete()
        .eq('id', video.id);

      if (deleteError) throw deleteError;

      toast({
        title: 'Video gelöscht',
        description: 'Das Video wurde erfolgreich gelöscht.',
      });

      onVideoUpdated();
      onClose();
    } catch (error: any) {
      console.error('Error deleting video:', error);
      toast({
        title: 'Fehler',
        description: 'Das Video konnte nicht gelöscht werden. Bitte versuchen Sie es erneut.',
        variant: 'destructive',
      });
    } finally {
      setIsDeleting(false);
    }
  };

  if (!video) return null;

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Video bearbeiten</DialogTitle>
        </DialogHeader>

        <div className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="title">Titel</Label>
            <Input
              id="title"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="Video titel eingeben..."
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="description">Beschreibung</Label>
            <Textarea
              id="description"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Video beschreibung eingeben..."
              rows={3}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="category">Kategorie</Label>
            <Select value={selectedCategory} onValueChange={setSelectedCategory}>
              <SelectTrigger>
                <SelectValue placeholder="Kategorie wählen..." />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="none">Keine Kategorie</SelectItem>
                {categories.map((category) => (
                  <SelectItem key={category.id} value={category.name}>
                    {category.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>


          <div className="flex justify-between pt-4">
            <AlertDialog>
              <AlertDialogTrigger asChild>
                <Button variant="destructive" disabled={isLoading || isDeleting}>
                  <Trash2 className="w-4 h-4 mr-2" />
                  Video löschen
                </Button>
              </AlertDialogTrigger>
              <AlertDialogContent>
                <AlertDialogHeader>
                  <AlertDialogTitle>Video löschen</AlertDialogTitle>
                  <AlertDialogDescription>
                    Sind Sie sicher, dass Sie dieses Video löschen möchten? Diese Aktion kann nicht rückgängig gemacht werden.
                  </AlertDialogDescription>
                </AlertDialogHeader>
                <AlertDialogFooter>
                  <AlertDialogCancel>Abbrechen</AlertDialogCancel>
                  <AlertDialogAction 
                    onClick={handleDelete}
                    disabled={isDeleting}
                    className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
                  >
                    {isDeleting ? 'Löschen...' : 'Löschen'}
                  </AlertDialogAction>
                </AlertDialogFooter>
              </AlertDialogContent>
            </AlertDialog>

            <div className="flex gap-2">
              <Button variant="outline" onClick={onClose} disabled={isLoading || isDeleting}>
                Abbrechen
              </Button>
              <Button onClick={handleSave} disabled={isLoading || isDeleting}>
                {isLoading ? 'Speichern...' : 'Speichern'}
              </Button>
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};