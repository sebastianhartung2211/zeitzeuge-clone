import { media } from '@/platform';
import { enqueueUpload } from '@/features/upload/enqueueUpload';
import { Button } from '@/components/ui/button';
import { useState } from 'react';
import { Upload } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { useAuth } from '@/hooks/useAuth';

export function UploadAndSend() {
  const [isUploading, setIsUploading] = useState(false);
  const { toast } = useToast();
  const { user } = useAuth();

  const handleUploadAndSend = async () => {
    if (!user) {
      toast({
        title: 'Nicht angemeldet',
        description: 'Bitte melden Sie sich an, um Videos hochzuladen.',
        variant: 'destructive',
      });
      return;
    }

    try {
      setIsUploading(true);
      
      // Pick video file
      const file = await media.pickVideo();
      console.log('Video file selected');
      
      // Save locally first
      const localPath = await media.saveLocal(file as Blob, `video-${Date.now()}.mp4`);
      console.log('Video saved locally:', localPath);
      
      // Generate unique object key scoped to user
      const objectKey = `${user.id}/uploads/${Date.now()}-${Math.random().toString(36).substring(7)}.mp4`;
      
      // Enqueue upload
      const result = await enqueueUpload(localPath, 'videos', objectKey);
      
      toast({
        title: 'Upload gestartet',
        description: `Video wird ${result.method === 'background' ? 'im Hintergrund' : 'direkt'} hochgeladen...`,
      });
      
      console.log('Upload enqueued successfully:', result);
      
    } catch (error) {
      console.error('Upload failed:', error);
      toast({
        title: 'Upload fehlgeschlagen',
        description: error instanceof Error ? error.message : 'Unbekannter Fehler',
        variant: 'destructive',
      });
    } finally {
      setIsUploading(false);
    }
  };

  return (
    <Button
      onClick={handleUploadAndSend}
      disabled={isUploading}
      className="bg-[hsl(var(--coral))] text-white hover:bg-[hsl(var(--coral))]/90 transition-colors"
    >
      <Upload className="w-4 h-4 mr-2" />
      {isUploading ? 'Upload läuft...' : 'Video hochladen'}
    </Button>
  );
}