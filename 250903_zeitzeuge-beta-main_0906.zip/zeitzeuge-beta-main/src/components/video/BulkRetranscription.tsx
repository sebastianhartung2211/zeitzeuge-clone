import React, { useState } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Play, RefreshCw, CheckCircle, AlertTriangle, Clock, Database } from 'lucide-react';
import { toast } from 'sonner';

interface RetranscriptionResult {
  id: string;
  title: string;
  status: string;
  error?: string;
  confidence?: number;
  processingTime?: number;
}

interface VideoStats {
  totalVideos: number;
  processedCount: number;
  successCount: number;
  failedCount: number;
  estimatedTimeRemaining: number;
}

export const BulkRetranscription: React.FC = () => {
  const [isRunning, setIsRunning] = useState(false);
  const [currentPhase, setCurrentPhase] = useState<'analysis' | 'processing' | 'completed' | null>(null);
  const [progress, setProgress] = useState(0);
  const [stats, setStats] = useState<VideoStats | null>(null);
  const [results, setResults] = useState<RetranscriptionResult[]>([]);
  const [analysisData, setAnalysisData] = useState<any>(null);

  const analyzeAllVideos = async () => {
    try {
      console.log('🔍 Starting comprehensive video analysis...');
      const { data, error } = await supabase.functions.invoke('video-reprocessor', {
        body: { action: 'analyze_all_videos' }
      });

      if (error) throw error;

      setAnalysisData(data.analysis);
      toast.success(`Analysis completed: ${data.analysis.totalVideos} videos analyzed`);
      
      return data.analysis;
    } catch (error: any) {
      console.error('Analysis error:', error);
      toast.error(`Analysis failed: ${error.message}`);
      throw error;
    }
  };

  const retranscribeAllVideos = async () => {
    try {
      console.log('🎤 Starting bulk retranscription...');
      const { data, error } = await supabase.functions.invoke('video-reprocessor', {
        body: { action: 'retranscribe_all' }
      });

      if (error) throw error;

      setResults(data.results);
      
      const finalStats: VideoStats = {
        totalVideos: data.results.length,
        processedCount: data.results.length,
        successCount: data.summary.successful,
        failedCount: data.summary.failed,
        estimatedTimeRemaining: 0
      };
      
      setStats(finalStats);
      setProgress(100);
      
      toast.success(`Retranscription completed: ${data.summary.successful}/${data.results.length} successful`);
      
      return data;
    } catch (error: any) {
      console.error('Retranscription error:', error);
      toast.error(`Retranscription failed: ${error.message}`);
      throw error;
    }
  };

  const reprocessFailedVideos = async () => {
    try {
      console.log('🔄 Starting failed video reprocessing...');
      const { data, error } = await supabase.functions.invoke('video-reprocessor', {
        body: { action: 'reprocess_failed_videos' }
      });

      if (error) throw error;

      // Add failed video results to our results array
      const failedResults = data.results.map((result: any) => ({
        ...result,
        status: result.status === 'processing' ? 'reprocessing' : result.status
      }));
      
      setResults(prev => [...prev, ...failedResults]);
      
      toast.success(`Failed videos reprocessed: ${data.summary.successful} videos restarted`);
      
      return data;
    } catch (error: any) {
      console.error('Failed video reprocessing error:', error);
      toast.error(`Failed video reprocessing failed: ${error.message}`);
      throw error;
    }
  };

  const runCompleteRetranscription = async () => {
    setIsRunning(true);
    setResults([]);
    setProgress(0);
    setCurrentPhase('analysis');

    try {
      // Phase 1: Analysis
      console.log('📊 Phase 1: Analyzing all videos...');
      const analysis = await analyzeAllVideos();
      setProgress(20);

      // Phase 2: Reprocess failed videos first
      if (analysis.statusBreakdown?.failed > 0) {
        console.log('🔄 Phase 2: Reprocessing failed videos...');
        setCurrentPhase('processing');
        await reprocessFailedVideos();
        setProgress(40);
      }

      // Phase 3: Retranscribe all videos
      console.log('🎤 Phase 3: Retranscribing all videos...');
      setCurrentPhase('processing');
      await retranscribeAllVideos();
      setProgress(100);

      setCurrentPhase('completed');
      
      toast.success('🎉 Complete retranscription process finished!');

    } catch (error: any) {
      console.error('Complete retranscription failed:', error);
      toast.error(`Process failed: ${error.message}`);
    } finally {
      setIsRunning(false);
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'success':
        return <CheckCircle className="h-4 w-4 text-green-500" />;
      case 'failed':
      case 'error':
        return <AlertTriangle className="h-4 w-4 text-red-500" />;
      case 'reprocessing':
      case 'processing':
        return <RefreshCw className="h-4 w-4 text-blue-500 animate-spin" />;
      default:
        return <Clock className="h-4 w-4 text-gray-500" />;
    }
  };

  const getStatusBadgeVariant = (status: string) => {
    switch (status) {
      case 'success': return 'default';
      case 'failed':
      case 'error': return 'destructive';
      case 'reprocessing':
      case 'processing': return 'secondary';
      default: return 'outline';
    }
  };

  return (
    <div className="space-y-6">
      {/* Control Panel */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Database className="h-5 w-5" />
            Bulk Video Retranscription
          </CardTitle>
          <CardDescription>
            Reprocess all existing videos with the improved Transcription Agent V2 for higher quality transcripts
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="flex flex-wrap gap-4">
              <Button
                onClick={analyzeAllVideos}
                disabled={isRunning}
                variant="outline"
                className="flex items-center gap-2"
              >
                <Database className="h-4 w-4" />
                Analyze Videos Only
              </Button>

              <Button
                onClick={retranscribeAllVideos}
                disabled={isRunning}
                variant="secondary"
                className="flex items-center gap-2"
              >
                <RefreshCw className="h-4 w-4" />
                Retranscribe All
              </Button>

              <Button
                onClick={runCompleteRetranscription}
                disabled={isRunning}
                className="flex items-center gap-2 bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700"
              >
                <Play className="h-4 w-4" />
                {isRunning ? 'Running...' : 'Complete Retranscription'}
              </Button>
            </div>

            {isRunning && (
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-sm font-medium">
                    {currentPhase === 'analysis' && '📊 Analyzing videos...'}
                    {currentPhase === 'processing' && '🎤 Processing videos...'}
                    {currentPhase === 'completed' && '✅ Process completed'}
                  </span>
                  <span className="text-sm text-muted-foreground">{progress}%</span>
                </div>
                <Progress value={progress} className="w-full" />
                {stats && (
                  <div className="text-xs text-muted-foreground">
                    Processed: {stats.processedCount}/{stats.totalVideos} | 
                    Success: {stats.successCount} | 
                    Failed: {stats.failedCount}
                  </div>
                )}
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Analysis Results */}
      {analysisData && (
        <Card>
          <CardHeader>
            <CardTitle>Video Analysis Results</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-4">
              <div className="text-center">
                <div className="text-2xl font-bold">{analysisData.totalVideos}</div>
                <div className="text-sm text-muted-foreground">Total Videos</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-green-600">{analysisData.transcriptStatus.withTranscripts}</div>
                <div className="text-sm text-muted-foreground">With Transcripts</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-yellow-600">{analysisData.transcriptStatus.lowConfidence}</div>
                <div className="text-sm text-muted-foreground">Low Confidence</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-red-600">{analysisData.statusBreakdown?.failed || 0}</div>
                <div className="text-sm text-muted-foreground">Failed Videos</div>
              </div>
            </div>

            {analysisData.recommendations?.length > 0 && (
              <Alert>
                <AlertTriangle className="h-4 w-4" />
                <AlertDescription>
                  <div className="space-y-1">
                    <strong>Recommendations:</strong>
                    <ul className="list-disc list-inside space-y-1">
                      {analysisData.recommendations.map((rec: string, index: number) => (
                        <li key={index} className="text-sm">{rec}</li>
                      ))}
                    </ul>
                  </div>
                </AlertDescription>
              </Alert>
            )}
          </CardContent>
        </Card>
      )}

      {/* Processing Results */}
      {results.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle>Processing Results</CardTitle>
            <CardDescription>
              {results.length} videos processed
            </CardDescription>
          </CardHeader>
          <CardContent>
            <ScrollArea className="h-96 w-full">
              <div className="space-y-2">
                {results.map((result, index) => (
                  <div key={`${result.id}-${index}`} className="flex items-center gap-3 p-3 border rounded">
                    {getStatusIcon(result.status)}
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-1">
                        <p className="font-medium text-sm truncate">{result.title}</p>
                        <Badge variant={getStatusBadgeVariant(result.status)}>
                          {result.status}
                        </Badge>
                      </div>
                      
                      <div className="flex items-center gap-4 text-xs text-muted-foreground">
                        {result.confidence && (
                          <span>Confidence: {typeof result.confidence === 'number' ? `${Math.round(result.confidence * 100)}%` : result.confidence}</span>
                        )}
                        {result.processingTime && (
                          <span>Time: {result.processingTime}ms</span>
                        )}
                      </div>
                      
                      {result.error && (
                        <p className="text-xs text-red-600 mt-1">{result.error}</p>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </ScrollArea>
          </CardContent>
        </Card>
      )}

      {/* Instructions */}
      <Card>
        <CardHeader>
          <CardTitle>Process Overview</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3 text-sm">
            <div className="flex items-start gap-2">
              <span className="font-semibold text-blue-600">1.</span>
              <div>
                <strong>Analysis:</strong> Scans all videos to identify transcription status, quality issues, and failed videos
              </div>
            </div>
            <div className="flex items-start gap-2">
              <span className="font-semibold text-blue-600">2.</span>
              <div>
                <strong>Failed Video Recovery:</strong> Reprocesses videos that previously failed during upload/processing
              </div>
            </div>
            <div className="flex items-start gap-2">
              <span className="font-semibold text-blue-600">3.</span>
              <div>
                <strong>Quality Retranscription:</strong> Re-transcribes videos with low confidence scores (&lt;80%) using improved Transcript Agent V2
              </div>
            </div>
            <div className="flex items-start gap-2">
              <span className="font-semibold text-blue-600">4.</span>
              <div>
                <strong>Enhanced Processing:</strong> Uses OpenAI Whisper with optimized settings, German language optimization, and quality validation
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};