
import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { 
  MessageCircle, 
  Video, 
  Play, 
  Send, 
  Plus,
  Users,
  Clock
} from 'lucide-react';
import { useAuth } from '../../hooks/useAuth';

const VideoConversations = () => {
  const { user } = useAuth();
  const [selectedConversation, setSelectedConversation] = useState<number | null>(null);
  const [messageText, setMessageText] = useState('');

  const [conversations] = useState([
    {
      id: 1,
      title: 'Familienurlaub Erinnerungen',
      participants: ['Maria Schmidt', 'Anna Weber', 'Thomas Klein'],
      lastMessage: 'Das war wirklich ein wunderschöner Tag!',
      lastActivity: '2 Std.',
      videoThumbnail: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=300&h=200&fit=crop',
      unreadCount: 3,
      messages: [
        {
          id: 1,
          author: 'Maria Schmidt',
          content: 'Schaut euch dieses wundervolle Video vom Strand an!',
          timestamp: '14:30',
          type: 'video'
        },
        {
          id: 2,
          author: 'Anna Weber',
          content: 'Oh wie schön! Die Kinder hatten so viel Spaß.',
          timestamp: '14:35',
          type: 'text'
        },
        {
          id: 3,
          author: 'Thomas Klein',
          content: 'Das war wirklich ein wunderschöner Tag!',
          timestamp: '15:20',
          type: 'text'
        }
      ]
    },
    {
      id: 2,
      title: 'Omas Kochgeheimnisse',
      participants: ['Anna Weber', 'Lisa Mueller'],
      lastMessage: 'Das Rezept ist perfekt geworden!',
      lastActivity: '1 Tag',
      videoThumbnail: 'https://images.unsplash.com/photo-1556909114-f6e7ad7d3136?w=300&h=200&fit=crop',
      unreadCount: 0,
      messages: [
        {
          id: 1,
          author: 'Anna Weber',
          content: 'Hier ist Omas geheimes Pfannkuchenrezept!',
          timestamp: 'Gestern 16:45',
          type: 'video'
        },
        {
          id: 2,
          author: 'Lisa Mueller',
          content: 'Das Rezept ist perfekt geworden!',
          timestamp: 'Gestern 18:30',
          type: 'text'
        }
      ]
    }
  ]);

  const selectedConv = conversations.find(c => c.id === selectedConversation);

  const handleSendMessage = () => {
    if (messageText.trim()) {
      // In a real app, this would send the message to your backend
      setMessageText('');
    }
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold text-gray-900">Video-Gespräche</h1>
        <p className="text-gray-600 mt-1">Diskutieren Sie über Ihre geteilten Videos und Erinnerungen</p>
      </div>

      <div className="grid lg:grid-cols-3 gap-6 min-h-[600px]">
        {/* Conversations List */}
        <div className="lg:col-span-1">
          <Card className="h-full">
            <CardHeader className="pb-3">
              <div className="flex items-center justify-between">
                <CardTitle className="text-lg">Gespräche</CardTitle>
                <Button size="sm" className="bg-gradient-to-r from-purple-600 to-pink-600">
                  <Plus className="h-4 w-4 mr-2" />
                  Neu
                </Button>
              </div>
            </CardHeader>
            <CardContent className="p-0">
              <div className="space-y-1">
                {conversations.map((conv) => (
                  <div
                    key={conv.id}
                    onClick={() => setSelectedConversation(conv.id)}
                    className={`p-4 cursor-pointer hover:bg-gray-50 transition-colors border-l-4 ${
                      selectedConversation === conv.id 
                        ? 'border-purple-500 bg-purple-50' 
                        : 'border-transparent'
                    }`}
                  >
                    <div className="flex items-start gap-3">
                      <div className="relative">
                        <img 
                          src={conv.videoThumbnail} 
                          alt={conv.title}
                          className="w-12 h-12 rounded-lg object-cover"
                        />
                        <div className="absolute -bottom-1 -right-1 bg-red-500 rounded-full p-1">
                          <Video className="h-3 w-3 text-white" />
                        </div>
                      </div>
                      
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center justify-between mb-1">
                          <h3 className="font-medium text-sm truncate">{conv.title}</h3>
                          {conv.unreadCount > 0 && (
                            <Badge className="bg-purple-600 text-white text-xs">
                              {conv.unreadCount}
                            </Badge>
                          )}
                        </div>
                        
                        <div className="flex items-center gap-1 mb-2">
                          <Users className="h-3 w-3 text-gray-400" />
                          <span className="text-xs text-gray-500">
                            {conv.participants.length} Teilnehmer
                          </span>
                        </div>
                        
                        <p className="text-xs text-gray-600 truncate mb-1">
                          {conv.lastMessage}
                        </p>
                        
                        <div className="flex items-center gap-1">
                          <Clock className="h-3 w-3 text-gray-400" />
                          <span className="text-xs text-gray-400">{conv.lastActivity}</span>
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Chat Area */}
        <div className="lg:col-span-2">
          {selectedConv ? (
            <Card className="h-full flex flex-col">
              <CardHeader className="pb-3 border-b">
                <div className="flex items-center gap-3">
                  <img 
                    src={selectedConv.videoThumbnail} 
                    alt={selectedConv.title}
                    className="w-10 h-10 rounded-lg object-cover"
                  />
                  <div>
                    <CardTitle className="text-lg">{selectedConv.title}</CardTitle>
                    <div className="flex items-center gap-2 mt-1">
                      <Users className="h-4 w-4 text-gray-400" />
                      <span className="text-sm text-gray-600">
                        {selectedConv.participants.join(', ')}
                      </span>
                    </div>
                  </div>
                  <div className="ml-auto">
                    <Button size="sm" variant="outline">
                      <Play className="h-4 w-4 mr-2" />
                      Video ansehen
                    </Button>
                  </div>
                </div>
              </CardHeader>

              <CardContent className="flex-1 flex flex-col p-0">
                {/* Messages */}
                <div className="flex-1 p-4 overflow-y-auto space-y-4">
                  {selectedConv.messages.map((message) => (
                    <div key={message.id} className="flex items-start gap-3">
                      <Avatar className="h-8 w-8">
                        <AvatarImage src={`https://api.dicebear.com/7.x/avataaars/svg?seed=${message.author}`} />
                        <AvatarFallback>{message.author.charAt(0)}</AvatarFallback>
                      </Avatar>
                      
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-1">
                          <span className="text-sm font-medium">{message.author}</span>
                          <span className="text-xs text-gray-500">{message.timestamp}</span>
                          {message.type === 'video' && (
                            <Badge variant="outline" className="text-xs">
                              <Video className="h-3 w-3 mr-1" />
                              Video
                            </Badge>
                          )}
                        </div>
                        <p className="text-sm text-gray-700">{message.content}</p>
                      </div>
                    </div>
                  ))}
                </div>

                {/* Message Input */}
                <div className="p-4 border-t bg-gray-50">
                  <div className="flex gap-2">
                    <Input
                      value={messageText}
                      onChange={(e) => setMessageText(e.target.value)}
                      placeholder="Nachricht eingeben..."
                      onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
                      className="flex-1"
                    />
                    <Button 
                      onClick={handleSendMessage}
                      disabled={!messageText.trim()}
                      className="bg-gradient-to-r from-purple-600 to-pink-600"
                    >
                      <Send className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          ) : (
            <Card className="h-full flex items-center justify-center">
              <CardContent className="text-center">
                <MessageCircle className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                <h3 className="text-lg font-medium text-gray-900 mb-2">
                  Wählen Sie ein Gespräch aus
                </h3>
                <p className="text-gray-600">
                  Klicken Sie auf ein Video-Gespräch links, um die Diskussion zu sehen
                </p>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </div>
  );
};

export default VideoConversations;
