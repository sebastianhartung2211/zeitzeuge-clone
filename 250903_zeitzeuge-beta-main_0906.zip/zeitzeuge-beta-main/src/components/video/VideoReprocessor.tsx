import React, { useState } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Progress } from '@/components/ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { RefreshCw, Play, BarChart3, Mic, AlertTriangle, CheckCircle, Database } from 'lucide-react';
import { toast } from 'sonner';
import { BulkRetranscription } from './BulkRetranscription';

interface AnalysisResult {
  totalVideos: number;
  statusBreakdown: Record<string, number>;
  transcriptStatus: {
    withTranscripts: number;
    withoutTranscripts: number;
    lowConfidence: number;
  };
  taggingStatus: {
    withTags: number;
    withoutTags: number;
  };
  problematicVideos: Array<{
    id: string;
    title: string;
    issue: string;
    confidence?: number;
    status?: string;
  }>;
  recommendations: string[];
}

interface ProcessingResult {
  id: string;
  title: string;
  status: string;
  error?: string;
  confidence?: string;
  message?: string;
}

export const VideoReprocessor: React.FC = () => {
  const [isProcessing, setIsProcessing] = useState(false);
  const [analysis, setAnalysis] = useState<AnalysisResult | null>(null);
  const [lastResults, setLastResults] = useState<ProcessingResult[]>([]);
  const [progress, setProgress] = useState(0);

  const analyzeVideos = async () => {
    setIsProcessing(true);
    try {
      const { data, error } = await supabase.functions.invoke('video-reprocessor', {
        body: { action: 'analyze_all_videos' }
      });

      if (error) throw error;

      setAnalysis(data.analysis);
      toast.success(`Analyse abgeschlossen: ${data.analysis.totalVideos} Videos analysiert`);
    } catch (error: any) {
      console.error('Analysis error:', error);
      toast.error(`Analyse fehlgeschlagen: ${error.message}`);
    } finally {
      setIsProcessing(false);
    }
  };

  const reprocessFailedVideos = async () => {
    setIsProcessing(true);
    setProgress(0);
    try {
      const { data, error } = await supabase.functions.invoke('video-reprocessor', {
        body: { action: 'reprocess_failed_videos' }
      });

      if (error) throw error;

      setLastResults(data.results);
      setProgress(100);
      toast.success(`${data.summary.successful} Videos erfolgreich neu verarbeitet`);
    } catch (error: any) {
      console.error('Reprocessing error:', error);
      toast.error(`Neuverarbeitung fehlgeschlagen: ${error.message}`);
    } finally {
      setIsProcessing(false);
    }
  };

  const retranscribeAll = async () => {
    setIsProcessing(true);
    setProgress(0);
    try {
      const { data, error } = await supabase.functions.invoke('video-reprocessor', {
        body: { action: 'retranscribe_all' }
      });

      if (error) throw error;

      setLastResults(data.results);
      setProgress(100);
      toast.success(`${data.summary.successful} Videos erfolgreich neu transkribiert`);
    } catch (error: any) {
      console.error('Retranscription error:', error);
      toast.error(`Neu-Transkription fehlgeschlagen: ${error.message}`);
    } finally {
      setIsProcessing(false);
    }
  };

  const getStatusBadgeVariant = (status: string) => {
    switch (status) {
      case 'completed': return 'default';
      case 'processing': return 'secondary';
      case 'failed': return 'destructive';
      case 'success': return 'default';
      case 'error': return 'destructive';
      default: return 'outline';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'completed':
      case 'success':
        return <CheckCircle className="h-4 w-4 text-green-500" />;
      case 'processing':
        return <RefreshCw className="h-4 w-4 text-blue-500 animate-spin" />;
      case 'failed':
      case 'error':
        return <AlertTriangle className="h-4 w-4 text-red-500" />;
      default:
        return null;
    }
  };

  return (
    <Tabs defaultValue="bulk" className="w-full">
      <TabsList className="grid grid-cols-2 w-full">
        <TabsTrigger value="bulk">Bulk Retranscription</TabsTrigger>
        <TabsTrigger value="individual">Individual Processing</TabsTrigger>
      </TabsList>
      
      <TabsContent value="bulk" className="space-y-6">
        <BulkRetranscription />
      </TabsContent>
      
      <TabsContent value="individual" className="space-y-6">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <BarChart3 className="h-5 w-5" />
              Individual Video Analysis & Repair
            </CardTitle>
            <CardDescription>
              Analyze and repair individual videos or small batches
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex flex-wrap gap-4">
              <Button
                onClick={analyzeVideos}
                disabled={isProcessing}
                variant="outline"
                className="flex items-center gap-2"
              >
                <BarChart3 className="h-4 w-4" />
                Analyze Videos
              </Button>

              <Button
                onClick={reprocessFailedVideos}
                disabled={isProcessing}
                variant="secondary"
                className="flex items-center gap-2"
              >
                <RefreshCw className="h-4 w-4" />
                Fix Failed Videos
              </Button>

              <Button
                onClick={retranscribeAll}
                disabled={isProcessing}
                className="flex items-center gap-2"
              >
                <Mic className="h-4 w-4" />
                Retranscribe Low Quality
              </Button>
            </div>

            {isProcessing && progress > 0 && (
              <div className="mt-4">
                <Progress value={progress} className="w-full" />
                <p className="text-sm text-muted-foreground mt-2">
                  Processing... {progress}%
                </p>
              </div>
            )}
          </CardContent>
        </Card>

        {analysis && (
          <Card>
            <CardHeader>
              <CardTitle>Analysis Results</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mb-6">
                <div className="space-y-2">
                  <h4 className="font-semibold">Total Statistics</h4>
                  <p className="text-2xl font-bold">{analysis.totalVideos}</p>
                  <p className="text-sm text-muted-foreground">Total Videos</p>
                </div>

                <div className="space-y-2">
                  <h4 className="font-semibold">Transcript Status</h4>
                  <div className="space-y-1">
                    <div className="flex justify-between">
                      <span className="text-sm">With Transcript:</span>
                      <Badge variant="default">{analysis.transcriptStatus.withTranscripts}</Badge>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-sm">Without Transcript:</span>
                      <Badge variant="destructive">{analysis.transcriptStatus.withoutTranscripts}</Badge>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-sm">Low Quality:</span>
                      <Badge variant="secondary">{analysis.transcriptStatus.lowConfidence}</Badge>
                    </div>
                  </div>
                </div>

                <div className="space-y-2">
                  <h4 className="font-semibold">Video Status</h4>
                  <div className="space-y-1">
                    {Object.entries(analysis.statusBreakdown).map(([status, count]) => (
                      <div key={status} className="flex justify-between">
                        <span className="text-sm capitalize">{status}:</span>
                        <Badge variant={getStatusBadgeVariant(status)}>{count}</Badge>
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              {analysis.recommendations.length > 0 && (
                <Alert>
                  <AlertTriangle className="h-4 w-4" />
                  <AlertDescription>
                    <div className="space-y-1">
                      <strong>Recommendations:</strong>
                      <ul className="list-disc list-inside space-y-1">
                        {analysis.recommendations.map((rec, index) => (
                          <li key={index} className="text-sm">{rec}</li>
                        ))}
                      </ul>
                    </div>
                  </AlertDescription>
                </Alert>
              )}

              {analysis.problematicVideos.length > 0 && (
                <div className="mt-6">
                  <h4 className="font-semibold mb-3">Problematic Videos</h4>
                  <ScrollArea className="h-64 w-full border rounded">
                    <div className="p-4 space-y-2">
                      {analysis.problematicVideos.map((video, index) => (
                        <div key={video.id} className="flex items-center justify-between p-2 border rounded">
                          <div className="flex-1">
                            <p className="font-medium text-sm">{video.title}</p>
                            <p className="text-xs text-muted-foreground">{video.issue}</p>
                            {video.confidence && (
                              <p className="text-xs text-muted-foreground">
                                Confidence: {Math.round(video.confidence * 100)}%
                              </p>
                            )}
                          </div>
                          <Badge variant="outline" className="ml-2">
                            {video.status || 'Problem'}
                          </Badge>
                        </div>
                      ))}
                    </div>
                  </ScrollArea>
                </div>
              )}
            </CardContent>
          </Card>
        )}

        {lastResults.length > 0 && (
          <Card>
            <CardHeader>
              <CardTitle>Processing Results</CardTitle>
              <CardDescription>
                Recently processed videos ({lastResults.length} total)
              </CardDescription>
            </CardHeader>
            <CardContent>
              <ScrollArea className="h-64 w-full">
                <div className="space-y-2">
                  {lastResults.map((result, index) => (
                    <div key={`${result.id}-${index}`} className="flex items-center gap-3 p-3 border rounded">
                      {getStatusIcon(result.status)}
                      <div className="flex-1">
                        <p className="font-medium text-sm">{result.title}</p>
                        <div className="flex items-center gap-2 mt-1">
                          <Badge variant={getStatusBadgeVariant(result.status)}>
                            {result.status}
                          </Badge>
                          {result.confidence && (
                            <Badge variant="outline">
                              Confidence: {result.confidence}
                            </Badge>
                          )}
                        </div>
                        {result.error && (
                          <p className="text-xs text-red-600 mt-1">{result.error}</p>
                        )}
                        {result.message && (
                          <p className="text-xs text-muted-foreground mt-1">{result.message}</p>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </ScrollArea>
            </CardContent>
          </Card>
        )}
      </TabsContent>
    </Tabs>
  );
};