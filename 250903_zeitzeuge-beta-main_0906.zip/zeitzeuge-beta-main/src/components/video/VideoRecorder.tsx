import React, { useState, useRef, useCallback, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Video, Square, Play, Pause, Upload, Camera, Save, Loader2 } from 'lucide-react';
import { useVideoStorage } from '@/hooks/useVideoStorage';
import { toast } from 'sonner';
import { OptimizedVideoRecorder } from '@/utils/OptimizedVideoRecorder';

const VideoRecorder = () => {
  const [stream, setStream] = useState<MediaStream | null>(null);
  const [recordedVideo, setRecordedVideo] = useState<string | null>(null);
  const [recordedBlob, setRecordedBlob] = useState<Blob | null>(null);
  const [isRecording, setIsRecording] = useState(false);
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [year, setYear] = useState(new Date().getFullYear());
  const [voiceEnergy, setVoiceEnergy] = useState(0);
  const [isSpeaking, setIsSpeaking] = useState(false);
  
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const optimizedRecorderRef = useRef<OptimizedVideoRecorder | null>(null);
  
  const { uploadVideo, isUploading } = useVideoStorage();

  // Refs for stable access in event handlers
  const titleRef = useRef(title);
  const descriptionRef = useRef(description);
  const yearRef = useRef(year);
  const uploadVideoRef = useRef(uploadVideo);
  
  // Update refs when state changes
  useEffect(() => {
    titleRef.current = title;
    descriptionRef.current = description;
    yearRef.current = year;
    uploadVideoRef.current = uploadVideo;
  }, [title, description, year, uploadVideo]);

  // Initialize optimized video recorder
  useEffect(() => {
    const initializeRecorder = async () => {
      try {
        console.log('🔧 INITIALIZING RECORDER: Starting recorder setup...');
        
        const recorder = new OptimizedVideoRecorder({
          video: {
            width: 1280,
            height: 720,
            frameRate: 30,
            facingMode: 'user'
          },
          audio: {
            sampleRate: 24000,
            channelCount: 1,
            echoCancellation: true,
            noiseSuppression: true,
            autoGainControl: true,
            vadThreshold: 0.008,
            vadSilenceDuration: 800
          }
        });

        console.log('✅ RECORDER CREATED: Recorder instance created');

        // Set up voice activity detection
        recorder.setVoiceActivityCallback((speaking, energy) => {
          setIsSpeaking(speaking);
          setVoiceEnergy(energy);
          console.log('Voice activity in VideoRecorder:', { speaking, energy: energy.toFixed(4) });
        });

        // Set up recording completion callback
        recorder.setStopCallback(async (videoBlob) => {
          console.log('🎬 RECORDING COMPLETED:', { 
            size: videoBlob.size, 
            type: videoBlob.type
          });
          
          // CRITICAL: Test the blob to see if it has audio
          const url = URL.createObjectURL(videoBlob);
          const testVideo = document.createElement('video');
          testVideo.src = url;
          
          testVideo.onloadedmetadata = () => {
            console.log('🔍 VIDEO BLOB ANALYSIS:', {
              duration: testVideo.duration,
              videoWidth: testVideo.videoWidth,
              videoHeight: testVideo.videoHeight,
              // Check if audio exists using track data
              audioTracks: (testVideo as any).audioTracks?.length || 'Unknown'
            });
            URL.revokeObjectURL(url);
          };
          
          setRecordedVideo(url);
          setRecordedBlob(videoBlob);
          
          // AUTO-SAVE: Immediately upload the video
          setTimeout(async () => {
            console.log('🔄 Auto-uploading video...');
            const autoTitle = titleRef.current.trim() || `Aufnahme vom ${new Date().toLocaleDateString('de-DE')} - ${new Date().toLocaleTimeString('de-DE')}`;
            
            try {
              const result = await uploadVideoRef.current(videoBlob, {
                title: autoTitle,
                description: descriptionRef.current.trim() || 'Automatisch gespeicherte Aufnahme',
                year: yearRef.current
              });
              
              console.log('✅ Auto-upload successful:', result);
              toast.success('Video automatisch gespeichert!');
              
              // Reset form after successful upload
              setTitle('');
              setDescription('');
              setYear(new Date().getFullYear());
              setRecordedVideo(null);
              setRecordedBlob(null);
              
            } catch (error) {
              console.error('❌ Auto-upload failed:', error);
              toast.error('Auto-Upload fehlgeschlagen. Bitte versuchen Sie es manuell.');
            }
          }, 1000);
        });

        // Set up error callback
        recorder.setErrorCallback((error) => {
          console.error('Video recording error:', error);
          toast.error('Aufnahme-Fehler: ' + error.message);
        });

        optimizedRecorderRef.current = recorder;
        console.log('Optimized video recorder initialized');
      } catch (error) {
        console.error('Failed to initialize optimized video recorder:', error);
        toast.error('Recorder-Initialisierung fehlgeschlagen');
      }
    };

    initializeRecorder();

    return () => {
      if (optimizedRecorderRef.current) {
        optimizedRecorderRef.current.destroy();
      }
    };
  }, []);

  // Optimized camera and recording functions
  const startCamera = useCallback(async () => {
    console.log('🔍 FUNCTIONALITY TEST: Starting camera test...');
    
    if (!optimizedRecorderRef.current) {
      console.error('🔍 TEST FAILURE: Video recorder not initialized');
      toast.error('Video-System nicht bereit. Versuchen Sie es erneut.');
      return;
    }

    try {
      console.log('🎥 Starting optimized camera...');
      console.log('🔍 TEST: Checking hardware access...');
      
      // Test hardware access
      const devices = await navigator.mediaDevices.enumerateDevices();
      const videoDevices = devices.filter(device => device.kind === 'videoinput');
      const audioDevices = devices.filter(device => device.kind === 'audioinput');
      
      console.log('🔍 HARDWARE TEST:', {
        videoDevices: videoDevices.length,
        audioDevices: audioDevices.length,
        devices: devices.map(d => ({ kind: d.kind, label: d.label }))
      });
      
      const videoStream = await optimizedRecorderRef.current.startCamera();
      
      console.log('🔍 STREAM TEST DETAILED:', {
        streamId: videoStream.id,
        videoTracks: videoStream.getVideoTracks().length,
        audioTracks: videoStream.getAudioTracks().length,
        active: videoStream.active,
        videoTrackSettings: videoStream.getVideoTracks().map(track => ({
          enabled: track.enabled,
          readyState: track.readyState,
          settings: track.getSettings()
        }))
      });
      
      // CRITICAL: Set the stream state FIRST
      setStream(videoStream);
      
      // Wait a tick for React to update, then set video element
      setTimeout(() => {
        if (videoRef.current && videoStream) {
          console.log('🔍 VIDEO PREVIEW TEST: Setting up video element', {
            videoElement: !!videoRef.current,
            stream: !!videoStream,
            streamActive: videoStream.active,
            videoTracks: videoStream.getVideoTracks().length
          });
          
          videoRef.current.srcObject = videoStream;
          videoRef.current.muted = true;
          videoRef.current.volume = 0;
          videoRef.current.autoplay = true;
          videoRef.current.playsInline = true;
          
          // Force play and log result
          videoRef.current.play()
            .then(() => {
              console.log('✅ VIDEO PREVIEW: Video element playing successfully');
            })
            .catch(error => {
              console.error('❌ VIDEO PREVIEW FAILURE:', error);
            });
          
          // Add load event listener for debugging
          videoRef.current.onloadedmetadata = () => {
            console.log('✅ VIDEO PREVIEW: Metadata loaded', {
              videoWidth: videoRef.current?.videoWidth,
              videoHeight: videoRef.current?.videoHeight,
              duration: videoRef.current?.duration
            });
          };
          
          videoRef.current.onerror = (error) => {
            console.error('❌ VIDEO ELEMENT ERROR:', error);
          };
        } else {
          console.error('❌ VIDEO PREVIEW FAILURE: Missing video element or stream', {
            videoRef: !!videoRef.current,
            videoStream: !!videoStream
          });
        }
      }, 100);
      
      console.log('✅ Optimized camera started successfully');
    } catch (error) {
      console.error("❌ CAMERA TEST FAILURE:", error);
      console.error("❌ Error details:", {
        name: error.name,
        message: error.message,
        stack: error.stack
      });
      toast.error('Kamera-Zugriff fehlgeschlagen: ' + error.message);
    }
  }, []);

  const stopCamera = useCallback(() => {
    if (optimizedRecorderRef.current) {
      console.log('🛑 Stopping optimized camera...');
      optimizedRecorderRef.current.stopCamera();
      setStream(null);
      setIsSpeaking(false);
      setVoiceEnergy(0);
      
      if (videoRef.current) {
        videoRef.current.srcObject = null;
      }
    }
  }, []);

  const startRecording = useCallback(async () => {
    console.log('🔍 FUNCTIONALITY TEST: Starting recording test...');
    
    if (!optimizedRecorderRef.current) {
      console.error('🔍 RECORDING TEST FAILURE: Recorder not ready');
      toast.error('Aufnahme-System nicht bereit.');
      return;
    }

    if (!stream) {
      console.error('❌ RECORDING TEST FAILURE: No stream available for recording');
      toast.error('Kein Stream verfügbar. Starten Sie zuerst die Kamera.');
      return;
    }
    
    try {
      console.log('🔴 Starting optimized recording...');
      console.log('🔍 RECORDING TEST: Stream state check', {
        streamActive: stream.active,
        videoTracks: stream.getVideoTracks().map(t => ({ enabled: t.enabled, readyState: t.readyState })),
        audioTracks: stream.getAudioTracks().map(t => ({ enabled: t.enabled, readyState: t.readyState }))
      });
      
      await optimizedRecorderRef.current.startRecording();
      setIsRecording(true);
      console.log('✅ RECORDING TEST: Recording started successfully');
    } catch (error) {
      console.error('❌ RECORDING TEST FAILURE:', error);
      console.error('❌ Recording error details:', {
        name: error.name,
        message: error.message,
        stack: error.stack
      });
      toast.error('Aufnahme konnte nicht gestartet werden: ' + error.message);
    }
  }, [stream]);

  const stopRecording = useCallback(() => {
    if (optimizedRecorderRef.current && optimizedRecorderRef.current.isRecording()) {
      console.log('⏹️ Stopping optimized recording...');
      optimizedRecorderRef.current.stopRecording();
      setIsRecording(false);
      setIsSpeaking(false);
      setVoiceEnergy(0);
    } else {
      console.warn('⚠️ Recorder not in recording state or not available');
    }
  }, []);

  const handleSaveVideo = async () => {
    console.log('💾 handleSaveVideo called', { 
      hasBlob: !!recordedBlob, 
      blobSize: recordedBlob?.size,
      title: title.trim(),
      description: description.trim(),
      year
    });

    if (!recordedBlob) {
      console.error('❌ No recorded blob available');
      toast.error('Kein Video zum Speichern verfügbar');
      return;
    }

    if (recordedBlob.size === 0) {
      console.error('❌ Recorded blob is empty');
      toast.error('Video-Aufnahme ist leer');
      return;
    }

    if (!title.trim()) {
      console.error('❌ No title provided');
      toast.error('Bitte geben Sie einen Titel ein');
      return;
    }

    console.log('✅ All validations passed, starting upload...');

    try {
      const result = await uploadVideo(recordedBlob, {
        title: title.trim(),
        description: description.trim() || undefined,
        year: year
      });

      console.log('✅ Upload successful:', result);

      // Reset form after successful upload
      setTitle('');
      setDescription('');
      setYear(new Date().getFullYear());
      setRecordedVideo(null);
      setRecordedBlob(null);
      
    } catch (error) {
      console.error('❌ Save video error:', error);
      toast.error('Upload fehlgeschlagen: ' + error.message);
    }
  };

  const downloadVideo = useCallback(() => {
    if (recordedVideo) {
      const a = document.createElement("a");
      a.href = recordedVideo;
      a.download = `${title || 'zeitzeuge_aufnahme'}.webm`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
    }
  }, [recordedVideo, title]);

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-4xl font-bold gradient-text mb-2">Erlebnis festhalten</h1>
        <p className="text-gray-600 text-lg">Nehmen Sie Ihre Erinnerungen auf und teilen Sie sie</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <Card className="glass-effect border-0 shadow-xl rounded-3xl overflow-hidden">
          <CardHeader className="bg-gradient-to-br from-violet-500/10 via-purple-500/10 to-indigo-500/10">
            <CardTitle className="gradient-text flex items-center gap-3">
              <Camera className="h-6 w-6" />
              Live Aufnahme
            </CardTitle>
          </CardHeader>
          <CardContent className="p-6">
            <div className="aspect-video bg-gradient-to-br from-gray-100 to-gray-200 rounded-2xl mb-6 flex items-center justify-center overflow-hidden shadow-inner">
              {stream ? (
                <video
                  ref={videoRef}
                  autoPlay
                  muted
                  playsInline
                  className="w-full h-full object-cover rounded-2xl"
                  style={{ 
                    pointerEvents: 'none'
                  }}
                />
              ) : (
                <div className="text-center">
                  <Video className="h-16 w-16 text-gray-400 mx-auto mb-4" />
                  <p className="text-gray-500 font-medium">Kamera nicht aktiviert</p>
                </div>
              )}
            </div>

            <div className="space-y-4">
              <div className="flex items-center justify-center gap-4">
                <Badge 
                  variant={stream ? "default" : "secondary"} 
                  className={stream ? "bg-green-500" : "bg-gray-400"}
                >
                  {stream ? "Kamera aktiv" : "Kamera inaktiv"}
                </Badge>
                <Badge 
                  variant={isRecording ? "destructive" : "secondary"}
                  style={{
                    backgroundColor: isRecording && isSpeaking ? '#00ff00' : undefined,
                    transform: isSpeaking ? 'scale(1.05)' : 'scale(1)',
                    transition: 'all 0.2s ease'
                  }}
                >
                  {isRecording 
                    ? (isSpeaking ? "🎤 Sprechen erkannt" : "Aufnahme läuft") 
                    : "Bereit"
                  }
                </Badge>
                
                {/* Voice Energy Indicator */}
                {isRecording && (
                  <Badge variant="outline" className="text-xs">
                    Audio: {(voiceEnergy * 100).toFixed(0)}%
                  </Badge>
                )}
              </div>

              <div className="flex gap-3 justify-center">
                {!stream ? (
                  <Button
                    onClick={startCamera}
                    variant="default"
                    className="bg-gradient-to-r from-violet-500 via-purple-500 to-indigo-500 hover:from-violet-600 hover:via-purple-600 hover:to-indigo-600 rounded-2xl font-semibold"
                  >
                    <Play className="h-4 w-4 mr-2" />
                    Kamera starten
                  </Button>
                ) : (
                  <>
                    <Button
                      onClick={stopCamera}
                      variant="outline"
                      className="rounded-2xl font-semibold"
                    >
                      <Video className="h-4 w-4 mr-2" />
                      Kamera stoppen
                    </Button>

                    <Button
                      onClick={isRecording ? stopRecording : startRecording}
                      variant={isRecording ? "secondary" : "destructive"}
                      className="rounded-2xl font-semibold"
                    >
                      {isRecording ? (
                        <>
                          <Square className="h-4 w-4 mr-2" />
                          Stoppen
                        </>
                      ) : (
                        <div className="flex items-center">
                          <div className="w-4 h-4 mr-2 bg-destructive rounded-full"></div>
                          Aufnehmen
                        </div>
                      )}
                    </Button>
                  </>
                )}
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="glass-effect border-0 shadow-xl rounded-3xl overflow-hidden">
          <CardHeader className="bg-gradient-to-br from-violet-500/10 via-purple-500/10 to-indigo-500/10">
            <CardTitle className="gradient-text flex items-center gap-3">
              <Upload className="h-6 w-6" />
              Vorschau & Upload
            </CardTitle>
          </CardHeader>
          <CardContent className="p-6">
            {recordedVideo ? (
              <div className="space-y-6">
                <div className="aspect-video bg-black rounded-2xl overflow-hidden shadow-lg">
                  <video
                    src={recordedVideo}
                    controls
                    className="w-full h-full object-cover"
                  />
                </div>
                
                {/* Video Details Form */}
                <div className="space-y-4">
                  <div>
                    <Label htmlFor="title" className="text-sm font-medium">
                      Titel *
                    </Label>
                    <Input
                      id="title"
                      value={title}
                      onChange={(e) => setTitle(e.target.value)}
                      placeholder="Titel für Ihr Video eingeben..."
                      className="rounded-xl"
                      required
                    />
                  </div>
                  
                  <div>
                    <Label htmlFor="description" className="text-sm font-medium">
                      Beschreibung
                    </Label>
                    <Textarea
                      id="description"
                      value={description}
                      onChange={(e) => setDescription(e.target.value)}
                      placeholder="Optionale Beschreibung..."
                      className="rounded-xl resize-none"
                      rows={3}
                    />
                  </div>
                  
                  <div>
                    <Label htmlFor="year" className="text-sm font-medium">
                      Jahr
                    </Label>
                    <Input
                      id="year"
                      type="number"
                      value={year}
                      onChange={(e) => setYear(parseInt(e.target.value) || new Date().getFullYear())}
                      min="1900"
                      max={new Date().getFullYear() + 10}
                      className="rounded-xl"
                    />
                  </div>
                </div>
                
                <div className="flex gap-3">
                  <Button 
                    onClick={handleSaveVideo}
                    disabled={isUploading || !title.trim()}
                    className="flex-1 bg-gradient-to-r from-blue-500 to-blue-600 hover:from-blue-600 hover:to-blue-700 rounded-2xl font-semibold"
                  >
                    {isUploading ? (
                      <>
                        <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                        Speichere...
                      </>
                    ) : (
                      <>
                        <Save className="h-4 w-4 mr-2" />
                        Speichern
                      </>
                    )}
                  </Button>
                  <Button 
                    onClick={downloadVideo} 
                    variant="outline"
                    className="rounded-2xl font-semibold"
                    disabled={isUploading}
                  >
                    <Upload className="h-4 w-4 mr-2" />
                    Download
                  </Button>
                  <Button 
                    variant="outline" 
                    onClick={() => {
                      setRecordedVideo(null);
                      setRecordedBlob(null);
                      setTitle('');
                      setDescription('');
                    }}
                    className="border-red-200 text-red-600 hover:bg-red-50 rounded-2xl font-semibold"
                    disabled={isUploading}
                  >
                    Löschen
                  </Button>
                </div>
              </div>
            ) : (
              <div className="aspect-video bg-gradient-to-br from-gray-50 to-gray-100 rounded-2xl flex items-center justify-center border-2 border-dashed border-gray-300">
                <div className="text-center">
                  <Upload className="h-16 w-16 text-gray-400 mx-auto mb-4" />
                  <p className="text-gray-500 font-medium">Keine Aufnahme verfügbar</p>
                  <p className="text-gray-400 text-sm">Starten Sie eine Aufnahme, um eine Vorschau zu sehen</p>
                </div>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default VideoRecorder;
