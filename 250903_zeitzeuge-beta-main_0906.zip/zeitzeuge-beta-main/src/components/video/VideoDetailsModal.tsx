import React from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Calendar, Clock, Edit } from 'lucide-react';
import { VideoData } from '@/hooks/useVideos';

interface VideoDetailsModalProps {
  video: VideoData | null;
  onClose: () => void;
  onEdit?: (video: VideoData) => void;
}

export const VideoDetailsModal: React.FC<VideoDetailsModalProps> = ({
  video,
  onClose,
  onEdit
}) => {
  if (!video) return null;

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'completed':
        return 'bg-green-100 text-green-800 border-green-200';
      case 'processing':
        return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      case 'failed':
        return 'bg-red-100 text-red-800 border-red-200';
      default:
        return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  const formatDuration = (duration?: number) => {
    if (!duration) return null;
    const minutes = Math.floor(duration / 60);
    const seconds = duration % 60;
    return `${minutes}:${seconds.toString().padStart(2, '0')}`;
  };

  return (
    <Dialog open={!!video} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto mx-2 sm:mx-0">
        <DialogHeader>
          <DialogTitle className="text-lg sm:text-xl md:text-2xl font-bold text-foreground mb-2">
            {video.title}
          </DialogTitle>
        </DialogHeader>
        
        <div className="space-y-6">
          {/* Video Player */}
          {video.video_url && (
            <div className="rounded-2xl overflow-hidden shadow-lg bg-muted">
              <video
                src={video.video_url}
                controls
                className="w-full max-h-[60vh] object-contain"
                preload="metadata"
              />
            </div>
          )}

          {/* Video Details */}
          <div className="flex flex-wrap gap-2 sm:gap-3">
            <Badge variant="secondary" className="bg-primary/10 text-primary font-medium text-xs sm:text-sm">
              <Calendar className="h-3 w-3 mr-1" />
              {new Date(video.date).toLocaleDateString('de-DE')}
            </Badge>
            
            {video.duration && (
              <Badge variant="secondary" className="bg-secondary/20 text-secondary-foreground font-medium text-xs sm:text-sm">
                <Clock className="h-3 w-3 mr-1" />
                {formatDuration(video.duration)}
              </Badge>
            )}
            
            {video.category && (
              <Badge variant="secondary" className="bg-accent/20 text-accent-foreground font-medium text-xs sm:text-sm">
                {video.category}
              </Badge>
            )}
            
            <Badge 
              variant="outline" 
              className={`${getStatusColor(video.status)} font-medium text-xs sm:text-sm`}
            >
              {video.status === 'completed' ? 'Fertig' : 
               video.status === 'processing' ? 'Verarbeitung' : 'Fehler'}
            </Badge>
          </div>

          {/* Description */}
          {video.description && (
            <div className="space-y-2">
              <h4 className="font-semibold text-foreground">Beschreibung</h4>
              <p className="text-muted-foreground leading-relaxed">
                {video.description}
              </p>
            </div>
          )}

          {/* Action Buttons */}
          <div className="flex flex-col sm:flex-row gap-2 sm:gap-3 pt-4">
            {onEdit && (
              <Button
                variant="outline"
                onClick={(e) => {
                  e.stopPropagation();
                  onEdit(video);
                }}
                className="flex items-center gap-2 text-sm sm:text-base"
              >
                <Edit className="w-4 h-4" />
                Video bearbeiten
              </Button>
            )}
            <Button
              variant="outline"
              onClick={onClose}
              className="text-sm sm:text-base"
            >
              Schließen
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default VideoDetailsModal;