import React from 'react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { X, RotateCcw, Activity } from 'lucide-react';
import { useVideoStatusSubscription } from '@/hooks/useVideoStatusSubscription';
import { useVideoRecovery } from '@/hooks/useVideoRecovery';

interface VideoStatusPanelProps {
  userId?: string;
  className?: string;
}

export const VideoStatusPanel: React.FC<VideoStatusPanelProps> = ({ userId, className = '' }) => {
  const { 
    statusUpdates, 
    isConnected, 
    clearNotifications, 
    removeNotification, 
    getStatusInfo 
  } = useVideoStatusSubscription(userId);
  
  const { recoveryState, recoverStuckVideos, retryFailedVideo } = useVideoRecovery();

  if (!userId || statusUpdates.length === 0) {
    return null;
  }

  return (
    <Card className={`w-80 ${className}`}>
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <CardTitle className="text-sm font-medium flex items-center gap-2">
            <Activity className="h-4 w-4" />
            Video Status Updates
            <Badge 
              variant={isConnected ? "default" : "secondary"} 
              className="text-xs"
            >
              {isConnected ? 'Live' : 'Offline'}
            </Badge>
          </CardTitle>
          <div className="flex gap-1">
            <Button
              variant="outline"
              size="sm"
              onClick={() => recoverStuckVideos({ manual: true })}
              disabled={recoveryState.isRecovering}
              className="h-7 px-2"
            >
              <RotateCcw className={`h-3 w-3 ${recoveryState.isRecovering ? 'animate-spin' : ''}`} />
            </Button>
            <Button
              variant="ghost"
              size="sm"
              onClick={clearNotifications}
              className="h-7 px-2"
            >
              <X className="h-3 w-3" />
            </Button>
          </div>
        </div>
      </CardHeader>
      <CardContent className="pt-0">
        <div className="space-y-2 max-h-60 overflow-y-auto">
          {statusUpdates.map((update) => {
            const statusInfo = getStatusInfo(update.status);
            
            return (
              <div
                key={update.id}
                className="flex items-center justify-between p-2 bg-muted rounded-lg text-sm"
              >
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-1">
                    <span className="text-xs">{statusInfo.icon}</span>
                    <span className={`font-medium ${statusInfo.color}`}>
                      {statusInfo.label}
                    </span>
                    {update.previous_status && (
                      <span className="text-xs text-muted-foreground">
                        (von {getStatusInfo(update.previous_status).label})
                      </span>
                    )}
                  </div>
                  <p className="text-xs text-muted-foreground truncate">
                    {update.title}
                  </p>
                  <p className="text-xs text-muted-foreground">
                    {new Date(update.updated_at).toLocaleTimeString('de-DE')}
                  </p>
                </div>
                <div className="flex gap-1 ml-2">
                  {update.status === 'failed' && (
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => retryFailedVideo(update.video_id)}
                      className="h-6 px-2 text-xs"
                    >
                      Retry
                    </Button>
                  )}
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => removeNotification(update.id)}
                    className="h-6 px-1"
                  >
                    <X className="h-3 w-3" />
                  </Button>
                </div>
              </div>
            );
          })}
        </div>
        
        {recoveryState.recoveredCount > 0 && (
          <div className="mt-3 p-2 bg-green-50 rounded-lg">
            <p className="text-xs text-green-700">
              ✅ {recoveryState.recoveredCount} Videos erfolgreich wiederhergestellt
            </p>
          </div>
        )}
      </CardContent>
    </Card>
  );
};

export default VideoStatusPanel;