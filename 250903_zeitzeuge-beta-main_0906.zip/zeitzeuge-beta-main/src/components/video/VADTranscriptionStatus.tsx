import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Separator } from '@/components/ui/separator';
import { supabase } from '@/integrations/supabase/client';
import { Mic, Activity, Cpu, CheckCircle, AlertCircle, RotateCcw } from 'lucide-react';

interface VADTranscriptionStatusProps {
  videoId: string;
  onTranscriptionComplete?: () => void;
}

interface ProcessingStatus {
  stage: string;
  progress: number;
  message: string;
  segments?: number;
  confidence?: number;
  processingMethod?: string;
}

export const VADTranscriptionStatus: React.FC<VADTranscriptionStatusProps> = ({
  videoId,
  onTranscriptionComplete
}) => {
  const [status, setStatus] = useState<ProcessingStatus>({
    stage: 'initializing',
    progress: 0,
    message: 'Initialisiere VAD-basierte Transkription...'
  });
  const [isComplete, setIsComplete] = useState(false);
  const [hasError, setHasError] = useState(false);

  useEffect(() => {
    const subscription = supabase
      .channel('transcription_progress')
      .on('postgres_changes', {
        event: '*',
        schema: 'public',
        table: 'processing_logs',
        filter: `video_id=eq.${videoId}`
      }, (payload) => {
        updateStatusFromLog(payload.new);
      })
      .subscribe();

    // Initial status check
    checkTranscriptionStatus();

    return () => {
      subscription.unsubscribe();
    };
  }, [videoId]);

  const checkTranscriptionStatus = async () => {
    try {
      // Check video status instead since processing_logs table might not be accessible
      const { data: video } = await supabase
        .from('videos')
        .select('status')
        .eq('id', videoId)
        .single();

      if (video) {
        // Update status based on video status
        if (video.status === 'transcribed') {
          setStatus({
            stage: 'complete',
            progress: 100,
            message: 'VAD-basierte Transkription erfolgreich abgeschlossen'
          });
          setIsComplete(true);
        }
      }
    } catch (error) {
      console.error('Failed to check transcription status:', error);
    }
  };

  const updateStatusFromLog = (log: any) => {
    if (!log) return;

    const outputData = log.output_data || {};
    
    switch (log.stage) {
      case 'vad_detection':
        setStatus({
          stage: 'vad',
          progress: 25,
          message: 'Erkenne Sprachsegmente mit Voice Activity Detection...',
          segments: outputData.segments
        });
        break;
      
      case 'audio_filtering':
        setStatus({
          stage: 'filtering',
          progress: 40,
          message: 'Wende FFmpeg-Filter an (Highpass 80Hz, Lowpass 8kHz)...'
        });
        break;
      
      case 'chunking':
        setStatus({
          stage: 'chunking',
          progress: 60,
          message: `Erstelle optimale Chunks (${outputData.chunks || 0} Segmente, 12% Overlap)...`,
          segments: outputData.chunks
        });
        break;
      
      case 'transcription':
        setStatus({
          stage: 'transcribing',
          progress: 80,
          message: 'Transkribiere Chunks mit lokaler Whisper-Engine...',
          confidence: outputData.confidence
        });
        break;
      
      case 'completed':
        setStatus({
          stage: 'complete',
          progress: 100,
          message: 'VAD-basierte Transkription erfolgreich abgeschlossen',
          segments: outputData.segmentCount,
          confidence: outputData.confidence,
          processingMethod: 'VAD-based-chunking'
        });
        setIsComplete(true);
        onTranscriptionComplete?.();
        break;
      
      case 'failed':
        setStatus({
          stage: 'error',
          progress: 0,
          message: log.error_message || 'Transkription fehlgeschlagen'
        });
        setHasError(true);
        break;
    }
  };

  const retryTranscription = async () => {
    setHasError(false);
    setIsComplete(false);
    setStatus({
      stage: 'initializing',
      progress: 0,
      message: 'Starte VAD-basierte Transkription erneut...'
    });

    try {
      await supabase.functions.invoke('coordinator-agent', {
        body: {
          videoId,
          action: 'process_video'
        }
      });
    } catch (error) {
      console.error('Failed to retry transcription:', error);
      setHasError(true);
    }
  };

  const getStageIcon = () => {
    switch (status.stage) {
      case 'vad':
        return <Activity className="h-5 w-5 text-blue-500" />;
      case 'filtering':
        return <Cpu className="h-5 w-5 text-purple-500" />;
      case 'chunking':
        return <Cpu className="h-5 w-5 text-orange-500" />;
      case 'transcribing':
        return <Mic className="h-5 w-5 text-green-500" />;
      case 'complete':
        return <CheckCircle className="h-5 w-5 text-green-600" />;
      case 'error':
        return <AlertCircle className="h-5 w-5 text-red-500" />;
      default:
        return <Cpu className="h-5 w-5 text-gray-500" />;
    }
  };

  const getStageColor = () => {
    switch (status.stage) {
      case 'complete':
        return 'bg-green-500';
      case 'error':
        return 'bg-red-500';
      default:
        return 'bg-blue-500';
    }
  };

  return (
    <Card className="w-full max-w-2xl mx-auto">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          {getStageIcon()}
          VAD-basierte Transkription
          {status.processingMethod && (
            <Badge variant="secondary" className="ml-2">
              {status.processingMethod}
            </Badge>
          )}
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Progress Bar */}
        <div className="space-y-2">
          <div className="flex justify-between text-sm">
            <span>{status.message}</span>
            <span>{status.progress}%</span>
          </div>
          <Progress 
            value={status.progress} 
            className="h-2"
          />
        </div>

        <Separator />

        {/* Processing Details */}
        <div className="grid grid-cols-2 gap-4 text-sm">
          <div className="space-y-2">
            <div className="font-semibold text-muted-foreground">Verarbeitung</div>
            <div className="space-y-1">
              <div className="flex justify-between">
                <span>Voice Activity Detection:</span>
                <Badge variant={status.stage === 'vad' || status.progress > 25 ? 'default' : 'outline'}>
                  {status.stage === 'vad' || status.progress > 25 ? 'Aktiv' : 'Wartend'}
                </Badge>
              </div>
              <div className="flex justify-between">
                <span>Audio-Filter (FFmpeg):</span>
                <Badge variant={status.stage === 'filtering' || status.progress > 40 ? 'default' : 'outline'}>
                  {status.stage === 'filtering' || status.progress > 40 ? 'Aktiv' : 'Wartend'}
                </Badge>
              </div>
              <div className="flex justify-between">
                <span>Optimales Chunking:</span>
                <Badge variant={status.stage === 'chunking' || status.progress > 60 ? 'default' : 'outline'}>
                  {status.stage === 'chunking' || status.progress > 60 ? 'Aktiv' : 'Wartend'}
                </Badge>
              </div>
              <div className="flex justify-between">
                <span>Lokale Whisper:</span>
                <Badge variant={status.stage === 'transcribing' || status.progress > 80 ? 'default' : 'outline'}>
                  {status.stage === 'transcribing' || status.progress > 80 ? 'Aktiv' : 'Wartend'}
                </Badge>
              </div>
            </div>
          </div>

          <div className="space-y-2">
            <div className="font-semibold text-muted-foreground">Metriken</div>
            <div className="space-y-1">
              {status.segments && (
                <div className="flex justify-between">
                  <span>Segmente:</span>
                  <span className="font-mono">{status.segments}</span>
                </div>
              )}
              {status.confidence && (
                <div className="flex justify-between">
                  <span>Konfidenz:</span>
                  <span className="font-mono">{(status.confidence * 100).toFixed(1)}%</span>
                </div>
              )}
              <div className="flex justify-between">
                <span>Overlap:</span>
                <span className="font-mono">12%</span>
              </div>
              <div className="flex justify-between">
                <span>Min/Max Segment:</span>
                <span className="font-mono">5s/90s</span>
              </div>
            </div>
          </div>
        </div>

        {/* Technical Details */}
        <div className="mt-4 p-3 rounded-lg bg-muted/50">
          <div className="text-xs text-muted-foreground space-y-1">
            <div><strong>Audio-Filter:</strong> Highpass 80Hz, Lowpass 8kHz, dynaudnorm</div>
            <div><strong>VAD-Parameter:</strong> Min 5s, Max 90s, 12% Overlap</div>
            <div><strong>Whisper-Model:</strong> Large-V3 oder Distilled (lokal)</div>
          </div>
        </div>

        {/* Action Buttons */}
        {hasError && (
          <Button onClick={retryTranscription} className="w-full" variant="outline">
            <RotateCcw className="h-4 w-4 mr-2" />
            Erneut versuchen
          </Button>
        )}

        {isComplete && (
          <div className="text-center text-sm text-green-600 font-medium">
            ✅ VAD-basierte Transkription erfolgreich abgeschlossen
          </div>
        )}
      </CardContent>
    </Card>
  );
};

export default VADTranscriptionStatus;