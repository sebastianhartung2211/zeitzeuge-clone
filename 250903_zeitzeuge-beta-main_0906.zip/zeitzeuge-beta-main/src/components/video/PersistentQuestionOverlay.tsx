import React from 'react';
import { Card } from '@/components/ui/card';

interface PersistentQuestionOverlayProps {
  question: string;
  questionIndex: number;
  totalQuestions: number;
  isVisible: boolean;
}

export const PersistentQuestionOverlay: React.FC<PersistentQuestionOverlayProps> = ({
  question,
  questionIndex,
  totalQuestions,
  isVisible
}) => {
  if (!isVisible) return null;

  return (
    <div className="absolute top-6 left-6 right-6 z-40 pointer-events-none">
      <Card className="bg-black/80 backdrop-blur-sm border-white/20 text-white p-4">
        <div className="flex justify-between items-start mb-2">
          <span className="text-xs font-medium text-white/70">
            Frage {questionIndex + 1} von {totalQuestions}
          </span>
        </div>
        <p className="text-sm leading-relaxed">
          {question}
        </p>
      </Card>
    </div>
  );
};