import React, { useState, useRef, useCallback, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { ArrowLeft, Square, Play, Settings, Calendar, Upload } from 'lucide-react';
import { useNavigate, useLocation } from 'react-router-dom';
import { useStories } from '@/hooks/useStories';
import { useToast } from '@/hooks/use-toast';
import { useVideoStorage } from '@/hooks/useVideoStorage';

import FloatingElements from '../ui/floating-elements';
import { MobileVideoRecorder } from '@/utils/MobileVideoRecorder';
import { PersistentQuestionOverlay } from './PersistentQuestionOverlay';
const VideoRecordingPage = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const {
    addStory
  } = useStories();
  const {
    toast
  } = useToast();
  const {
    uploadVideoOptimistic,
    isUploading
  } = useVideoStorage();
  const [stream, setStream] = useState<MediaStream | null>(null);
  const [isRecording, setIsRecording] = useState(false);
  const [recordedVideo, setRecordedVideo] = useState<string | null>(null);
  const [recordedBlob, setRecordedBlob] = useState<Blob | null>(null);
  const [cameraError, setCameraError] = useState<string | null>(null);
  const [isReadyToRecord, setIsReadyToRecord] = useState(false);
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [recordingYear, setRecordingYear] = useState<string>(new Date().getFullYear().toString());
  const [recordingDate, setRecordingDate] = useState<string>(new Date().toISOString().split('T')[0]);
  const [showYearDateEdit, setShowYearDateEdit] = useState(false);
  const [voiceEnergy, setVoiceEnergy] = useState(0);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const mobileRecorderRef = useRef<MobileVideoRecorder | null>(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  // Get questions from navigation state or use default required questions
  const {
    questions = [],
    hasSelectedQuestions = false,
    questionCategories = []
  } = location.state || {};
  const defaultRequiredQuestions = ['Nehmen Sie sich auf, wie Sie zehn Sekunden lang still sitzen.', 'Sagen Sie: "Ich habe gerade keine Antwort darauf."', 'Sagen Sie Hallo!', 'Sagen Sie Auf Wiedersehen!', 'Reagieren Sie auf eine unhöfliche Frage.'];
  const questionsToShow = questions.length > 0 ? questions : defaultRequiredQuestions;
  const currentQuestion = questionsToShow[currentQuestionIndex] || "Keine Frage verfügbar";

  // Helper function to find question category
  const findQuestionCategory = (question: string) => {
    // Default categories from ConversationStarterPage
    const allCategories = [{
      id: 'required',
      title: 'Erforderlich',
      questions: defaultRequiredQuestions
    }, {
      id: 'childhood',
      title: 'Kind & Familie',
      questions: ['Wie sah ein ganz normaler Tag in deiner Kindheit aus?', 'Welche Spiele hast du als Kind am liebsten gespielt?', 'Gab es ein besonderes Haustier oder Tier, an das du dich erinnerst?', 'Was haben deine Eltern dir beigebracht, das du nie vergessen hast?']
    }, {
      id: 'youth',
      title: 'Jugend & Schule',
      questions: ['Wie war deine Schulzeit – gab es ein Lieblingsfach oder einen Lehrer, der dir besonders in Erinnerung geblieben ist?', 'Was hast du in deiner Freizeit gemacht, als du ein Teenager warst?', 'Erinnerst du dich an deinen ersten Kinofilm oder das erste Konzert, auf dem du warst?']
    }, {
      id: 'love',
      title: 'Liebe & Beziehungen',
      questions: ['Wie hast du deine große Liebe kennengelernt?', 'Was war das romantischste, was du je erlebt hast?', 'Was würdest du jungen Menschen heute über Beziehungen und Ehe mitgeben?']
    }, {
      id: 'work',
      title: 'Arbeit & Alltag',
      questions: ['Was war dein erster Job – und wie hast du dich dabei gefühlt?', 'Gab es eine Arbeit oder Aufgabe, auf die du besonders stolz bist?', 'Wie sah dein Alltag aus, als du berufstätig warst?']
    }, {
      id: 'traditions',
      title: 'Zuhause & Traditionen',
      questions: ['Welche Feste habt ihr in der Familie besonders gefeiert – und wie?', 'Gab es typische Gerichte oder Rezepte, die in deiner Familie weitergegeben wurden?', 'Wie sah dein Kinderzimmer oder dein erstes eigenes Zuhause aus?']
    }, {
      id: 'history',
      title: 'Zeitgeschichte & Wandel',
      questions: ['Was war ein Ereignis in der Welt, das dich besonders bewegt oder beeinflusst hat?', 'Welche Veränderungen in der Welt hast du erlebt, die dich besonders erstaunt haben?', 'Was vermisst du von früher – und was findest du heute besser als damals?']
    }];
    for (const category of allCategories) {
      if (category.questions.includes(question)) {
        return category;
      }
    }
    return {
      id: 'required',
      title: 'Erforderlich',
      questions: []
    };
  };
  const showQuestionSelectionHint = !hasSelectedQuestions;

  // Initialize mobile-optimized video recorder on component mount
  useEffect(() => {
    const initializeRecorder = async () => {
      try {
        console.log('🎯 Initializing Mobile Video Recorder for optimized recording...');
        const recorder = new MobileVideoRecorder({
          enablePerformanceMonitoring: true,
          enableAutoFallback: true,
          enableZoomReset: true,
          preferredCodec: 'auto',
          bitrateKbps: 2500
        });

        // Set up recording completion callback
        recorder.setStopCallback(async videoBlob => {
          console.log('Video recording completed, size:', videoBlob.size);
          const url = URL.createObjectURL(videoBlob);
          setRecordedVideo(url);
          setRecordedBlob(videoBlob);

          // Log performance report
          recorder.logPerformanceReport();
        });

        // Set up error callback
        recorder.setErrorCallback(error => {
          console.error('Mobile video recording error:', error);
          setCameraError(error.message);
          toast({
            title: "Aufnahme-Fehler",
            description: error.message,
            variant: "destructive"
          });
        });
        mobileRecorderRef.current = recorder;
        console.log('✅ Mobile Video Recorder initialized successfully');
      } catch (error) {
        console.error('Failed to initialize mobile video recorder:', error);
        setCameraError('Mobile-Recorder-Initialisierung fehlgeschlagen');
      }
    };
    initializeRecorder();

    // Cleanup on unmount
    return () => {
      if (mobileRecorderRef.current) {
        mobileRecorderRef.current.destroy();
      }
    };
  }, []);

  // Mobile-optimized camera and recording functions
  const startCamera = useCallback(async () => {
    console.log('🔍 MOBILE HARDWARE TEST: Starting mobile-optimized camera...');
    if (!mobileRecorderRef.current) {
      console.error('🔍 MOBILE TEST FAILURE: No mobile recorder instance');
      toast({
        title: "System-Fehler",
        description: "Mobile-Video-System nicht bereit.",
        variant: "destructive"
      });
      setCameraError("Mobile-Video-System nicht bereit");
      return;
    }
    try {
      setCameraError(null);
      console.log('🔍 HARDWARE TEST: Starting device-optimized camera...');
      const videoStream = await mobileRecorderRef.current.initializeCamera();
      console.log('🔍 MOBILE STREAM TEST:', {
        streamId: videoStream.id,
        active: videoStream.active,
        videoTracks: videoStream.getVideoTracks().length,
        audioTracks: videoStream.getAudioTracks().length,
        videoTrackDetails: videoStream.getVideoTracks().map(track => ({
          id: track.id,
          kind: track.kind,
          enabled: track.enabled,
          readyState: track.readyState,
          settings: track.getSettings()
        }))
      });

      // Set stream state and verify it's set
      setStream(videoStream);
      setIsReadyToRecord(true);
      console.log('🔍 STATE UPDATE: Stream state updated, waiting for React render...');

      // Setup video element
      if (videoRef.current) {
        mobileRecorderRef.current.attachToVideoElement(videoRef.current);
        console.log('✅ VIDEO ELEMENT ATTACHED to mobile recorder');
      }
      console.log('✅ MOBILE HARDWARE TEST: Device-optimized camera started successfully');
    } catch (error) {
      console.error('❌ MOBILE TEST FAILURE:', error);
      console.error('❌ Mobile error details:', {
        name: error.name,
        message: error.message,
        stack: error.stack
      });
      setCameraError(`Mobile-Kamera-Fehler: ${error.message}`);
      setIsReadyToRecord(false);
      toast({
        title: "Kamera-Fehler",
        description: `Kamera konnte nicht aktiviert werden: ${error.message}`,
        variant: "destructive"
      });
    }
  }, []);
  const stopCamera = useCallback(() => {
    if (mobileRecorderRef.current) {
      console.log('🛑 Stopping mobile camera...');
      mobileRecorderRef.current.stopCamera();
      setStream(null);
      setIsReadyToRecord(false);
      setIsSpeaking(false);
      setVoiceEnergy(0);
      if (videoRef.current) {
        videoRef.current.srcObject = null;
      }
    }
  }, []);
  const startRecording = useCallback(async () => {
    if (!mobileRecorderRef.current) {
      toast({
        title: "System-Fehler",
        description: "Aufnahme-System nicht bereit.",
        variant: "destructive"
      });
      return;
    }

    // Check if mobile and request fullscreen
    const isMobile = window.innerWidth < 768;
    if (isMobile) {
      try {
        // Request fullscreen on the video container
        const videoContainer = document.querySelector('.video-fullscreen-container');
        if (videoContainer && videoContainer.requestFullscreen) {
          await videoContainer.requestFullscreen();
          setIsFullscreen(true);
        }
      } catch (error) {
        console.warn('Fullscreen request failed:', error);
      }
    }

    // Start camera first if not already started
    if (!stream) {
      await startCamera();
      // Wait a bit for camera to initialize before starting recording
      setTimeout(() => {
        if (mobileRecorderRef.current) {
          mobileRecorderRef.current.startRecording();
          setIsRecording(true);
        }
      }, 1000);
      return;
    }
    try {
      console.log('🔴 Starting mobile video recording...');
      await mobileRecorderRef.current.startRecording();
      setIsRecording(true);
      console.log('✅ Mobile recording started successfully');
    } catch (error) {
      console.error('Error starting mobile recording:', error);
      toast({
        title: "Aufnahme-Fehler",
        description: "Aufnahme konnte nicht gestartet werden.",
        variant: "destructive"
      });
    }
  }, [stream, startCamera]);
  const stopRecording = useCallback(() => {
    if (mobileRecorderRef.current && mobileRecorderRef.current.isCurrentlyRecording()) {
      console.log('⏸️ Pausing mobile recording...');
      // Pause instead of stop
      mobileRecorderRef.current.pauseRecording();

      // Create a preview blob from current chunks
      const previewBlob = mobileRecorderRef.current.getCurrentBlob();
      const url = URL.createObjectURL(previewBlob);
      setRecordedVideo(url);
      setRecordedBlob(previewBlob);

      setIsRecording(false);
      setIsFullscreen(false);
      setIsSpeaking(false);
      setVoiceEnergy(0);

      // Exit fullscreen if active
      if (document.fullscreenElement) {
        document.exitFullscreen().catch(console.warn);
      }
      // Important: Do NOT stop the camera here so we can resume recording
    }
  }, []);

  // Handle file upload
  const handleUploadClick = useCallback(() => {
    fileInputRef.current?.click();
  }, []);

  const handleFileUpload = useCallback(async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    // Validate file type
    if (!file.type.includes('mp4')) {
      toast({
        title: "Ungültiges Dateiformat",
        description: "Bitte wählen Sie eine MP4-Datei aus.",
        variant: "destructive"
      });
      return;
    }

    // Validate file size (max 100MB)
    const maxSize = 100 * 1024 * 1024; // 100MB
    if (file.size > maxSize) {
      toast({
        title: "Datei zu groß",
        description: "Maximale Dateigröße: 100MB",
        variant: "destructive"
      });
      return;
    }

    console.log('📤 File upload initiated:', {
      name: file.name,
      size: file.size,
      type: file.type,
      question: currentQuestion
    });

    try {
      // Convert File to Blob for compatibility with existing upload logic
      const videoBlob = new Blob([file], { type: file.type });
      
      // Create preview URL
      const url = URL.createObjectURL(videoBlob);
      setRecordedVideo(url);
      setRecordedBlob(videoBlob);

      // Show success message
      toast({
        title: "Video hochgeladen",
        description: "Video wurde erfolgreich geladen. Sie können es jetzt speichern.",
        variant: "default"
      });

      console.log('✅ File upload successful, ready for processing');
    } catch (error) {
      console.error('❌ File upload error:', error);
      toast({
        title: "Upload-Fehler",
        description: "Video konnte nicht geladen werden.",
        variant: "destructive"
      });
    }

    // Reset input
    event.target.value = '';
  }, [currentQuestion, toast]);
  return <div className="min-h-screen bg-background text-foreground">
      {/* Floating Elements */}
      <FloatingElements />
      
      
      {/* Header */}
      <div className="flex items-center justify-between p-6 pt-24 bg-card/50 backdrop-blur-sm border-b border-border">
        <h1 className="text-xl font-semibold mx-auto">Deine Erinnerung AUFNEHMEN</h1>
      </div>

      {/* Question Section */}
      <div className="text-center py-8 px-6">
        <div className="bg-card/50 backdrop-blur-sm rounded-2xl p-6 max-w-4xl mx-auto border border-border">
          {/* Question counter at top */}
          <div className="flex justify-center mb-4">
            <div className="bg-primary text-primary-foreground px-4 py-2 rounded-full text-sm font-medium">
              {currentQuestionIndex + 1} von {questionsToShow.length}
            </div>
          </div>
          
          {/* Question text in middle */}
          <div className="text-base sm:text-lg md:text-xl font-medium leading-relaxed text-center max-w-2xl mx-auto px-4 mb-4">
            {currentQuestion}
          </div>
          
          {/* Skip and Upload buttons centered */}
          <div className="flex justify-center gap-3">
            <Button variant="outline" size="sm" className="bg-yellow-500/20 border-yellow-500 text-yellow-700 dark:text-yellow-300 hover:bg-yellow-500/30 min-h-[36px] px-4 text-sm touch-manipulation font-medium" onClick={() => {
            if (currentQuestionIndex < questionsToShow.length - 1) {
              setCurrentQuestionIndex(currentQuestionIndex + 1);
            }
          }} disabled={currentQuestionIndex >= questionsToShow.length - 1}>
              SKIP
            </Button>
            <Button variant="outline" size="sm" className="bg-blue-500/20 border-blue-500 text-blue-700 dark:text-blue-300 hover:bg-blue-500/30 min-h-[36px] px-4 text-sm touch-manipulation font-medium" onClick={handleUploadClick}>
              <Upload className="h-4 w-4 mr-1" />
              UPLOAD
            </Button>
            <input
              ref={fileInputRef}
              type="file"
              accept="video/mp4"
              onChange={handleFileUpload}
              className="hidden"
            />
          </div>
          {showQuestionSelectionHint && <div className="mt-4 p-3 bg-yellow-100 dark:bg-yellow-900/20 rounded-lg border border-yellow-200 dark:border-yellow-800">
              <p className="text-sm text-yellow-800 dark:text-yellow-200">
                Du siehst nur die erforderlichen Fragen.
                <Button variant="link" className="text-yellow-800 dark:text-yellow-200 underline p-0 h-auto ml-1" onClick={() => navigate('/conversation-starter')}>
                  Weitere Fragen auswählen
                </Button>
              </p>
            </div>}
        </div>
      </div>


      {/* Video Recording Section */}
      <div className={`flex-1 flex items-center justify-center ${isRecording && isFullscreen ? 'fixed inset-0 z-50 bg-black' : 'px-4 sm:px-6'}`}>
        <div className={`relative w-full ${isRecording && isFullscreen ? 'w-screen h-screen max-w-none' : 'max-w-2xl'}`}>
          {/* Video Container with mobile fullscreen support */}
          <div className={`video-fullscreen-container relative bg-muted overflow-hidden shadow-2xl border border-border ${isRecording && isFullscreen ? 'fixed inset-0 z-50 w-screen h-screen aspect-auto rounded-none' : 'rounded-3xl h-[70vh] sm:h-auto sm:aspect-video'}`}>
            <div className="w-full h-full relative">
              {/* Debug Info Overlay */}
              <div className="absolute top-2 right-2 bg-black/70 text-white text-xs p-2 rounded z-10">
                Stream: {stream ? '✅' : '❌'} | Error: {cameraError ? '❌' : '✅'}
              </div>
              
              {stream && !cameraError ? <>
                  {/* Primary Video Element */}
                  <video ref={videoRef} autoPlay muted={true} playsInline className="w-full h-full object-cover scale-x-[-1] bg-black" style={{
                display: 'block',
                visibility: 'visible',
                opacity: 1,
                zIndex: 1
              }} onLoadedData={() => console.log('✅ VIDEO LOADED DATA EVENT')} onPlay={() => console.log('✅ VIDEO PLAY EVENT')} onPlaying={() => console.log('✅ VIDEO PLAYING EVENT')} onError={e => console.error('❌ VIDEO ERROR EVENT:', e)} />
                  
                  {/* Fallback Test Video - Hidden by default */}
                  <video autoPlay muted playsInline className="absolute inset-0 w-full h-full object-cover scale-x-[-1] bg-red-500" style={{
                display: 'none',
                zIndex: 0
              }} ref={fallbackVideoRef => {
                if (fallbackVideoRef && stream && !videoRef.current?.srcObject) {
                  console.log('🔄 FALLBACK: Setting stream to fallback video element');
                  fallbackVideoRef.srcObject = stream;
                  fallbackVideoRef.style.display = 'block';
                  fallbackVideoRef.play().catch(console.error);
                }
              }} />
                  
                  {/* Face Positioning Guide */}
                  <div className="absolute inset-0 flex items-center justify-center pointer-events-none z-20">
                    <div className="relative">
                      {/* Outer circle guide */}
                      <div className="w-64 h-80 border-2 border-accent/60 rounded-full"></div>
                      {/* Inner guide lines */}
                      <div className="absolute top-1/3 left-1/2 transform -translate-x-1/2 w-px h-16 bg-muted-foreground/50"></div>
                      <div className="absolute top-2/3 left-1/2 transform -translate-x-1/2 w-px h-8 bg-muted-foreground/50"></div>
                      <div className="absolute top-1/2 left-1/3 transform -translate-y-1/2 w-8 h-px bg-muted-foreground/50"></div>
                      <div className="absolute top-1/2 right-1/3 transform -translate-y-1/2 w-8 h-px bg-muted-foreground/50"></div>
                    </div>
                  </div>

                   {/* Persistent Question Overlay - Only visible when recording AND in fullscreen */}
                   <PersistentQuestionOverlay
                     question={currentQuestion}
                     questionIndex={currentQuestionIndex}
                     totalQuestions={questionsToShow.length}
                     isVisible={isRecording && isFullscreen}
                   />

                   {/* Recording indicator */}
                   {isRecording && <>
                       <div className="absolute top-4 left-4 flex items-center gap-2 z-30">
                         <div className="w-3 h-3 bg-destructive rounded-full animate-pulse"></div>
                         <span className="text-foreground text-sm font-medium">REC</span>
                       </div>
                      
                    </>}
                </> : <div className="w-full h-full flex items-center justify-center min-h-[14vh] sm:min-h-0 bg-slate-50">
                  <div className="text-center p-1">
                    <button onClick={startCamera} className="w-14 h-14 md:w-11 md:h-11 bg-primary rounded-full flex items-center justify-center mx-auto mb-2 hover:bg-primary/90 transition-colors cursor-pointer touch-manipulation">
                      <Play className="h-7 w-7 md:h-5 md:w-5 text-primary-foreground" />
                    </button>
                    <p className="text-muted-foreground text-sm md:text-xs">
                      {cameraError || "Klicke auf Play um zu starten"}
                    </p>
                  </div>
                </div>}
            </div>
          </div>

          {/* Control Buttons - Mobile optimized */}
          <div className="flex items-center justify-center mt-6 md:mt-8 gap-4 md:gap-6">
            {/* Record Button - Larger touch target for mobile */}
            <Button onClick={isRecording ? stopRecording : startRecording} disabled={cameraError !== null} className={`w-16 h-16 md:w-20 md:h-20 rounded-full border-4 transition-all duration-300 touch-manipulation ${isRecording ? 'bg-destructive hover:bg-destructive/90 border-destructive/60 shadow-lg shadow-destructive/25' : 'bg-primary hover:bg-primary/90 border-primary/60 shadow-lg shadow-primary/25'}`} aria-label={isRecording ? "Aufnahme stoppen" : "Aufnahme starten"}>
              {isRecording ? <Square className="h-6 w-6 md:h-8 md:w-8 text-primary-foreground" /> : <div className="w-4 h-4 md:w-6 md:h-6 bg-primary-foreground rounded-full"></div>}
            </Button>
          </div>

          {/* Additional Instructions - Mobile responsive text */}
          <div className="text-center mt-4 md:mt-6 px-4">
            <p className="text-muted-foreground text-sm md:text-base leading-relaxed">
              {isRecording ? "Aufnahme läuft - klicke Stop um zu beenden" : "Positioniere dein Gesicht im Kreis und klicke auf Aufnahme"}
            </p>
          </div>
        </div>
      </div>


      {/* Preview Modal for recorded video */}
      {recordedVideo && <div className="fixed inset-0 bg-background/80 backdrop-blur-sm z-50 flex flex-col">
          <div className="flex-1 overflow-y-auto p-4">
            <div className="bg-card rounded-3xl p-4 sm:p-6 max-w-2xl mx-auto border border-border min-h-full flex flex-col">
              <h3 className="text-xl font-semibold mb-4 text-center text-foreground">Aufnahme Vorschau</h3>
              <video src={recordedVideo} controls className="w-full rounded-2xl mb-6" />
              
              {/* Year/Date editing section */}
              <div className="mb-6 p-4 bg-muted/50 rounded-xl border border-border">
                <div className="flex items-center justify-between mb-3">
                  <h4 className="font-medium text-foreground flex items-center gap-2">
                    <Calendar className="h-4 w-4" />
                    Datum & Jahr
                  </h4>
                  <Button variant="outline" size="sm" onClick={() => setShowYearDateEdit(!showYearDateEdit)} className="text-xs">
                    {showYearDateEdit ? 'Fertig' : 'Bearbeiten'}
                  </Button>
                </div>
                
                {showYearDateEdit ? <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="recording-year" className="text-sm text-muted-foreground">
                        Jahr
                      </Label>
                      <Input id="recording-year" type="number" value={recordingYear} onChange={e => setRecordingYear(e.target.value)} min="1950" max="2030" className="text-sm" />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="recording-date" className="text-sm text-muted-foreground">
                        Datum
                      </Label>
                      <Input id="recording-date" type="date" value={recordingDate} onChange={e => setRecordingDate(e.target.value)} className="text-sm" />
                    </div>
                  </div> : <div className="text-sm text-muted-foreground">
                    Jahr: <span className="font-medium text-foreground">{recordingYear}</span> • 
                    Datum: <span className="font-medium text-foreground">{new Date(recordingDate).toLocaleDateString('de-DE')}</span>
                  </div>}
              </div>
              
              <div className="flex flex-col sm:flex-row gap-3 sm:gap-4 justify-center mt-auto">
                <Button
                  variant="secondary"
                  onClick={async () => {
                    // Resume recording from paused state
                    try {
                      const isMobile = window.innerWidth < 768;
                      if (isMobile) {
                        try {
                          const videoContainer = document.querySelector('.video-fullscreen-container') as any;
                          if (videoContainer && videoContainer.requestFullscreen) {
                            await videoContainer.requestFullscreen();
                            setIsFullscreen(true);
                          }
                        } catch (err) {
                          console.warn('Fullscreen request failed on resume:', err);
                        }
                      }
                      mobileRecorderRef.current?.resumeRecording();
                      setIsRecording(true);
                      // Close preview
                      setRecordedVideo(null);
                      setShowYearDateEdit(false);
                    } catch (e) {
                      console.error('Failed to resume recording:', e);
                    }
                  }}
                  className="w-full sm:w-auto min-h-[44px] touch-manipulation"
                >
                  Video Fortsetzen
                </Button>

                <Button variant="outline" onClick={() => {
              // Fully stop current recording session and discard preview
              try { mobileRecorderRef.current?.stopRecording(); } catch {}
              setRecordedVideo(null);
              setShowYearDateEdit(false);
              // Reset to current year/date when rerecording
              setRecordingYear(new Date().getFullYear().toString());
              setRecordingDate(new Date().toISOString().split('T')[0]);
            }} className="border-border text-foreground hover:bg-accent w-full sm:w-auto min-h-[44px] touch-manipulation">
                  <span className="text-sm md:text-base">Erneut aufnehmen</span>
                </Button>
                <Button className="bg-primary hover:bg-primary/90 text-primary-foreground w-full sm:w-auto min-h-[44px] touch-manipulation" disabled={isUploading} onClick={async () => {
              console.log('💾 Speichern & Weiter clicked', {
                hasBlob: !!recordedBlob,
                blobSize: recordedBlob?.size,
                currentQuestion,
                recordingYear: parseInt(recordingYear),
                recordingDate
              });

              // Upload to Supabase first
              if (recordedBlob) {
                try {
                  console.log('🚀 Starting upload to Supabase...');
                  const questionCategory = findQuestionCategory(currentQuestion);
                  const result = await uploadVideoOptimistic(recordedBlob, {
                    title: currentQuestion.substring(0, 100),
                    description: `Antwort auf: ${currentQuestion}`,
                    year: parseInt(recordingYear) || new Date().getFullYear(),
                    customDate: recordingDate,
                    questionContext: {
                      question: currentQuestion,
                      category: questionCategory.title,
                      categoryId: questionCategory.id
                    }
                  });
                  console.log('✅ Upload successful:', result);
                  // Don't show success toast here - uploadVideoOptimistic already shows it
                  console.log('Optimistic upload initiated');
                } catch (error) {
                  console.error('❌ Optimistic upload failed:', error);
                  // Error already handled by uploadVideoOptimistic
                  return; // Don't proceed if upload failed
                }
              }

              // Save to local timeline (only if not required question)
              const finalYear = parseInt(recordingYear) || new Date().getFullYear();
              const finalDate = recordingDate || new Date().toISOString().split('T')[0];
              const isRequiredQuestion = defaultRequiredQuestions.includes(currentQuestion);
              if (!isRequiredQuestion) {
                addStory({
                  type: 'video',
                  title: currentQuestion.substring(0, 50) + (currentQuestion.length > 50 ? '...' : ''),
                  date: finalDate,
                  year: finalYear,
                  location: 'Aufgenommen zu Hause',
                  description: `Antwort auf: ${currentQuestion}`,
                  videoUrl: recordedVideo,
                  previewImage: 'https://images.unsplash.com/photo-1516589178581-6cd7833ae3b2?w=400&h=300&fit=crop',
                  isUserGenerated: true,
                  questions: [currentQuestion]
                });
              }

              // Reset recording state
              setRecordedVideo(null);
              setRecordedBlob(null);
              setShowYearDateEdit(false);
              // Reset to current year/date for next recording
              setRecordingYear(new Date().getFullYear().toString());
              setRecordingDate(new Date().toISOString().split('T')[0]);

              // Check if there are more questions to answer
              if (currentQuestionIndex < questionsToShow.length - 1) {
                // Move to next question
                setCurrentQuestionIndex(currentQuestionIndex + 1);
                // Restart camera for next recording
                startCamera();
              } else {
                // All questions answered, navigate back to timeline
                navigate('/');
              }
            }}>
                  {isUploading ? 'Speichere...' : 'Speichern & Weiter'}
                </Button>
              </div>
            </div>
          </div>
        </div>}
    </div>;
};
export default VideoRecordingPage;