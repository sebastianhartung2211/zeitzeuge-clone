import React from 'react';
import { Heart, Star, Circle, Triangle, Sparkles, Sun, Moon } from 'lucide-react';

const FloatingElements = () => {
  return (
    <div className="fixed inset-0 pointer-events-none overflow-hidden z-0">
      {/* Coral colored elements */}
      <div className="absolute top-20 left-10 w-16 h-16 bg-[hsl(var(--coral))]/20 rounded-full animate-pulse"></div>
      <div className="absolute top-40 right-20 w-8 h-8 bg-[hsl(var(--coral))]/30 rounded-full animate-bounce" style={{ animationDelay: '0.5s' }}></div>
      <Heart className="absolute top-60 left-1/4 w-6 h-6 text-[hsl(var(--coral))]/40 animate-pulse" style={{ animationDelay: '1s' }} />
      <div className="absolute bottom-40 right-10 w-12 h-12 bg-[hsl(var(--coral))]/25 rounded-full animate-pulse" style={{ animationDelay: '2s' }}></div>
      
      {/* Light yellow elements */}
      <div className="absolute top-32 right-1/3 w-10 h-10 bg-[hsl(var(--yellow))]/30 rounded-full animate-bounce" style={{ animationDelay: '0.8s' }}></div>
      <Star className="absolute top-80 left-16 w-5 h-5 text-[hsl(var(--yellow))]/50 animate-pulse" style={{ animationDelay: '1.5s' }} />
      <div className="absolute bottom-60 left-1/3 w-14 h-14 bg-[hsl(var(--yellow))]/20 rounded-full animate-pulse" style={{ animationDelay: '0.3s' }}></div>
      <Sun className="absolute bottom-20 right-1/4 w-6 h-6 text-[hsl(var(--yellow))]/40 animate-pulse" style={{ animationDelay: '2.5s' }} />
      
      {/* Light blue elements */}
      <div className="absolute top-72 right-12 w-9 h-9 bg-[hsl(var(--light-blue))]/25 rounded-full animate-bounce" style={{ animationDelay: '1.2s' }}></div>
      <Circle className="absolute top-96 left-1/2 w-4 h-4 text-[hsl(var(--light-blue))]/45 animate-pulse" style={{ animationDelay: '0.7s' }} />
      <div className="absolute bottom-80 left-8 w-11 h-11 bg-[hsl(var(--light-blue))]/30 rounded-full animate-pulse" style={{ animationDelay: '1.8s' }}></div>
      <Triangle className="absolute bottom-32 right-16 w-5 h-5 text-[hsl(var(--light-blue))]/40 animate-pulse" style={{ animationDelay: '0.1s' }} />
      
      {/* Additional scattered elements */}
      <Sparkles className="absolute top-44 left-1/2 w-4 h-4 text-[hsl(var(--coral))]/35 animate-pulse" style={{ animationDelay: '2.2s' }} />
      <div className="absolute top-88 right-1/4 w-6 h-6 bg-[hsl(var(--yellow))]/25 rounded-full animate-bounce" style={{ animationDelay: '1.7s' }}></div>
      <Moon className="absolute bottom-48 left-1/4 w-5 h-5 text-[hsl(var(--light-blue))]/50 animate-pulse" style={{ animationDelay: '0.9s' }} />
      <div className="absolute top-16 right-40 w-7 h-7 bg-[hsl(var(--coral))]/20 rounded-full animate-pulse" style={{ animationDelay: '3s' }}></div>
    </div>
  );
};

export default FloatingElements;