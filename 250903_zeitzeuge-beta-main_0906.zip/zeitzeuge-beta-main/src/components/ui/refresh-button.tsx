import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { RotateCcw } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

interface RefreshButtonProps {
  onRefresh: () => Promise<void> | void;
  disabled?: boolean;
  size?: 'sm' | 'default' | 'lg';
  variant?: 'default' | 'outline' | 'secondary' | 'ghost';
  children?: React.ReactNode;
}

export function RefreshButton({ 
  onRefresh, 
  disabled = false, 
  size = 'default',
  variant = 'outline',
  children = 'Aktualisieren'
}: RefreshButtonProps) {
  const [isRefreshing, setIsRefreshing] = useState(false);
  const { toast } = useToast();

  const handleRefresh = async () => {
    if (isRefreshing || disabled) return;
    
    setIsRefreshing(true);
    try {
      await onRefresh();
      toast({
        title: "Erfolgreich aktualisiert",
        description: "Die Daten wurden neu geladen.",
      });
    } catch (error) {
      console.error('Refresh failed:', error);
      toast({
        title: "Fehler beim Aktualisieren",
        description: "Die Daten konnten nicht neu geladen werden.",
        variant: "destructive",
      });
    } finally {
      setIsRefreshing(false);
    }
  };

  return (
    <Button
      onClick={handleRefresh}
      disabled={disabled || isRefreshing}
      size={size}
      variant={variant}
      className="gap-2"
    >
      <RotateCcw 
        className={`h-4 w-4 ${isRefreshing ? 'animate-spin' : ''}`} 
      />
      {children}
    </Button>
  );
}