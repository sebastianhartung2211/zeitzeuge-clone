import React from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Loader2, AlertCircle, RotateCcw } from 'lucide-react';
import { Button } from '@/components/ui/button';

interface ProcessingPlaceholderProps {
  question: string;
  status: 'processing' | 'failed' | 'completed';
  onRetry?: () => void;
  className?: string;
}

const ProcessingPlaceholder: React.FC<ProcessingPlaceholderProps> = ({
  question,
  status,
  onRetry,
  className = ''
}) => {
  const getStatusDisplay = () => {
    switch (status) {
      case 'processing':
        return {
          icon: <Loader2 className="h-4 w-4 animate-spin" />,
          label: 'Wird gespeichert...',
          bgColor: 'bg-blue-50 border-blue-200',
          textColor: 'text-blue-800',
          badgeColor: 'bg-blue-500'
        };
      case 'failed':
        return {
          icon: <AlertCircle className="h-4 w-4" />,
          label: 'Fehler beim Speichern',
          bgColor: 'bg-red-50 border-red-200',
          textColor: 'text-red-800',
          badgeColor: 'bg-red-500'
        };
      case 'completed':
        return {
          icon: null,
          label: 'Fertig',
          bgColor: 'bg-green-50 border-green-200',
          textColor: 'text-green-800',
          badgeColor: 'bg-green-500'
        };
    }
  };

  const statusInfo = getStatusDisplay();

  return (
    <Card className={`${statusInfo.bgColor} ${className} interactive-layer`}>
      <CardContent className="p-6">
        <div className="space-y-4">
          {/* Question Title */}
          <div className="flex items-start justify-between gap-3">
            <h3 className={`font-semibold text-sm leading-tight ${statusInfo.textColor}`}>
              {question}
            </h3>
            <Badge 
              variant="secondary" 
              className={`${statusInfo.badgeColor} text-white text-xs flex-shrink-0 flex items-center gap-1`}
            >
              {statusInfo.icon}
              {statusInfo.label}
            </Badge>
          </div>

          {/* Processing Info */}
          {status === 'processing' && (
            <div className="space-y-2">
              <div className="h-20 bg-gray-200 rounded-lg animate-pulse flex items-center justify-center">
                <div className="text-gray-500 text-sm">Video wird verarbeitet...</div>
              </div>
              <p className="text-xs text-blue-600">
                Antwort wird im Hintergrund gespeichert und automatisch aktualisiert
              </p>
            </div>
          )}

          {/* Error State */}
          {status === 'failed' && (
            <div className="space-y-3">
              <div className="h-20 bg-red-100 rounded-lg flex items-center justify-center">
                <div className="text-red-600 text-sm text-center">
                  <AlertCircle className="h-6 w-6 mx-auto mb-1" />
                  Upload fehlgeschlagen
                </div>
              </div>
              <div className="flex gap-2">
                {onRetry && (
                  <Button 
                    size="sm" 
                    variant="outline" 
                    onClick={onRetry}
                    className="text-red-700 border-red-300 hover:bg-red-50"
                  >
                    <RotateCcw className="h-3 w-3 mr-1" />
                    Erneut versuchen
                  </Button>
                )}
              </div>
            </div>
          )}

          {/* Completed State */}
          {status === 'completed' && (
            <div className="h-20 bg-green-100 rounded-lg flex items-center justify-center">
              <div className="text-green-600 text-sm">
                ✓ Erfolgreich gespeichert
              </div>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
};

export default ProcessingPlaceholder;