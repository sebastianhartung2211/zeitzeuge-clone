import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Loader2, User, Mail, Lock, LogIn, Heart, Users, Shield, ExternalLink } from 'lucide-react';
import { useAuth } from '../../hooks/useAuth';
import { toast } from 'sonner';
const LoginPage = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [referralInfo, setReferralInfo] = useState<any>(null);
  const [defaultTab, setDefaultTab] = useState('login');
  const {
    login,
    signUp,
    loading
  } = useAuth();

  useEffect(() => {
    // Check for referral information from landing page
    const referral = sessionStorage.getItem('zeitzeuge_referral');
    if (referral) {
      try {
        const info = JSON.parse(referral);
        setReferralInfo(info);
        
        // Set default tab based on action parameter
        if (info.action === 'signup') {
          setDefaultTab('signup');
        }
        
        // Show welcome message
        setTimeout(() => {
          toast.success('Willkommen bei Zeitzeuge! 🎉', {
            description: 'Schön, dass du von unserer Website zu uns gefunden hast.'
          });
        }, 500);
        
        // Clear referral info after showing
        sessionStorage.removeItem('zeitzeuge_referral');
      } catch (error) {
        console.error('Error parsing referral info:', error);
      }
    }
  }, []);
  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email || !password) {
      toast.error('Bitte fülle alle Felder aus');
      return;
    }
    setIsSubmitting(true);
    try {
      const success = await login(email, password);
      if (success) {
        toast.success('Erfolgreich angemeldet!');
      }
    } catch (error) {
      console.error('Login error:', error);
    } finally {
      setIsSubmitting(false);
    }
  };
  const handleSignUp = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email || !password) {
      toast.error('Bitte fülle alle Felder aus');
      return;
    }
    if (password.length < 6) {
      toast.error('Das Passwort muss mindestens 6 Zeichen lang sein');
      return;
    }
    setIsSubmitting(true);
    try {
      const success = await signUp(email, password, name);
      if (success) {
        toast.success('Account erfolgreich erstellt!');
        setEmail('');
        setPassword('');
        setName('');
      }
    } catch (error) {
      console.error('Sign up error:', error);
    } finally {
      setIsSubmitting(false);
    }
  };
  return <div className="min-h-screen flex items-center justify-center p-4">
      <div className="w-full max-w-6xl grid lg:grid-cols-2 gap-8 items-center">
        
        {/* Left Side - Welcome Section */}
        <div className="text-center lg:text-left space-y-8">
          <div className="flex items-center justify-center lg:justify-start gap-3 mb-8">
            <div className="w-12 h-12 bg-gradient-to-br from-purple-500 to-pink-500 rounded-2xl flex items-center justify-center">
              <Heart className="h-6 w-6 text-white" />
            </div>
            <h1 className="text-3xl font-bold bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent">Zeitzeuge</h1>
          </div>
          
          <div className="space-y-4">
            <h2 className="text-2xl lg:text-3xl font-bold text-gray-800">
              Verbinde dich mit deinen Liebsten durch geteilte Erinnerungen, Videos und bedeutungsvolle Gespräche.
            </h2>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-12">
            <div className="text-center space-y-3">
              <div className="w-16 h-16 bg-purple-100 rounded-2xl flex items-center justify-center mx-auto">
                <Users className="h-8 w-8 text-purple-600" />
              </div>
              <h3 className="font-semibold text-gray-800">Gemeinsame Erinnerungen</h3>
            </div>
            <div className="text-center space-y-3">
              <div className="w-16 h-16 bg-purple-100 rounded-2xl flex items-center justify-center mx-auto">
                <Heart className="h-8 w-8 text-purple-600" />
              </div>
              <h3 className="font-semibold text-gray-800">Video-Gespräche</h3>
            </div>
            <div className="text-center space-y-3">
              <div className="w-16 h-16 bg-purple-100 rounded-2xl flex items-center justify-center mx-auto">
                <Shield className="h-8 w-8 text-purple-600" />
              </div>
              <h3 className="font-semibold text-gray-800">DSGVO-konform</h3>
            </div>
          </div>
        </div>

        {/* Right Side - Login/Register Forms */}
        <div className="w-full max-w-md mx-auto">
          <Card className="shadow-2xl border-0 rounded-3xl overflow-hidden">
            <CardHeader className="bg-gradient-to-br from-purple-50 to-pink-50 text-center py-8">
              <CardTitle className="text-2xl font-bold text-gray-800">
                Anmelden
              </CardTitle>
              <p className="text-gray-600 mt-2">Melde dich an, um fortzufahren</p>
            </CardHeader>
            
            <CardContent className="p-8">
              {/* Welcome message for landing page users */}
              {referralInfo && (
                <Alert className="mb-6 border-green-200 bg-green-50">
                  <ExternalLink className="h-4 w-4 text-green-600" />
                  <AlertDescription className="text-green-700">
                    <strong>Willkommen von unserer Website!</strong> Du bist nur noch einen Schritt davon entfernt, 
                    deine ersten Erinnerungen mit Zeitzeuge zu erstellen.
                  </AlertDescription>
                </Alert>
              )}
              
              <Tabs defaultValue={defaultTab} className="w-full">
                <TabsList className="grid w-full grid-cols-2 mb-6 bg-purple-50 border border-purple-200 rounded-xl p-1 h-12">
                  <TabsTrigger value="login" className="rounded-lg font-semibold text-sm data-[state=active]:bg-purple-500 data-[state=active]:text-white data-[state=inactive]:text-gray-600 data-[state=inactive]:hover:bg-purple-100 transition-all duration-200">
                    👤 Anmelden
                  </TabsTrigger>
                  <TabsTrigger value="signup" className="rounded-lg font-semibold text-sm data-[state=active]:bg-green-500 data-[state=active]:text-white data-[state=inactive]:text-gray-600 data-[state=inactive]:hover:bg-purple-100 transition-all duration-200">
                    ✨ Registrieren
                  </TabsTrigger>
                </TabsList>
                
                <TabsContent value="login">
                  <form onSubmit={handleLogin} className="space-y-6">
                    <div className="space-y-2">
                      <Label htmlFor="login-email" className="text-gray-700">E-Mail</Label>
                      <div className="relative">
                        <Mail className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                        <Input id="login-email" placeholder="test@beispiel.de" type="email" value={email} onChange={e => setEmail(e.target.value)} className="pl-10 rounded-xl border-gray-200 focus:border-purple-400 focus:ring-purple-400" required />
                      </div>
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="login-password" className="text-gray-700">Passwort</Label>
                      <div className="relative">
                        <Lock className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                        <Input id="login-password" placeholder="••••••" type="password" value={password} onChange={e => setPassword(e.target.value)} className="pl-10 rounded-xl border-gray-200 focus:border-purple-400 focus:ring-purple-400" required />
                      </div>
                    </div>
                    
                    <Button type="submit" disabled={isSubmitting} className="w-full bg-gradient-to-r from-purple-500 to-purple-600 hover:from-purple-600 hover:to-purple-700 text-white font-semibold py-3 rounded-xl transition-all duration-200 transform hover:scale-105">
                      {isSubmitting ? <>
                          <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                          Anmelden...
                        </> : <>
                          <LogIn className="mr-2 h-4 w-4" />
                          Anmelden
                        </>}
                    </Button>
                  </form>
                </TabsContent>
                
                <TabsContent value="signup">
                  <form onSubmit={handleSignUp} className="space-y-6">
                    <div className="space-y-2">
                      <Label htmlFor="signup-name" className="text-gray-700">Name (optional)</Label>
                      <div className="relative">
                        <User className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                        <Input id="signup-name" placeholder="Dein Name" type="text" value={name} onChange={e => setName(e.target.value)} className="pl-10 rounded-xl border-gray-200 focus:border-green-400 focus:ring-green-400" />
                      </div>
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="signup-email" className="text-gray-700">E-Mail</Label>
                      <div className="relative">
                        <Mail className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                        <Input id="signup-email" placeholder="test@beispiel.de" type="email" value={email} onChange={e => setEmail(e.target.value)} className="pl-10 rounded-xl border-gray-200 focus:border-green-400 focus:ring-green-400" required />
                      </div>
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="signup-password" className="text-gray-700">Passwort</Label>
                      <div className="relative">
                        <Lock className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                        <Input id="signup-password" placeholder="Mindestens 6 Zeichen" type="password" value={password} onChange={e => setPassword(e.target.value)} className="pl-10 rounded-xl border-gray-200 focus:border-green-400 focus:ring-green-400" required minLength={6} />
                      </div>
                    </div>
                    
                    <Button type="submit" disabled={isSubmitting} className="w-full bg-gradient-to-r from-green-500 to-green-600 hover:from-green-600 hover:to-green-700 text-white font-semibold py-3 rounded-xl transition-all duration-200 transform hover:scale-105">
                      {isSubmitting ? <>
                          <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                          Registrieren...
                        </> : <>
                          <User className="mr-2 h-4 w-4" />
                          Registrieren
                        </>}
                    </Button>
                  </form>
                </TabsContent>
              </Tabs>
              
              <div className="text-center mt-6 text-sm text-gray-500">
                <p className="mb-2">💡 <strong>Neu hier?</strong> Klicke auf "✨ Registrieren"</p>
                <div className="bg-blue-50 border border-blue-200 px-3 py-2 rounded-lg mt-2">
                  <p><strong>Demo:</strong> Verwende eine beliebige E-Mail und ein Passwort</p>
                  <p className="text-green-600 font-semibold">✅ Account wird sofort erstellt!</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>;
};
export default LoginPage;