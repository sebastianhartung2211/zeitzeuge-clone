import { Button } from '@/components/ui/button';
import { startLogin } from '@/features/auth/startLogin';
import { useState } from 'react';

export const MobileAuthButton = () => {
  const [loading, setLoading] = useState(false);

  const handleLogin = async () => {
    try {
      setLoading(true);
      await startLogin();
    } catch (error) {
      console.error('Login error:', error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <Button 
      onClick={handleLogin} 
      disabled={loading}
      className="bg-[hsl(var(--coral))] text-white hover:bg-[hsl(var(--coral))]/90"
    >
      {loading ? 'Anmelden...' : 'Mit Google anmelden'}
    </Button>
  );
};