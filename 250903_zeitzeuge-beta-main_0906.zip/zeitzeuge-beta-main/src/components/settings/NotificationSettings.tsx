import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { PushNotificationSetup } from '@/components/push/PushNotificationSetup';
import { Separator } from '@/components/ui/separator';

export const NotificationSettings = () => {
  return (
    <div className="space-y-6">
      <div>
        <h3 className="text-lg font-medium">Benachrichtigungseinstellungen</h3>
        <p className="text-sm text-muted-foreground">
          Verwalten Sie Ihre Push-Benachrichtigungen und andere Einstellungen
        </p>
      </div>
      
      <Separator />
      
      <PushNotificationSetup />
      
      <Card>
        <CardHeader>
          <CardTitle>Weitere Einstellungen</CardTitle>
          <CardDescription>
            Zusätzliche Benachrichtigungsoptionen werden hier angezeigt
          </CardDescription>
        </CardHeader>
        <CardContent>
          <p className="text-sm text-muted-foreground">
            Weitere Benachrichtigungstypen können hier konfiguriert werden
          </p>
        </CardContent>
      </Card>
    </div>
  );
};