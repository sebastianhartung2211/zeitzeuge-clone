
import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { 
  Upload, 
  FileText, 
  Video, 
  Search, 
  Download, 
  Trash2,
  Eye,
  Filter
} from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

const FileManager = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [filterType, setFilterType] = useState('all');
  const { toast } = useToast();

  const [files] = useState([
    {
      id: 1,
      name: 'Familienurlaub_2024.mp4',
      type: 'video',
      size: '125 MB',
      uploadDate: '15.01.2024',
      thumbnail: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=200&h=150&fit=crop'
    },
    {
      id: 2,
      name: 'Omas_Rezept.pdf',
      type: 'document',
      size: '2.3 MB',
      uploadDate: '12.01.2024',
      thumbnail: null
    },
    {
      id: 3,
      name: 'Kindergeburtstag.jpg',
      type: 'image',
      size: '3.1 MB',
      uploadDate: '10.01.2024',
      thumbnail: 'https://images.unsplash.com/photo-1530103862676-de8c9debad1d?w=200&h=150&fit=crop'
    },
    {
      id: 4,
      name: 'Weihnachten_2023.mp4',
      type: 'video',
      size: '89 MB',
      uploadDate: '25.12.2023',
      thumbnail: 'https://images.unsplash.com/photo-1512389142860-9c449e58a543?w=200&h=150&fit=crop'
    },
    {
      id: 5,
      name: 'Familienchronik.docx',
      type: 'document',
      size: '1.8 MB',
      uploadDate: '20.12.2023',
      thumbnail: null
    }
  ]);

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const files = event.target.files;
    if (files && files.length > 0) {
      toast({
        title: "Dateien hochgeladen",
        description: `${files.length} Datei(en) erfolgreich hochgeladen.`,
      });
    }
  };

  const getFileIcon = (type: string) => {
    switch (type) {
      case 'video':
        return <Video className="h-5 w-5 text-red-500" />;
      case 'image':
        return <Upload className="h-5 w-5 text-green-500" />;
      case 'document':
        return <FileText className="h-5 w-5 text-blue-500" />;
      default:
        return <FileText className="h-5 w-5 text-gray-500" />;
    }
  };

  const getFileTypeBadge = (type: string) => {
    const colors = {
      video: 'bg-red-100 text-red-700',
      image: 'bg-green-100 text-green-700',
      document: 'bg-blue-100 text-blue-700'
    };
    return colors[type as keyof typeof colors] || 'bg-gray-100 text-gray-700';
  };

  const filteredFiles = files.filter(file => {
    const matchesSearch = file.name.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesFilter = filterType === 'all' || file.type === filterType;
    return matchesSearch && matchesFilter;
  });

  const handleDelete = (fileId: number, fileName: string) => {
    toast({
      title: "Datei gelöscht",
      description: `"${fileName}" wurde erfolgreich gelöscht.`,
    });
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold text-gray-900">Dateiverwaltung</h1>
        <p className="text-gray-600 mt-1">Verwalten Sie Ihre Fotos, Videos und Dokumente</p>
      </div>

      {/* Upload Area */}
      <Card>
        <CardContent className="p-6">
          <div className="border-2 border-dashed border-gray-300 rounded-lg p-8 text-center hover:border-purple-400 transition-colors">
            <Upload className="h-12 w-12 text-gray-400 mx-auto mb-4" />
            <h3 className="text-lg font-medium text-gray-900 mb-2">Dateien hochladen</h3>
            <p className="text-gray-600 mb-4">Ziehen Sie Dateien hierher oder klicken Sie zum Auswählen</p>
            <input
              type="file"
              multiple
              onChange={handleFileUpload}
              className="hidden"
              id="file-upload"
              accept="image/*,video/*,.pdf,.doc,.docx"
            />
            <label htmlFor="file-upload">
              <Button className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700">
                Dateien auswählen
              </Button>
            </label>
          </div>
        </CardContent>
      </Card>

      {/* Search and Filter */}
      <Card>
        <CardContent className="p-4">
          <div className="flex flex-col sm:flex-row gap-4">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
              <Input
                placeholder="Dateien suchen..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
            <div className="flex gap-2">
              <Button
                variant={filterType === 'all' ? 'default' : 'outline'}
                size="sm"
                onClick={() => setFilterType('all')}
              >
                Alle
              </Button>
              <Button
                variant={filterType === 'video' ? 'default' : 'outline'}
                size="sm"
                onClick={() => setFilterType('video')}
              >
                Videos
              </Button>
              <Button
                variant={filterType === 'image' ? 'default' : 'outline'}
                size="sm"
                onClick={() => setFilterType('image')}
              >
                Bilder
              </Button>
              <Button
                variant={filterType === 'document' ? 'default' : 'outline'}
                size="sm"
                onClick={() => setFilterType('document')}
              >
                Dokumente
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Files Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredFiles.map((file) => (
          <Card key={file.id} className="overflow-hidden hover:shadow-lg transition-shadow">
            <div className="aspect-video bg-gray-100 relative">
              {file.thumbnail ? (
                <img 
                  src={file.thumbnail} 
                  alt={file.name}
                  className="w-full h-full object-cover"
                />
              ) : (
                <div className="w-full h-full flex items-center justify-center bg-gray-50">
                  {getFileIcon(file.type)}
                </div>
              )}
              <div className="absolute top-2 right-2">
                <Badge className={getFileTypeBadge(file.type)}>
                  {file.type}
                </Badge>
              </div>
            </div>
            
            <CardContent className="p-4">
              <h3 className="font-medium text-gray-900 truncate mb-1">{file.name}</h3>
              <div className="flex items-center justify-between text-sm text-gray-500 mb-3">
                <span>{file.size}</span>
                <span>{file.uploadDate}</span>
              </div>
              
              <div className="flex gap-2">
                <Button variant="outline" size="sm" className="flex-1">
                  <Eye className="h-4 w-4 mr-1" />
                  Ansehen
                </Button>
                <Button variant="outline" size="sm">
                  <Download className="h-4 w-4" />
                </Button>
                <Button 
                  variant="outline" 
                  size="sm"
                  onClick={() => handleDelete(file.id, file.name)}
                  className="text-red-600 hover:text-red-700"
                >
                  <Trash2 className="h-4 w-4" />
                </Button>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {filteredFiles.length === 0 && (
        <Card>
          <CardContent className="p-8 text-center">
            <FileText className="h-12 w-12 text-gray-400 mx-auto mb-4" />
            <h3 className="text-lg font-medium text-gray-900 mb-2">Keine Dateien gefunden</h3>
            <p className="text-gray-600">
              {searchTerm || filterType !== 'all' 
                ? 'Versuchen Sie andere Suchbegriffe oder Filter.'
                : 'Laden Sie Ihre ersten Dateien hoch, um zu beginnen.'
              }
            </p>
          </CardContent>
        </Card>
      )}
    </div>
  );
};

export default FileManager;
