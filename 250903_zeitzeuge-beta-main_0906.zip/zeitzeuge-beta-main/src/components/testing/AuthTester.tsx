import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { useAuth } from '@/hooks/useAuth';
import { supabase } from '@/integrations/supabase/client';
import { Badge } from '@/components/ui/badge';

export function AuthTester() {
  const { user } = useAuth();
  const [testResults, setTestResults] = useState<string[]>([]);

  const addResult = (result: string) => {
    setTestResults(prev => [...prev, `${new Date().toLocaleTimeString()}: ${result}`]);
  };

  const testLogin = async () => {
    try {
      const { error } = await supabase.auth.signInWithOAuth({
        provider: 'google',
        options: {
          redirectTo: 'zeitzeuge://auth-callback'
        }
      });
      
      if (error) {
        addResult(`❌ Login Error: ${error.message}`);
      } else {
        addResult('✅ Login initiated - check for deep link redirect');
      }
    } catch (err) {
      addResult(`❌ Login Exception: ${err}`);
    }
  };

  const testLogout = async () => {
    try {
      const { error } = await supabase.auth.signOut();
      if (error) {
        addResult(`❌ Logout Error: ${error.message}`);
      } else {
        addResult('✅ Logout successful');
      }
    } catch (err) {
      addResult(`❌ Logout Exception: ${err}`);
    }
  };

  const clearResults = () => setTestResults([]);

  return (
    <Card className="w-full max-w-2xl mx-auto">
      <CardHeader>
        <CardTitle>🔐 Authentication Test Console</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="flex items-center gap-2">
          <span>Status:</span>
          {user ? (
            <Badge variant="default">✅ Authenticated</Badge>
          ) : (
            <Badge variant="secondary">❌ Not Authenticated</Badge>
          )}
        </div>

        {user && (
          <div className="text-sm text-muted-foreground">
            <p>User ID: {user.id}</p>
            <p>Email: {user.email}</p>
          </div>
        )}

        <div className="flex gap-2">
          <Button onClick={testLogin} disabled={!!user}>
            Test Login
          </Button>
          <Button onClick={testLogout} disabled={!user} variant="outline">
            Test Logout
          </Button>
          <Button onClick={clearResults} variant="ghost" size="sm">
            Clear Log
          </Button>
        </div>

        <div className="space-y-1 max-h-40 overflow-y-auto bg-muted p-3 rounded text-sm">
          <p className="font-medium">Test Results:</p>
          {testResults.length === 0 ? (
            <p className="text-muted-foreground">No tests run yet...</p>
          ) : (
            testResults.map((result, i) => (
              <p key={i} className="font-mono text-xs">{result}</p>
            ))
          )}
        </div>

        <div className="text-xs text-muted-foreground space-y-1">
          <p><strong>Test Steps:</strong></p>
          <p>1. Click "Test Login" → Should redirect to OAuth</p>
          <p>2. Complete login → Deep link should return to app</p>
          <p>3. Verify session is set and user data displayed</p>
          <p>4. Test logout → Should clear session</p>
        </div>
      </CardContent>
    </Card>
  );
}