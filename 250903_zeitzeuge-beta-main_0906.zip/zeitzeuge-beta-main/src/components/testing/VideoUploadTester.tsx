import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { media } from '@/platform';
import { enqueueUpload } from '@/features/upload/enqueueUpload';
import { useAuth } from '@/hooks/useAuth';
import { Capacitor } from '@capacitor/core';

export function VideoUploadTester() {
  const { user } = useAuth();
  const [testResults, setTestResults] = useState<string[]>([]);
  const [isUploading, setIsUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);

  const addResult = (result: string) => {
    setTestResults(prev => [...prev, `${new Date().toLocaleTimeString()}: ${result}`]);
  };

  const testVideoFlow = async () => {
    if (!user) {
      addResult('❌ Please authenticate first');
      return;
    }

    try {
      setIsUploading(true);
      setUploadProgress(0);
      
      addResult('📱 Starting video picker...');
      const file = await media.pickVideo();
      setUploadProgress(25);
      addResult(`✅ Video selected: ${file.size} bytes`);
      
      addResult('💾 Saving locally...');
      const localPath = await media.saveLocal(file as Blob, `test-video-${Date.now()}.mp4`);
      setUploadProgress(50);
      addResult(`✅ Saved locally: ${localPath}`);
      
      addResult('🚀 Starting background upload...');
      const objectKey = `${user.id}/test-uploads/${Date.now()}-test.mp4`;
      const result = await enqueueUpload(localPath, 'videos', objectKey);
      setUploadProgress(100);
      
      addResult(`✅ Upload ${result.method}: ${result.success ? 'SUCCESS' : 'FAILED'}`);
      
      if (result.method === 'native') {
        addResult('📱 MINIMIZE APP NOW - Upload should continue in background');
      }
      
    } catch (error) {
      addResult(`❌ Video Flow Error: ${error}`);
    } finally {
      setIsUploading(false);
    }
  };

  const clearResults = () => {
    setTestResults([]);
    setUploadProgress(0);
  };

  return (
    <Card className="w-full max-w-2xl mx-auto">
      <CardHeader>
        <CardTitle>📹 Video Upload Test Console</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="flex items-center gap-2">
          <span>Platform:</span>
          <Badge variant={Capacitor.isNativePlatform() ? "default" : "secondary"}>
            {Capacitor.isNativePlatform() ? `📱 ${Capacitor.getPlatform()}` : '🌐 Web'}
          </Badge>
        </div>

        <div className="flex items-center gap-2">
          <span>Auth Status:</span>
          {user ? (
            <Badge variant="default">✅ Ready</Badge>
          ) : (
            <Badge variant="destructive">❌ Login Required</Badge>
          )}
        </div>

        {isUploading && (
          <div className="space-y-2">
            <div className="flex justify-between text-sm">
              <span>Upload Progress</span>
              <span>{uploadProgress}%</span>
            </div>
            <Progress value={uploadProgress} />
          </div>
        )}

        <div className="flex gap-2">
          <Button 
            onClick={testVideoFlow} 
            disabled={!user || isUploading}
          >
            {isUploading ? '📱 Testing...' : '🎬 Test Video Flow'}
          </Button>
          <Button onClick={clearResults} variant="ghost" size="sm">
            Clear Log
          </Button>
        </div>

        <div className="space-y-1 max-h-40 overflow-y-auto bg-muted p-3 rounded text-sm">
          <p className="font-medium">Test Results:</p>
          {testResults.length === 0 ? (
            <p className="text-muted-foreground">No tests run yet...</p>
          ) : (
            testResults.map((result, i) => (
              <p key={i} className="font-mono text-xs">{result}</p>
            ))
          )}
        </div>

        <div className="text-xs text-muted-foreground space-y-1">
          <p><strong>Test Steps:</strong></p>
          <p>1. Select video from gallery/camera</p>
          <p>2. Verify local save (cap:// path on mobile)</p>
          <p>3. Check upload method (native vs direct)</p>
          <p>4. If native: minimize app → upload continues</p>
          <p>5. Check Supabase Storage for uploaded file</p>
        </div>
      </CardContent>
    </Card>
  );
}