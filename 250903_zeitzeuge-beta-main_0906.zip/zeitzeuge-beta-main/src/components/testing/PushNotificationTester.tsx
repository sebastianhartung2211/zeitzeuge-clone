import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { usePushNotifications } from '@/hooks/usePushNotifications';
import { useAuth } from '@/hooks/useAuth';
import { supabase } from '@/integrations/supabase/client';
import { PushNotifications } from '@capacitor/push-notifications';
import { Capacitor } from '@capacitor/core';

export function PushNotificationTester() {
  const { user } = useAuth();
  const { isRegistered, isRegistering, registerForPush } = usePushNotifications();
  const [testResults, setTestResults] = useState<string[]>([]);
  const [pushToken, setPushToken] = useState<string | null>(null);
  const [isSupported, setIsSupported] = useState(false);

  useEffect(() => {
    // Check if push notifications are supported
    setIsSupported(Capacitor.isNativePlatform());
  }, []);

  const addResult = (result: string) => {
    setTestResults(prev => [...prev, `${new Date().toLocaleTimeString()}: ${result}`]);
  };

  const testPushRegistration = async () => {
    if (!user) {
      addResult('❌ Please authenticate first');
      return;
    }

    try {
      addResult('🔔 Requesting push permission...');
      
      if (Capacitor.isNativePlatform()) {
        // Request permissions first
        const permission = await PushNotifications.requestPermissions();
        if (permission.receive !== 'granted') {
          addResult('❌ Push permission denied');
          return;
        }
        
        addResult('✅ Push permission granted');
        
        // Register for push notifications
        await PushNotifications.register();
        addResult('✅ Push registration initiated');
        
        // The token will be received via addListener
        addResult('⏳ Waiting for push token...');
        
      } else {
        addResult('❌ Push notifications only work on native platforms');
      }
    } catch (error) {
      addResult(`❌ Push Registration Error: ${error}`);
    }
  };

  const testHookRegistration = async () => {
    try {
      addResult('🔔 Using hook registration...');
      await registerForPush();
      addResult(`✅ Hook registration ${isRegistered ? 'completed' : 'initiated'}`);
    } catch (error) {
      addResult(`❌ Hook Registration Error: ${error}`);
    }
  };

  const checkStoredTokens = async () => {
    if (!user) {
      addResult('❌ Please authenticate first');
      return;
    }

    try {
      const { data, error } = await supabase
        .from('push_tokens')
        .select('*')
        .eq('user_id', user.id);

      if (error) {
        addResult(`❌ Database Error: ${error.message}`);
      } else {
        addResult(`✅ Found ${data.length} stored push tokens`);
        data.forEach((token, i) => {
          addResult(`  Token ${i + 1}: ${token.token.substring(0, 20)}... (${token.platform})`);
        });
      }
    } catch (error) {
      addResult(`❌ Check Tokens Error: ${error}`);
    }
  };

  const clearResults = () => {
    setTestResults([]);
    setPushToken(null);
  };

  return (
    <Card className="w-full max-w-2xl mx-auto">
      <CardHeader>
        <CardTitle>🔔 Push Notification Test Console</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="flex items-center gap-2">
          <span>Support:</span>
          <Badge variant={isSupported ? "default" : "destructive"}>
            {isSupported ? '✅ Supported' : '❌ Not Supported (Web)'}
          </Badge>
        </div>

        <div className="flex items-center gap-2">
          <span>Registration:</span>
          <Badge variant={isRegistered ? "default" : "secondary"}>
            {isRegistered ? '✅ Registered' : '❌ Not Registered'}
          </Badge>
        </div>

        <div className="flex items-center gap-2">
          <span>Auth Status:</span>
          {user ? (
            <Badge variant="default">✅ Ready</Badge>
          ) : (
            <Badge variant="destructive">❌ Login Required</Badge>
          )}
        </div>

        {pushToken && (
          <div className="text-sm text-muted-foreground">
            <p>Current Token: {pushToken.substring(0, 40)}...</p>
          </div>
        )}

        <div className="flex gap-2 flex-wrap">
          <Button 
            onClick={testPushRegistration} 
            disabled={!user || !isSupported}
          >
            🔔 Manual Register
          </Button>
          <Button 
            onClick={testHookRegistration} 
            disabled={!user || !isSupported || isRegistering}
          >
            {isRegistering ? '⏳ Registering...' : '🪝 Hook Register'}
          </Button>
          <Button 
            onClick={checkStoredTokens} 
            disabled={!user}
            variant="outline"
          >
            📊 Check DB Tokens
          </Button>
          <Button onClick={clearResults} variant="ghost" size="sm">
            Clear Log
          </Button>
        </div>

        <div className="space-y-1 max-h-40 overflow-y-auto bg-muted p-3 rounded text-sm">
          <p className="font-medium">Test Results:</p>
          {testResults.length === 0 ? (
            <p className="text-muted-foreground">No tests run yet...</p>
          ) : (
            testResults.map((result, i) => (
              <p key={i} className="font-mono text-xs">{result}</p>
            ))
          )}
        </div>

        <div className="text-xs text-muted-foreground space-y-1">
          <p><strong>Test Steps:</strong></p>
          <p>1. Click "Manual Register" → Grant permission</p>
          <p>2. Or click "Hook Register" → Use existing hook</p>
          <p>3. Check "Check DB Tokens" → Verify token stored</p>
          <p>4. Use Supabase console to send test push</p>
          <p>5. Verify notification received on device</p>
        </div>

        <div className="text-xs text-yellow-600 bg-yellow-50 p-2 rounded">
          <p><strong>Note:</strong> Push notifications only work on native platforms (iOS/Android). Web push requires additional setup.</p>
        </div>
      </CardContent>
    </Card>
  );
}