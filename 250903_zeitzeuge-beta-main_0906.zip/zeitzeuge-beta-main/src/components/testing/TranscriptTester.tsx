import React, { useState } from 'react';
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { 
  Play, 
  TestTube, 
  CheckCircle, 
  XCircle, 
  AlertCircle,
  RefreshCw,
  Mic,
  FileText,
  Database
} from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/components/ui/use-toast";

interface TestResult {
  name: string;
  passed: boolean | null;
  message: string;
  details?: any;
  error?: string;
}

interface TranscriptTestResults {
  success: boolean;
  tests: TestResult[];
  summary: {
    total: number;
    passed: number;
    failed: number;
  };
}

export const TranscriptTester: React.FC = () => {
  const [isRecording, setIsRecording] = useState(false);
  const [isTesting, setIsTesting] = useState(false);
  const [testResults, setTestResults] = useState<TranscriptTestResults | null>(null);
  const [recordedAudio, setRecordedAudio] = useState<string | null>(null);
  const [mediaRecorder, setMediaRecorder] = useState<MediaRecorder | null>(null);
  
  const { user } = useAuth();
  const { toast } = useToast();

  const startRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ 
        audio: {
          sampleRate: 24000,
          channelCount: 1,
          echoCancellation: true,
          noiseSuppression: true
        }
      });
      
      const recorder = new MediaRecorder(stream, {
        mimeType: 'audio/webm;codecs=opus'
      });
      
      const chunks: Blob[] = [];
      
      recorder.ondataavailable = (event) => {
        if (event.data.size > 0) {
          chunks.push(event.data);
        }
      };
      
      recorder.onstop = async () => {
        const audioBlob = new Blob(chunks, { type: 'audio/webm' });
        
        // Convert to base64
        const reader = new FileReader();
        reader.onloadend = () => {
          const base64 = (reader.result as string).split(',')[1];
          setRecordedAudio(base64);
        };
        reader.readAsDataURL(audioBlob);
        
        stream.getTracks().forEach(track => track.stop());
      };
      
      setMediaRecorder(recorder);
      recorder.start();
      setIsRecording(true);
      
      toast({
        title: "Aufnahme gestartet",
        description: "Sprechen Sie etwas für den Transcript-Test...",
      });
      
    } catch (error) {
      console.error('Error starting recording:', error);
      toast({
        title: "Aufnahme-Fehler",
        description: "Mikrofon konnte nicht aktiviert werden.",
        variant: "destructive",
      });
    }
  };

  const stopRecording = () => {
    if (mediaRecorder && isRecording) {
      mediaRecorder.stop();
      setIsRecording(false);
      
      toast({
        title: "Aufnahme beendet",
        description: "Audio wurde für den Test vorbereitet.",
      });
    }
  };

  const runTranscriptTests = async (testType: string = 'test_transcription') => {
    if (!user) {
      toast({
        title: "Anmeldung erforderlich",
        description: "Bitte melden Sie sich an, um Tests durchzuführen.",
        variant: "destructive",
      });
      return;
    }

    setIsTesting(true);
    setTestResults(null);

    try {
      const { data, error } = await supabase.functions.invoke('transcript-agent-tester', {
        body: {
          action: testType,
          userId: user.id,
          audioBlob: recordedAudio,
          language: 'de'
        }
      });

      if (error) {
        throw error;
      }

      setTestResults(data);
      
      const passRate = data.summary.total > 0 
        ? Math.round((data.summary.passed / data.summary.total) * 100)
        : 0;
      
      toast({
        title: "Tests abgeschlossen",
        description: `${data.summary.passed}/${data.summary.total} Tests bestanden (${passRate}%)`,
        variant: data.success ? "default" : "destructive",
      });

    } catch (error) {
      console.error('Test error:', error);
      toast({
        title: "Test-Fehler",
        description: `Tests konnten nicht durchgeführt werden: ${error.message}`,
        variant: "destructive",
      });
    } finally {
      setIsTesting(false);
    }
  };

  const getTestIcon = (test: TestResult) => {
    if (test.passed === null) return <AlertCircle className="h-4 w-4 text-gray-400" />;
    return test.passed 
      ? <CheckCircle className="h-4 w-4 text-green-500" />
      : <XCircle className="h-4 w-4 text-red-500" />;
  };

  const getTestBadgeVariant = (test: TestResult) => {
    if (test.passed === null) return "secondary";
    return test.passed ? "default" : "destructive";
  };

  return (
    <div className="space-y-6 p-6">
      <div className="flex items-center gap-3">
        <div className="p-2 bg-blue-100 rounded-lg">
          <TestTube className="h-6 w-6 text-blue-600" />
        </div>
        <div>
          <h2 className="text-xl font-bold">Transcript Agent Tester</h2>
          <p className="text-gray-600">
            Testen Sie die Funktionalität der Transkriptions-Pipeline
          </p>
        </div>
      </div>

      {/* Audio Recording Section */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Mic className="h-5 w-5" />
            Audio-Aufnahme für Tests
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="flex items-center gap-4">
              <Button
                onClick={isRecording ? stopRecording : startRecording}
                variant={isRecording ? "destructive" : "default"}
                className="flex items-center gap-2"
              >
                <Mic className="h-4 w-4" />
                {isRecording ? 'Aufnahme stoppen' : 'Test-Aufnahme starten'}
              </Button>
              
              {recordedAudio && (
                <Badge variant="outline" className="text-green-600">
                  Audio bereit für Tests
                </Badge>
              )}
            </div>
            
            {isRecording && (
              <div className="text-sm text-gray-600">
                🔴 Aufnahme läuft... Sprechen Sie etwas für den Transcript-Test
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Test Controls */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Play className="h-5 w-5" />
            Test-Kontrollen
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            <Button
              onClick={() => runTranscriptTests('test_transcription')}
              disabled={isTesting}
              variant="outline"
              className="flex items-center gap-2"
            >
              {isTesting ? <RefreshCw className="h-4 w-4 animate-spin" /> : <TestTube className="h-4 w-4" />}
              Pipeline Test
            </Button>
            
            <Button
              onClick={() => runTranscriptTests('test_voice_to_text')}
              disabled={isTesting || !recordedAudio}
              variant="outline"
              className="flex items-center gap-2"
            >
              <Mic className="h-4 w-4" />
              Voice-to-Text
            </Button>
            
            <Button
              onClick={() => runTranscriptTests('test_transcript_quality')}
              disabled={isTesting}
              variant="outline"
              className="flex items-center gap-2"
            >
              <FileText className="h-4 w-4" />
              Qualitäts-Check
            </Button>
            
            <Button
              onClick={() => runTranscriptTests('test_full_pipeline')}
              disabled={isTesting}
              variant="outline"
              className="flex items-center gap-2"
            >
              <Database className="h-4 w-4" />
              Volltest
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Test Results */}
      {testResults && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              {testResults.success 
                ? <CheckCircle className="h-5 w-5 text-green-500" />
                : <XCircle className="h-5 w-5 text-red-500" />
              }
              Test-Ergebnisse
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {/* Summary */}
              <div className="flex items-center gap-4">
                <div className="text-sm text-gray-600">
                  Gesamt: {testResults.summary.passed}/{testResults.summary.total}
                </div>
                <Progress 
                  value={testResults.summary.total > 0 
                    ? (testResults.summary.passed / testResults.summary.total) * 100 
                    : 0
                  } 
                  className="flex-1 h-2" 
                />
                <Badge variant={testResults.success ? "default" : "destructive"}>
                  {testResults.success ? 'Bestanden' : 'Fehlgeschlagen'}
                </Badge>
              </div>

              {/* Individual Test Results */}
              <div className="space-y-2">
                {testResults.tests.map((test, index) => (
                  <div
                    key={index}
                    className="flex items-center justify-between p-3 border rounded-lg"
                  >
                    <div className="flex items-center gap-3">
                      {getTestIcon(test)}
                      <div>
                        <div className="font-medium text-sm">{test.name}</div>
                        <div className="text-xs text-gray-500">{test.message}</div>
                      </div>
                    </div>
                    <Badge variant={getTestBadgeVariant(test)}>
                      {test.passed === null ? 'Übersprungen' : test.passed ? 'OK' : 'Fehler'}
                    </Badge>
                  </div>
                ))}
              </div>

              {/* Details for Failed Tests */}
              {testResults.tests.some(test => test.error || test.details) && (
                <details className="mt-4">
                  <summary className="text-sm font-medium cursor-pointer text-blue-600">
                    Detaillierte Ergebnisse anzeigen
                  </summary>
                  <div className="mt-2 space-y-2">
                    {testResults.tests
                      .filter(test => test.error || test.details)
                      .map((test, index) => (
                        <div key={index} className="p-3 bg-gray-50 rounded-lg">
                          <div className="font-medium text-sm">{test.name}</div>
                          {test.error && (
                            <div className="text-xs text-red-600 mt-1">
                              Fehler: {test.error}
                            </div>
                          )}
                          {test.details && (
                            <pre className="text-xs text-gray-600 mt-1 overflow-x-auto">
                              {JSON.stringify(test.details, null, 2)}
                            </pre>
                          )}
                        </div>
                      ))
                    }
                  </div>
                </details>
              )}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Instructions */}
      <Card>
        <CardHeader>
          <CardTitle>Test-Anweisungen</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3 text-sm">
            <div className="flex items-start gap-2">
              <div className="w-6 h-6 bg-blue-100 rounded-full flex items-center justify-center text-blue-600 font-bold text-xs">1</div>
              <div>
                <div className="font-medium">Audio aufnehmen</div>
                <div className="text-gray-600">Nehmen Sie eine kurze Testaufnahme auf (5-10 Sekunden)</div>
              </div>
            </div>
            <div className="flex items-start gap-2">
              <div className="w-6 h-6 bg-blue-100 rounded-full flex items-center justify-center text-blue-600 font-bold text-xs">2</div>
              <div>
                <div className="font-medium">Pipeline Test</div>
                <div className="text-gray-600">Testet die grundlegende Funktionalität des Transkriptions-Systems</div>
              </div>
            </div>
            <div className="flex items-start gap-2">
              <div className="w-6 h-6 bg-blue-100 rounded-full flex items-center justify-center text-blue-600 font-bold text-xs">3</div>
              <div>
                <div className="font-medium">Voice-to-Text</div>
                <div className="text-gray-600">Testet die Audio-zu-Text-Konvertierung mit Ihrer Aufnahme</div>
              </div>
            </div>
            <div className="flex items-start gap-2">
              <div className="w-6 h-6 bg-blue-100 rounded-full flex items-center justify-center text-blue-600 font-bold text-xs">4</div>
              <div>
                <div className="font-medium">Qualitäts-Check</div>
                <div className="text-gray-600">Analysiert die Qualität vorhandener Transkripte</div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};