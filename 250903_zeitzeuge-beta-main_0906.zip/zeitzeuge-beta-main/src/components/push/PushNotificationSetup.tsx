import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { usePushNotifications } from '@/hooks/usePushNotifications';
import { Bell, BellOff, Loader2 } from 'lucide-react';

export const PushNotificationSetup = () => {
  const { isRegistered, isRegistering, registerForPush } = usePushNotifications();

  return (
    <Card className="w-full max-w-md mx-auto">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          {isRegistered ? (
            <Bell className="w-5 h-5 text-[hsl(var(--coral))]" />
          ) : (
            <BellOff className="w-5 h-5 text-muted-foreground" />
          )}
          Push Benachrichtigungen
        </CardTitle>
        <CardDescription>
          Erhalten Sie Benachrichtigungen über neue Inhalte und Updates
        </CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          <div className="text-sm text-muted-foreground">
            Status: {isRegistered ? (
              <span className="text-[hsl(var(--coral))] font-medium">Aktiviert</span>
            ) : (
              <span className="text-muted-foreground">Nicht aktiviert</span>
            )}
          </div>
          
          {!isRegistered && (
            <Button
              onClick={registerForPush}
              disabled={isRegistering}
              className="w-full bg-[hsl(var(--coral))] text-white hover:bg-[hsl(var(--coral))]/90"
            >
              {isRegistering ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Registriere...
                </>
              ) : (
                <>
                  <Bell className="w-4 h-4 mr-2" />
                  Benachrichtigungen aktivieren
                </>
              )}
            </Button>
          )}
          
          {isRegistered && (
            <div className="text-sm text-[hsl(var(--coral))] font-medium">
              ✓ Push Benachrichtigungen sind aktiv
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
};