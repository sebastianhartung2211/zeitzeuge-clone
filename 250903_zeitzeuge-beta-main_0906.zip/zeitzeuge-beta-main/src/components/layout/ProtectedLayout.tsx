import React, { useEffect } from 'react';
import { Outlet, Navigate, useLocation } from 'react-router-dom';
import { useAuth } from '@/hooks/useAuth';
import TopNavigation from '@/components/navigation/TopNavigation';

const ProtectedLayout = () => {
  const { isAuthenticated, loading } = useAuth();
  const location = useLocation();

  // Auth state debugging
  React.useEffect(() => {
    console.log('🔐 [AUTH DEBUG] Protected layout state:', {
      isAuthenticated,
      loading,
      currentPath: location.pathname,
      timestamp: new Date().toISOString()
    });
  }, [isAuthenticated, loading, location.pathname]);

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto"></div>
          <p className="mt-4 text-muted-foreground">Loading...</p>
        </div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return <Navigate to="/login" state={{ from: location }} replace />;
  }

  // Check if current route is conversation page
  const isConversationPage = location.pathname === '/app/conversation';

  return (
    <div className="min-h-screen w-full">
      {!isConversationPage && <TopNavigation />}
      <main className={isConversationPage ? "" : "pt-16"}>
        <Outlet />
      </main>
    </div>
  );
};

export default ProtectedLayout;