import React, { useState } from 'react';
import { Link, useNavigate, useLocation } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Sheet, SheetContent, SheetTrigger } from '@/components/ui/sheet';
import { Menu, LogOut, X } from 'lucide-react';
import { useAuth } from '@/hooks/useAuth';
import zeitzeugeLogo from '@/assets/zeitzeuge-logo.png';

const TopNavigation = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const { user, logout } = useAuth();
  const [isOpen, setIsOpen] = useState(false);

  const isActive = (path: string) => location.pathname === path;

  const navigationItems = [
    { path: '/app/timeline', label: 'Kategorien' },
    { path: '/app/family', label: 'Familie' },
    { path: '/app/conversation-starter', label: 'Gesprächsanregungen' },
    { path: '/app/record', label: 'Neues Erlebnis' },
    { path: '/app/conversation', label: 'Gespräch' },
  ];

  const handleNavigation = (path: string) => {
    console.log('🧭 [NAV DEBUG] Using navigate() method to:', path, {
      currentPath: location.pathname,
      timestamp: new Date().toISOString()
    });
    navigate(path);
    setIsOpen(false);
  };

  // Navigation method debugging
  const debugLinkClick = (path: string) => {
    console.log('🔗 [NAV DEBUG] Using Link component to:', path, {
      currentPath: location.pathname,
      timestamp: new Date().toISOString()
    });
  };

  return (
    <div className="sticky top-0 left-0 right-0 bg-white/95 backdrop-blur-sm border-b border-gray-200 z-[100] shadow-sm">
      <div className="px-4 sm:px-6 lg:px-8 py-3 sm:py-4 flex items-center justify-between">
        {/* Logo/Brand - Always visible */}
        <div className="flex items-center gap-3">
          <img 
            src="/lovable-uploads/01d68dc5-6469-4970-b25d-efa7eb2b0f3d.png" 
            alt="Zeitzeuge Logo" 
            className="h-8 w-8 sm:h-10 sm:w-10 object-contain"
          />
          <Link
            to="/app/timeline"
            className="text-lg sm:text-xl font-bold text-[hsl(var(--coral))] hover:text-[hsl(var(--coral))]/80 transition-colors"
          >
            zeitzeuge
          </Link>
        </div>

        {/* Desktop Navigation - Hidden on mobile */}
        <nav className="hidden lg:flex items-center gap-4 xl:gap-6">
          {navigationItems.map((item) => (
            <Link
              key={item.path}
              to={item.path}
              onClick={() => debugLinkClick(item.path)}
              className={`px-4 xl:px-6 py-2 xl:py-3 rounded-lg font-medium transition-all duration-300 text-sm xl:text-base ${
                isActive(item.path) 
                  ? 'bg-[hsl(var(--coral))] text-white shadow-lg' 
                  : 'text-[hsl(var(--navy))] hover:text-white hover:bg-[hsl(var(--coral))] hover:shadow-lg'
              }`}
            >
              {item.label}
            </Link>
          ))}
        </nav>
        
        {/* Right side - User Profile and Mobile Menu */}
        <div className="flex items-center gap-2 sm:gap-3">
          {/* User Profile - Simplified for mobile */}
          {user ? (
            <div className="flex items-center gap-2">
              <Avatar className="h-8 w-8 sm:h-10 sm:w-10 border-2 border-[hsl(var(--coral))]/30">
                <AvatarImage src={user?.avatar} alt={user?.name} />
                <AvatarFallback className="bg-[hsl(var(--coral))] text-white font-semibold text-sm">
                  {user?.name?.charAt(0).toUpperCase() || 'A'}
                </AvatarFallback>
              </Avatar>
              
              {/* User info - Hidden on mobile */}
              <div className="hidden md:block">
                <p className="text-sm font-medium text-[hsl(var(--navy))] truncate max-w-32">
                  {user?.name}
                </p>
                <p className="text-xs text-gray-500 truncate max-w-32">
                  {user?.email}
                </p>
              </div>
              
              {/* Logout - Hidden on mobile, shown in hamburger menu */}
              <Button 
                variant="ghost" 
                size="sm" 
                onClick={logout}
                className="hidden sm:flex text-gray-600 hover:text-gray-800 hover:bg-gray-100"
              >
                <LogOut className="h-4 w-4" />
              </Button>
            </div>
          ) : (
            <Button
              onClick={() => navigate('/login')}
              className="bg-gradient-to-r from-violet-500 via-purple-500 to-indigo-500 hover:from-violet-600 hover:via-purple-600 hover:to-indigo-600 text-white px-3 sm:px-6 py-2 rounded-lg font-medium text-sm"
            >
              Anmelden
            </Button>
          )}

          {/* Mobile Menu Button */}
          <Sheet open={isOpen} onOpenChange={setIsOpen}>
            <SheetTrigger asChild>
              <Button 
                variant="ghost" 
                size="sm" 
                className="lg:hidden p-2 text-[hsl(var(--navy))] hover:bg-[hsl(var(--coral))]/10"
              >
                <Menu className="h-5 w-5" />
              </Button>
            </SheetTrigger>
            
            <SheetContent side="right" className="w-[280px] p-0">
              <div className="flex flex-col h-full bg-white">
                {/* Header */}
                <div className="flex items-center justify-between p-4 border-b">
                  <h2 className="text-lg font-semibold text-[hsl(var(--navy))]">
                    Navigation
                  </h2>
                  <Button 
                    variant="ghost" 
                    size="sm" 
                    onClick={() => setIsOpen(false)}
                    className="p-2"
                  >
                    <X className="h-4 w-4" />
                  </Button>
                </div>

                {/* Navigation Items */}
                <div className="flex-1 p-4">
                  <nav className="space-y-2">
                    {navigationItems.map((item) => (
                        <Link
                          key={item.path}
                          to={item.path}
                          onClick={() => {
                            debugLinkClick(item.path);
                            setIsOpen(false);
                          }}
                        className={`block w-full text-left px-4 py-3 rounded-lg font-medium transition-all duration-200 ${
                          isActive(item.path) 
                            ? 'bg-[hsl(var(--coral))] text-white' 
                            : 'text-[hsl(var(--navy))] hover:bg-[hsl(var(--coral))]/10 hover:text-[hsl(var(--coral))]'
                        }`}
                      >
                        {item.label}
                      </Link>
                    ))}
                   </nav>

                   {/* Legal/Footer Links */}
                   <div className="mt-6 pt-4 border-t border-gray-200">
                     <nav className="space-y-2">
                       <Link
                         to="/impressum"
                         onClick={() => setIsOpen(false)}
                         className={`block w-full text-left px-4 py-2 rounded-lg text-sm transition-all duration-200 ${
                           isActive('/impressum') 
                             ? 'bg-[hsl(var(--coral))] text-white' 
                             : 'text-gray-600 hover:bg-gray-100 hover:text-[hsl(var(--coral))]'
                         }`}
                       >
                         Impressum
                       </Link>
                       <Link
                         to="/datenschutz"
                         onClick={() => setIsOpen(false)}
                         className={`block w-full text-left px-4 py-2 rounded-lg text-sm transition-all duration-200 ${
                           isActive('/datenschutz') 
                             ? 'bg-[hsl(var(--coral))] text-white' 
                             : 'text-gray-600 hover:bg-gray-100 hover:text-[hsl(var(--coral))]'
                         }`}
                       >
                         Datenschutzbestimmungen
                       </Link>
                     </nav>
                   </div>

                  {/* User info and logout in mobile menu */}
                  {user && (
                    <div className="mt-6 pt-6 border-t">
                      <div className="flex items-center gap-3 mb-4 px-4">
                        <Avatar className="h-10 w-10 border-2 border-[hsl(var(--coral))]/30">
                          <AvatarImage src={user?.avatar} alt={user?.name} />
                          <AvatarFallback className="bg-[hsl(var(--coral))] text-white font-semibold">
                            {user?.name?.charAt(0).toUpperCase() || 'A'}
                          </AvatarFallback>
                        </Avatar>
                        <div className="flex-1 min-w-0">
                          <p className="text-sm font-medium text-[hsl(var(--navy))] truncate">
                            {user?.name}
                          </p>
                          <p className="text-xs text-gray-500 truncate">
                            {user?.email}
                          </p>
                        </div>
                      </div>
                      
                      <Button 
                        variant="ghost" 
                        onClick={() => {
                          logout();
                          setIsOpen(false);
                        }}
                        className="w-full justify-start px-4 py-3 text-gray-600 hover:text-gray-800 hover:bg-gray-100"
                      >
                        <LogOut className="h-4 w-4 mr-3" />
                        Abmelden
                      </Button>
                    </div>
                  )}
                </div>
              </div>
            </SheetContent>
          </Sheet>
        </div>
      </div>
    </div>
  );
};

export default TopNavigation;