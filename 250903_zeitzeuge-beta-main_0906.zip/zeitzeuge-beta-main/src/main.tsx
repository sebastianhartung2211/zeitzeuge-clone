import { createRoot } from 'react-dom/client';
import App from './App.tsx';
import './index.css';

import { analytics } from './services/analytics';
import { cleanupSW } from './features/pwa/cleanup';
import { initializePWA, setupInstallPrompt } from './features/pwa/pwaService';

// Analytics initialisieren (Sentry DSN aus Env)
analytics.initialize(import.meta.env.VITE_SENTRY_DSN);

// Immer zuerst: SW/Caches aufräumen, wenn PWA aus ist
cleanupSW();

// PWA nur, wenn explizit aktiviert
if (import.meta.env.PROD && import.meta.env.VITE_ENABLE_PWA === 'true') {
  initializePWA();
  setupInstallPrompt();
}

createRoot(document.getElementById("root")!).render(
  <App />
);
