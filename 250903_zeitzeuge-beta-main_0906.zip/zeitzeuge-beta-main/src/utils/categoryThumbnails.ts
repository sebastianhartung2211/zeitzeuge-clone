// Category thumbnail mapping using Supabase storage
const SUPABASE_STORAGE_BASE = 'https://fepcoqrfrkfiaftkkfht.supabase.co/storage/v1/object/public/videos/thumbnails';

export const categoryThumbnails: Record<string, string[]> = {
  'Kindheit & Familie': [
    `${SUPABASE_STORAGE_BASE}/Kindheit%20%26%20Familie1.png`,
    `${SUPABASE_STORAGE_BASE}/Kindheit%20%26%20Familie2.png`,
    `${SUPABASE_STORAGE_BASE}/Kindheit%20%26%20Familie3.png`,
    `${SUPABASE_STORAGE_BASE}/Kind%20%26%20Familie.png`,
    `${SUPABASE_STORAGE_BASE}/Familie.png`
  ],
  'Jugend & Schule': [
    `${SUPABASE_STORAGE_BASE}/Jugend%20%26%20Schule1.png`,
    `${SUPABASE_STORAGE_BASE}/Jugend%20%26%20Schule2.png`,
    `${SUPABASE_STORAGE_BASE}/Jugend%20%26%20Schule3.png`,
    `${SUPABASE_STORAGE_BASE}/Jugend%20und%20Schule.png`
  ],
  'Liebe & Beziehungen': [
    `${SUPABASE_STORAGE_BASE}/Liebe%20%26%20Beziehungen1.png`,
    `${SUPABASE_STORAGE_BASE}/Liebe%20%26%20Beziehungen2.png`,
    `${SUPABASE_STORAGE_BASE}/Liebe%20%26%20Beziehungen3.png`,
    `${SUPABASE_STORAGE_BASE}/Liebe.png`
  ],
  'Arbeit & Alltag': [
    `${SUPABASE_STORAGE_BASE}/Arbeit%20%26%20Alltag%201.png`,
    `${SUPABASE_STORAGE_BASE}/Arbeit%20%26%20Alltag%202.png`,
    `${SUPABASE_STORAGE_BASE}/Arbeit%20%26%20Alltag%203.png`,
    `${SUPABASE_STORAGE_BASE}/Arbeit%20%26%20Alltag.png`
  ],
  'Zuhause & Traditionen': [
    `${SUPABASE_STORAGE_BASE}/Zuhause%20%26%20Traditionen.png`,
    `${SUPABASE_STORAGE_BASE}/Zuhause%20%26%20Traditionen2.png`,
    `${SUPABASE_STORAGE_BASE}/Zuhause%20%26%20Traditionen3.png`,
    `${SUPABASE_STORAGE_BASE}/Zuhause.png`
  ],
  'Zeitgeschichte & Wandel': [
    `${SUPABASE_STORAGE_BASE}/Zeitgeschichte.png`,
    `${SUPABASE_STORAGE_BASE}/Zeitgeschichte_2.png`
  ],
  'Reisen & Abenteuer': [
    `${SUPABASE_STORAGE_BASE}/Reisen%20%26%20Abenteuer1.png`,
    `${SUPABASE_STORAGE_BASE}/Reisen%20%26%20Abenteuer2.png`,
    `${SUPABASE_STORAGE_BASE}/Reisen%20%26%20Abenteuer3.png`
  ],
  'Hobbies & Leidenschaften': [
    `${SUPABASE_STORAGE_BASE}/Hobbies%20%26%20Leidenschaften1.png`
  ],
  'Personalisierte Themen': [
    `${SUPABASE_STORAGE_BASE}/Familie.png`
  ],
  // Fallback for any other categories
  'Uncategorized': [
    `${SUPABASE_STORAGE_BASE}/Familie.png`
  ]
};

export const getCategoryThumbnail = (category: string | null | undefined, index: number = 0): string => {
  if (!category) return categoryThumbnails['Uncategorized'][0];
  
  // Direct match first
  if (categoryThumbnails[category]) {
    const images = categoryThumbnails[category];
    return images[index % images.length];
  }
  
  // Exact category name matches from database
  const normalizedCategory = category.toLowerCase().trim();
  
  // Check for exact normalized matches
  for (const [key, images] of Object.entries(categoryThumbnails)) {
    if (key.toLowerCase() === normalizedCategory) {
      return images[index % images.length];
    }
  }
  
  // Partial matches for variations
  if (normalizedCategory.includes('liebe') || normalizedCategory.includes('beziehung')) {
    const images = categoryThumbnails['Liebe & Beziehungen'];
    return images[index % images.length];
  }
  if (normalizedCategory.includes('familie') || normalizedCategory.includes('kind')) {
    const images = categoryThumbnails['Kindheit & Familie'];
    return images[index % images.length];
  }
  if (normalizedCategory.includes('jugend') || normalizedCategory.includes('schule')) {
    const images = categoryThumbnails['Jugend & Schule'];
    return images[index % images.length];
  }
  if (normalizedCategory.includes('arbeit') || normalizedCategory.includes('alltag')) {
    const images = categoryThumbnails['Arbeit & Alltag'];
    return images[index % images.length];
  }
  if (normalizedCategory.includes('zuhause') || normalizedCategory.includes('tradition')) {
    const images = categoryThumbnails['Zuhause & Traditionen'];
    return images[index % images.length];
  }
  if (normalizedCategory.includes('geschichte') || normalizedCategory.includes('wandel')) {
    const images = categoryThumbnails['Zeitgeschichte & Wandel'];
    return images[index % images.length];
  }
  if (normalizedCategory.includes('reisen') || normalizedCategory.includes('abenteuer')) {
    const images = categoryThumbnails['Reisen & Abenteuer'];
    return images[index % images.length];
  }
  if (normalizedCategory.includes('hobbies') || normalizedCategory.includes('leidenschaften')) {
    const images = categoryThumbnails['Hobbies & Leidenschaften'];
    return images[index % images.length];
  }
  
  // Default fallback
  return categoryThumbnails['Uncategorized'][0];
};