/**
 * Canvas-based Video Recorder to eliminate motion artifacts
 * Uses manual frame capture to prevent compression artifacts
 */

export interface CanvasRecorderConfig {
  width: number;
  height: number;
  frameRate: number;
  quality: number; // 0.1 to 1.0
  format: 'webm' | 'mp4';
}

export class CanvasVideoRecorder {
  private canvas: HTMLCanvasElement;
  private ctx: CanvasRenderingContext2D;
  private videoElement: HTMLVideoElement | null = null;
  private audioStream: MediaStream | null = null;
  private mediaRecorder: MediaRecorder | null = null;
  private canvasStream: MediaStream | null = null;
  private animationFrame: number | null = null;
  private isRecording = false;
  private recordedChunks: Blob[] = [];
  
  private config: CanvasRecorderConfig;
  private onDataAvailable?: (chunk: Blob) => void;
  private onStop?: (videoBlob: Blob) => void;
  private onError?: (error: Error) => void;

  constructor(config: Partial<CanvasRecorderConfig> = {}) {
    this.config = {
      width: 1280,
      height: 720,
      frameRate: 30,
      quality: 0.95, // High quality
      format: 'mp4',
      ...config
    };

    // Create canvas for manual frame capture
    this.canvas = document.createElement('canvas');
    this.canvas.width = this.config.width;
    this.canvas.height = this.config.height;
    this.ctx = this.canvas.getContext('2d')!;
    
    // Set high-quality rendering
    this.ctx.imageSmoothingEnabled = true;
    this.ctx.imageSmoothingQuality = 'high';
  }

  async startCamera(): Promise<MediaStream> {
    console.log('🎥 Starting canvas-based camera for artifact-free recording...');
    
    try {
      // Get video stream with optimal settings for canvas capture
      const videoStream = await navigator.mediaDevices.getUserMedia({
        video: {
          width: { ideal: this.config.width },
          height: { ideal: this.config.height },
          frameRate: { ideal: this.config.frameRate },
          facingMode: 'user'
        },
        audio: false
      });

      // Get separate audio stream
      this.audioStream = await navigator.mediaDevices.getUserMedia({
        audio: {
          sampleRate: 48000,
          channelCount: 1,
          echoCancellation: true,
          noiseSuppression: true,
          autoGainControl: true
        }
      });

      // Create video element for canvas drawing
      this.videoElement = document.createElement('video');
      this.videoElement.srcObject = videoStream;
      this.videoElement.muted = true;
      this.videoElement.playsInline = true;
      
      await new Promise<void>((resolve, reject) => {
        this.videoElement!.onloadedmetadata = () => resolve();
        this.videoElement!.onerror = () => reject(new Error('Video load failed'));
        this.videoElement!.play();
      });

      console.log('✅ Canvas camera initialized successfully');
      return videoStream;
      
    } catch (error) {
      console.error('❌ Canvas camera initialization failed:', error);
      throw error;
    }
  }

  private drawVideoFrame() {
    if (!this.videoElement || !this.isRecording) return;

    // Clear canvas
    this.ctx.fillStyle = '#000000';
    this.ctx.fillRect(0, 0, this.canvas.width, this.canvas.height);

    // Draw video frame with anti-aliasing
    this.ctx.save();
    
    // Apply horizontal flip for mirror effect
    this.ctx.scale(-1, 1);
    this.ctx.translate(-this.canvas.width, 0);
    
    // Draw the video frame
    this.ctx.drawImage(
      this.videoElement,
      0, 0, 
      this.canvas.width, 
      this.canvas.height
    );
    
    this.ctx.restore();

    // Schedule next frame
    if (this.isRecording) {
      this.animationFrame = requestAnimationFrame(() => this.drawVideoFrame());
    }
  }

  async startRecording(): Promise<void> {
    if (!this.videoElement || !this.audioStream) {
      throw new Error('Camera not started. Call startCamera() first.');
    }

    console.log('🔴 Starting canvas-based recording...');
    
    try {
      // Get canvas stream with high quality settings
      this.canvasStream = this.canvas.captureStream(this.config.frameRate);
      
      // Combine canvas video with audio
      const combinedStream = new MediaStream([
        ...this.canvasStream.getVideoTracks(),
        ...this.audioStream.getAudioTracks()
      ]);

      // Use highest quality settings with artifact-free codec
      const recorderOptions: MediaRecorderOptions = {
        mimeType: this.getOptimalMimeType(),
        videoBitsPerSecond: 15000000, // 15Mbps for ultra-high quality
        audioBitsPerSecond: 320000 // High-quality audio
      };

      this.mediaRecorder = new MediaRecorder(combinedStream, recorderOptions);
      this.recordedChunks = [];

      this.mediaRecorder.ondataavailable = (event) => {
        if (event.data.size > 0) {
          this.recordedChunks.push(event.data);
          this.onDataAvailable?.(event.data);
        }
      };

      this.mediaRecorder.onstop = () => {
        const videoBlob = new Blob(this.recordedChunks, {
          type: this.getOptimalMimeType().split(';')[0]
        });
        
        console.log('📁 Canvas recording completed:', {
          size: videoBlob.size,
          type: videoBlob.type,
          chunks: this.recordedChunks.length
        });

        this.onStop?.(videoBlob);
      };

      this.mediaRecorder.onerror = (event) => {
        console.error('❌ Canvas recording error:', event);
        this.onError?.(new Error('Canvas recording failed'));
      };

      // Start recording and canvas drawing
      this.isRecording = true;
      this.mediaRecorder.start(100); // Very frequent chunks for smooth quality
      this.drawVideoFrame(); // Start drawing loop

      console.log('✅ Canvas recording started with ultra-high quality settings');

    } catch (error) {
      console.error('❌ Canvas recording failed:', error);
      throw error;
    }
  }

  stopRecording(): void {
    console.log('⏹️ Stopping canvas recording...');
    
    this.isRecording = false;
    
    if (this.animationFrame) {
      cancelAnimationFrame(this.animationFrame);
      this.animationFrame = null;
    }
    
    if (this.mediaRecorder && this.mediaRecorder.state === 'recording') {
      this.mediaRecorder.stop();
    }
  }

  private getOptimalMimeType(): string {
    // Priority order for MP4 recording
    const codecs = [
      'video/mp4;codecs=avc1.42E01E,mp4a.40.2',
      'video/mp4;codecs=h264,aac',
      'video/mp4',
      'video/webm;codecs=vp9,opus',
      'video/webm;codecs=vp8,opus',
      'video/webm'
    ];

    for (const codec of codecs) {
      if (MediaRecorder.isTypeSupported(codec)) {
        console.log('🎯 Using optimal MP4 codec for canvas recording:', codec);
        return codec;
      }
    }

    return 'video/mp4';
  }

  stopCamera(): void {
    console.log('🛑 Stopping canvas camera...');
    
    this.stopRecording();
    
    if (this.videoElement) {
      const stream = this.videoElement.srcObject as MediaStream;
      if (stream) {
        stream.getTracks().forEach(track => track.stop());
      }
      this.videoElement.srcObject = null;
      this.videoElement = null;
    }

    if (this.audioStream) {
      this.audioStream.getTracks().forEach(track => track.stop());
      this.audioStream = null;
    }

    if (this.canvasStream) {
      this.canvasStream.getTracks().forEach(track => track.stop());
      this.canvasStream = null;
    }
  }

  isCurrentlyRecording(): boolean {
    return this.isRecording;
  }

  // Callback setters
  setDataAvailableCallback(callback: (chunk: Blob) => void): void {
    this.onDataAvailable = callback;
  }

  setStopCallback(callback: (videoBlob: Blob) => void): void {
    this.onStop = callback;
  }

  setErrorCallback(callback: (error: Error) => void): void {
    this.onError = callback;
  }

  destroy(): void {
    this.stopCamera();
  }
}