import { DeviceDetectionService } from '@/services/DeviceDetectionService';
import { PerformanceMonitor } from '@/services/PerformanceMonitor';

export interface MobileRecorderConfig {
  enablePerformanceMonitoring: boolean;
  enableAutoFallback: boolean;
  enableZoomReset: boolean;
  preferredCodec: 'h264' | 'vp8' | 'vp9' | 'auto';
  bitrateKbps: number;
}

export class MobileVideoRecorder {
  private deviceService: DeviceDetectionService;
  private performanceMonitor: PerformanceMonitor;
  private config: MobileRecorderConfig;
  private mediaRecorder: MediaRecorder | null = null;
  private videoStream: MediaStream | null = null;
  private audioStream: MediaStream | null = null;
  private combinedStream: MediaStream | null = null;
  private videoElement: HTMLVideoElement | null = null;
  private recordedChunks: Blob[] = [];
  private isRecording = false;
  private isPaused = false;
  private retryCount = 0;
  private maxRetries = 3;

  // Callbacks
  private onDataAvailableCallback?: (chunk: Blob) => void;
  private onStopCallback?: (videoBlob: Blob) => void;
  private onErrorCallback?: (error: Error) => void;

  constructor(config: Partial<MobileRecorderConfig> = {}) {
    this.deviceService = DeviceDetectionService.getInstance();
    this.performanceMonitor = PerformanceMonitor.getInstance();
    
    this.config = {
      enablePerformanceMonitoring: true,
      enableAutoFallback: true,
      enableZoomReset: true,
      preferredCodec: 'auto',
      bitrateKbps: 2500,
      ...config
    };
  }

  async initializeCamera(): Promise<MediaStream> {
    if (this.config.enablePerformanceMonitoring) {
      this.performanceMonitor.startCameraLaunchTimer();
    }

    try {
      // Detect device capabilities first
      await this.deviceService.detectCapabilities();
      const capabilities = this.deviceService.getCapabilities();
      
      if (capabilities) {
        this.deviceService.logDeviceInfo();
      }

      // Get optimized constraints
      const constraints = await this.deviceService.getOptimizedConstraints();
      
      // Request media streams
      const stream = await this.requestMediaWithFallback(constraints);
      
      // Validate and set up stream
      await this.setupVideoStream(stream);
      
      if (this.config.enablePerformanceMonitoring) {
        this.performanceMonitor.endCameraLaunchTimer();
      }

      return stream;
      
    } catch (error) {
      this.handleCameraError(error as Error);
      throw error;
    }
  }

  private async requestMediaWithFallback(constraints: any): Promise<MediaStream> {
    try {
      return await navigator.mediaDevices.getUserMedia(constraints);
    } catch (error) {
      if (this.config.enableAutoFallback && this.retryCount < this.maxRetries) {
        this.retryCount++;
        console.warn(`Camera initialization failed, attempting fallback ${this.retryCount}/${this.maxRetries}:`, error);
        
        // Progressive fallback constraints
        const fallbackConstraints = this.getFallbackConstraints(this.retryCount);
        return await this.requestMediaWithFallback(fallbackConstraints);
      }
      throw error;
    }
  }

  private getFallbackConstraints(retryLevel: number) {
    const baseConstraints = {
      video: true,
      audio: {
        echoCancellation: true,
        noiseSuppression: true,
        autoGainControl: true
      }
    };

    switch (retryLevel) {
      case 1:
        // First fallback: Lower resolution
        return {
          video: {
            width: { ideal: 1280 },
            height: { ideal: 720 },
            frameRate: { ideal: 30 },
            facingMode: 'user'
          },
          audio: baseConstraints.audio
        };
      
      case 2:
        // Second fallback: Even lower resolution
        return {
          video: {
            width: { ideal: 640 },
            height: { ideal: 480 },
            frameRate: { ideal: 24 },
            facingMode: 'user'
          },
          audio: baseConstraints.audio
        };
      
      case 3:
        // Final fallback: Basic constraints
        return baseConstraints;
      
      default:
        return baseConstraints;
    }
  }

  private async setupVideoStream(stream: MediaStream): Promise<void> {
    this.combinedStream = stream;
    
    // Separate video and audio tracks for better control
    const videoTracks = stream.getVideoTracks();
    const audioTracks = stream.getAudioTracks();
    
    if (videoTracks.length > 0) {
      this.videoStream = new MediaStream(videoTracks);
      
      // Reset zoom if supported and enabled
      if (this.config.enableZoomReset) {
        await this.resetZoomLevel(videoTracks[0]);
      }
      
      // Apply additional video track settings
      await this.optimizeVideoTrack(videoTracks[0]);
    }
    
    if (audioTracks.length > 0) {
      this.audioStream = new MediaStream(audioTracks);
      
      // Apply audio optimizations
      this.optimizeAudioTrack(audioTracks[0]);
    }
  }

  private async resetZoomLevel(videoTrack: MediaStreamTrack): Promise<void> {
    try {
      const capabilities = videoTrack.getCapabilities();
      
      if ('zoom' in capabilities && capabilities.zoom) {
        await videoTrack.applyConstraints({
          zoom: 1.0
        } as any);
        console.log('Zoom level reset to 1x');
      }
    } catch (error) {
      console.warn('Could not reset zoom level:', error);
      // Don't throw error as this is not critical
    }
  }

  private async optimizeVideoTrack(videoTrack: MediaStreamTrack): Promise<void> {
    try {
      const capabilities = videoTrack.getCapabilities();
      const settings = videoTrack.getSettings();
      
      console.log('Video track settings:', settings);
      console.log('Video track capabilities:', capabilities);
      
      // Log current configuration for debugging
      const deviceCapabilities = this.deviceService.getCapabilities();
      if (deviceCapabilities && this.config.enablePerformanceMonitoring) {
        this.performanceMonitor.setBitrate(this.config.bitrateKbps * 1000);
      }
      
    } catch (error) {
      console.warn('Could not optimize video track:', error);
    }
  }

  private optimizeAudioTrack(audioTrack: MediaStreamTrack): void {
    try {
      const settings = audioTrack.getSettings();
      console.log('Audio track settings:', settings);
    } catch (error) {
      console.warn('Could not optimize audio track:', error);
    }
  }

  async startRecording(): Promise<void> {
    if (!this.combinedStream) {
      throw new Error('No media stream available. Call initializeCamera() first.');
    }

    if (this.config.enablePerformanceMonitoring) {
      this.performanceMonitor.startRecordingTimer();
    }

    try {
      // Determine optimal codec
      const mimeType = this.getOptimalMimeType();
      
      // Configure MediaRecorder options
      const options: MediaRecorderOptions = {
        mimeType,
        videoBitsPerSecond: this.config.bitrateKbps * 1000,
        audioBitsPerSecond: 128000 // 128 kbps for audio
      };

      this.mediaRecorder = new MediaRecorder(this.combinedStream, options);
      this.recordedChunks = [];
      
      // Set up event handlers
      this.setupMediaRecorderEvents();
      
      // Start recording
      this.mediaRecorder.start(1000); // Request data every second
      this.isRecording = true;
      this.isPaused = false;
      
      console.log('Recording started with options:', options);
      
    } catch (error) {
      this.handleRecordingError(error as Error);
      throw error;
    }
  }

  private getOptimalMimeType(): string {
    const capabilities = this.deviceService.getCapabilities();
    const isIOS = capabilities?.isIOS || false;
    const isAndroid = capabilities?.isAndroid || false;

    // Define codec preferences by platform - MP4 first
    const codecPreferences = {
      ios: ['video/mp4;codecs=avc1.42E01E,mp4a.40.2', 'video/mp4;codecs=h264', 'video/mp4'],
      android: ['video/mp4;codecs=avc1.42E01E,mp4a.40.2', 'video/mp4;codecs=h264', 'video/mp4'],
      desktop: ['video/mp4;codecs=avc1.42E01E,mp4a.40.2', 'video/mp4;codecs=h264', 'video/mp4']
    };

    let candidates: string[];
    if (isIOS) {
      candidates = codecPreferences.ios;
    } else if (isAndroid) {
      candidates = codecPreferences.android;
    } else {
      candidates = codecPreferences.desktop;
    }

    // Override with user preference if specified
    if (this.config.preferredCodec !== 'auto') {
      const codecMap = {
        h264: 'video/mp4;codecs=avc1.42E01E,mp4a.40.2',
        vp8: 'video/webm;codecs=vp8',
        vp9: 'video/webm;codecs=vp9'
      };
      candidates.unshift(codecMap[this.config.preferredCodec]);
    }

    // Find first supported codec
    for (const mimeType of candidates) {
      if (MediaRecorder.isTypeSupported(mimeType)) {
        console.log('Selected codec:', mimeType);
        return mimeType;
      }
    }

    // Fallback to basic mp4
    return 'video/mp4';
  }

  private setupMediaRecorderEvents(): void {
    if (!this.mediaRecorder) return;

    this.mediaRecorder.ondataavailable = (event) => {
      if (event.data && event.data.size > 0) {
        this.recordedChunks.push(event.data);
        if (this.onDataAvailableCallback) {
          this.onDataAvailableCallback(event.data);
        }
      }
    };

    this.mediaRecorder.onstop = () => {
      const videoBlob = new Blob(this.recordedChunks, { type: 'video/mp4' });
      
      if (this.config.enablePerformanceMonitoring) {
        this.performanceMonitor.stopRecordingTimer();
      }
      
      if (this.onStopCallback) {
        this.onStopCallback(videoBlob);
      }
      
      this.isRecording = false;
      this.isPaused = false;
      console.log('Recording stopped, blob size:', videoBlob.size);
    };

    this.mediaRecorder.onerror = (event) => {
      const error = new Error(`MediaRecorder error: ${(event as any).error || 'Unknown error'}`);
      this.handleRecordingError(error);
    };
  }

  stopRecording(): void {
    if (this.mediaRecorder && (this.isRecording || this.isPaused)) {
      // Fully stop and finalize the recording
      this.mediaRecorder.stop();
      this.isRecording = false;
      this.isPaused = false;
    }
  }

  pauseRecording(): void {
    if (this.mediaRecorder && this.isRecording && this.mediaRecorder.state === 'recording') {
      this.mediaRecorder.pause();
      this.isPaused = true;
      console.log('Recording paused');
    }
  }

  resumeRecording(): void {
    if (this.mediaRecorder && this.isPaused && this.mediaRecorder.state === 'paused') {
      this.mediaRecorder.resume();
      this.isPaused = false;
      this.isRecording = true;
      console.log('Recording resumed');
    }
  }

  getCurrentBlob(): Blob {
    return new Blob(this.recordedChunks, { type: 'video/mp4' });
  }

  isCurrentlyPaused(): boolean {
    return this.isPaused;
  }

  stopCamera(): void {
    // Stop all media tracks
    [this.videoStream, this.audioStream, this.combinedStream].forEach(stream => {
      if (stream) {
        stream.getTracks().forEach(track => {
          track.stop();
        });
      }
    });

    // Clear references
    this.videoStream = null;
    this.audioStream = null;
    this.combinedStream = null;
    this.mediaRecorder = null;
    
    // Reset retry counter
    this.retryCount = 0;
  }

  attachToVideoElement(videoElement: HTMLVideoElement): void {
    this.videoElement = videoElement;
    if (this.combinedStream) {
      videoElement.srcObject = this.combinedStream;
    }
  }

  isCurrentlyRecording(): boolean {
    return this.isRecording;
  }

  getPerformanceReport() {
    if (this.config.enablePerformanceMonitoring) {
      return this.performanceMonitor.getComplianceReport();
    }
    return null;
  }

  logPerformanceReport(): void {
    if (this.config.enablePerformanceMonitoring) {
      this.performanceMonitor.logReport();
    }
  }

  exportPerformanceData(): string | null {
    if (this.config.enablePerformanceMonitoring) {
      return this.performanceMonitor.exportReport();
    }
    return null;
  }

  // Event handlers
  setDataAvailableCallback(callback: (chunk: Blob) => void): void {
    this.onDataAvailableCallback = callback;
  }

  setStopCallback(callback: (videoBlob: Blob) => void): void {
    this.onStopCallback = callback;
  }

  setErrorCallback(callback: (error: Error) => void): void {
    this.onErrorCallback = callback;
  }

  private handleCameraError(error: Error): void {
    console.error('Camera error:', error);
    
    if (this.config.enablePerformanceMonitoring) {
      this.performanceMonitor.recordError(`Camera error: ${error.message}`);
    }
    
    if (this.onErrorCallback) {
      this.onErrorCallback(error);
    }
  }

  private handleRecordingError(error: Error): void {
    console.error('Recording error:', error);
    
    if (this.config.enablePerformanceMonitoring) {
      this.performanceMonitor.recordError(`Recording error: ${error.message}`);
      this.performanceMonitor.recordCrash();
    }
    
    this.isRecording = false;
    
    if (this.onErrorCallback) {
      this.onErrorCallback(error);
    }
  }

  destroy(): void {
    this.stopRecording();
    this.stopCamera();
    
    // Clear callbacks
    this.onDataAvailableCallback = undefined;
    this.onStopCallback = undefined;
    this.onErrorCallback = undefined;
  }
}