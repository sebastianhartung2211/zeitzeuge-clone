/**
 * Enhanced Video Recording Utility with Optimized Audio
 * Combines optimized audio processing with video recording capabilities
 */

import { AudioProcessor, VoiceActivityDetector } from './AudioProcessor';

export interface VideoRecorderConfig {
  video: {
    width: number;
    height: number;
    frameRate: number;
    facingMode?: 'user' | 'environment';
  };
  audio: {
    sampleRate: number;
    channelCount: number;
    echoCancellation: boolean;
    noiseSuppression: boolean;
    autoGainControl: boolean;
    vadThreshold: number;
    vadSilenceDuration: number;
  };
  recording: {
    mimeType: string;
    videoBitsPerSecond: number;
    audioBitsPerSecond: number;
  };
}

export class OptimizedVideoRecorder {
  private videoStream: MediaStream | null = null;
  private audioStream: MediaStream | null = null;
  private combinedStream: MediaStream | null = null;
  private mediaRecorder: MediaRecorder | null = null;
  private audioProcessor: AudioProcessor;
  private config: VideoRecorderConfig;
  private recordedChunks: Blob[] = [];
  
  private onDataAvailable?: (chunk: Blob) => void;
  private onStop?: (videoBlob: Blob) => void;
  private onVoiceActivity?: (isSpeaking: boolean, energy: number) => void;
  private onError?: (error: Error) => void;

  constructor(config: Partial<VideoRecorderConfig> = {}) {
    this.config = {
      video: {
        width: 1280,
        height: 720,
        frameRate: 30,
        facingMode: 'user',
        ...config.video
      },
      audio: {
        sampleRate: 24000,
        channelCount: 1,
        echoCancellation: true,
        noiseSuppression: true,
        autoGainControl: true,
        vadThreshold: 0.008,
        vadSilenceDuration: 800,
        ...config.audio
      },
      recording: {
        // Use H.264 MP4 for better motion handling and fewer artifacts
        mimeType: 'video/mp4;codecs=avc1.42E01E,mp4a.40.2',
        videoBitsPerSecond: 8000000, // Increased to 8Mbps for highest quality
        audioBitsPerSecond: 192000, // Increased audio quality too
        ...config.recording
      }
    };

    this.audioProcessor = new AudioProcessor(this.config.audio);
  }

  async startCamera(): Promise<MediaStream> {
    console.log('🎥 Starting optimized video camera...');
    
    try {
      // SIMPLIFIED APPROACH: Get video and audio together first
      console.log('📱 Requesting combined video+audio stream...');
      const combinedMediaStream = await navigator.mediaDevices.getUserMedia({
        video: {
          width: { ideal: this.config.video.width },
          height: { ideal: this.config.video.height },
          frameRate: { ideal: this.config.video.frameRate },
          facingMode: this.config.video.facingMode,
          aspectRatio: { ideal: 16/9 }
        },
        audio: {
          sampleRate: this.config.audio.sampleRate,
          channelCount: this.config.audio.channelCount,
          echoCancellation: this.config.audio.echoCancellation,
          noiseSuppression: this.config.audio.noiseSuppression,
          autoGainControl: this.config.audio.autoGainControl
        }
      });

      console.log('✅ AUDIO DEBUG: Combined stream obtained:', {
        totalTracks: combinedMediaStream.getTracks().length,
        videoTracks: combinedMediaStream.getVideoTracks().length,
        audioTracks: combinedMediaStream.getAudioTracks().length,
        videoTrackSettings: combinedMediaStream.getVideoTracks().map(t => t.getSettings()),
        audioTrackSettings: combinedMediaStream.getAudioTracks().map(t => t.getSettings())
      });

      // Separate tracks for individual management
      const videoTracks = combinedMediaStream.getVideoTracks();
      const audioTracks = combinedMediaStream.getAudioTracks();

      if (videoTracks.length === 0) {
        throw new Error('No video track available');
      }

      if (audioTracks.length === 0) {
        console.error('❌ CRITICAL: No audio tracks in stream!');
        throw new Error('Audio track missing - microphone permission required');
      }

      // Create individual streams
      this.videoStream = new MediaStream(videoTracks);
      this.audioStream = new MediaStream(audioTracks);
      this.combinedStream = combinedMediaStream; // Use original combined stream
      
      // Initialize audio processing for voice activity detection
      try {
        this.audioProcessor.initializeAudioContext(this.audioStream);
        this.audioProcessor.setVoiceActivityCallback((isSpeaking, energy) => {
          if (this.onVoiceActivity) {
            this.onVoiceActivity(isSpeaking, energy);
          }
        });
        console.log('✅ Audio processing initialized');
      } catch (audioError) {
        console.warn('⚠️ Audio processing setup failed:', audioError);
        // Continue without audio processing
      }

      console.log('✅ FINAL STREAM VERIFICATION:', {
        combinedStreamTracks: this.combinedStream.getTracks().length,
        videoStreamTracks: this.videoStream.getVideoTracks().length,
        audioStreamTracks: this.audioStream.getAudioTracks().length,
        combinedStreamActive: this.combinedStream.active,
        audioTrackEnabled: this.audioStream.getAudioTracks()[0]?.enabled,
        audioTrackReadyState: this.audioStream.getAudioTracks()[0]?.readyState
      });

      return this.videoStream; // Return video stream for preview
      
    } catch (error) {
      console.error('❌ CAMERA ERROR:', error);
      this.cleanup();
      
      // Provide specific error messages
      if (error.name === 'NotAllowedError') {
        throw new Error('Kamera- und Mikrofon-Berechtigung verweigert. Bitte erlauben Sie den Zugriff.');
      } else if (error.name === 'NotFoundError') {
        throw new Error('Kamera oder Mikrofon nicht gefunden. Überprüfen Sie Ihre Geräte.');
      } else {
        throw new Error(`Kamera-Fehler: ${error.message}`);
      }
    }
  }

  stopCamera(): void {
    console.log('🛑 Stopping optimized camera...');
    
    if (this.videoStream) {
      this.videoStream.getTracks().forEach(track => {
        track.stop();
        console.log(`Stopped video track: ${track.label}`);
      });
      this.videoStream = null;
    }

    if (this.audioStream) {
      this.audioStream.getTracks().forEach(track => {
        track.stop();
        console.log(`Stopped audio track: ${track.label}`);
      });
      this.audioStream = null;
    }

    if (this.combinedStream) {
      this.combinedStream = null;
    }

    this.audioProcessor.cleanup();
  }

  async startRecording(): Promise<void> {
    if (!this.combinedStream) {
      throw new Error('No media stream available. Call startCamera() first.');
    }

    console.log('🔴 Starting optimized recording...');
    
    // CRITICAL: Verify audio tracks before recording
    const audioTracks = this.combinedStream.getAudioTracks();
    const videoTracks = this.combinedStream.getVideoTracks();
    
    console.log('🔍 PRE-RECORDING VERIFICATION:', {
      totalTracks: this.combinedStream.getTracks().length,
      audioTracks: audioTracks.length,
      videoTracks: videoTracks.length,
      audioEnabled: audioTracks.map(t => ({ enabled: t.enabled, readyState: t.readyState, label: t.label })),
      videoEnabled: videoTracks.map(t => ({ enabled: t.enabled, readyState: t.readyState, label: t.label })),
      streamActive: this.combinedStream.active
    });

    if (audioTracks.length === 0) {
      console.error('❌ RECORDING BLOCKED: No audio tracks in combined stream!');
      throw new Error('Keine Audio-Spur verfügbar. Mikrofonberechtigung erforderlich.');
    }

    if (videoTracks.length === 0) {
      console.error('❌ RECORDING BLOCKED: No video tracks in combined stream!');
      throw new Error('Keine Video-Spur verfügbar. Kameraberechtigung erforderlich.');
    }
    
    try {
      this.recordedChunks = [];

      // Test codec support with MP4 priority order
      let recordingConfig = this.config.recording;
      const supportedCodecs = [
        // H.264 MP4 - Primary format
        'video/mp4;codecs=avc1.42E01E,mp4a.40.2',
        'video/mp4;codecs=avc1.42E01E',
        'video/mp4',
        // WebM fallbacks
        'video/webm;codecs=h264,opus',
        'video/webm;codecs=vp8,opus',
        'video/webm;codecs=vp9,opus',
        'video/webm'
      ];

      let mimeType = recordingConfig.mimeType;
      if (!MediaRecorder.isTypeSupported(mimeType)) {
        console.warn(`🔄 Codec ${mimeType} not supported, trying MP4 fallbacks...`);
        mimeType = supportedCodecs.find(codec => MediaRecorder.isTypeSupported(codec)) || 'video/mp4';
        console.log(`✅ Using MP4 codec: ${mimeType}`);
      }

      // Create MediaRecorder with motion-artifact-resistant settings
      const recorderOptions: any = {
        mimeType: mimeType,
        videoBitsPerSecond: recordingConfig.videoBitsPerSecond,
        audioBitsPerSecond: recordingConfig.audioBitsPerSecond
      };

      // Add advanced options for motion handling if supported
      if (mimeType.includes('mp4') || mimeType.includes('h264')) {
        recorderOptions.videoKeyFrameIntervalDuration = 2000; // Keyframe every 2 seconds
        recorderOptions.videoBitrateMode = 'constant'; // Constant bitrate for consistent quality
      }

      this.mediaRecorder = new MediaRecorder(this.combinedStream, recorderOptions);

      this.mediaRecorder.ondataavailable = (event) => {
        if (event.data.size > 0) {
          this.recordedChunks.push(event.data);
          console.log('📊 Recording chunk:', event.data.size, 'bytes');
          
          if (this.onDataAvailable) {
            this.onDataAvailable(event.data);
          }
        }
      };

      this.mediaRecorder.onstop = () => {
        console.log('⏹️ Recording stopped, creating blob...');
        
        const videoBlob = new Blob(this.recordedChunks, {
          type: mimeType.split(';')[0]
        });
        
        console.log('📁 Video blob created:', {
          size: videoBlob.size,
          type: videoBlob.type,
          chunks: this.recordedChunks.length
        });

        if (this.onStop) {
          this.onStop(videoBlob);
        }
      };

      this.mediaRecorder.onerror = (event) => {
        console.error('❌ MediaRecorder error:', event);
        const error = new Error('Recording failed');
        
        if (this.onError) {
          this.onError(error);
        }
      };

      // Start recording with very frequent data collection to minimize artifacts
      this.mediaRecorder.start(250); // Collect data every 250ms for ultra-smooth motion
      console.log('✅ MP4 recording started with codec:', mimeType, 'at', recordingConfig.videoBitsPerSecond, 'bps');

    } catch (error) {
      console.error('❌ Failed to start recording:', error);
      throw new Error(`Failed to start recording: ${error}`);
    }
  }

  stopRecording(): void {
    if (this.mediaRecorder && this.mediaRecorder.state === 'recording') {
      console.log('⏹️ Stopping optimized recording...');
      this.mediaRecorder.stop();
    } else {
      console.warn('⚠️ MediaRecorder not in recording state');
    }
  }

  getRecordingState(): string {
    return this.mediaRecorder?.state || 'inactive';
  }

  isRecording(): boolean {
    return this.mediaRecorder?.state === 'recording';
  }

  getAudioAnalytics() {
    return this.audioProcessor.getAudioAnalytics();
  }

  // Callback setters
  setDataAvailableCallback(callback: (chunk: Blob) => void): void {
    this.onDataAvailable = callback;
  }

  setStopCallback(callback: (videoBlob: Blob) => void): void {
    this.onStop = callback;
  }

  setVoiceActivityCallback(callback: (isSpeaking: boolean, energy: number) => void): void {
    this.onVoiceActivity = callback;
  }

  setErrorCallback(callback: (error: Error) => void): void {
    this.onError = callback;
  }

  private cleanup(): void {
    console.log('🧹 Cleaning up optimized video recorder...');
    
    this.stopCamera();
    
    if (this.mediaRecorder) {
      this.mediaRecorder = null;
    }
    
    this.recordedChunks = [];
  }

  destroy(): void {
    this.stopRecording();
    this.cleanup();
  }
}

// Utility function for creating optimized constraints
export function createOptimizedConstraints(config: Partial<VideoRecorderConfig> = {}) {
  const fullConfig = {
    video: {
      width: 1280,
      height: 720,
      frameRate: 30,
      facingMode: 'user',
      ...config.video
    },
    audio: {
      sampleRate: 24000,
      channelCount: 1,
      echoCancellation: true,
      noiseSuppression: true,
      autoGainControl: true,
      suppressLocalAudioPlayback: true,
      latency: 0.01,
      volume: 1.0,
      ...config.audio
    }
  };

  return {
    video: {
      width: { ideal: fullConfig.video.width },
      height: { ideal: fullConfig.video.height },
      frameRate: { ideal: fullConfig.video.frameRate },
      facingMode: fullConfig.video.facingMode
    },
    audio: fullConfig.audio as any
  };
}