/**
 * Enhanced Audio Processing Utility for WebRTC
 * Provides optimized echo cancellation, noise suppression, and voice activity detection
 */

export interface AudioProcessorConfig {
  sampleRate: number;
  channelCount: number;
  echoCancellation: boolean;
  noiseSuppression: boolean;
  autoGainControl: boolean;
  vadThreshold: number;
  vadSilenceDuration: number;
}

export class VoiceActivityDetector {
  private readonly threshold: number;
  private readonly silenceDuration: number;
  private lastSpeechTime: number = 0;
  private isSpeaking: boolean = false;
  
  constructor(threshold: number = 0.01, silenceDuration: number = 1000) {
    this.threshold = threshold;
    this.silenceDuration = silenceDuration;
  }

  analyze(audioData: Float32Array): { isSpeaking: boolean; energy: number } {
    // Calculate RMS (Root Mean Square) energy
    let sum = 0;
    for (let i = 0; i < audioData.length; i++) {
      sum += audioData[i] * audioData[i];
    }
    const rms = Math.sqrt(sum / audioData.length);
    
    const currentTime = Date.now();
    
    if (rms > this.threshold) {
      this.lastSpeechTime = currentTime;
      if (!this.isSpeaking) {
        this.isSpeaking = true;
        console.log('Voice activity detected, energy:', rms);
      }
    } else {
      if (this.isSpeaking && currentTime - this.lastSpeechTime > this.silenceDuration) {
        this.isSpeaking = false;
        console.log('Voice activity ended after silence');
      }
    }
    
    return {
      isSpeaking: this.isSpeaking,
      energy: rms
    };
  }

  reset(): void {
    this.isSpeaking = false;
    this.lastSpeechTime = 0;
  }
}

export class AudioProcessor {
  private audioContext: AudioContext | null = null;
  private analyser: AnalyserNode | null = null;
  private source: MediaStreamAudioSourceNode | null = null;
  private processor: ScriptProcessorNode | null = null;
  private vad: VoiceActivityDetector;
  private config: AudioProcessorConfig;
  private onVoiceActivity?: (isSpeaking: boolean, energy: number) => void;

  constructor(config: Partial<AudioProcessorConfig> = {}) {
    this.config = {
      sampleRate: 24000,
      channelCount: 1,
      echoCancellation: true,
      noiseSuppression: true,
      autoGainControl: true,
      vadThreshold: 0.01,
      vadSilenceDuration: 1000,
      ...config
    };
    
    this.vad = new VoiceActivityDetector(
      this.config.vadThreshold,
      this.config.vadSilenceDuration
    );
  }

  async getOptimizedMediaStream(): Promise<MediaStream> {
    console.log('Requesting optimized media stream with config:', this.config);
    
    const constraints: MediaStreamConstraints = {
      audio: {
        sampleRate: this.config.sampleRate,
        channelCount: this.config.channelCount,
        echoCancellation: this.config.echoCancellation,
        noiseSuppression: this.config.noiseSuppression,
        autoGainControl: this.config.autoGainControl,
        // Additional WebRTC optimizations
        suppressLocalAudioPlayback: true, // Prevent local audio feedback
        latency: 0.01, // Low latency for real-time processing
        volume: 1.0
      } as any
    };

    try {
      const stream = await navigator.mediaDevices.getUserMedia(constraints);
      console.log('Media stream obtained successfully');
      
      // Log actual stream settings
      const audioTracks = stream.getAudioTracks();
      if (audioTracks.length > 0) {
        const settings = audioTracks[0].getSettings();
        console.log('Actual audio settings:', settings);
      }
      
      return stream;
    } catch (error) {
      console.error('Error getting media stream:', error);
      throw new Error(`Failed to access microphone: ${error}`);
    }
  }

  initializeAudioContext(stream: MediaStream): void {
    console.log('Initializing audio context for real-time processing');
    
    this.audioContext = new AudioContext({
      sampleRate: this.config.sampleRate,
      latencyHint: 'interactive'
    });

    // Create audio source from stream
    this.source = this.audioContext.createMediaStreamSource(stream);
    
    // Create analyser for real-time audio analysis
    this.analyser = this.audioContext.createAnalyser();
    this.analyser.fftSize = 512;
    this.analyser.smoothingTimeConstant = 0.3;
    
    // Create processor for voice activity detection
    this.processor = this.audioContext.createScriptProcessor(4096, 1, 1);
    
    this.processor.onaudioprocess = (event) => {
      const inputBuffer = event.inputBuffer;
      const inputData = inputBuffer.getChannelData(0);
      
      // Apply additional noise gate
      const processedData = this.applyNoiseGate(inputData, 0.005);
      
      // Perform voice activity detection
      const vadResult = this.vad.analyze(processedData);
      
      if (this.onVoiceActivity) {
        this.onVoiceActivity(vadResult.isSpeaking, vadResult.energy);
      }
    };

    // Connect audio nodes
    this.source.connect(this.analyser);
    this.analyser.connect(this.processor);
    this.processor.connect(this.audioContext.destination);
    
    console.log('Audio context initialized with real-time processing');
  }

  private applyNoiseGate(audioData: Float32Array, threshold: number): Float32Array {
    const processed = new Float32Array(audioData.length);
    
    for (let i = 0; i < audioData.length; i++) {
      const amplitude = Math.abs(audioData[i]);
      if (amplitude > threshold) {
        processed[i] = audioData[i];
      } else {
        processed[i] = 0; // Gate out noise below threshold
      }
    }
    
    return processed;
  }

  setVoiceActivityCallback(callback: (isSpeaking: boolean, energy: number) => void): void {
    this.onVoiceActivity = callback;
  }

  getAudioAnalytics(): { frequency: Uint8Array; timeDomain: Uint8Array } | null {
    if (!this.analyser) return null;
    
    const frequencyData = new Uint8Array(this.analyser.frequencyBinCount);
    const timeDomainData = new Uint8Array(this.analyser.frequencyBinCount);
    
    this.analyser.getByteFrequencyData(frequencyData);
    this.analyser.getByteTimeDomainData(timeDomainData);
    
    return {
      frequency: frequencyData,
      timeDomain: timeDomainData
    };
  }

  cleanup(): void {
    console.log('Cleaning up audio processor');
    
    if (this.source) {
      this.source.disconnect();
      this.source = null;
    }
    
    if (this.analyser) {
      this.analyser.disconnect();
      this.analyser = null;
    }
    
    if (this.processor) {
      this.processor.disconnect();
      this.processor = null;
    }
    
    if (this.audioContext && this.audioContext.state !== 'closed') {
      this.audioContext.close();
      this.audioContext = null;
    }
    
    this.vad.reset();
  }
}

export class OptimizedMediaRecorder {
  private mediaRecorder: MediaRecorder | null = null;
  private audioProcessor: AudioProcessor;
  private stream: MediaStream | null = null;
  private recordedChunks: Blob[] = [];
  private onDataAvailable?: (chunk: Blob) => void;
  private onStop?: (audioBlob: Blob) => void;
  private onVoiceActivity?: (isSpeaking: boolean, energy: number) => void;

  constructor(config: Partial<AudioProcessorConfig> = {}) {
    this.audioProcessor = new AudioProcessor(config);
  }

  async initialize(): Promise<void> {
    console.log('Initializing optimized media recorder');
    
    try {
      // Get optimized audio stream
      this.stream = await this.audioProcessor.getOptimizedMediaStream();
      
      // Initialize audio processing for real-time analysis
      this.audioProcessor.initializeAudioContext(this.stream);
      
      // Set up voice activity detection
      this.audioProcessor.setVoiceActivityCallback((isSpeaking, energy) => {
        if (this.onVoiceActivity) {
          this.onVoiceActivity(isSpeaking, energy);
        }
      });
      
      // Create MediaRecorder with optimized settings
      const options = {
        mimeType: 'audio/webm;codecs=opus',
        audioBitsPerSecond: 128000
      };
      
      this.mediaRecorder = new MediaRecorder(this.stream, options);
      
      this.mediaRecorder.ondataavailable = (event) => {
        if (event.data.size > 0) {
          this.recordedChunks.push(event.data);
          if (this.onDataAvailable) {
            this.onDataAvailable(event.data);
          }
        }
      };
      
      this.mediaRecorder.onstop = () => {
        const audioBlob = new Blob(this.recordedChunks, { type: 'audio/webm' });
        console.log('Recording stopped, blob size:', audioBlob.size);
        
        if (this.onStop) {
          this.onStop(audioBlob);
        }
        
        this.cleanup();
      };
      
      console.log('Optimized media recorder initialized successfully');
      
    } catch (error) {
      console.error('Failed to initialize media recorder:', error);
      throw error;
    }
  }

  startRecording(): void {
    if (!this.mediaRecorder) {
      throw new Error('Media recorder not initialized');
    }
    
    console.log('Starting optimized recording');
    this.recordedChunks = [];
    this.mediaRecorder.start(100); // Collect data every 100ms for better responsiveness
  }

  stopRecording(): void {
    if (this.mediaRecorder && this.mediaRecorder.state === 'recording') {
      console.log('Stopping recording');
      this.mediaRecorder.stop();
    }
  }

  setDataAvailableCallback(callback: (chunk: Blob) => void): void {
    this.onDataAvailable = callback;
  }

  setStopCallback(callback: (audioBlob: Blob) => void): void {
    this.onStop = callback;
  }

  setVoiceActivityCallback(callback: (isSpeaking: boolean, energy: number) => void): void {
    this.onVoiceActivity = callback;
  }

  getAudioAnalytics() {
    return this.audioProcessor.getAudioAnalytics();
  }

  private cleanup(): void {
    console.log('Cleaning up media recorder');
    
    if (this.stream) {
      this.stream.getTracks().forEach(track => {
        track.stop();
        console.log('Audio track stopped:', track.label);
      });
      this.stream = null;
    }
    
    this.audioProcessor.cleanup();
  }

  destroy(): void {
    this.stopRecording();
    this.cleanup();
  }
}