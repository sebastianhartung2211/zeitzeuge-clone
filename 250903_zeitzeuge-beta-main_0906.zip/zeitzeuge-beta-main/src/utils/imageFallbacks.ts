// Centralized image fallback system using Supabase storage
import { getCategoryThumbnail } from './categoryThumbnails';

const SUPABASE_STORAGE_BASE = 'https://fepcoqrfrkfiaftkkfht.supabase.co/storage/v1/object/public/videos/thumbnails';

// Get fallback image based on context
export const getFallbackImage = (type: 'placeholder' | 'video' | 'profile' | 'category', category?: string): string => {
  switch (type) {
    case 'placeholder':
      return `${SUPABASE_STORAGE_BASE}/Familie.png`;
    case 'video':
      return getCategoryThumbnail(category || 'Uncategorized', 0);
    case 'profile':
      return `${SUPABASE_STORAGE_BASE}/Familie.png`;
    case 'category':
      return getCategoryThumbnail(category || 'Uncategorized', 0);
    default:
      return `${SUPABASE_STORAGE_BASE}/Familie.png`;
  }
};

// Image error handler for React img elements
export const handleImageError = (e: React.SyntheticEvent<HTMLImageElement, Event>, fallbackType: 'placeholder' | 'video' | 'profile' | 'category' = 'placeholder', category?: string) => {
  const target = e.currentTarget;
  target.src = getFallbackImage(fallbackType, category);
};

// Preload image with fallback
export const getImageWithFallback = (src: string | undefined | null, fallbackType: 'placeholder' | 'video' | 'profile' | 'category' = 'placeholder', category?: string): string => {
  if (!src || src === '/placeholder.svg') {
    return getFallbackImage(fallbackType, category);
  }
  return src;
};