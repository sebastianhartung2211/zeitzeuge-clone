import { useState } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';

export interface VideoUploadData {
  title: string;
  description?: string;
  year: number;
  customDate?: string;
  questionContext?: {
    question: string;
    category: string;
    categoryId: string;
  };
}

export const useVideoStorage = () => {
  const [isUploading, setIsUploading] = useState(false);

  // Original upload function (kept for compatibility)
  const uploadVideo = async (videoBlob: Blob, videoData: VideoUploadData) => {
    console.log('🔍 FUNCTIONALITY TEST: Starting upload test...');
    setIsUploading(true);
    
    try {
      console.log('🚀 Starting video upload process...', {
        blobSize: videoBlob.size,
        blobType: videoBlob.type,
        title: videoData.title
      });
      
      // Validate blob
      if (!videoBlob || videoBlob.size === 0) {
        console.error('🔍 UPLOAD TEST FAILURE: Empty or invalid video blob');
        throw new Error('Video-Datei ist leer oder ungültig');
      }
      
      console.log('🔍 UPLOAD TEST: Blob validation passed');
      
      // Check if user is authenticated
      console.log('🔐 Checking user authentication...');
      const { data: { user }, error: authError } = await supabase.auth.getUser();
      
      if (authError || !user) {
        throw new Error('Benutzer ist nicht angemeldet. Bitte loggen Sie sich ein.');
      }

      console.log('User authenticated:', user.id);

      // Upload video file to storage - detect format from blob type
      const fileExtension = videoBlob.type.includes('mp4') ? 'mp4' : 
                           videoBlob.type.includes('webm') ? 'webm' : 'mp4';
      const fileName = `${user.id}/${Date.now()}_video.${fileExtension}`;
      
      console.log('📤 Uploading video file to storage...', { 
        fileName, 
        blobSize: videoBlob.size, 
        blobType: videoBlob.type,
        detectedExtension: fileExtension 
      });
      
      const { data: uploadData, error: uploadError } = await supabase.storage
        .from('videos')
        .upload(fileName, videoBlob, {
          cacheControl: '3600',
          upsert: false,
          contentType: videoBlob.type
        });

      if (uploadError) {
        console.error('Storage upload error:', uploadError);
        throw new Error(`Video-Upload fehlgeschlagen: ${uploadError.message}`);
      }

      console.log('Video uploaded to storage:', uploadData.path);

      // Get public URL for the video
      const { data: { publicUrl } } = supabase.storage
        .from('videos')
        .getPublicUrl(uploadData.path);

      console.log('Video public URL:', publicUrl);

      // Create video record in database
      console.log('Creating video record in database...');
      const { data: videoRecord, error: dbError } = await supabase
        .from('videos')
        .insert({
          user_id: user.id,
          title: videoData.title,
          description: videoData.description,
          video_url: publicUrl,
          status: 'processing',
          custom_date: videoData.customDate,
          category: videoData.questionContext?.category || null
        })
        .select()
        .single();

      if (dbError) {
        console.error('Database insert error:', dbError);
        throw new Error(`Datenbank-Fehler: ${dbError.message}`);
      }

      console.log('Video record created:', videoRecord.id);

      // Trigger coordinator agent to process the video
      console.log('Triggering coordinator agent...');
      const coordinatorResponse = await supabase.functions.invoke('coordinator-agent', {
        body: {
          videoId: videoRecord.id,
          action: 'process_video',
          userId: user.id,
          questionContext: videoData.questionContext
        }
      });

      if (coordinatorResponse.error) {
        console.error('Coordinator agent error:', coordinatorResponse.error);
        toast.error('Video wurde gespeichert, aber die Verarbeitung ist fehlgeschlagen.');
      } else {
        console.log('Coordinator agent response:', coordinatorResponse.data);
        toast.success('Video erfolgreich hochgeladen und wird verarbeitet!');
      }

      return videoRecord;

    } catch (error: any) {
      console.error('Video upload error:', error);
      toast.error(error.message || 'Video-Upload fehlgeschlagen');
      throw error;
    } finally {
      setIsUploading(false);
    }
  };

  // New optimistic upload function with background processing
  const uploadVideoOptimistic = async (videoBlob: Blob, videoData: VideoUploadData) => {
    console.log('🔍 OPTIMISTIC UPLOAD: Starting optimistic upload...');
    
    try {
      // Check authentication first
      const { data: { user }, error: authError } = await supabase.auth.getUser();
      if (authError || !user) {
        throw new Error('Benutzer ist nicht angemeldet. Bitte loggen Sie sich ein.');
      }

      // Create optimistic record immediately with 'processing' status
      const optimisticRecord = {
        id: crypto.randomUUID(), // Temporary ID
        user_id: user.id,
        title: videoData.title,
        description: videoData.description,
        video_url: 'processing...',
        status: 'processing' as const,
        custom_date: videoData.customDate,
        category: videoData.questionContext?.category || null,
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
        transcripts: [],
        thumbnail_url: null,
        duration: null,
        tags: []
      };

      // Show immediate success message
      toast.success('Video wird im Hintergrund gespeichert...');

      // Start background upload asynchronously (fire and forget)
      uploadVideoInBackground(videoBlob, videoData, optimisticRecord.id).catch(error => {
        console.error('Background upload failed:', error);
        toast.error('Hintergrund-Upload fehlgeschlagen. Video wird erneut versucht.');
      });

      // Return optimistic record immediately for UI update
      return optimisticRecord;

    } catch (error: any) {
      console.error('Optimistic upload error:', error);
      toast.error(error.message || 'Video-Upload fehlgeschlagen');
      throw error;
    }
  };

  // Background upload function (does not block UI)
  const uploadVideoInBackground = async (videoBlob: Blob, videoData: VideoUploadData, tempId: string) => {
    console.log('🔍 BACKGROUND UPLOAD: Starting background processing for tempId:', tempId);
    
    try {
      // Validate blob
      if (!videoBlob || videoBlob.size === 0) {
        throw new Error('Video-Datei ist leer oder ungültig');
      }

      // Get user authentication
      const { data: { user }, error: authError } = await supabase.auth.getUser();
      if (authError || !user) {
        throw new Error('Benutzer ist nicht angemeldet.');
      }

      // Upload video file to storage - detect format from blob type
      const fileExtension = videoBlob.type.includes('mp4') ? 'mp4' : 
                           videoBlob.type.includes('webm') ? 'webm' : 'mp4';
      const fileName = `${user.id}/${Date.now()}_video.${fileExtension}`;
      
      console.log('📤 Background: Uploading video file to storage...', { 
        fileName, 
        blobType: videoBlob.type,
        detectedExtension: fileExtension 
      });
      
      const { data: uploadData, error: uploadError } = await supabase.storage
        .from('videos')
        .upload(fileName, videoBlob, {
          cacheControl: '3600',
          upsert: false,
          contentType: videoBlob.type
        });

      if (uploadError) {
        throw new Error(`Video-Upload fehlgeschlagen: ${uploadError.message}`);
      }

      // Get public URL for the video
      const { data: { publicUrl } } = supabase.storage
        .from('videos')
        .getPublicUrl(uploadData.path);

      // Create video record in database
      console.log('Background: Creating video record in database...');
      const { data: videoRecord, error: dbError } = await supabase
        .from('videos')
        .insert({
          user_id: user.id,
          title: videoData.title,
          description: videoData.description,
          video_url: publicUrl,
          status: 'processing',
          custom_date: videoData.customDate,
          category: videoData.questionContext?.category || null
        })
        .select()
        .single();

      if (dbError) {
        throw new Error(`Datenbank-Fehler: ${dbError.message}`);
      }

      console.log('Background: Video record created:', videoRecord.id);

      // Trigger coordinator agent to process the video
      console.log('Background: Triggering coordinator agent...');
      const coordinatorResponse = await supabase.functions.invoke('coordinator-agent', {
        body: {
          videoId: videoRecord.id,
          action: 'process_video',
          userId: user.id,
          questionContext: videoData.questionContext
        }
      });

      if (coordinatorResponse.error) {
        console.error('Background: Coordinator agent error:', coordinatorResponse.error);
        toast.error('Video gespeichert, aber Verarbeitung fehlgeschlagen.');
      } else {
        console.log('Background: Coordinator agent response:', coordinatorResponse.data);
        toast.success('Video erfolgreich verarbeitet!');
      }

      return videoRecord;

    } catch (error: any) {
      console.error('Background upload error:', error);
      toast.error('Hintergrund-Upload fehlgeschlagen');
      throw error;
    }
  };

  return {
    uploadVideo,
    uploadVideoOptimistic,
    isUploading
  };
};