import { useEffect, useState, useCallback } from 'react';
import { supabase } from '@/integrations/supabase/client';

interface VideoStatusNotification {
  id: string;
  video_id: string;
  title: string;
  status: string;
  previous_status?: string;
  updated_at: string;
}

export function useVideoStatusSubscription(userId?: string) {
  const [statusUpdates, setStatusUpdates] = useState<VideoStatusNotification[]>([]);
  const [isConnected, setIsConnected] = useState(false);

  // Subscribe to real-time video status changes
  useEffect(() => {
    if (!userId) return;

    console.log('🔔 Setting up video status subscription for user:', userId);

    const channel = supabase
      .channel('video-status-updates')
      .on(
        'postgres_changes',
        {
          event: 'UPDATE',
          schema: 'public',
          table: 'videos',
          filter: `user_id=eq.${userId}`
        },
        (payload) => {
          console.log('📺 Video status update received:', payload);
          
          const { new: newRecord, old: oldRecord } = payload;
          
          // Only process actual status changes
          if (newRecord.status !== oldRecord?.status) {
            const notification: VideoStatusNotification = {
              id: `${newRecord.id}-${Date.now()}`,
              video_id: newRecord.id,
              title: newRecord.title,
              status: newRecord.status,
              previous_status: oldRecord?.status,
              updated_at: newRecord.updated_at
            };

            setStatusUpdates(prev => [notification, ...prev.slice(0, 9)]); // Keep last 10 updates
          }
        }
      )
      .on(
        'postgres_changes',
        {
          event: 'INSERT',
          schema: 'public',
          table: 'videos',
          filter: `user_id=eq.${userId}`
        },
        (payload) => {
          console.log('📺 New video created:', payload);
          
          const newRecord = payload.new;
          const notification: VideoStatusNotification = {
            id: `${newRecord.id}-${Date.now()}`,
            video_id: newRecord.id,
            title: newRecord.title,
            status: newRecord.status,
            updated_at: newRecord.updated_at
          };

          setStatusUpdates(prev => [notification, ...prev.slice(0, 9)]);
        }
      )
      .subscribe((status) => {
        console.log('🔔 Subscription status:', status);
        setIsConnected(status === 'SUBSCRIBED');
      });

    return () => {
      console.log('🔔 Unsubscribing from video status updates');
      supabase.removeChannel(channel);
      setIsConnected(false);
    };
  }, [userId]);

  // Clear old notifications
  const clearNotifications = useCallback(() => {
    setStatusUpdates([]);
  }, []);

  // Remove specific notification
  const removeNotification = useCallback((notificationId: string) => {
    setStatusUpdates(prev => prev.filter(n => n.id !== notificationId));
  }, []);

  // Get status display info
  const getStatusInfo = useCallback((status: string) => {
    switch (status) {
      case 'processing':
        return { 
          label: 'Verarbeitung läuft', 
          color: 'text-blue-600', 
          icon: '🔄' 
        };
      case 'completed':
        return { 
          label: 'Abgeschlossen', 
          color: 'text-green-600', 
          icon: '✅' 
        };
      case 'failed':
        return { 
          label: 'Fehlgeschlagen', 
          color: 'text-red-600', 
          icon: '❌' 
        };
      default:
        return { 
          label: status, 
          color: 'text-gray-600', 
          icon: '📹' 
        };
    }
  }, []);

  return {
    statusUpdates,
    isConnected,
    clearNotifications,
    removeNotification,
    getStatusInfo
  };
}