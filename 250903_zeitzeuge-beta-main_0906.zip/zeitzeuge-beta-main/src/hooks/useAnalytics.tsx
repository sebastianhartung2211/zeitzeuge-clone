import { useEffect } from 'react';
import { useLocation } from 'react-router-dom';
import { analytics } from '@/services/analytics';
import { useAuth } from './useAuth';

export const useAnalytics = () => {
  const location = useLocation();
  const { user } = useAuth();

  // Track page views
  useEffect(() => {
    const pageName = location.pathname === '/' ? 'dashboard' : location.pathname.slice(1);
    analytics.trackPageView(pageName);
  }, [location]);

  // Set user context when user changes
  useEffect(() => {
    if (user) {
      analytics.setUserContext(user.id, {
        // Only non-PII context
        hasProfile: true,
        userSince: new Date().toISOString()
      });
    } else {
      analytics.setUserContext(undefined);
    }
  }, [user]);

  return {
    trackEvent: analytics.trackEvent.bind(analytics),
    trackUserAction: analytics.trackUserAction.bind(analytics),
    trackVideoEvent: analytics.trackVideoEvent.bind(analytics),
    trackPerformance: analytics.trackPerformance.bind(analytics),
    trackError: analytics.trackError.bind(analytics)
  };
};