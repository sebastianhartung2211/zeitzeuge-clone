import { useEffect, useState } from 'react';
import { registerForPush } from '@/features/push/registerPush';
import { useMobileAuth } from './useMobileAuth';

export const usePushNotifications = () => {
  const [isRegistered, setIsRegistered] = useState(false);
  const [isRegistering, setIsRegistering] = useState(false);
  const { user } = useMobileAuth();

  useEffect(() => {
    // Auto-register when user is authenticated
    if (user && !isRegistered && !isRegistering) {
      handleRegister();
    }
  }, [user, isRegistered, isRegistering]);

  const handleRegister = async () => {
    if (isRegistering) return;
    
    try {
      setIsRegistering(true);
      const success = await registerForPush();
      setIsRegistered(success);
    } catch (error) {
      console.error('Push registration failed:', error);
      setIsRegistered(false);
    } finally {
      setIsRegistering(false);
    }
  };

  return {
    isRegistered,
    isRegistering,
    registerForPush: handleRegister
  };
};