import React, { createContext, useContext, useState, ReactNode } from 'react';

export interface RecordedStory {
  id: string;
  type: 'video' | 'text' | 'image';
  title: string;
  date: string;
  year: number;
  location?: string;
  participants?: string[];
  description?: string;
  videoUrl?: string;
  previewImage?: string;
  isUserGenerated: boolean;
  questions?: string[];
}

interface StoriesContextType {
  userStories: RecordedStory[];
  addStory: (story: Omit<RecordedStory, 'id'>) => void;
  updateStory: (id: string, updates: Partial<RecordedStory>) => void;
  deleteStory: (id: string) => void;
  moveStoryToYear: (id: string, newYear: number) => void;
}

const StoriesContext = createContext<StoriesContextType | undefined>(undefined);

export const StoriesProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [userStories, setUserStories] = useState<RecordedStory[]>([]);

  const addStory = (story: Omit<RecordedStory, 'id'>) => {
    const newStory: RecordedStory = {
      ...story,
      id: `user-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
    };
    setUserStories(prev => {
      // Check if story already exists to prevent duplicates
      const existingStory = prev.find(s => 
        s.title === newStory.title && 
        s.date === newStory.date &&
        s.type === newStory.type
      );
      
      if (existingStory) {
        console.log('Story already exists, not adding duplicate');
        return prev;
      }
      
      return [...prev, newStory];
    });
  };

  const updateStory = (id: string, updates: Partial<RecordedStory>) => {
    setUserStories(prev => prev.map(story => 
      story.id === id ? { ...story, ...updates } : story
    ));
  };

  const deleteStory = (id: string) => {
    setUserStories(prev => prev.filter(story => story.id !== id));
  };

  const moveStoryToYear = (id: string, newYear: number) => {
    setUserStories(prev => prev.map(story => 
      story.id === id ? { ...story, year: newYear, date: `${newYear}-01-01` } : story
    ));
  };

  return (
    <StoriesContext.Provider value={{
      userStories,
      addStory,
      updateStory,
      deleteStory,
      moveStoryToYear,
    }}>
      {children}
    </StoriesContext.Provider>
  );
};

export const useStories = () => {
  const context = useContext(StoriesContext);
  if (context === undefined) {
    throw new Error('useStories must be used within a StoriesProvider');
  }

  // Stories hook debugging
  React.useEffect(() => {
    console.log('📖 [STORIES HOOK DEBUG] User stories updated:', {
      userStoriesCount: context.userStories.length,
      userStories: context.userStories.map(s => ({ id: s.id, title: s.title, year: s.year })),
      timestamp: new Date().toISOString()
    });
  }, [context.userStories]);

  return context;
};