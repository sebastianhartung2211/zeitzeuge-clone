import { useEffect, useState } from 'react';
import { User, Session } from '@supabase/supabase-js';
import { supabase } from '@/lib/supabase';
import { handleDeepLink } from '@/features/auth/handleCallback';
import { App } from '@capacitor/app';

export const useMobileAuth = () => {
  const [user, setUser] = useState<User | null>(null);
  const [session, setSession] = useState<Session | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Set up auth state listener
    const { data: { subscription } } = supabase.auth.onAuthStateChange(
      (event, session) => {
        setSession(session);
        setUser(session?.user ?? null);
        setLoading(false);
      }
    );

    // Check for existing session
    supabase.auth.getSession().then(({ data: { session } }) => {
      setSession(session);
      setUser(session?.user ?? null);
      setLoading(false);
    });

    // Handle deep links on mobile
    const isMobile = typeof window !== 'undefined' && !!(window as any).Capacitor;
    
    if (isMobile) {
      App.addListener('appUrlOpen', async (event) => {
        if (event.url.startsWith('zeitzeuge://auth-callback')) {
          try {
            await handleDeepLink(event.url);
          } catch (error) {
            console.error('Deep link auth error:', error);
          }
        }
      });
    }

    return () => {
      subscription.unsubscribe();
      if (isMobile) {
        App.removeAllListeners();
      }
    };
  }, []);

  return { user, session, loading };
};