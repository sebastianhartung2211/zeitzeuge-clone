import { useEffect, useState, useCallback } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';

interface VideoStatusUpdate {
  id: string;
  status: string;
  title: string;
  updated_at: string;
}

interface VideoRecoveryState {
  isRecovering: boolean;
  lastRecovery: Date | null;
  recoveredCount: number;
}

export function useVideoRecovery() {
  const [recoveryState, setRecoveryState] = useState<VideoRecoveryState>({
    isRecovering: false,
    lastRecovery: null,
    recoveredCount: 0
  });
  const { toast } = useToast();

  // Automatic recovery for stuck videos
  const recoverStuckVideos = useCallback(async (options: { manual?: boolean } = {}) => {
    if (recoveryState.isRecovering) return;

    setRecoveryState(prev => ({ ...prev, isRecovering: true }));

    try {
      console.log('🔧 Starting video recovery process...');
      
      const { data, error } = await supabase.functions.invoke('video-recovery-agent', {
        body: {
          action: 'recover_stuck_videos',
          options: {
            timeoutMinutes: 15,
            batchSize: 10
          }
        }
      });

      if (error) throw error;

      const { recoveredCount = 0, failedCount = 0 } = data;

      setRecoveryState(prev => ({
        ...prev,
        isRecovering: false,
        lastRecovery: new Date(),
        recoveredCount: prev.recoveredCount + recoveredCount
      }));

      if (options.manual) {
        toast({
          title: "Video-Wiederherstellung abgeschlossen",
          description: `${recoveredCount} Videos wiederhergestellt, ${failedCount} fehlgeschlagen.`,
          variant: recoveredCount > 0 ? "default" : "destructive",
        });
      }

      console.log(`✅ Recovery completed: ${recoveredCount} recovered, ${failedCount} failed`);
      return { recoveredCount, failedCount };

    } catch (error) {
      console.error('Video recovery failed:', error);
      setRecoveryState(prev => ({ ...prev, isRecovering: false }));
      
      if (options.manual) {
        toast({
          title: "Wiederherstellung fehlgeschlagen",
          description: "Videos konnten nicht wiederhergestellt werden.",
          variant: "destructive",
        });
      }
      
      throw error;
    }
  }, [recoveryState.isRecovering, toast]);

  // Retry specific failed video
  const retryFailedVideo = useCallback(async (videoId: string) => {
    try {
      console.log(`🔄 Retrying failed video: ${videoId}`);
      
      const { data, error } = await supabase.functions.invoke('video-recovery-agent', {
        body: {
          action: 'retry_failed_video',
          videoId,
          options: { maxRetries: 3 }
        }
      });

      if (error) throw error;

      toast({
        title: "Video wird erneut verarbeitet",
        description: "Die Verarbeitung wurde neu gestartet.",
      });

      return data;

    } catch (error) {
      console.error('Failed to retry video:', error);
      toast({
        title: "Wiederholung fehlgeschlagen",
        description: "Video konnte nicht erneut verarbeitet werden.",
        variant: "destructive",
      });
      throw error;
    }
  }, [toast]);

  // Get system health status
  const getHealthStatus = useCallback(async () => {
    try {
      const { data, error } = await supabase.functions.invoke('video-recovery-agent', {
        body: { action: 'health_check' }
      });

      if (error) throw error;
      return data;

    } catch (error) {
      console.error('Health check failed:', error);
      return null;
    }
  }, []);

  // Automatic recovery on mount and interval
  useEffect(() => {
    // Run initial recovery after a short delay
    const initialTimer = setTimeout(() => {
      recoverStuckVideos().catch(console.error);
    }, 5000);

    // Set up periodic recovery (every 10 minutes)
    const recoveryInterval = setInterval(() => {
      recoverStuckVideos().catch(console.error);
    }, 10 * 60 * 1000);

    return () => {
      clearTimeout(initialTimer);
      clearInterval(recoveryInterval);
    };
  }, [recoverStuckVideos]);

  return {
    recoveryState,
    recoverStuckVideos: (options?: { manual?: boolean }) => recoverStuckVideos(options),
    retryFailedVideo,
    getHealthStatus
  };
}