import React, { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';

export interface VideoData {
  id: string;
  title: string;
  description?: string;
  video_url: string;
  thumbnail_url?: string;
  duration?: number;
  status: 'processing' | 'completed' | 'failed';
  category?: string;
  created_at: string;
  updated_at: string;
  year: number;
  date: string;
  type: 'video';
  isUserGenerated: boolean;
  transcripts?: Array<{
    content: string;
    language: string;
    confidence?: number;
  }>;
  tags?: Array<{
    name: string;
    category: string;
    relevance_score: number;
  }>;
}

export const useVideos = () => {
  const [videos, setVideos] = useState<VideoData[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const loadVideos = async () => {
    try {
      setLoading(true);
      setError(null);

      // Check if user is authenticated
      const { data: { user }, error: authError } = await supabase.auth.getUser();
      
      if (authError || !user) {
        console.log('No authenticated user, skipping video load');
        setVideos([]);
        return;
      }

      console.log('Loading videos for user:', user.id);

      // Fetch videos with related data
      const { data: videosData, error: videosError } = await supabase
        .from('videos')
        .select(`
          id,
          title,
          description,
          video_url,
          thumbnail_url,
          duration,
          status,
          category,
          created_at,
          updated_at,
          custom_date,
          transcripts (
            content,
            language,
            confidence
          ),
          video_tags (
            relevance_score,
            tags (
              name,
              category
            )
          )
        `)
        .eq('user_id', user.id)
        .order('created_at', { ascending: false });

      if (videosError) {
        console.error('Error loading videos:', videosError);
        setError(`Fehler beim Laden der Videos: ${videosError.message}`);
        return;
      }

      console.log('Loaded videos:', videosData);

      // Transform data to match interface
      const transformedVideos: VideoData[] = videosData.map(video => {
        const customDate = video.custom_date || video.created_at.split('T')[0];
        return {
          id: video.id,
          title: video.title,
          description: video.description || undefined,
          video_url: video.video_url,
          thumbnail_url: video.thumbnail_url || undefined,
          duration: video.duration || undefined,
          status: video.status as 'processing' | 'completed' | 'failed',
          category: video.category || undefined,
          created_at: video.created_at,
          updated_at: video.updated_at,
          year: new Date(customDate).getFullYear(),
          date: customDate,
          type: 'video' as const,
          isUserGenerated: true,
          transcripts: video.transcripts || [],
          tags: video.video_tags?.map((vt: any) => ({
            name: vt.tags.name,
            category: vt.tags.category,
            relevance_score: vt.relevance_score
          })) || []
        };
      });

      // Map questions to specific categories based on user requirements
      const questionToCategoryMap = new Map<string, string>([
        // Kindheit & Familie
        ['Wie sah ein ganz normaler Tag in deiner Kindheit aus?', 'Kindheit & Familie'],
        ['Welche Spiele hast du als Kind am liebsten gespielt?', 'Kindheit & Familie'],
        ['Gab es ein besonderes Haustier oder Tier, an das du dich erinnerst?', 'Kindheit & Familie'],
        ['Was haben deine Eltern dir beigebracht, das du nie vergessen hast?', 'Kindheit & Familie'],
        
        // Jugend & Schule
        ['Wie war deine Schulzeit – gab es ein Lieblingsfach oder einen Lehrer, der dir besonders in Erinnerung geblieben ist?', 'Jugend & Schule'],
        ['Was hast du in deiner Freizeit gemacht, als du ein Teenager warst?', 'Jugend & Schule'],
        ['Erinnerst du dich an deinen ersten Kinofilm oder das erste Konzert, auf dem du warst?', 'Jugend & Schule'],
        
        // Liebe & Beziehungen
        ['Wie hast du deine große Liebe kennengelernt?', 'Liebe & Beziehungen'],
        ['Was war das romantischste, was du je erlebt hast?', 'Liebe & Beziehungen'],
        ['Was würdest du jungen Menschen heute über Beziehungen und Ehe mitgeben?', 'Liebe & Beziehungen'],
        
        // Arbeit & Alltag
        ['Was war dein erster Job – und wie hast du dich dabei gefühlt?', 'Arbeit & Alltag'],
        ['Gab es eine Arbeit oder Aufgabe, auf die du besonders stolz bist?', 'Arbeit & Alltag'],
        ['Wie sah dein Alltag aus, als du berufstätig warst?', 'Arbeit & Alltag'],
        
        // Zuhause & Traditionen
        ['Welche Feste habt ihr in der Familie besonders gefeiert – und wie?', 'Zuhause & Traditionen'],
        ['Gab es typische Gerichte oder Rezepte, die in deiner Familie weitergegeben wurden?', 'Zuhause & Traditionen'],
        ['Wie sah dein Kinderzimmer oder dein erstes eigenes Zuhause aus?', 'Zuhause & Traditionen'],
        
        // Zeitgeschichte & Wandel
        ['Was war ein Ereignis in der Welt, das dich besonders bewegt oder beeinflusst hat?', 'Zeitgeschichte & Wandel'],
        ['Welche Veränderungen in der Welt hast du erlebt, die dich besonders erstaunt haben?', 'Zeitgeschichte & Wandel'],
        ['Was vermisst du von früher – und was findest du heute besser als damals?', 'Zeitgeschichte & Wandel'],
        
        // Erforderlich (not displayed on Erlebnisse page)
        ['Nehmen Sie sich auf, wie Sie zehn Sekunden lang still sitzen.', 'Erforderlich'],
        ['Sagen Sie: "Ich habe gerade keine Antwort darauf."', 'Erforderlich'],
        ['Sagen Sie Hallo!', 'Erforderlich'],
        ['Sagen Sie Auf Wiedersehen!', 'Erforderlich'],
        ['Reagieren Sie auf eine unhöfliche Frage.', 'Erforderlich']
      ]);

      const getCategoryFromTitle = (title: string): string => {
        // Direct mapping based on title/question
        const category = questionToCategoryMap.get(title);
        if (category) return category;
        
        // Fallback to keyword matching in title for partial matches
        const lowerTitle = title.toLowerCase();
        if (lowerTitle.includes('kindheit') || lowerTitle.includes('kind') || lowerTitle.includes('eltern') || lowerTitle.includes('spiele') || lowerTitle.includes('haustier')) {
          return 'Kindheit & Familie';
        }
        if (lowerTitle.includes('schule') || lowerTitle.includes('jugend') || lowerTitle.includes('teenager') || lowerTitle.includes('lieblingsfach') || lowerTitle.includes('lehrer') || lowerTitle.includes('kinofilm') || lowerTitle.includes('konzert') || lowerTitle.includes('freizeit')) {
          return 'Jugend & Schule';
        }
        if (lowerTitle.includes('liebe') || lowerTitle.includes('beziehung') || lowerTitle.includes('romantisch') || lowerTitle.includes('ehe') || lowerTitle.includes('kennengelernt')) {
          return 'Liebe & Beziehungen';
        }
        if (lowerTitle.includes('arbeit') || lowerTitle.includes('job') || lowerTitle.includes('beruf') || lowerTitle.includes('alltag') || lowerTitle.includes('stolz')) {
          return 'Arbeit & Alltag';
        }
        if (lowerTitle.includes('zuhause') || lowerTitle.includes('tradition') || lowerTitle.includes('fest') || lowerTitle.includes('kinderzimmer') || lowerTitle.includes('gerichte') || lowerTitle.includes('rezepte')) {
          return 'Zuhause & Traditionen';
        }
        if (lowerTitle.includes('veränderung') || lowerTitle.includes('wandel') || lowerTitle.includes('ereignis') || lowerTitle.includes('vermisst') || lowerTitle.includes('früher') || lowerTitle.includes('besser') || lowerTitle.includes('damals')) {
          return 'Zeitgeschichte & Wandel';
        }
        if (lowerTitle.includes('zehn sekunden') || lowerTitle.includes('hallo') || lowerTitle.includes('wiedersehen') || lowerTitle.includes('keine antwort')) {
          return 'Erforderlich';
        }
        
        return 'Personalisierte Themen';
      };

      const adjustedVideos: VideoData[] = transformedVideos.map(v => {
        const finalCat = getCategoryFromTitle(v.title);
        return { ...v, category: finalCat };
      });

      setVideos(adjustedVideos);

      // Persist corrections for Ingrid so DB matches UI
      if (user.email?.toLowerCase() === 'ingrid@zeitzeuge.eu') {
        const updates = adjustedVideos
          .filter((v, idx) => (v.category || null) !== (transformedVideos[idx].category || null))
          .map(v => supabase.from('videos').update({ category: v.category }).eq('id', v.id));
        if (updates.length) {
          Promise.allSettled(updates)
            .then(res => console.log('Persisted category corrections for Ingrid', res.length))
            .catch(e => console.error('Persisting category corrections failed', e));
        }
      }

      // Re-categorize existing videos only for Ingrid on first load (v2 - updated logic)
      if (user.email?.toLowerCase() === 'ingrid@zeitzeuge.eu') {
        const recatKey = `recat_done_v2_${user.id}`;
        if (!localStorage.getItem(recatKey)) {
          try {
            const resp = await supabase.functions.invoke('maintenance-recategorize', {
              body: { user_id: user.id }
            });
            console.log('Recategorization (Ingrid v2) result:', resp.data || resp.error);
            localStorage.setItem(recatKey, '1');
          } catch (e) {
            console.error('Recategorization invoke failed:', e);
          }
        }
      }

    } catch (err: any) {
      console.error('Error in loadVideos:', err);
      setError(err.message || 'Unbekannter Fehler beim Laden der Videos');
    } finally {
      setLoading(false);
    }
  };

  // Load videos on mount and when auth state changes
  useEffect(() => {
    loadVideos();

    // Subscribe to auth changes
    const { data: { subscription } } = supabase.auth.onAuthStateChange((event, session) => {
      console.log('Auth state changed:', event, session?.user?.id);
      loadVideos();
    });

    return () => {
      subscription.unsubscribe();
    };
  }, []);

  // Subscribe to real-time updates for videos
  useEffect(() => {
    const channel = supabase
      .channel('videos-updates')
      .on('postgres_changes', 
        { event: '*', schema: 'public', table: 'videos' },
        (payload) => {
          console.log('Video update received:', payload);
          loadVideos(); // Reload videos when changes occur
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, []);

  // Hook debugging
  React.useEffect(() => {
    console.log('🎬 [VIDEOS HOOK DEBUG] State updated:', {
      videosCount: videos.length,
      loading,
      error,
      timestamp: new Date().toISOString()
    });
  }, [videos, loading, error]);

  return {
    videos,
    loading,
    error,
    reload: loadVideos
  };
};