import { createClient } from '@supabase/supabase-js';

export const supabase = createClient(
  'https://fepcoqrfrkfiaftkkfht.supabase.co',
  'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImZlcGNvcXJmcmtmaWFmdGtrZmh0Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTMxNDU4NjUsImV4cCI6MjA2ODcyMTg2NX0.EA3jUpmXSlnMh_YYGNo3yWtZEcBdZ7JkRDSlSjALGdc',
  { auth: { flowType: 'pkce' } }
);