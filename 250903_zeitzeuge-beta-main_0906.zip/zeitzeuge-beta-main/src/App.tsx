import React from 'react';
import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route, Navigate, useLocation } from "react-router-dom";
import { AuthProvider } from "./hooks/useAuth";
import { StoriesProvider } from "./hooks/useStories";
import LoginPage from "./components/auth/LoginPage";
import Timeline from "./components/dashboard/Timeline";
import Profile from "./components/profile/Profile";
import NotFound from "./pages/NotFound";
import VideoRecordingPage from "./components/video/VideoRecordingPage";
import ConversationStarterPage from "./pages/ConversationStarterPage";
import ConversationPage from "./pages/ConversationPage";
import ImpressumPage from "./pages/ImpressumPage";
import DatenschutzPage from "./pages/DatenschutzPage";
import PrivacyPage from "./pages/PrivacyPage";
import TestingPage from "./pages/TestingPage";
import FamilyView from "@/features/family/FamilyView";
import ProtectedLayout from "./components/layout/ProtectedLayout";
import { PWAInstallPrompt } from "./components/pwa/PWAInstallPrompt";
import { ErrorBoundary } from "./components/debug/ErrorBoundary";

const queryClient = new QueryClient();

// Route change debugging component
const RouteDebugger = () => {
  const location = useLocation();
  
  React.useEffect(() => {
    console.log('🚀 [ROUTE DEBUG] Route changed to:', location.pathname, {
      search: location.search,
      hash: location.hash,
      state: location.state,
      timestamp: new Date().toISOString()
    });
  }, [location]);

  return null;
};

const App = () => {
  console.log('🔄 [APP DEBUG] App component rendering');
  
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <AuthProvider>
          <StoriesProvider>
            <Toaster />
            <Sonner />
            <PWAInstallPrompt />
            <BrowserRouter>
              <RouteDebugger />
              <Routes>
                <Route path="/" element={<Navigate to="/app/timeline" replace />} />
                <Route path="/login" element={<LoginPage />} />
                
                <Route path="/app" element={<ProtectedLayout />}>
                  <Route index element={<Navigate to="/app/timeline" replace />} />
                  <Route path="timeline" element={<Timeline />} />
                  <Route path="family" element={
                    <ErrorBoundary>
                      <FamilyView />
                    </ErrorBoundary>
                  } />
                  <Route path="record" element={<VideoRecordingPage />} />
                  <Route path="profile" element={<Profile />} />
                  <Route path="conversation-starter" element={<ConversationStarterPage />} />
                  <Route path="conversation" element={<ConversationPage />} />
                </Route>
                
                <Route path="/impressum" element={<ImpressumPage />} />
                <Route path="/datenschutz" element={<DatenschutzPage />} />
                <Route path="/privacy" element={<PrivacyPage />} />
                <Route path="/testing" element={<TestingPage />} />
                <Route path="*" element={<NotFound />} />
              </Routes>
            </BrowserRouter>
          </StoriesProvider>
        </AuthProvider>
      </TooltipProvider>
    </QueryClientProvider>
  );
};

export default App;