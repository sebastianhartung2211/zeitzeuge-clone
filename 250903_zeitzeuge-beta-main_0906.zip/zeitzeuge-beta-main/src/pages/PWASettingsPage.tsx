import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { PWAStatus } from '@/components/pwa/PWAStatus';
import { NotificationSettings } from '@/components/settings/NotificationSettings';
import { Separator } from '@/components/ui/separator';

const PWASettingsPage = () => {
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50">
      <div className="container mx-auto px-4 py-8 max-w-4xl">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">
            App Einstellungen
          </h1>
          <p className="text-gray-600">
            Verwalten Sie Progressive Web App Features und Benachrichtigungen
          </p>
        </div>

        <div className="grid gap-6 md:grid-cols-2">
          <PWAStatus />
          
          <Card>
            <CardHeader>
              <CardTitle>Offline-Funktionen</CardTitle>
              <CardDescription>
                Ihre App funktioniert auch ohne Internetverbindung
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <div className="flex items-center justify-between text-sm">
                  <span>Statische Inhalte:</span>
                  <span className="text-green-600 font-medium">✓ Gecacht</span>
                </div>
                <div className="flex items-center justify-between text-sm">
                  <span>Video-Uploads:</span>
                  <span className="text-green-600 font-medium">✓ Retry-Queue</span>
                </div>
                <div className="flex items-center justify-between text-sm">
                  <span>Grundfunktionen:</span>
                  <span className="text-green-600 font-medium">✓ Verfügbar</span>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        <Separator className="my-8" />

        <div className="space-y-6">
          <NotificationSettings />
        </div>

        <Separator className="my-8" />

        <Card>
          <CardHeader>
            <CardTitle>Progressive Web App Info</CardTitle>
            <CardDescription>
              Technische Details und Vorteile
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid gap-4 md:grid-cols-2">
              <div>
                <h4 className="font-medium mb-2">Web-Vorteile:</h4>
                <ul className="text-sm text-muted-foreground space-y-1">
                  <li>• Keine App Store Installation nötig</li>
                  <li>• Automatische Updates</li>
                  <li>• Plattformübergreifend</li>
                  <li>• Sofortige Verfügbarkeit</li>
                </ul>
              </div>
              <div>
                <h4 className="font-medium mb-2">App-Funktionen:</h4>
                <ul className="text-sm text-muted-foreground space-y-1">
                  <li>• Offline-Unterstützung</li>
                  <li>• Native App Gefühl</li>
                  <li>• Push-Benachrichtigungen</li>
                  <li>• Hintergrund-Synchronisation</li>
                </ul>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default PWASettingsPage;