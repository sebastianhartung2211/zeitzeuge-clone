import React from 'react';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { ArrowLeft } from 'lucide-react';
import TopNavigation from '@/components/navigation/TopNavigation';

const ImpressumPage = () => {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-background">
      <TopNavigation />
      
      <div className="max-w-4xl mx-auto px-4 py-8">
        <div className="mb-6">
          <Button
            onClick={() => navigate(-1)}
            variant="ghost"
            className="mb-4"
          >
            <ArrowLeft className="h-4 w-4 mr-2" />
            Zurück
          </Button>
          
          <h1 className="text-3xl font-bold text-[hsl(var(--navy))] mb-2">
            Impressum
          </h1>
          <p className="text-gray-600">
            Rechtliche Angaben gemäß § 5 TMG
          </p>
        </div>

        <Card className="p-6 space-y-6">
          <section>
            <h2 className="text-xl font-semibold text-[hsl(var(--navy))] mb-3">
              Angaben gemäß § 5 TMG
            </h2>
            <div className="space-y-2 text-gray-700">
              <p><strong>Betreiber:</strong> Zeitzeuge Platform</p>
              <p><strong>Adresse:</strong> Musterstraße 123, 12345 Musterstadt, Deutschland</p>
              <p><strong>Telefon:</strong> +49 (0) 123 456 789</p>
              <p><strong>E-Mail:</strong> kontakt@zeitzeuge.de</p>
            </div>
          </section>

          <section>
            <h2 className="text-xl font-semibold text-[hsl(var(--navy))] mb-3">
              Vertreten durch
            </h2>
            <div className="space-y-2 text-gray-700">
              <p><strong>Geschäftsführer:</strong> Max Mustermann</p>
            </div>
          </section>

          <section>
            <h2 className="text-xl font-semibold text-[hsl(var(--navy))] mb-3">
              Registereintrag
            </h2>
            <div className="space-y-2 text-gray-700">
              <p><strong>Registergericht:</strong> Amtsgericht Musterstadt</p>
              <p><strong>Registernummer:</strong> HRB 12345</p>
            </div>
          </section>

          <section>
            <h2 className="text-xl font-semibold text-[hsl(var(--navy))] mb-3">
              Umsatzsteuer-ID
            </h2>
            <div className="space-y-2 text-gray-700">
              <p>Umsatzsteuer-Identifikationsnummer gemäß §27 a Umsatzsteuergesetz:</p>
              <p><strong>DE123456789</strong></p>
            </div>
          </section>

          <section>
            <h2 className="text-xl font-semibold text-[hsl(var(--navy))] mb-3">
              Haftungsausschluss
            </h2>
            <div className="space-y-4 text-gray-700">
              <div>
                <h3 className="font-medium mb-2">Haftung für Inhalte</h3>
                <p className="text-sm">
                  Als Diensteanbieter sind wir gemäß § 7 Abs.1 TMG für eigene Inhalte auf diesen Seiten nach den allgemeinen Gesetzen verantwortlich. Nach §§ 8 bis 10 TMG sind wir als Diensteanbieter jedoch nicht unter der Verpflichtung, übermittelte oder gespeicherte fremde Informationen zu überwachen oder nach Umständen zu forschen, die auf eine rechtswidrige Tätigkeit hinweisen.
                </p>
              </div>
              
              <div>
                <h3 className="font-medium mb-2">Haftung für Links</h3>
                <p className="text-sm">
                  Unser Angebot enthält Links zu externen Websites Dritter, auf deren Inhalte wir keinen Einfluss haben. Deshalb können wir für diese fremden Inhalte auch keine Gewähr übernehmen. Für die Inhalte der verlinkten Seiten ist stets der jeweilige Anbieter oder Betreiber der Seiten verantwortlich.
                </p>
              </div>
            </div>
          </section>

          <section>
            <h2 className="text-xl font-semibold text-[hsl(var(--navy))] mb-3">
              Urheberrecht
            </h2>
            <div className="text-gray-700">
              <p className="text-sm">
                Die durch die Seitenbetreiber erstellten Inhalte und Werke auf diesen Seiten unterliegen dem deutschen Urheberrecht. Die Vervielfältigung, Bearbeitung, Verbreitung und jede Art der Verwertung außerhalb der Grenzen des Urheberrechtes bedürfen der schriftlichen Zustimmung des jeweiligen Autors bzw. Erstellers.
              </p>
            </div>
          </section>
        </Card>
      </div>
    </div>
  );
};

export default ImpressumPage;