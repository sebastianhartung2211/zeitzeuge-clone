import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { EmbeddingManager } from "@/components/optimization/EmbeddingManager";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  Zap, 
  BarChart3, 
  Settings, 
  Database,
  Brain,
  Target
} from "lucide-react";
import { Badge } from "@/components/ui/badge";

export const OptimizationPage: React.FC = () => {
  return (
    <div className="container mx-auto p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center gap-3 mb-6">
        <div className="p-2 bg-gradient-to-r from-blue-500 to-purple-600 rounded-lg">
          <Brain className="h-6 w-6 text-white" />
        </div>
        <div>
          <h1 className="text-2xl font-bold">KI-Optimierung</h1>
          <p className="text-gray-600">
            Verwalten und optimieren Sie die Qualität Ihrer Konversations-KI
          </p>
        </div>
        <Badge variant="secondary" className="ml-auto">
          V4 Optimiert
        </Badge>
      </div>

      {/* Key Metrics Overview */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-green-100 rounded-lg">
                <Target className="h-5 w-5 text-green-600" />
              </div>
              <div>
                <div className="text-2xl font-bold text-green-600">80%</div>
                <div className="text-sm text-gray-500">Ziel-Genauigkeit</div>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-blue-100 rounded-lg">
                <Zap className="h-5 w-5 text-blue-600" />
              </div>
              <div>
                <div className="text-2xl font-bold text-blue-600">V4</div>
                <div className="text-sm text-gray-500">Pipeline Version</div>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-purple-100 rounded-lg">
                <BarChart3 className="h-5 w-5 text-purple-600" />
              </div>
              <div>
                <div className="text-2xl font-bold text-purple-600">Live</div>
                <div className="text-sm text-gray-500">Monitoring</div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Main Content Tabs */}
      <Tabs defaultValue="embeddings" className="space-y-6">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="embeddings" className="flex items-center gap-2">
            <Database className="h-4 w-4" />
            Embeddings
          </TabsTrigger>
          <TabsTrigger value="quality" className="flex items-center gap-2">
            <Target className="h-4 w-4" />
            Qualität
          </TabsTrigger>
          <TabsTrigger value="analytics" className="flex items-center gap-2">
            <BarChart3 className="h-4 w-4" />
            Analytics
          </TabsTrigger>
          <TabsTrigger value="settings" className="flex items-center gap-2">
            <Settings className="h-4 w-4" />
            Einstellungen
          </TabsTrigger>
        </TabsList>

        <TabsContent value="embeddings" className="space-y-6">
          <EmbeddingManager />
        </TabsContent>

        <TabsContent value="quality" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Target className="h-5 w-5" />
                Qualitäts-Metriken
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                {/* Quality Improvements */}
                <div>
                  <h3 className="font-semibold mb-3">Implementierte Verbesserungen</h3>
                  <div className="space-y-2">
                    <div className="flex items-center gap-2 text-sm">
                      <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                      Enhanced Hybrid Search (60% Semantic + 25% BM25 + 15% Category)
                    </div>
                    <div className="flex items-center gap-2 text-sm">
                      <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                      Query Expansion mit deutschen Synonymen
                    </div>
                    <div className="flex items-center gap-2 text-sm">
                      <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                      Intent Classification (biografisch, temporal, emotional, faktisch)
                    </div>
                    <div className="flex items-center gap-2 text-sm">
                      <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                      Optimized Transcript Chunking (512 tokens, 15% overlap)
                    </div>
                    <div className="flex items-center gap-2 text-sm">
                      <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                      Advanced LLM Cross-Encoder Reranking
                    </div>
                    <div className="flex items-center gap-2 text-sm">
                      <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                      Response Quality Validation
                    </div>
                    <div className="flex items-center gap-2 text-sm">
                      <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                      Feedback Collection System
                    </div>
                  </div>
                </div>

                {/* Key Performance Indicators */}
                <div>
                  <h3 className="font-semibold mb-3">Leistungsindikatoren</h3>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="p-4 border rounded-lg">
                      <div className="text-lg font-bold text-blue-600">≥ 65%</div>
                      <div className="text-sm text-gray-500">Min. Konfidenz-Schwelle</div>
                    </div>
                    <div className="p-4 border rounded-lg">
                      <div className="text-lg font-bold text-green-600">25</div>
                      <div className="text-sm text-gray-500">Top-K Kandidaten</div>
                    </div>
                    <div className="p-4 border rounded-lg">
                      <div className="text-lg font-bold text-purple-600">12</div>
                      <div className="text-sm text-gray-500">Rerank Top-K</div>
                    </div>
                    <div className="p-4 border rounded-lg">
                      <div className="text-lg font-bold text-orange-600">1536</div>
                      <div className="text-sm text-gray-500">Embedding Dimensionen</div>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="analytics" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <BarChart3 className="h-5 w-5" />
                Performance Analytics
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-center py-12">
                <BarChart3 className="h-12 w-12 mx-auto text-gray-400 mb-4" />
                <h3 className="text-lg font-semibold mb-2">Analytics Dashboard</h3>
                <p className="text-gray-500 mb-4">
                  Detaillierte Leistungsanalysen und Feedback-Auswertungen werden hier angezeigt.
                </p>
                <p className="text-sm text-gray-400">
                  Verfügbar in zukünftigen Updates
                </p>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="settings" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Settings className="h-5 w-5" />
                Optimierungs-Einstellungen
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                <div>
                  <h3 className="font-semibold mb-3">Aktuelle Konfiguration</h3>
                  <div className="space-y-3 text-sm">
                    <div className="flex justify-between">
                      <span>Embedding Model:</span>
                      <code className="bg-gray-100 px-2 py-1 rounded">text-embedding-3-small</code>
                    </div>
                    <div className="flex justify-between">
                      <span>Similarity Threshold:</span>
                      <code className="bg-gray-100 px-2 py-1 rounded">0.65</code>
                    </div>
                    <div className="flex justify-between">
                      <span>Chunk Size:</span>
                      <code className="bg-gray-100 px-2 py-1 rounded">512 tokens</code>
                    </div>
                    <div className="flex justify-between">
                      <span>Chunk Overlap:</span>
                      <code className="bg-gray-100 px-2 py-1 rounded">15%</code>
                    </div>
                    <div className="flex justify-between">
                      <span>Language:</span>
                      <code className="bg-gray-100 px-2 py-1 rounded">Deutsch (de)</code>
                    </div>
                  </div>
                </div>

                <div>
                  <h3 className="font-semibold mb-3">Erweiterte Features</h3>
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <span>Query Expansion</span>
                      <Badge variant="default" className="bg-green-100 text-green-800">Aktiv</Badge>
                    </div>
                    <div className="flex items-center justify-between">
                      <span>Intent Classification</span>
                      <Badge variant="default" className="bg-green-100 text-green-800">Aktiv</Badge>
                    </div>
                    <div className="flex items-center justify-between">
                      <span>Response Validation</span>
                      <Badge variant="default" className="bg-green-100 text-green-800">Aktiv</Badge>
                    </div>
                    <div className="flex items-center justify-between">
                      <span>Feedback Collection</span>
                      <Badge variant="default" className="bg-green-100 text-green-800">Aktiv</Badge>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};