import React, { useState, useRef, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card } from '@/components/ui/card';
import { Textarea } from '@/components/ui/textarea';
import { Mic, Keyboard, Home, Lightbulb, TestTube, X } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/hooks/useAuth';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';
import { OptimizedMediaRecorder } from '@/utils/AudioProcessor';
import { TranscriptTester } from '@/components/testing/TranscriptTester';
import { VideoReprocessor } from '@/components/video/VideoReprocessor';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';

const ConversationPage = () => {
  const navigate = useNavigate();
  const { user } = useAuth();
  const { toast } = useToast();
  const [isListening, setIsListening] = useState(false);
  const [showKeyboard, setShowKeyboard] = useState(false);
  const [showHints, setShowHints] = useState(false);
  const [question, setQuestion] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [currentVideoUrl, setCurrentVideoUrl] = useState('https://fepcoqrfrkfiaftkkfht.supabase.co/storage/v1/object/public/videos/e188dfde-b523-4b15-889a-8ba2d32e6aec/1755591207875_video.mp4');
  const [isProcessing, setIsProcessing] = useState(false);
  const [voiceEnergy, setVoiceEnergy] = useState(0);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [lastAnswer, setLastAnswer] = useState('');
  const [showAnswer, setShowAnswer] = useState(false);
  const [showTester, setShowTester] = useState(false);
  const micButtonRef = useRef<HTMLButtonElement>(null);
  const videoRef = useRef<HTMLVideoElement>(null);
  const optimizedRecorderRef = useRef<OptimizedMediaRecorder | null>(null);

  // Default loop video URL
  const defaultVideoUrl = 'https://fepcoqrfrkfiaftkkfht.supabase.co/storage/v1/object/public/videos/e188dfde-b523-4b15-889a-8ba2d32e6aec/1755591207875_video.mp4';

  const questionCategories = [
    {
      id: 'required',
      title: 'Erforderlich',
      color: 'coral-bg',
      questions: [
        'Nehmen Sie sich auf, wie Sie zehn Sekunden lang still sitzen.',
        'Sagen Sie: "Ich habe gerade keine Antwort darauf."',
        'Sagen Sie Hallo!',
        'Sagen Sie Auf Wiedersehen!',
        'Reagieren Sie auf eine unhöfliche Frage.'
      ]
    },
    {
      id: 'childhood',
      title: 'Kindheit & Familie',
      color: 'yellow-bg',
      questions: [
        'Wie sah ein ganz normaler Tag in deiner Kindheit aus?',
        'Welche Spiele hast du als Kind am liebsten gespielt?',
        'Gab es ein besonderes Haustier oder Tier, an das du dich erinnerst?',
        'Was haben deine Eltern dir beigebracht, das du nie vergessen hast?'
      ]
    },
    {
      id: 'youth',
      title: 'Jugend & Schule',
      color: 'yellow-bg',
      questions: [
        'Wie war deine Schulzeit – gab es ein Lieblingsfach oder einen Lehrer, der dir besonders in Erinnerung geblieben ist?',
        'Was hast du in deiner Freizeit gemacht, als du ein Teenager warst?',
        'Erinnerst du dich an deinen ersten Kinofilm oder das erste Konzert, auf dem du warst?'
      ]
    },
    {
      id: 'love',
      title: 'Liebe & Beziehungen',
      color: 'yellow-bg',
      questions: [
        'Wie hast du deine große Liebe kennengelernt?',
        'Was war das romantischste, was du je erlebt hast?',
        'Was würdest du jungen Menschen heute über Beziehungen und Ehe mitgeben?'
      ]
    },
    {
      id: 'work',
      title: 'Arbeit & Alltag',
      color: 'yellow-bg',
      questions: [
        'Was war dein erster Job – und wie hast du dich dabei gefühlt?',
        'Gab es eine Arbeit oder Aufgabe, auf die du besonders stolz bist?',
        'Wie sah dein Alltag aus, als du berufstätig warst?'
      ]
    },
    {
      id: 'traditions',
      title: 'Zuhause & Traditionen',
      color: 'yellow-bg',
      questions: [
        'Welche Feste habt ihr in der Familie besonders gefeiert – und wie?',
        'Gab es typische Gerichte oder Rezepte, die in deiner Familie weitergegeben wurden?',
        'Wie sah dein Kinderzimmer oder dein erstes eigenes Zuhause aus?'
      ]
    },
    {
      id: 'history',
      title: 'Zeitgeschichte & Wandel',
      color: 'yellow-bg',
      questions: [
        'Was war ein Ereignis in der Welt, das dich besonders bewegt oder beeinflusst hat?',
        'Welche Veränderungen in der Welt hast du erlebt, die dich besonders erstaunt haben?',
        'Was vermisst du von früher – und was findest du heute besser als damals?'
      ]
    }
  ];

  // Initialize optimized audio recorder on component mount
  useEffect(() => {
    const initializeRecorder = async () => {
      try {
        // Desktop: Use OptimizedMediaRecorder
        if (!isMobileDevice()) {
          const recorder = new OptimizedMediaRecorder({
            sampleRate: 24000,
            channelCount: 1,
            echoCancellation: true,
            noiseSuppression: true,
            autoGainControl: true,
            vadThreshold: 0.008,
            vadSilenceDuration: 800
          });

          recorder.setVoiceActivityCallback((speaking, energy) => {
            setIsSpeaking(speaking);
            setVoiceEnergy(energy);
            console.log('Voice activity:', { speaking, energy: energy.toFixed(4) });
          });

          recorder.setStopCallback(async (audioBlob) => {
            console.log('✅ DESKTOP - Audio recording completed, size:', audioBlob.size);
            await processAudioQuestion(audioBlob);
          });

          optimizedRecorderRef.current = recorder;
          console.log('✅ DESKTOP - OptimizedMediaRecorder initialized');
          
        } else {
          // Mobile: Use native MediaRecorder fallback
          console.log('📱 MOBILE BUGFIX - Initializing native MediaRecorder fallback...');
          
          const stream = await navigator.mediaDevices.getUserMedia({ 
            audio: {
              echoCancellation: true,
              noiseSuppression: true,
              autoGainControl: true,
              sampleRate: 24000
            } 
          });
          
          const mediaRecorder = new MediaRecorder(stream, {
            mimeType: 'audio/webm;codecs=opus'
          });
          
          let audioChunks: Blob[] = [];
          
          mediaRecorder.ondataavailable = (event) => {
            if (event.data.size > 0) {
              audioChunks.push(event.data);
              console.log('📱 MOBILE BUGFIX - Audio chunk:', event.data.size);
            }
          };
          
          mediaRecorder.onstop = async () => {
            console.log('📱 MOBILE BUGFIX - Recording stopped, processing...');
            if (audioChunks.length > 0) {
              const audioBlob = new Blob(audioChunks, { type: 'audio/webm' });
              console.log('📱 MOBILE BUGFIX - Created audio blob:', audioBlob.size);
              audioChunks = [];
              await processAudioQuestion(audioBlob);
            } else {
              console.error('📱 MOBILE BUGFIX - No audio data captured');
              toast({
                title: "Aufnahme-Fehler",
                description: "Keine Audiodaten empfangen. Versuchen Sie es erneut.",
                variant: "destructive",
              });
            }
          };
          
          // Store mobile recorder globally for access
          (window as any).mobileRecorder = {
            mediaRecorder,
            stream,
            audioChunks: () => audioChunks,
            start: () => {
              audioChunks = [];
              mediaRecorder.start(100);
              console.log('📱 MOBILE BUGFIX - Native recording started');
            },
            stop: () => {
              if (mediaRecorder.state === 'recording') {
                mediaRecorder.stop();
                console.log('📱 MOBILE BUGFIX - Native recording stopped');
              }
            }
          };
          
          console.log('📱 MOBILE BUGFIX - Native MediaRecorder initialized successfully');
        }
        
      } catch (error) {
        console.error('Failed to initialize recorder:', error);
      }
    };

    initializeRecorder();

    // Cleanup on unmount
    return () => {
      if (optimizedRecorderRef.current) {
        optimizedRecorderRef.current.destroy();
      }
      
      if ((window as any).mobileRecorder) {
        const mobile = (window as any).mobileRecorder;
        if (mobile.stream) {
          mobile.stream.getTracks().forEach((track: MediaStreamTrack) => track.stop());
        }
      }
    };
  }, []);

  // Optimized audio recording functions
  const startAudioRecording = async () => {
    if (!user) {
      toast({
        title: "Anmeldung erforderlich",
        description: "Bitte melden Sie sich an, um Fragen zu stellen.",
        variant: "destructive",
      });
      return;
    }

    try {
      if (isMobileDevice()) {
        // Use mobile native MediaRecorder
        const mobileRecorder = (window as any).mobileRecorder;
        if (mobileRecorder) {
          console.log('📱 MOBILE BUGFIX - Starting native recording...');
          mobileRecorder.start();
          setIsListening(true);
        } else {
          throw new Error('Mobile recorder not initialized');
        }
      } else {
        // Use OptimizedMediaRecorder for desktop
        if (!optimizedRecorderRef.current) {
          throw new Error('Audio-System nicht bereit');
        }
        
        console.log('✅ DESKTOP - Starting optimized recording...');
        await optimizedRecorderRef.current.initialize();
        optimizedRecorderRef.current.startRecording();
        setIsListening(true);
      }
    } catch (error) {
      console.error('Error starting audio recording:', error);
      toast({
        title: "Mikrofon-Fehler",
        description: "Mikrofon konnte nicht aktiviert werden. Prüfen Sie die Berechtigungen.",
        variant: "destructive",
      });
    }
  };

  const stopAudioRecording = () => {
    try {
      if (isMobileDevice()) {
        // Use mobile native MediaRecorder
        const mobileRecorder = (window as any).mobileRecorder;
        if (mobileRecorder && isListening) {
          console.log('📱 MOBILE BUGFIX - Stopping native recording...');
          mobileRecorder.stop();
          setIsListening(false);
          setIsSpeaking(false);
          setVoiceEnergy(0);
        }
      } else {
        // Use OptimizedMediaRecorder for desktop
        if (optimizedRecorderRef.current && isListening) {
          console.log('✅ DESKTOP - Stopping optimized recording...');
          optimizedRecorderRef.current.stopRecording();
          setIsListening(false);
          setIsSpeaking(false);
          setVoiceEnergy(0);
        }
      }
    } catch (error) {
      console.error('Error stopping audio recording:', error);
      toast({
        title: "Audio-Fehler", 
        description: "Aufnahme konnte nicht gestoppt werden.",
        variant: "destructive",
      });
      setIsListening(false);
      setIsSpeaking(false);
      setVoiceEnergy(0);
    }
  };

  const handleMicMouseDown = (e: React.MouseEvent | React.TouchEvent) => {
    e.preventDefault();
    startAudioRecording();
  };

  const handleMicMouseUp = (e: React.MouseEvent | React.TouchEvent) => {
    e.preventDefault();
    stopAudioRecording();
  };

  const handleMicTouchStart = (e: React.TouchEvent) => {
    e.preventDefault();
    e.stopPropagation();
    startAudioRecording();
  };

  const handleMicTouchEnd = (e: React.TouchEvent) => {
    e.preventDefault();
    e.stopPropagation();
    stopAudioRecording();
  };

  const handleKeyboardClick = () => {
    setShowKeyboard(!showKeyboard);
  };

  const toggleHints = () => {
    setShowHints(!showHints);
  };

  const handleQuestionSubmit = async () => {
    if (question.trim() && user) {
      await processTextQuestion(question.trim());
      setQuestion('');
      setShowKeyboard(false);
    }
  };

  const handleCategoryClick = (categoryId: string) => {
    setSelectedCategory(selectedCategory === categoryId ? null : categoryId);
  };

  const handleQuestionClick = async (questionText: string) => {
    if (user) {
      await processTextQuestion(questionText);
      setShowHints(false);
    }
  };

  // Detect mobile device
  const isMobileDevice = () => {
    return /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent) ||
           (typeof window.orientation !== 'undefined');
  };

  // Phase 2A: Disable faulty WAV conversion - use original WebM format
  const convertAudioForMobile = async (audioBlob: Blob): Promise<Blob> => {
    console.log('📱 Phase 2A: Mobile audio processing - using original format:', {
      type: audioBlob.type,
      size: audioBlob.size,
      isMobile: isMobileDevice(),
      reasonForChange: 'WAV conversion produced files too short for transcription'
    });
    
    // Return original audio blob without conversion
    // Desktop works fine with WebM, so mobile should too
    return audioBlob;
  };

  // Helper function to convert AudioBuffer to WAV
  const audioBufferToWav = async (audioBuffer: AudioBuffer): Promise<Blob> => {
    const numberOfChannels = audioBuffer.numberOfChannels;
    const sampleRate = audioBuffer.sampleRate;
    const format = 1; // PCM
    const bitDepth = 16;

    const bytesPerSample = bitDepth / 8;
    const blockAlign = numberOfChannels * bytesPerSample;
    const byteRate = sampleRate * blockAlign;
    const dataSize = audioBuffer.length * blockAlign;
    const bufferSize = 44 + dataSize;

    const arrayBuffer = new ArrayBuffer(bufferSize);
    const view = new DataView(arrayBuffer);

    // WAV header
    const writeString = (offset: number, string: string) => {
      for (let i = 0; i < string.length; i++) {
        view.setUint8(offset + i, string.charCodeAt(i));
      }
    };

    writeString(0, 'RIFF');
    view.setUint32(4, bufferSize - 8, true);
    writeString(8, 'WAVE');
    writeString(12, 'fmt ');
    view.setUint32(16, 16, true);
    view.setUint16(20, format, true);
    view.setUint16(22, numberOfChannels, true);
    view.setUint32(24, sampleRate, true);
    view.setUint32(28, byteRate, true);
    view.setUint16(32, blockAlign, true);
    view.setUint16(34, bitDepth, true);
    writeString(36, 'data');
    view.setUint32(40, dataSize, true);

    // Convert audio data
    const channelData = audioBuffer.getChannelData(0);
    let offset = 44;
    for (let i = 0; i < channelData.length; i++) {
      const sample = Math.max(-1, Math.min(1, channelData[i]));
      view.setInt16(offset, sample * 0x7FFF, true);
      offset += 2;
    }

    return new Blob([arrayBuffer], { type: 'audio/wav' });
  };

  // Process audio question by transcribing and then finding matching video
  const processAudioQuestion = async (audioBlob: Blob) => {
    if (!user) return;
    
    setIsProcessing(true);
    console.log('🎙️ MOBILE AUDIO DEBUG - Starting processAudioQuestion:', {
      isMobile: isMobileDevice(),
      originalAudioSize: audioBlob.size,
      originalAudioType: audioBlob.type,
      hasAudioData: audioBlob.size > 0,
      timestamp: new Date().toISOString()
    });
    
    if (audioBlob.size === 0) {
      console.error('❌ MOBILE AUDIO DEBUG - Empty audio blob detected');
      toast({
        title: "Leere Aufnahme",
        description: "Keine Audioaufnahme erkannt. Sprechen Sie und versuchen Sie erneut.",
        variant: "destructive",
      });
      setIsProcessing(false);
      return;
    }
    try {
      // Convert audio format for mobile compatibility
      const processedAudioBlob = await convertAudioForMobile(audioBlob);
      console.log('Processed audio format:', processedAudioBlob.type, 'Size:', processedAudioBlob.size);

      // Validate audio blob
      if (processedAudioBlob.size === 0) {
        throw new Error('Audio recording is empty');
      }

      if (processedAudioBlob.size > 25 * 1024 * 1024) { // 25MB limit
        throw new Error('Audio file too large');
      }

      // Determine correct MIME type for the processed audio
      const audioFormat = processedAudioBlob.type.includes('wav') ? 'wav' : 'webm';
      const fileName = `audio.${audioFormat}`;
      
      console.log('Mobile audio processing details:', {
        originalFormat: audioBlob.type,
        processedFormat: processedAudioBlob.type,
        fileName: fileName,
        isMobile: isMobileDevice(),
        size: processedAudioBlob.size
      });

      // Convert audio to text using OpenAI Whisper via edge function
      const formData = new FormData();
      formData.append('audio', processedAudioBlob, fileName);
      
      console.log('🚀 MOBILE AUDIO DEBUG - About to send transcription request:', {
        blobType: processedAudioBlob.type,
        fileName: fileName,
        size: processedAudioBlob.size,
        formDataHasAudio: formData.has('audio'),
        timestamp: new Date().toISOString(),
        userAgent: navigator.userAgent.substring(0, 100)
      });
      
      console.log('🔄 MOBILE AUDIO DEBUG - Calling supabase.functions.invoke...');
      const transcriptionResponse = await supabase.functions.invoke('transcribe-v2', {
        body: formData
      });
      
      console.log('📨 MOBILE AUDIO DEBUG - Transcription response received:', {
        success: !transcriptionResponse.error,
        hasData: !!transcriptionResponse.data,
        error: transcriptionResponse.error?.message,
        dataKeys: transcriptionResponse.data ? Object.keys(transcriptionResponse.data) : [],
        fullResponse: transcriptionResponse,
        timestamp: new Date().toISOString()
      });
      
      // Fixed response structure handling
      if (transcriptionResponse.error) {
        console.error('Transcription service error:', transcriptionResponse.error);
        throw new Error(`Transcription failed: ${transcriptionResponse.error.message}`);
      }
      
      // FIXED: Defensive response extraction for mobile compatibility
      let transcriptionData;
      
      // Handle different response structures between mobile and desktop
      if (transcriptionResponse.data) {
        transcriptionData = transcriptionResponse.data;
      } else {
        // Direct response (rare edge case)
        transcriptionData = transcriptionResponse;
      }
      
      console.log('📱 Mobile-optimized response extraction:', {
        hasData: !!transcriptionData,
        responseKeys: Object.keys(transcriptionResponse),
        dataKeys: transcriptionData ? Object.keys(transcriptionData) : null,
        isMobile: isMobileDevice()
      });
      
      if (!transcriptionData) {
        console.error('❌ No transcription data found in any response structure');
        throw new Error('No transcription data received from service');
      }
      
      // Robust text extraction with multiple fallbacks
      let transcribedText = '';
      
      // Try all possible text fields
      const textFields = ['text', 'transcription', 'result', 'content', 'transcript'];
      for (const field of textFields) {
        if (transcriptionData[field] && typeof transcriptionData[field] === 'string') {
          transcribedText = transcriptionData[field].trim();
          if (transcribedText.length > 0) {
            console.log(`✅ Text extracted from field: ${field}`);
            break;
          }
        }
      }
      
      console.log('📝 Final text extraction result:', {
        text: transcribedText,
        length: transcribedText.length,
        success: transcriptionData.success,
        confidence: transcriptionData.confidence
      });
      
      if (!transcribedText || transcribedText.length === 0) {
        console.error('❌ Empty text after all extraction attempts:', transcriptionData);
        throw new Error('Transcription resulted in empty text');
      }
      
      if (transcribedText.trim().length < 3) {
        console.warn('Very short transcription detected:', transcribedText);
        throw new Error('Transcription too short - please speak more clearly');
      }
      
      // Process as text question
      console.log('Processing transcribed text as question:', transcribedText);
      await processTextQuestion(transcribedText);
      
    } catch (error) {
      console.error('Error processing audio question:', error);
      
      // Enhanced mobile-specific error messages
      let errorMessage = "Ihre Frage konnte nicht verarbeitet werden.";
      let errorTitle = "Fehler bei der Verarbeitung";
      
      if (isMobileDevice()) {
        console.log('Mobile-specific error handling for:', error.message);
        
        if (error.message?.includes('Audio recording is empty')) {
          errorMessage = "Keine Audioaufnahme erkannt. Stellen Sie sicher, dass Sie sprechen und das Mikrofon freigegeben ist.";
          errorTitle = "Leere Aufnahme";
        } else if (error.message?.includes('Audio file too large')) {
          errorMessage = "Aufnahme zu lang. Bitte halten Sie Ihre Frage kürzer.";
          errorTitle = "Aufnahme zu groß";
        } else if (error.message?.includes('Transcription failed') || error.message?.includes('too short')) {
          errorMessage = "Sprache konnte nicht erkannt werden. Sprechen Sie deutlich und versuchen Sie es erneut.";
          errorTitle = "Spracherkennung fehlgeschlagen";
        } else if (error.message?.includes('No transcription data')) {
          errorMessage = "Spracherkennungs-Service nicht verfügbar. Versuchen Sie die Texteingabe.";
          errorTitle = "Service-Fehler";
        } else if (error.message?.includes('empty text')) {
          errorMessage = "Keine Sprache erkannt. Sprechen Sie lauter und deutlicher.";
          errorTitle = "Sprache nicht erkannt";
        } else {
          errorMessage = "Mobile Audioaufnahme fehlgeschlagen. Versuchen Sie die Texteingabe oder prüfen Sie Ihre Internetverbindung.";
          console.log('Generic mobile error fallback used');
        }
      } else {
        // Desktop error handling
        if (error.message?.includes('Transcription failed')) {
          errorMessage = "Spracherkennung fehlgeschlagen. Versuchen Sie es erneut.";
          errorTitle = "Spracherkennung fehlgeschlagen";
        }
      }
      
      toast({
        title: errorTitle,
        description: errorMessage,
        variant: "destructive",
      });
    } finally {
      setIsProcessing(false);
    }
  };

  // Process text question by finding matching video
  const processTextQuestion = async (questionText: string) => {
    if (!user) return;
    
    setIsProcessing(true);
    try {
      console.log('Processing question:', questionText);
      
      // Call optimized conversation agent V4
      const response = await supabase.functions.invoke('conversation-agent-v4', {
        body: {
          question: questionText,
          userId: user.id,
          action: 'answer_question'
        }
      });

      if (response.error) {
        throw new Error(response.error.message);
      }

      const { data } = response;
      console.log('Conversation response:', data);

      // Keep answer processing logic but don't show to user
      if (data.answer) {
        setLastAnswer(data.answer);
        // setShowAnswer(true); // Hide from user
        
        // Keep timer logic for consistency
        // setTimeout(() => {
        //   setShowAnswer(false);
        // }, 8000);
        
        // Keep logic but hide toast from user
        // const confidenceText = data.confidence ? `(${(data.confidence * 100).toFixed(1)}% Konfidenz)` : '';
        // toast({
        //   title: "Antwort gefunden",
        //   description: data.videoTitle ? `Video: "${data.videoTitle}" ${confidenceText}` : `Antwort wurde gefunden ${confidenceText}`,
        // });
      }

      if (data.videoUrl) {
        // Play the matching video
        setCurrentVideoUrl(data.videoUrl);

        // After video ends, return to default video
        if (videoRef.current) {
          videoRef.current.onended = () => {
            setCurrentVideoUrl(defaultVideoUrl);
            if (videoRef.current) {
              videoRef.current.loop = true;
              videoRef.current.play();
            }
          };
          
          // Remove loop and play the matching video
          videoRef.current.loop = false;
          videoRef.current.play();
        }
      }
      
    } catch (error) {
      console.error('Error processing text question:', error);
      toast({
        title: "Fehler bei der Verarbeitung",
        description: "Ihre Frage konnte nicht verarbeitet werden. Versuchen Sie es erneut.",
        variant: "destructive",
      });
    } finally {
      setIsProcessing(false);
    }
  };

  // Handle video state changes
  useEffect(() => {
    if (videoRef.current) {
      // Set up default video loop when it's the default video
      if (currentVideoUrl === defaultVideoUrl) {
        videoRef.current.loop = true;
      } else {
        videoRef.current.loop = false;
      }
    }
  }, [currentVideoUrl, defaultVideoUrl]);

  // Mobile viewport optimization
  useEffect(() => {
    const style = document.createElement('style');
    style.textContent = `
      @media (max-width: 768px) {
        .mobile-optimized {
          height: 100vh;
          height: 100dvh; /* Dynamic viewport height for mobile */
          overflow: hidden;
          display: flex;
          flex-direction: column;
        }
        .mobile-video-container {
          flex: 1;
          display: flex;
          align-items: center;
          justify-content: center;
          min-height: 0;
        }
        .mobile-controls {
          position: fixed;
          bottom: env(safe-area-inset-bottom, 1.5rem);
          left: 0;
          right: 0;
          padding: 1rem;
          z-index: 50;
        }
        .mobile-hints-button {
          position: fixed;
          bottom: calc(env(safe-area-inset-bottom, 1.5rem) + 1rem);
          left: 1.5rem;
          z-index: 50;
        }
        .mobile-home-button {
          position: fixed;
          top: env(safe-area-inset-top, 1.5rem);
          left: 1.5rem;
          z-index: 50;
        }
        .mobile-test-button {
          position: fixed;
          top: env(safe-area-inset-top, 1.5rem);
          right: 1.5rem;
          z-index: 50;
        }
        /* Prevent text selection on mobile buttons */
        .no-select {
          -webkit-user-select: none;
          -moz-user-select: none;
          -ms-user-select: none;
          user-select: none;
          -webkit-touch-callout: none;
          -webkit-tap-highlight-color: transparent;
        }
      }
    `;
    document.head.appendChild(style);
    
    return () => {
      document.head.removeChild(style);
    };
  }, []);

  const isMobile = window.innerWidth <= 768;

  return (
    <div className="min-h-screen relative overflow-hidden">
      <div className={`min-h-screen relative ${isMobile ? 'mobile-optimized' : ''}`}>
      {/* Video Background */}
      <div className={`motion-background absolute inset-0 ${isMobile ? 'mobile-video-container' : ''}`}>
        <video
          ref={videoRef}
          className="w-full h-full object-cover"
          src={currentVideoUrl}
          autoPlay
          loop={currentVideoUrl === defaultVideoUrl}
          playsInline
          onLoadStart={() => console.log('Video loading:', currentVideoUrl)}
          onCanPlay={() => console.log('Video ready to play:', currentVideoUrl)}
        />
      </div>

      {/* Home Button - Top Left */}
      <Button
        onClick={() => navigate('/')}
        className={`absolute interactive-layer rounded-full bg-[hsl(var(--coral))] backdrop-blur-sm border-white/30 hover:scale-105 transition-all ${
          isMobile ? 'mobile-home-button' : 'top-6 left-6'
        }`}
      >
        <Home className="h-6 w-6 mr-2" style={{ color: '#243058' }} />
        <span style={{ color: '#243058' }}>Home</span>
      </Button>

      {/* Transcript Tester Button - Top Right - Hidden from user */}
      <Button
        onClick={() => setShowTester(true)}
        className={`absolute interactive-layer rounded-full bg-blue-500 backdrop-blur-sm border-white/30 hover:scale-105 transition-all hidden ${
          isMobile ? 'mobile-test-button' : 'top-6 right-6'
        }`}
      >
        <TestTube className="h-6 w-6 mr-2" style={{ color: 'white' }} />
        <span style={{ color: 'white' }}>Test Transcript</span>
      </Button>

      {/* Question Suggestions Sidebar */}
      <div className={`absolute top-0 left-0 w-80 h-full backdrop-blur-md border-r transition-transform duration-300 ease-in-out interactive-layer ${
        showHints ? 'translate-x-0' : '-translate-x-full'
      }`} style={{ backgroundColor: 'rgba(168, 208, 230, 0.15)', borderColor: 'rgba(255, 255, 255, 0.2)' }}>
        <div className="p-6 pt-20">
          <h3 className="text-lg font-semibold mb-6" style={{ color: '#243058' }}>Mögliche Fragen</h3>
          <div className="space-y-3">
            {questionCategories.map((category) => (
              <div key={category.id}>
                <Card 
                  className="backdrop-blur-sm border-white/30 p-4 hover:bg-white/30 transition-colors cursor-pointer" 
                  style={{ backgroundColor: 'hsl(var(--coral) / 0.2)' }}
                  onClick={() => handleCategoryClick(category.id)}
                >
                  <div className="flex items-center gap-3">
                    <span className="text-sm" style={{ color: '#243058' }}>{category.title} - {category.questions.length} Fragen</span>
                  </div>
                </Card>
                
                {/* Questions for expanded category */}
                {selectedCategory === category.id && (
                  <div className="mt-2 ml-4 space-y-2">
                    {category.questions.map((question, questionIndex) => (
                      <Card 
                        key={questionIndex}
                        className="backdrop-blur-sm border-white/20 p-3 hover:bg-white/20 transition-colors cursor-pointer text-xs"
                        style={{ backgroundColor: 'rgba(168, 208, 230, 0.2)' }}
                        onClick={() => handleQuestionClick(question)}
                      >
                        <span style={{ color: '#243058' }}>{question}</span>
                      </Card>
                    ))}
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Keyboard Input Overlay */}
      {showKeyboard && (
        <div className="absolute bottom-24 right-6 z-30">
          <Card className="backdrop-blur-sm p-4 w-80" style={{ backgroundColor: 'rgba(255, 255, 255, 0.95)' }}>
            <Textarea
              value={question}
              onChange={(e) => setQuestion(e.target.value)}
              placeholder="Geben Sie Ihre Frage ein..."
              className="mb-3 min-h-[100px] resize-none"
              onKeyPress={(e) => e.key === 'Enter' && !e.shiftKey && handleQuestionSubmit()}
            />
            <div className="flex gap-2">
            <Button 
              onClick={handleQuestionSubmit} 
              className="flex-1 bg-[hsl(var(--coral))]" 
              disabled={isProcessing}
            >
              {isProcessing ? 'Verarbeite...' : 'Frage stellen'}
            </Button>
              <Button onClick={() => setShowKeyboard(false)} variant="outline" className="px-4">
                Abbrechen
              </Button>
            </div>
          </Card>
        </div>
      )}

      {/* Answer Display Overlay - Hidden from user but logic preserved */}
      {false && showAnswer && lastAnswer && (
        <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 z-40 max-w-2xl mx-4">
          <Card className="backdrop-blur-md p-6 border border-white/30 animate-fade-in">
            <div className="text-center">
              <h3 className="text-lg font-semibold mb-3" style={{ color: '#243058' }}>
                Antwort
              </h3>
              <p className="text-base leading-relaxed" style={{ color: '#243058' }}>
                {lastAnswer}
              </p>
              <Button 
                onClick={() => setShowAnswer(false)}
                variant="outline"
                size="sm"
                className="mt-4"
              >
                Schließen
              </Button>
            </div>
          </Card>
        </div>
      )}

      {/* Hints Button - Bottom Left */}
      <div className={`absolute interactive-layer ${
        isMobile ? 'mobile-hints-button' : 'bottom-6 left-6'
      }`}>
        <Button
          onClick={toggleHints}
          size="lg"
          className="rounded-full w-16 h-16 p-0 bg-[hsl(var(--coral))] backdrop-blur-sm border-white/30 hover:scale-105 transition-all"
        >
          <Lightbulb className="h-7 w-7" style={{ color: '#243058' }} />
        </Button>
      </div>
      <div className={`absolute flex gap-4 interactive-layer ${
        isMobile ? 'mobile-controls justify-center' : 'bottom-6 right-6'
      }`}>
        <Button
          onClick={handleKeyboardClick}
          size="lg"
          className="rounded-full w-16 h-16 p-0 bg-[hsl(var(--coral))] backdrop-blur-sm border-white/30 hover:scale-105 transition-all"
          disabled={isProcessing}
        >
          <Keyboard className="h-7 w-7" style={{ color: '#243058' }} />
        </Button>
        
        <Button
          ref={micButtonRef}
          onMouseDown={handleMicMouseDown}
          onMouseUp={handleMicMouseUp}
          onMouseLeave={handleMicMouseUp}
          onTouchStart={handleMicTouchStart}
          onTouchEnd={handleMicTouchEnd}
          onTouchCancel={handleMicTouchEnd}
          size="lg"
          className="rounded-full w-16 h-16 p-0 backdrop-blur-sm border-white/30 hover:scale-105 transition-all relative no-select"
          style={{ 
            backgroundColor: 'hsl(var(--yellow))',
            transform: isSpeaking ? 'scale(1.1)' : 'scale(1)',
            boxShadow: isSpeaking ? `0 0 ${20 + voiceEnergy * 100}px hsl(var(--yellow) / 0.6)` : 'none'
          }}
          disabled={isProcessing}
        >
          <Mic className="h-7 w-7 no-select" style={{ color: '#243058' }} />
          
          {/* Voice Activity Indicator */}
          {isListening && (
            <>
              <div 
                className="absolute top-2 right-2 w-3 h-3 rounded-full animate-pulse"
                style={{ 
                  backgroundColor: isSpeaking ? '#00ff00' : isProcessing ? '#FFA500' : '#ff0000',
                  animation: isSpeaking ? 'pulse 0.5s infinite' : 'pulse 1s infinite'
                }}
              />
              
              {/* Voice Energy Ring */}
              <div 
                className="absolute inset-0 rounded-full border-2 transition-all duration-200"
                style={{
                  borderColor: isSpeaking ? 'rgba(0, 255, 0, 0.8)' : 'transparent',
                  transform: `scale(${1 + voiceEnergy * 0.5})`,
                  opacity: isSpeaking ? 0.8 : 0
                }}
              />
            </>
          )}
          
          {isProcessing && (
            <div 
              className="absolute top-2 right-2 w-3 h-3 rounded-full animate-pulse"
              style={{ backgroundColor: '#FFA500', animation: 'pulse 1s infinite' }}
            />
          )}
        </Button>
      </div>

      {/* Video Management & Testing Dialog */}
      {showTester && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-lg max-w-6xl w-full max-h-[90vh] overflow-hidden">
            <div className="p-4 border-b flex items-center justify-between">
              <h2 className="text-xl font-semibold">Video Management & Testing</h2>
              <Button
                onClick={() => setShowTester(false)}
                variant="ghost"
                size="sm"
              >
                <X className="h-4 w-4" />
              </Button>
            </div>
            <div className="p-6 overflow-auto max-h-[80vh]">
              <Tabs defaultValue="repair" className="w-full">
                <TabsList className="grid grid-cols-2 w-full">
                  <TabsTrigger value="repair">Video-Reparatur</TabsTrigger>
                  <TabsTrigger value="testing">Transkript-Test</TabsTrigger>
                </TabsList>
                
                <TabsContent value="repair" className="space-y-6">
                  <VideoReprocessor />
                </TabsContent>
                
                <TabsContent value="testing" className="space-y-6">
                  <TranscriptTester />
                </TabsContent>
              </Tabs>
            </div>
          </div>
        </div>
      )}

    </div>
    </div>
  );
};

export default ConversationPage;