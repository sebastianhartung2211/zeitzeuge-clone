import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { AuthTester } from '@/components/testing/AuthTester';
import { VideoUploadTester } from '@/components/testing/VideoUploadTester';
import { PushNotificationTester } from '@/components/testing/PushNotificationTester';
import { PWAStatus } from '@/components/pwa/PWAStatus';
import { PWAInstallPrompt } from '@/components/pwa/PWAInstallPrompt';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';

export default function TestingPage() {
  return (
    <div className="container mx-auto p-4 space-y-6">
      <div className="text-center space-y-2">
        <h1 className="text-3xl font-bold">🧪 Zeitzeuge Testing Console</h1>
        <p className="text-muted-foreground">
          Comprehensive testing tools for authentication, uploads, push, and PWA functionality
        </p>
      </div>

      <Tabs defaultValue="auth" className="w-full">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="auth">🔐 Auth</TabsTrigger>
          <TabsTrigger value="video">📹 Video</TabsTrigger>
          <TabsTrigger value="push">🔔 Push</TabsTrigger>
          <TabsTrigger value="pwa">📱 PWA</TabsTrigger>
        </TabsList>

        <TabsContent value="auth" className="space-y-4">
          <AuthTester />
        </TabsContent>

        <TabsContent value="video" className="space-y-4">
          <VideoUploadTester />
        </TabsContent>

        <TabsContent value="push" className="space-y-4">
          <PushNotificationTester />
        </TabsContent>

        <TabsContent value="pwa" className="space-y-4">
          <div className="grid gap-4 max-w-2xl mx-auto">
            <PWAStatus />
            <PWAInstallPrompt />
            
            <Card>
              <CardHeader>
                <CardTitle>📱 PWA Testing Guide</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3 text-sm">
                <div>
                  <p className="font-medium">Installation Test:</p>
                  <p className="text-muted-foreground">1. Open app in browser (iOS Safari / Android Chrome)</p>
                  <p className="text-muted-foreground">2. Look for "Install" button/prompt</p>
                  <p className="text-muted-foreground">3. Install and verify app icon appears</p>
                </div>
                
                <div>
                  <p className="font-medium">Offline Test:</p>
                  <p className="text-muted-foreground">1. Install PWA first</p>
                  <p className="text-muted-foreground">2. Turn off network/airplane mode</p>
                  <p className="text-muted-foreground">3. Open PWA → should show cached content</p>
                  <p className="text-muted-foreground">4. Try upload → should queue for later</p>
                </div>

                <div className="text-xs text-yellow-600 bg-yellow-50 p-2 rounded">
                  <p><strong>Note:</strong> PWA features work best when installed via browser menu "Add to Home Screen" option.</p>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>

      <Card className="max-w-4xl mx-auto">
        <CardHeader>
          <CardTitle>📋 Complete Test Checklist</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid md:grid-cols-2 gap-6 text-sm">
            <div className="space-y-3">
              <h3 className="font-medium">🔧 Build & Deploy</h3>
              <div className="space-y-1 text-muted-foreground">
                <p>□ npm run build (no errors)</p>
                <p>□ npx cap sync (plugins synced)</p>
                <p>□ npx cap run ios (simulator works)</p>
                <p>□ npx cap run android (emulator works)</p>
              </div>

              <h3 className="font-medium">🔐 Authentication</h3>
              <div className="space-y-1 text-muted-foreground">
                <p>□ Login redirects to OAuth</p>
                <p>□ Deep link returns to app</p>
                <p>□ Session persists across app restarts</p>
                <p>□ Logout clears session</p>
              </div>
            </div>

            <div className="space-y-3">
              <h3 className="font-medium">📹 Video Upload</h3>
              <div className="space-y-1 text-muted-foreground">
                <p>□ Video picker opens gallery</p>
                <p>□ Local save works (cap:// path)</p>
                <p>□ Background upload queued</p>
                <p>□ Upload continues when app minimized</p>
                <p>□ File appears in Supabase Storage</p>
              </div>

              <h3 className="font-medium">🔔 Push & PWA</h3>
              <div className="space-y-1 text-muted-foreground">
                <p>□ Push permission granted</p>
                <p>□ Token stored in database</p>
                <p>□ PWA install prompt shows</p>
                <p>□ Offline functionality works</p>
                <p>□ Service worker caches assets</p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}