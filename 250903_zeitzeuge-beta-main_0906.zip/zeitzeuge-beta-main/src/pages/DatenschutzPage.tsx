import React from 'react';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { ArrowLeft } from 'lucide-react';
import TopNavigation from '@/components/navigation/TopNavigation';

const DatenschutzPage = () => {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-background">
      <TopNavigation />
      
      <div className="max-w-4xl mx-auto px-4 py-8">
        <div className="mb-6">
          <Button
            onClick={() => navigate(-1)}
            variant="ghost"
            className="mb-4"
          >
            <ArrowLeft className="h-4 w-4 mr-2" />
            Zurück
          </Button>
          
          <h1 className="text-3xl font-bold text-[hsl(var(--navy))] mb-2">
            Datenschutzbestimmungen
          </h1>
          <p className="text-gray-600">
            Informationen zur Erhebung und Verwendung personenbezogener Daten
          </p>
        </div>

        <Card className="p-6 space-y-6">
          <section>
            <h2 className="text-xl font-semibold text-[hsl(var(--navy))] mb-3">
              1. Datenschutz auf einen Blick
            </h2>
            <div className="space-y-4 text-gray-700">
              <div>
                <h3 className="font-medium mb-2">Allgemeine Hinweise</h3>
                <p className="text-sm">
                  Die folgenden Hinweise geben einen einfachen Überblick darüber, was mit Ihren personenbezogenen Daten passiert, wenn Sie diese Website besuchen. Personenbezogene Daten sind alle Daten, mit denen Sie persönlich identifiziert werden können.
                </p>
              </div>
              
              <div>
                <h3 className="font-medium mb-2">Datenerfassung auf dieser Website</h3>
                <p className="text-sm">
                  Die Datenverarbeitung auf dieser Website erfolgt durch den Websitebetreiber. Dessen Kontaktdaten können Sie dem Abschnitt „Hinweis zur Verantwortlichen Stelle" in dieser Datenschutzerklärung entnehmen.
                </p>
              </div>
            </div>
          </section>

          <section>
            <h2 className="text-xl font-semibold text-[hsl(var(--navy))] mb-3">
              2. Allgemeine Hinweise und Pflichtinformationen
            </h2>
            <div className="space-y-4 text-gray-700">
              <div>
                <h3 className="font-medium mb-2">Datenschutz</h3>
                <p className="text-sm">
                  Wir nehmen den Schutz Ihrer persönlichen Daten sehr ernst. Wir behandeln Ihre personenbezogenen Daten vertraulich und entsprechend den gesetzlichen Datenschutzvorschriften sowie dieser Datenschutzerklärung.
                </p>
              </div>
              
              <div>
                <h3 className="font-medium mb-2">Hinweis zur verantwortlichen Stelle</h3>
                <p className="text-sm">
                  Die verantwortliche Stelle für die Datenverarbeitung auf dieser Website ist:
                </p>
                <div className="mt-2 space-y-1 text-sm">
                  <p>Zeitzeuge Platform</p>
                  <p>Musterstraße 123</p>
                  <p>12345 Musterstadt</p>
                  <p>Deutschland</p>
                  <p>E-Mail: datenschutz@zeitzeuge.de</p>
                </div>
              </div>
            </div>
          </section>

          <section>
            <h2 className="text-xl font-semibold text-[hsl(var(--navy))] mb-3">
              3. Datenerfassung auf dieser Website
            </h2>
            <div className="space-y-4 text-gray-700">
              <div>
                <h3 className="font-medium mb-2">Server-Log-Dateien</h3>
                <p className="text-sm">
                  Der Provider der Seiten erhebt und speichert automatisch Informationen in so genannten Server-Log-Dateien, die Ihr Browser automatisch an uns übermittelt. Dies sind:
                </p>
                <ul className="list-disc list-inside text-sm mt-2 space-y-1">
                  <li>Browsertyp und Browserversion</li>
                  <li>verwendetes Betriebssystem</li>
                  <li>Referrer URL</li>
                  <li>Hostname des zugreifenden Rechners</li>
                  <li>Uhrzeit der Serveranfrage</li>
                  <li>IP-Adresse</li>
                </ul>
              </div>
              
              <div>
                <h3 className="font-medium mb-2">Kontaktformular</h3>
                <p className="text-sm">
                  Wenn Sie uns per Kontaktformular Anfragen zukommen lassen, werden Ihre Angaben aus dem Anfrageformular inklusive der von Ihnen dort angegebenen Kontaktdaten zwecks Bearbeitung der Anfrage und für den Fall von Anschlussfragen bei uns gespeichert.
                </p>
              </div>
            </div>
          </section>

          <section>
            <h2 className="text-xl font-semibold text-[hsl(var(--navy))] mb-3">
              4. Video- und Audioaufnahmen
            </h2>
            <div className="space-y-4 text-gray-700">
              <div>
                <h3 className="font-medium mb-2">Zeitzeuge-Videos</h3>
                <p className="text-sm">
                  Diese Plattform ermöglicht es Ihnen, persönliche Erinnerungen und Geschichten in Form von Video- und Audioaufnahmen zu speichern. Diese Aufnahmen werden verschlüsselt gespeichert und sind nur für Sie und von Ihnen autorisierte Personen zugänglich.
                </p>
                <ul className="list-disc list-inside text-sm mt-2 space-y-1">
                  <li>Video- und Audioaufnahmen werden sicher verschlüsselt gespeichert</li>
                  <li>Sie haben jederzeit die Kontrolle über Ihre Aufnahmen</li>
                  <li>Aufnahmen können jederzeit gelöscht werden</li>
                  <li>Keine Weitergabe an Dritte ohne Ihre explizite Zustimmung</li>
                </ul>
              </div>
            </div>
          </section>

          <section>
            <h2 className="text-xl font-semibold text-[hsl(var(--navy))] mb-3">
              5. Ihre Rechte
            </h2>
            <div className="space-y-4 text-gray-700">
              <div>
                <p className="text-sm">
                  Sie haben folgende Rechte bezüglich Ihrer personenbezogenen Daten:
                </p>
                <ul className="list-disc list-inside text-sm mt-2 space-y-1">
                  <li>Recht auf Auskunft</li>
                  <li>Recht auf Berichtigung</li>
                  <li>Recht auf Löschung</li>
                  <li>Recht auf Einschränkung der Verarbeitung</li>
                  <li>Recht auf Datenübertragbarkeit</li>
                  <li>Recht auf Widerspruch</li>
                  <li>Recht auf Beschwerde bei einer Aufsichtsbehörde</li>
                </ul>
              </div>
            </div>
          </section>

          <section>
            <h2 className="text-xl font-semibold text-[hsl(var(--navy))] mb-3">
              6. Kontakt
            </h2>
            <div className="text-gray-700">
              <p className="text-sm">
                Bei Fragen zum Datenschutz können Sie sich jederzeit an uns wenden:
              </p>
              <div className="mt-2 space-y-1 text-sm">
                <p>E-Mail: datenschutz@zeitzeuge.de</p>
                <p>Telefon: +49 (0) 123 456 789</p>
              </div>
            </div>
          </section>

          <div className="mt-8 pt-6 border-t border-gray-200">
            <p className="text-xs text-gray-500">
              Stand: Januar 2024 - Diese Datenschutzerklärung kann sich ändern. Bitte überprüfen Sie sie regelmäßig.
            </p>
          </div>
        </Card>
      </div>
    </div>
  );
};

export default DatenschutzPage;