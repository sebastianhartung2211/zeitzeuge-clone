import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Label } from '@/components/ui/label';
import { Plus, Eye, ArrowLeft, Baby, Heart, Briefcase, Home, Clock, User } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

import FloatingElements from '../components/ui/floating-elements';
import { useVideos } from '@/hooks/useVideos';
import { useAuth } from '@/hooks/useAuth';

const questionCategories = [
  {
    id: 'required',
    title: 'Erforderlich',
    color: 'coral-bg',
    icon: User,
    questions: [
      'Nehmen Sie sich auf, wie Sie zehn Sekunden lang still sitzen.',
      'Sagen Sie: "Ich habe gerade keine Antwort darauf."',
      'Sagen Sie Hallo!',
      'Sagen Sie Auf Wiedersehen!',
      'Reagieren Sie auf eine unhöfliche Frage.'
    ]
  },
  {
    id: 'childhood',
    title: 'Kindheit & Familie',
    color: 'yellow-bg',
    icon: Baby,
    questions: [
      'Wie sah ein ganz normaler Tag in deiner Kindheit aus?',
      'Welche Spiele hast du als Kind am liebsten gespielt?',
      'Gab es ein besonderes Haustier oder Tier, an das du dich erinnerst?',
      'Was haben deine Eltern dir beigebracht, das du nie vergessen hast?'
    ]
  },
  {
    id: 'youth',
    title: 'Jugend & Schule',
    color: 'yellow-bg',
    icon: User,
    questions: [
      'Wie war deine Schulzeit – gab es ein Lieblingsfach oder einen Lehrer, der dir besonders in Erinnerung geblieben ist?',
      'Was hast du in deiner Freizeit gemacht, als du ein Teenager warst?',
      'Erinnerst du dich an deinen ersten Kinofilm oder das erste Konzert, auf dem du warst?'
    ]
  },
  {
    id: 'love',
    title: 'Liebe & Beziehungen',
    color: 'yellow-bg',
    icon: Heart,
    questions: [
      'Wie hast du deine große Liebe kennengelernt?',
      'Was war das romantischste, was du je erlebt hast?',
      'Was würdest du jungen Menschen heute über Beziehungen und Ehe mitgeben?'
    ]
  },
  {
    id: 'work',
    title: 'Arbeit & Alltag',
    color: 'yellow-bg',
    icon: Briefcase,
    questions: [
      'Was war dein erster Job – und wie hast du dich dabei gefühlt?',
      'Gab es eine Arbeit oder Aufgabe, auf die du besonders stolz bist?',
      'Wie sah dein Alltag aus, als du berufstätig warst?'
    ]
  },
  {
    id: 'traditions',
    title: 'Zuhause & Traditionen',
    color: 'yellow-bg',
    icon: Home,
    questions: [
      'Welche Feste habt ihr in der Familie besonders gefeiert – und wie?',
      'Gab es typische Gerichte oder Rezepte, die in deiner Familie weitergegeben wurden?',
      'Wie sah dein Kinderzimmer oder dein erstes eigenes Zuhause aus?'
    ]
  },
  {
    id: 'history',
    title: 'Zeitgeschichte & Wandel',
    color: 'yellow-bg',
    icon: Clock,
    questions: [
      'Was war ein Ereignis in der Welt, das dich besonders bewegt oder beeinflusst hat?',
      'Welche Veränderungen in der Welt hast du erlebt, die dich besonders erstaunt haben?',
      'Was vermisst du von früher – und was findest du heute besser als damals?'
    ]
  }
];

const ConversationStarterPage = () => {
  const [selectedQuestions, setSelectedQuestions] = useState<string[]>([]);
  const [activeCategory, setActiveCategory] = useState('required');
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [customQuestion, setCustomQuestion] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('required');
  const [answeredQuestions, setAnsweredQuestions] = useState<string[]>([]);
  const navigate = useNavigate();
  const { videos } = useVideos();
  const { user } = useAuth();

  const addQuestion = (question: string) => {
    if (!selectedQuestions.includes(question)) {
      setSelectedQuestions([...selectedQuestions, question]);
    }
  };

  const addAllQuestionsFromCategory = (categoryId: string) => {
    const category = questionCategories.find(cat => cat.id === categoryId);
    if (category) {
      const questionsToAdd = category.questions.filter(q => !selectedQuestions.includes(q));
      setSelectedQuestions([...selectedQuestions, ...questionsToAdd]);
    }
  };

  // Load answered questions from user's videos - match by video title (direct question matching)
  useEffect(() => {
    if (videos && videos.length > 0) {
      const answeredQuestionsSet = new Set<string>();
      
      console.log('🔍 MATCHING DEBUG: Starting question matching...');
      console.log('Videos found:', videos.length);
      
      videos.forEach(video => {
        // Only consider videos with status 'completed' (fully processed)
        if (video.status === 'completed') {
          console.log(`🎥 Checking video: "${video.title}" (status: ${video.status})`);
          
          // Direct title matching - video titles contain the exact question
          questionCategories.forEach(category => {
            category.questions.forEach(question => {
              // Normalize both strings for comparison
              const normalizeText = (text: string) => text.toLowerCase()
                .replace(/[^\w\s]/g, ' ')
                .replace(/\s+/g, ' ')
                .trim();

              const questionNormalized = normalizeText(question);
              const videoTitleNormalized = normalizeText(video.title);
              
              // Check if video title matches question (should be exact or very close)
              if (videoTitleNormalized === questionNormalized || 
                  videoTitleNormalized.includes(questionNormalized) ||
                  questionNormalized.includes(videoTitleNormalized)) {
                console.log(`✅ MATCH FOUND: Question "${question}" matches video "${video.title}"`);
                answeredQuestionsSet.add(question);
              }
            });
          });
        } else {
          console.log(`⏳ Skipping video "${video.title}" - status: ${video.status}`);
        }
      });
      
      console.log('🎯 FINAL RESULT: Answered questions:', Array.from(answeredQuestionsSet));
      setAnsweredQuestions(Array.from(answeredQuestionsSet));
    }
  }, [videos]);

  const addCustomQuestion = () => {
    if (customQuestion.trim() && !selectedQuestions.includes(customQuestion.trim())) {
      // Add question to the selected category
      const categoryIndex = questionCategories.findIndex(cat => cat.id === selectedCategory);
      if (categoryIndex !== -1) {
        questionCategories[categoryIndex].questions.push(customQuestion.trim());
      }
      setSelectedQuestions([...selectedQuestions, customQuestion.trim()]);
      setCustomQuestion('');
      setSelectedCategory('required');
      setIsDialogOpen(false);
    }
  };

  const removeQuestion = (question: string) => {
    setSelectedQuestions(selectedQuestions.filter(q => q !== question));
  };

  const activeQuestions = questionCategories.find(cat => cat.id === activeCategory)?.questions || [];

  return (
    <div className="min-h-screen gradient-bg relative overflow-hidden">
      {/* Floating Elements - Background Layer */}
      <div className="motion-background absolute inset-0">
        <FloatingElements />
      </div>
      
      
      <div className="container mx-auto px-4 py-6 md:py-8 pt-20 md:pt-24 content-layer">
        {/* Header */}
        <div className="mb-8">
          <div className="mb-6 md:mb-8">
            <h1 className="text-2xl sm:text-3xl lg:text-4xl font-bold text-foreground mb-2 leading-tight">Gesprächsanregungen</h1>
            <p className="text-sm sm:text-base text-muted-foreground leading-relaxed max-w-3xl">Wähle hier die Fragen aus, die du im nächsten Schritt beantworten und als Erlebnis festhalten möchtest. Füge gerne auch neue eigene Fragen hinzu.</p>
          </div>
          
          {/* Button "Antworten aufnehmen" */}
          <Button 
            className="yellow-bg font-semibold hover:bg-accent/90 hover:text-white min-h-[44px] sm:min-h-[48px] px-4 sm:px-6 text-sm sm:text-base touch-manipulation"
            style={{ color: '#243058' }}
            onClick={() => {
              const questionsToRecord = selectedQuestions.length > 0 
                ? selectedQuestions 
                : questionCategories.find(cat => cat.id === 'required')?.questions || [];
              navigate('/record-story', { state: { questions: questionsToRecord, hasSelectedQuestions: selectedQuestions.length > 0 } });
            }}
          >
            <Eye className="h-4 w-4 mr-2" style={{ color: '#243058' }} />
            <span>Antworten aufnehmen</span>
          </Button>
        </div>

        {/* Section "Ihre Fragen" */}
        <div className="mb-8">
          <h2 className="text-xl lg:text-2xl font-semibold text-foreground mb-4">Ihre Fragen</h2>
          <Card className="bg-card border border-border shadow-lg">
            <CardHeader className="border-b border-border">
              <CardTitle className="text-card-foreground flex items-center gap-2">
                <div className="w-2 h-6 coral-bg rounded"></div>
                Ausgewählte Fragen
                <Badge variant="secondary" className="coral-bg text-white">
                  {selectedQuestions.length}
                </Badge>
              </CardTitle>
            </CardHeader>
            <CardContent className="p-4">
              {selectedQuestions.length === 0 ? (
                <p className="text-muted-foreground text-center py-8">
                  Noch keine Fragen ausgewählt. Klicken Sie auf Fragen aus den Kategorien, um sie hier hinzuzufügen.
                </p>
              ) : (
                <div className="space-y-3">
                  {selectedQuestions.map((question, index) => (
                    <div key={index} className="p-3 bg-muted rounded-lg flex justify-between items-start gap-3 min-h-[60px] touch-manipulation">
                      <span className="text-sm text-muted-foreground flex-1 leading-relaxed">{index + 1}. {question}</span>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => removeQuestion(question)}
                        className="text-destructive hover:text-destructive hover:bg-destructive/10 ml-2 min-h-[32px] min-w-[32px] flex-shrink-0 touch-manipulation"
                        aria-label="Frage entfernen"
                      >
                        <span className="text-lg leading-none">×</span>
                      </Button>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        {/* "Weitere Fragen hinzufügen" */}
        <div className="mb-8">
          <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
            <DialogTrigger asChild>
              <Button 
                variant="outline"
                className="text-foreground hover:bg-primary/10 min-h-[44px] px-6 touch-manipulation"
              >
                <Plus className="h-4 w-4 mr-2" />
                <span className="text-sm sm:text-base">Eigene Frage hinzufügen</span>
              </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-[425px] mx-4 max-h-[90vh] overflow-y-auto">
              <DialogHeader className="pb-4">
                <DialogTitle className="text-lg sm:text-xl">Neue Frage hinzufügen</DialogTitle>
              </DialogHeader>
              <div className="grid gap-4 py-2">
                <div className="grid gap-3">
                  <Label htmlFor="question" className="text-sm font-medium">Ihre Frage</Label>
                  <Input
                    id="question"
                    value={customQuestion}
                    onChange={(e) => setCustomQuestion(e.target.value)}
                    placeholder="Geben Sie Ihre Frage ein..."
                    className="min-h-[44px] text-base sm:text-sm"
                    onKeyDown={(e) => {
                      if (e.key === 'Enter' && !e.shiftKey) {
                        addCustomQuestion();
                      }
                    }}
                  />
                </div>
                <div className="grid gap-3">
                  <Label htmlFor="category" className="text-sm font-medium">Kategorie</Label>
                  <Select value={selectedCategory} onValueChange={setSelectedCategory}>
                    <SelectTrigger className="min-h-[44px]">
                      <SelectValue placeholder="Wählen Sie eine Kategorie" />
                    </SelectTrigger>
                    <SelectContent className="max-h-[200px]">
                      {questionCategories.map((category) => (
                        <SelectItem key={category.id} value={category.id} className="min-h-[44px] flex items-center">
                          {category.title}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="flex flex-col sm:flex-row justify-end gap-3 pt-4">
                  <Button
                    variant="outline"
                    onClick={() => {
                      setIsDialogOpen(false);
                      setCustomQuestion('');
                      setSelectedCategory('required');
                    }}
                    className="min-h-[44px] w-full sm:w-auto touch-manipulation"
                  >
                    Abbrechen
                  </Button>
                  <Button
                    onClick={addCustomQuestion}
                    disabled={!customQuestion.trim() || !selectedCategory}
                    className="min-h-[44px] w-full sm:w-auto touch-manipulation"
                  >
                    Speichern
                  </Button>
                </div>
              </div>
            </DialogContent>
          </Dialog>
        </div>

        {/* Section "Mögliche Fragen zum Auswählen" */}
        <div>
          <h2 className="text-xl lg:text-2xl font-semibold text-foreground mb-4">Mögliche Fragen zum Auswählen</h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-4 md:gap-6">
            {questionCategories.map((category) => (
              <div key={category.id} className="space-y-3">
                <div className="flex items-center gap-2 px-1">
                  <category.icon className="h-5 w-5 text-foreground" />
                  <h3 className="text-base sm:text-lg font-semibold text-foreground">{category.title}</h3>
                </div>
                <Card className="bg-card border border-border shadow-lg">
                  <CardHeader className="pb-2">
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center gap-2">
                        <div className={`w-8 h-8 ${category.color} rounded-full flex items-center justify-center text-foreground font-bold text-sm`}>
                          {category.questions.length}
                        </div>
                        <span className="text-xs text-muted-foreground">Fragen</span>
                      </div>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => addAllQuestionsFromCategory(category.id)}
                        className="text-coral hover:bg-coral/10 p-1 h-8 w-8 rounded-full"
                        title="Alle Fragen dieser Kategorie auswählen"
                      >
                        <Plus className="h-4 w-4" />
                      </Button>
                    </div>
                  </CardHeader>
                  <CardContent className="pt-0 pb-3">
                    <div className="space-y-2 max-h-60 sm:max-h-64 overflow-y-auto">
                      {category.questions.map((question, index) => {
                        const isAnswered = answeredQuestions.includes(question);
                        const isSelected = selectedQuestions.includes(question);
                        
                        return (
                          <div
                            key={index}
                            className={`p-3 rounded-lg text-sm leading-relaxed transition-colors min-h-[44px] flex items-center touch-manipulation ${
                              isAnswered 
                                ? 'bg-success/10 border border-success/30 text-muted-foreground cursor-pointer' 
                                : 'bg-muted text-muted-foreground hover:bg-muted/80 cursor-pointer'
                            }`}
                            onClick={() => addQuestion(question)}
                          >
                            <span className="flex-1">{question}</span>
                            {isAnswered && (
                              <Badge variant="secondary" className="ml-2 success-bg text-blue-800 text-xs flex-shrink-0">
                                Beantwortet
                              </Badge>
                            )}
                            {!isAnswered && isSelected && (
                              <Badge variant="secondary" className="ml-2 success-bg text-white text-xs flex-shrink-0">
                                Hinzugefügt
                              </Badge>
                            )}
                          </div>
                        );
                      })}
                    </div>
                  </CardContent>
                </Card>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default ConversationStarterPage;