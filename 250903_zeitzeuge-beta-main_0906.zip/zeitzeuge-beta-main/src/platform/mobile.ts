import { Filesystem, Directory, Encoding } from '@capacitor/filesystem';
import { FilePicker } from '@capawesome/capacitor-file-picker';
import { VoiceRecorder } from 'capacitor-voice-recorder';

export const mediaMobile: import('./types').MediaAPI = {
  async recordAudio() {
    const can = await VoiceRecorder.canDeviceVoiceRecord();
    if (!can.value) throw new Error('Recording not supported');

    // Permission
    const perm = await VoiceRecorder.requestAudioRecordingPermission();
    if (!perm.value) throw new Error('Mic permission denied');

    await VoiceRecorder.startRecording();
    // -> in der UI stoppst du später…
    const res = await VoiceRecorder.stopRecording(); // res.value.recordDataBase64
    const base64 = res.value.recordDataBase64;
    return new Blob([Uint8Array.from(atob(base64), c => c.charCodeAt(0))], { type: 'audio/m4a' });
  },
  async pickVideo() {
    const { files } = await FilePicker.pickFiles({ 
      types: ['video/*'],
      limit: 1 
    }); // iOS/Android
    if (!files?.length) throw new Error('No video selected');

    // Wir bleiben kompatibel mit deiner aktuellen MediaAPI (Blob erwartet):
    // Achtung: Für sehr große Files ist das speicherintensiv -> mittelfristig direkt per Pfad an den Uploader geben.
    const path = files[0].path;
    const file = await Filesystem.readFile({ path }); // base64
    const byteChars = atob(file.data as string);
    const byteNums = new Array(byteChars.length).fill(0).map((_, i) => byteChars.charCodeAt(i));
    const blob = new Blob([new Uint8Array(byteNums)], { type: 'video/mp4' });
    return blob; // kompatibel zum bestehenden Save-Flow
  },
  async saveLocal(file, name = 'media.mp4') {
    const buffer = await (file as Blob).arrayBuffer();
    const base64 = btoa(String.fromCharCode(...new Uint8Array(buffer)));
    const path = `zeitzeuge/${Date.now()}-${name}`;
    await Filesystem.writeFile({
      path,
      data: base64,
      directory: Directory.Documents,
      encoding: Encoding.UTF8,
      recursive: true,
    });
    return `cap://${path}`;
  }
};