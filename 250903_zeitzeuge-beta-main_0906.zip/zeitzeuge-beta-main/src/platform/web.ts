export const mediaWeb: import('./types').MediaAPI = {
  async recordAudio() {
    const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
    const rec = new MediaRecorder(stream);
    const chunks: BlobPart[] = [];
    rec.ondataavailable = (e) => chunks.push(e.data);
    rec.start();
    await new Promise(r => setTimeout(r, 3000)); // Demo: 3s aufnehmen
    rec.stop();
    await new Promise<void>(res => rec.onstop = () => res());
    return new Blob(chunks, { type: 'audio/webm' });
  },
  async pickVideo() {
    return new Promise((resolve, reject) => {
      const input = document.createElement('input');
      input.type = 'file'; input.accept = 'video/*';
      input.onchange = () => {
        const f = input.files?.[0];
        f ? resolve(f) : reject(new Error('No file'));
      };
      input.click();
    });
  },
  async saveLocal(file, name = 'media.webm') {
    // Minimal: im Web nur URL.createObjectURL nutzen
    return URL.createObjectURL(file as Blob);
  }
};