export interface MediaAPI {
  recordAudio(): Promise<File | Blob>;
  pickVideo(): Promise<File | Blob>;
  saveLocal(file: File | Blob, name?: string): Promise<string>; // returns local path/id
}