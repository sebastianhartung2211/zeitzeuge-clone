import { mediaWeb } from './web';
import { mediaMobile } from './mobile';
// import { Capacitor } from '@capacitor/core';

// Force web/desktop mode - no mobile views for now
const isNative = false;

export const media = isNative ? mediaMobile : mediaWeb;