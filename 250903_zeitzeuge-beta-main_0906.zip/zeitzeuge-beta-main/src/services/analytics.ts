import * as Sentry from '@sentry/react';

// Analytics service without PII (Personal Identifiable Information)
export class AnalyticsService {
  private static instance: AnalyticsService;
  private initialized = false;

  private constructor() {}

  static getInstance(): AnalyticsService {
    if (!AnalyticsService.instance) {
      AnalyticsService.instance = new AnalyticsService();
    }
    return AnalyticsService.instance;
  }

  initialize(dsn?: string) {
    if (this.initialized) return;

    // Initialize Sentry for crash reporting
    if (dsn) {
      Sentry.init({
        dsn,
        environment: import.meta.env.MODE || 'development',
        tracesSampleRate: 0.1, // Low sample rate for performance monitoring
        beforeSend(event) {
          // Remove PII before sending
          if (event.user) {
            delete event.user.email;
            delete event.user.username;
            delete event.user.ip_address;
          }
          
          // Remove URLs with potential PII
          if (event.request?.url) {
            event.request.url = event.request.url.replace(/\/users\/[^\/]+/, '/users/[id]');
          }
          
          return event;
        }
      });
    }

    this.initialized = true;
    console.log('Analytics service initialized');
  }

  // Track app events without PII
  trackEvent(eventName: string, properties?: Record<string, any>) {
    try {
      // Clean properties to remove PII
      const cleanProperties = this.cleanProperties(properties);
      
      // Add to Sentry breadcrumbs for context
      Sentry.addBreadcrumb({
        message: eventName,
        category: 'user-action',
        data: cleanProperties,
        level: 'info'
      });

      console.log(`Analytics: ${eventName}`, cleanProperties);
    } catch (error) {
      console.error('Analytics tracking failed:', error);
    }
  }

  // Track page views
  trackPageView(pageName: string) {
    this.trackEvent('page_view', { page: pageName });
  }

  // Track user actions
  trackUserAction(action: string, context?: string) {
    this.trackEvent('user_action', { 
      action,
      context,
      timestamp: Date.now()
    });
  }

  // Track video processing events
  trackVideoEvent(event: 'upload_started' | 'upload_completed' | 'upload_failed' | 'processing_started' | 'processing_completed', context?: Record<string, any>) {
    this.trackEvent(`video_${event}`, {
      ...this.cleanProperties(context),
      timestamp: Date.now()
    });
  }

  // Track app performance
  trackPerformance(metric: string, value: number, unit: string = 'ms') {
    this.trackEvent('performance_metric', {
      metric,
      value,
      unit,
      timestamp: Date.now()
    });
  }

  // Track errors (non-crash)
  trackError(error: Error, context?: Record<string, any>) {
    Sentry.captureException(error, {
      extra: this.cleanProperties(context)
    });
  }

  // Set user context (without PII)
  setUserContext(userId?: string, additionalContext?: Record<string, any>) {
    Sentry.setUser({
      id: userId ? this.hashUserId(userId) : undefined, // Hash user ID
      ...this.cleanProperties(additionalContext)
    });
  }

  // Clean properties to remove PII
  private cleanProperties(properties?: Record<string, any>): Record<string, any> {
    if (!properties) return {};

    const cleaned = { ...properties };
    
    // Remove common PII fields
    const piiFields = ['email', 'name', 'phone', 'address', 'ip', 'user_id', 'username'];
    piiFields.forEach(field => {
      delete cleaned[field];
    });

    // Remove any field containing sensitive data patterns
    Object.keys(cleaned).forEach(key => {
      const value = cleaned[key];
      if (typeof value === 'string') {
        // Remove email patterns
        if (value.includes('@') && value.includes('.')) {
          delete cleaned[key];
        }
        // Remove URL parameters that might contain PII
        if (value.startsWith('http') && value.includes('user')) {
          cleaned[key] = '[URL_REMOVED]';
        }
      }
    });

    return cleaned;
  }

  // Hash user ID for analytics (one-way hash)
  private hashUserId(userId: string): string {
    // Simple hash function (in production, use a proper crypto hash)
    let hash = 0;
    for (let i = 0; i < userId.length; i++) {
      const char = userId.charCodeAt(i);
      hash = ((hash << 5) - hash) + char;
      hash = hash & hash; // Convert to 32-bit integer
    }
    return `user_${Math.abs(hash)}`;
  }
}

// Export singleton instance
export const analytics = AnalyticsService.getInstance();