export interface PerformanceMetrics {
  cameraLaunchTime: number;
  recordingStartTime: number;
  recordingStopTime: number;
  processingTime: number;
  sessionDuration: number;
  frameRate: number;
  bitrate: number;
  memoryUsage: number;
  crashes: number;
  errors: string[];
}

export interface PerformanceThresholds {
  maxCameraLaunchTime: number; // 300ms
  maxRecordingStopTime: number; // 500ms
  minSessionDuration: number; // 2 minutes
  targetFrameRate: number;
  maxMemoryUsage: number;
}

export class PerformanceMonitor {
  private static instance: PerformanceMonitor;
  private metrics: Partial<PerformanceMetrics> = {};
  private thresholds: PerformanceThresholds;
  private sessionStartTime: number = 0;
  private frameCount: number = 0;
  private lastFrameTime: number = 0;
  private memoryCheckInterval: number | null = null;

  constructor() {
    this.thresholds = {
      maxCameraLaunchTime: 300, // 300ms
      maxRecordingStopTime: 500, // 500ms
      minSessionDuration: 120000, // 2 minutes
      targetFrameRate: 30,
      maxMemoryUsage: 100 // MB
    };
    
    this.resetMetrics();
  }

  static getInstance(): PerformanceMonitor {
    if (!PerformanceMonitor.instance) {
      PerformanceMonitor.instance = new PerformanceMonitor();
    }
    return PerformanceMonitor.instance;
  }

  resetMetrics(): void {
    this.metrics = {
      cameraLaunchTime: 0,
      recordingStartTime: 0,
      recordingStopTime: 0,
      processingTime: 0,
      sessionDuration: 0,
      frameRate: 0,
      bitrate: 0,
      memoryUsage: 0,
      crashes: 0,
      errors: []
    };
    this.frameCount = 0;
    this.lastFrameTime = 0;
  }

  startCameraLaunchTimer(): void {
    this.sessionStartTime = performance.now();
  }

  endCameraLaunchTimer(): void {
    this.metrics.cameraLaunchTime = performance.now() - this.sessionStartTime;
    console.log(`Camera launch time: ${this.metrics.cameraLaunchTime}ms`);
  }

  startRecordingTimer(): void {
    const startTime = performance.now();
    this.metrics.recordingStartTime = startTime - this.sessionStartTime;
    this.startFrameRateMonitoring();
    this.startMemoryMonitoring();
  }

  stopRecordingTimer(): void {
    const stopTime = performance.now();
    this.metrics.recordingStopTime = stopTime - this.sessionStartTime;
    this.metrics.sessionDuration = stopTime - this.sessionStartTime;
    this.stopFrameRateMonitoring();
    this.stopMemoryMonitoring();
    console.log(`Recording stop time: ${this.metrics.recordingStopTime}ms`);
    console.log(`Session duration: ${this.metrics.sessionDuration}ms`);
  }

  startProcessingTimer(): number {
    return performance.now();
  }

  endProcessingTimer(startTime: number): void {
    this.metrics.processingTime = performance.now() - startTime;
    console.log(`Processing time: ${this.metrics.processingTime}ms`);
  }

  private startFrameRateMonitoring(): void {
    this.frameCount = 0;
    this.lastFrameTime = performance.now();
    this.trackFrame();
  }

  private trackFrame(): void {
    const currentTime = performance.now();
    this.frameCount++;
    
    // Calculate frame rate every second
    if (currentTime - this.lastFrameTime >= 1000) {
      this.metrics.frameRate = this.frameCount;
      this.frameCount = 0;
      this.lastFrameTime = currentTime;
    }
    
    // Continue monitoring if recording is active
    if (this.sessionStartTime > 0) {
      requestAnimationFrame(() => this.trackFrame());
    }
  }

  private stopFrameRateMonitoring(): void {
    // Final frame rate calculation
    const sessionDuration = (performance.now() - this.sessionStartTime) / 1000;
    if (sessionDuration > 0) {
      this.metrics.frameRate = this.frameCount / sessionDuration;
    }
  }

  private startMemoryMonitoring(): void {
    this.memoryCheckInterval = window.setInterval(() => {
      this.checkMemoryUsage();
    }, 1000); // Check every second
  }

  private stopMemoryMonitoring(): void {
    if (this.memoryCheckInterval) {
      clearInterval(this.memoryCheckInterval);
      this.memoryCheckInterval = null;
    }
  }

  private checkMemoryUsage(): void {
    if ('memory' in performance) {
      const memory = (performance as any).memory;
      const usedMB = memory.usedJSHeapSize / 1024 / 1024;
      this.metrics.memoryUsage = Math.max(this.metrics.memoryUsage || 0, usedMB);
      
      // Warning if memory usage is high
      if (usedMB > this.thresholds.maxMemoryUsage) {
        this.recordError(`High memory usage: ${usedMB.toFixed(2)}MB`);
      }
    }
  }

  recordError(error: string): void {
    if (!this.metrics.errors) {
      this.metrics.errors = [];
    }
    this.metrics.errors.push(`${new Date().toISOString()}: ${error}`);
    console.warn('Performance issue:', error);
  }

  recordCrash(): void {
    this.metrics.crashes = (this.metrics.crashes || 0) + 1;
  }

  setBitrate(bitrate: number): void {
    this.metrics.bitrate = bitrate;
  }

  getMetrics(): PerformanceMetrics {
    return this.metrics as PerformanceMetrics;
  }

  getComplianceReport(): {
    compliant: boolean;
    issues: string[];
    summary: {
      cameraLaunch: 'pass' | 'fail' | 'unknown';
      recordingStop: 'pass' | 'fail' | 'unknown';
      sessionDuration: 'pass' | 'fail' | 'unknown';
      frameRate: 'pass' | 'fail' | 'unknown';
      memoryUsage: 'pass' | 'fail' | 'unknown';
      crashFree: 'pass' | 'fail' | 'unknown';
    };
  } {
    const issues: string[] = [];
    const summary = {
      cameraLaunch: 'unknown' as 'pass' | 'fail' | 'unknown',
      recordingStop: 'unknown' as 'pass' | 'fail' | 'unknown',
      sessionDuration: 'unknown' as 'pass' | 'fail' | 'unknown',
      frameRate: 'unknown' as 'pass' | 'fail' | 'unknown',
      memoryUsage: 'unknown' as 'pass' | 'fail' | 'unknown',
      crashFree: 'unknown' as 'pass' | 'fail' | 'unknown'
    };

    // Check camera launch time
    if (this.metrics.cameraLaunchTime !== undefined) {
      if (this.metrics.cameraLaunchTime > this.thresholds.maxCameraLaunchTime) {
        issues.push(`Camera launch time exceeded: ${this.metrics.cameraLaunchTime}ms > ${this.thresholds.maxCameraLaunchTime}ms`);
        summary.cameraLaunch = 'fail';
      } else {
        summary.cameraLaunch = 'pass';
      }
    }

    // Check recording stop time
    if (this.metrics.recordingStopTime !== undefined) {
      if (this.metrics.recordingStopTime > this.thresholds.maxRecordingStopTime) {
        issues.push(`Recording stop time exceeded: ${this.metrics.recordingStopTime}ms > ${this.thresholds.maxRecordingStopTime}ms`);
        summary.recordingStop = 'fail';
      } else {
        summary.recordingStop = 'pass';
      }
    }

    // Check session duration
    if (this.metrics.sessionDuration !== undefined) {
      if (this.metrics.sessionDuration < this.thresholds.minSessionDuration) {
        issues.push(`Session duration too short: ${this.metrics.sessionDuration}ms < ${this.thresholds.minSessionDuration}ms`);
        summary.sessionDuration = 'fail';
      } else {
        summary.sessionDuration = 'pass';
      }
    }

    // Check frame rate
    if (this.metrics.frameRate !== undefined) {
      if (this.metrics.frameRate < this.thresholds.targetFrameRate * 0.8) { // Allow 20% tolerance
        issues.push(`Frame rate too low: ${this.metrics.frameRate}fps < ${this.thresholds.targetFrameRate * 0.8}fps`);
        summary.frameRate = 'fail';
      } else {
        summary.frameRate = 'pass';
      }
    }

    // Check memory usage
    if (this.metrics.memoryUsage !== undefined) {
      if (this.metrics.memoryUsage > this.thresholds.maxMemoryUsage) {
        issues.push(`Memory usage exceeded: ${this.metrics.memoryUsage}MB > ${this.thresholds.maxMemoryUsage}MB`);
        summary.memoryUsage = 'fail';
      } else {
        summary.memoryUsage = 'pass';
      }
    }

    // Check crash-free recording
    if (this.metrics.crashes !== undefined) {
      if (this.metrics.crashes > 0) {
        issues.push(`Recording crashed ${this.metrics.crashes} times`);
        summary.crashFree = 'fail';
      } else {
        summary.crashFree = 'pass';
      }
    }

    return {
      compliant: issues.length === 0,
      issues,
      summary
    };
  }

  exportReport(): string {
    const metrics = this.getMetrics();
    const compliance = this.getComplianceReport();
    
    return JSON.stringify({
      timestamp: new Date().toISOString(),
      metrics,
      compliance,
      deviceInfo: navigator.userAgent
    }, null, 2);
  }

  logReport(): void {
    const report = this.getComplianceReport();
    console.group('📊 Performance Report');
    console.log('Metrics:', this.getMetrics());
    console.log('Compliance:', report);
    if (report.issues.length > 0) {
      console.warn('Issues found:', report.issues);
    } else {
      console.log('✅ All performance criteria met');
    }
    console.groupEnd();
  }
}