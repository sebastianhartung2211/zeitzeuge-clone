export interface DeviceCapabilities {
  isIOS: boolean;
  isAndroid: boolean;
  isMobile: boolean;
  browserName: string;
  osVersion: string;
  deviceType: 'smartphone' | 'tablet' | 'desktop';
  supportedResolutions: { width: number; height: number }[];
  defaultResolution: { width: number; height: number };
  supportsZoom: boolean;
  maxZoom: number;
  supportedFrameRates: number[];
  preferredFrameRate: number;
}

export interface CameraConstraints {
  video: MediaTrackConstraints;
  audio: MediaTrackConstraints;
}

export class DeviceDetectionService {
  private static instance: DeviceDetectionService;
  private capabilities: DeviceCapabilities | null = null;

  static getInstance(): DeviceDetectionService {
    if (!DeviceDetectionService.instance) {
      DeviceDetectionService.instance = new DeviceDetectionService();
    }
    return DeviceDetectionService.instance;
  }

  async detectCapabilities(): Promise<DeviceCapabilities> {
    if (this.capabilities) {
      return this.capabilities;
    }

    const userAgent = navigator.userAgent;
    const isIOS = /iPad|iPhone|iPod/.test(userAgent);
    const isAndroid = /Android/.test(userAgent);
    const isMobile = isIOS || isAndroid || /Mobile/.test(userAgent);
    
    // Detect browser
    let browserName = 'unknown';
    if (/Chrome/.test(userAgent)) browserName = 'chrome';
    else if (/Safari/.test(userAgent) && !(/Chrome/.test(userAgent))) browserName = 'safari';
    else if (/Firefox/.test(userAgent)) browserName = 'firefox';

    // Detect OS version
    let osVersion = 'unknown';
    if (isIOS) {
      const match = userAgent.match(/OS (\d+)_(\d+)/);
      if (match) osVersion = `${match[1]}.${match[2]}`;
    } else if (isAndroid) {
      const match = userAgent.match(/Android (\d+\.?\d*)/);
      if (match) osVersion = match[1];
    }

    // Detect device type
    let deviceType: 'smartphone' | 'tablet' | 'desktop' = 'desktop';
    if (isMobile) {
      const screenWidth = window.screen.width;
      deviceType = screenWidth > 768 ? 'tablet' : 'smartphone';
    }

    // Get camera capabilities
    const { supportedResolutions, defaultResolution, supportsZoom, maxZoom, supportedFrameRates, preferredFrameRate } = 
      await this.getCameraCapabilities(isIOS, isAndroid, deviceType);

    this.capabilities = {
      isIOS,
      isAndroid,
      isMobile,
      browserName,
      osVersion,
      deviceType,
      supportedResolutions,
      defaultResolution,
      supportsZoom,
      maxZoom,
      supportedFrameRates,
      preferredFrameRate
    };

    return this.capabilities;
  }

  private async getCameraCapabilities(isIOS: boolean, isAndroid: boolean, deviceType: string) {
    try {
      // Get available video devices
      const devices = await navigator.mediaDevices.enumerateDevices();
      const videoDevices = devices.filter(device => device.kind === 'videoinput');
      
      if (videoDevices.length === 0) {
        return this.getDefaultCapabilities(isIOS, isAndroid, deviceType);
      }

      // Try to get capabilities from the back camera (usually index 0 or contains 'back')
      const backCamera = videoDevices.find(device => 
        device.label.toLowerCase().includes('back') || 
        device.label.toLowerCase().includes('rear')
      ) || videoDevices[0];

      // Get supported constraints
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { deviceId: backCamera.deviceId }
      });
      
      const track = stream.getVideoTracks()[0];
      const capabilities = track.getCapabilities();
      
      // Clean up
      track.stop();
      stream.getTracks().forEach(track => track.stop());

      // Extract supported resolutions
      const supportedResolutions = this.extractSupportedResolutions(capabilities, isIOS, isAndroid, deviceType);
      const defaultResolution = this.getDefaultResolution(supportedResolutions, isIOS, isAndroid, deviceType);
      
      return {
        supportedResolutions,
        defaultResolution,
        supportsZoom: 'zoom' in capabilities && capabilities.zoom ? true : false,
        maxZoom: 'zoom' in capabilities && capabilities.zoom && typeof capabilities.zoom === 'object' && 'max' in capabilities.zoom ? (capabilities.zoom as any).max || 1 : 1,
        supportedFrameRates: this.extractSupportedFrameRates(capabilities),
        preferredFrameRate: isIOS ? 30 : 30 // Most devices perform better at 30fps
      };
    } catch (error) {
      console.warn('Could not detect camera capabilities:', error);
      return this.getDefaultCapabilities(isIOS, isAndroid, deviceType);
    }
  }

  private extractSupportedResolutions(capabilities: MediaTrackCapabilities, isIOS: boolean, isAndroid: boolean, deviceType: string) {
    const resolutions = [];
    
    if (capabilities.width && capabilities.height) {
      // Use device capabilities if available
      const widthRange = capabilities.width;
      const heightRange = capabilities.height;
      
      if (typeof widthRange === 'object' && typeof heightRange === 'object') {
        // Common mobile resolutions
        const commonResolutions = [
          { width: 1920, height: 1080 }, // 1080p
          { width: 1280, height: 720 },  // 720p
          { width: 854, height: 480 },   // 480p
          { width: 640, height: 480 },   // VGA
        ];
        
        commonResolutions.forEach(res => {
          if (res.width >= (widthRange.min || 0) && res.width <= (widthRange.max || 4096) &&
              res.height >= (heightRange.min || 0) && res.height <= (heightRange.max || 4096)) {
            resolutions.push(res);
          }
        });
      }
    }

    // Fallback to device-specific defaults
    if (resolutions.length === 0) {
      if (isIOS) {
        resolutions.push(
          { width: 1920, height: 1080 },
          { width: 1280, height: 720 },
          { width: 640, height: 480 }
        );
      } else if (isAndroid) {
        resolutions.push(
          { width: 1920, height: 1080 },
          { width: 1280, height: 720 },
          { width: 854, height: 480 }
        );
      } else {
        resolutions.push({ width: 1280, height: 720 });
      }
    }

    return resolutions;
  }

  private extractSupportedFrameRates(capabilities: MediaTrackCapabilities): number[] {
    if (capabilities.frameRate && typeof capabilities.frameRate === 'object') {
      const frameRate = capabilities.frameRate;
      return [30, 24, 15].filter(rate => 
        rate >= (frameRate.min || 0) && rate <= (frameRate.max || 60)
      );
    }
    return [30, 24, 15];
  }

  private getDefaultResolution(supportedResolutions: { width: number; height: number }[], isIOS: boolean, isAndroid: boolean, deviceType: string) {
    // Prefer 720p for mobile devices for better performance
    const preferred720p = supportedResolutions.find(res => res.width === 1280 && res.height === 720);
    if (preferred720p && deviceType === 'smartphone') {
      return preferred720p;
    }

    // Prefer 1080p for tablets and desktop
    const preferred1080p = supportedResolutions.find(res => res.width === 1920 && res.height === 1080);
    if (preferred1080p) {
      return preferred1080p;
    }

    // Return the highest resolution available
    return supportedResolutions.reduce((max, current) => 
      (current.width * current.height > max.width * max.height) ? current : max
    );
  }

  private getDefaultCapabilities(isIOS: boolean, isAndroid: boolean, deviceType: string) {
    let defaultResolution = { width: 1280, height: 720 };
    
    if (deviceType === 'smartphone') {
      defaultResolution = { width: 1280, height: 720 }; // 720p for mobile
    } else {
      defaultResolution = { width: 1920, height: 1080 }; // 1080p for tablets/desktop
    }

    return {
      supportedResolutions: [defaultResolution, { width: 640, height: 480 }],
      defaultResolution,
      supportsZoom: false,
      maxZoom: 1,
      supportedFrameRates: [30, 24, 15],
      preferredFrameRate: 30
    };
  }

  async getOptimizedConstraints(): Promise<CameraConstraints> {
    const capabilities = await this.detectCapabilities();
    
    const videoConstraints: MediaTrackConstraints = {
      width: { ideal: capabilities.defaultResolution.width },
      height: { ideal: capabilities.defaultResolution.height },
      frameRate: { ideal: capabilities.preferredFrameRate },
      facingMode: 'user' // Front camera for self-recording
    };

    // Reset zoom to 1x if supported
    if (capabilities.supportsZoom) {
      (videoConstraints as any).zoom = 1.0;
    }

    // iOS-specific optimizations
    if (capabilities.isIOS) {
      videoConstraints.aspectRatio = capabilities.defaultResolution.width / capabilities.defaultResolution.height;
    }

    // Android-specific optimizations
    if (capabilities.isAndroid) {
      // Android Chrome sometimes needs explicit aspect ratio
      videoConstraints.aspectRatio = { ideal: capabilities.defaultResolution.width / capabilities.defaultResolution.height };
    }

    const audioConstraints: MediaTrackConstraints = {
      echoCancellation: true,
      noiseSuppression: true,
      autoGainControl: true,
      sampleRate: 44100,
      channelCount: 1 // Mono for smaller file sizes
    };

    return {
      video: videoConstraints,
      audio: audioConstraints
    };
  }

  getCapabilities(): DeviceCapabilities | null {
    return this.capabilities;
  }

  logDeviceInfo(): void {
    if (this.capabilities) {
      console.log('Device Capabilities:', {
        device: `${this.capabilities.isIOS ? 'iOS' : this.capabilities.isAndroid ? 'Android' : 'Desktop'} ${this.capabilities.osVersion}`,
        browser: this.capabilities.browserName,
        type: this.capabilities.deviceType,
        defaultResolution: this.capabilities.defaultResolution,
        supportedResolutions: this.capabilities.supportedResolutions,
        zoom: `${this.capabilities.supportsZoom ? 'Yes' : 'No'} (max: ${this.capabilities.maxZoom}x)`,
        frameRates: this.capabilities.supportedFrameRates,
        preferredFrameRate: this.capabilities.preferredFrameRate
      });
    }
  }
}