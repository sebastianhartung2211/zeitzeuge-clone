import { pipeline } from '@huggingface/transformers';

interface VADSegment {
  start: number;
  end: number;
  confidence: number;
}

interface TranscriptionChunk {
  text: string;
  start: number;
  end: number;
  confidence: number;
}

interface WhisperConfig {
  model: string;
  device: 'cpu' | 'webgpu';
  vadThreshold: number;
  minSegmentLength: number; // 5s
  maxSegmentLength: number; // 90s
  overlapPercentage: number; // 12%
  audioFilters: {
    highpass: number; // 80Hz
    lowpass: number;  // 8000Hz
    normalizeAudio: boolean;
  };
}

export class WhisperService {
  private whisperPipeline: any = null;
  private vadPipeline: any = null;
  private config: WhisperConfig;

  constructor(config: Partial<WhisperConfig> = {}) {
    this.config = {
      model: 'onnx-community/whisper-small.en',
      device: 'webgpu',
      vadThreshold: 0.5,
      minSegmentLength: 5,
      maxSegmentLength: 90,
      overlapPercentage: 0.12,
      audioFilters: {
        highpass: 80,
        lowpass: 8000,
        normalizeAudio: true
      },
      ...config
    };
  }

  async initialize(): Promise<void> {
    try {
      console.log('🎤 Initializing local Whisper pipeline...');
      
      // Initialize Whisper for transcription
      this.whisperPipeline = await pipeline(
        'automatic-speech-recognition',
        this.config.model,
        { device: this.config.device }
      );

      // Initialize VAD model for voice activity detection
      this.vadPipeline = await pipeline(
        'audio-classification',
        'onnx-community/silero-vad',
        { device: this.config.device }
      );

      console.log('✅ Whisper and VAD pipelines initialized');
    } catch (error) {
      console.error('❌ Failed to initialize Whisper service:', error);
      throw error;
    }
  }

  async processAudioFile(audioBlob: Blob): Promise<TranscriptionChunk[]> {
    if (!this.whisperPipeline || !this.vadPipeline) {
      await this.initialize();
    }

    try {
      console.log('🎵 Processing audio file with VAD-based chunking...');
      
      // Step 1: Apply FFmpeg-style audio filters
      const filteredAudio = await this.applyAudioFilters(audioBlob);
      
      // Step 2: Perform VAD to detect speech segments
      const vadSegments = await this.performVAD(filteredAudio);
      console.log(`🔍 VAD detected ${vadSegments.length} speech segments`);
      
      // Step 3: Create optimal chunks with overlap
      const chunks = this.createOptimalChunks(vadSegments, filteredAudio);
      console.log(`📦 Created ${chunks.length} optimized chunks`);
      
      // Step 4: Transcribe each chunk
      const transcriptions: TranscriptionChunk[] = [];
      for (let i = 0; i < chunks.length; i++) {
        const chunk = chunks[i];
        console.log(`📝 Transcribing chunk ${i + 1}/${chunks.length} (${chunk.start}s - ${chunk.end}s)`);
        
        const audioChunk = await this.extractAudioSegment(filteredAudio, chunk.start, chunk.end);
        const result = await this.whisperPipeline(audioChunk);
        
        transcriptions.push({
          text: result.text,
          start: chunk.start,
          end: chunk.end,
          confidence: result.confidence || 0.8
        });
      }
      
      console.log('✅ Transcription completed with VAD-based chunking');
      return transcriptions;
      
    } catch (error) {
      console.error('❌ Audio processing failed:', error);
      throw error;
    }
  }

  private async applyAudioFilters(audioBlob: Blob): Promise<AudioBuffer> {
    console.log('🔧 Applying FFmpeg-style audio filters...');
    
    try {
      // Convert blob to AudioBuffer for processing
      const arrayBuffer = await audioBlob.arrayBuffer();
      const audioContext = new (window.AudioContext || (window as any).webkitAudioContext)();
      const audioBuffer = await audioContext.decodeAudioData(arrayBuffer);
      
      // Apply high-pass filter (removes low-frequency noise)
      const filteredBuffer = await this.applyHighPassFilter(audioBuffer, this.config.audioFilters.highpass);
      
      // Apply low-pass filter (removes high-frequency noise)
      const finalBuffer = await this.applyLowPassFilter(filteredBuffer, this.config.audioFilters.lowpass);
      
      // Normalize audio (equivalent to dynaudnorm)
      if (this.config.audioFilters.normalizeAudio) {
        this.normalizeAudio(finalBuffer);
      }
      
      console.log('✅ Audio filters applied successfully');
      return finalBuffer;
      
    } catch (error) {
      console.error('❌ Audio filtering failed:', error);
      throw error;
    }
  }

  private async applyHighPassFilter(audioBuffer: AudioBuffer, frequency: number): Promise<AudioBuffer> {
    const audioContext = new (window.AudioContext || (window as any).webkitAudioContext)();
    const offlineContext = new OfflineAudioContext(
      audioBuffer.numberOfChannels,
      audioBuffer.length,
      audioBuffer.sampleRate
    );
    
    const source = offlineContext.createBufferSource();
    const filter = offlineContext.createBiquadFilter();
    
    filter.type = 'highpass';
    filter.frequency.value = frequency;
    
    source.buffer = audioBuffer;
    source.connect(filter);
    filter.connect(offlineContext.destination);
    
    source.start();
    return await offlineContext.startRendering();
  }

  private async applyLowPassFilter(audioBuffer: AudioBuffer, frequency: number): Promise<AudioBuffer> {
    const audioContext = new (window.AudioContext || (window as any).webkitAudioContext)();
    const offlineContext = new OfflineAudioContext(
      audioBuffer.numberOfChannels,
      audioBuffer.length,
      audioBuffer.sampleRate
    );
    
    const source = offlineContext.createBufferSource();
    const filter = offlineContext.createBiquadFilter();
    
    filter.type = 'lowpass';
    filter.frequency.value = frequency;
    
    source.buffer = audioBuffer;
    source.connect(filter);
    filter.connect(offlineContext.destination);
    
    source.start();
    return await offlineContext.startRendering();
  }

  private normalizeAudio(audioBuffer: AudioBuffer): void {
    for (let channel = 0; channel < audioBuffer.numberOfChannels; channel++) {
      const data = audioBuffer.getChannelData(channel);
      let maxAmplitude = 0;
      
      // Find peak amplitude
      for (let i = 0; i < data.length; i++) {
        maxAmplitude = Math.max(maxAmplitude, Math.abs(data[i]));
      }
      
      // Normalize to 0.9 to prevent clipping
      if (maxAmplitude > 0) {
        const scale = 0.9 / maxAmplitude;
        for (let i = 0; i < data.length; i++) {
          data[i] *= scale;
        }
      }
    }
  }

  private async performVAD(audioBuffer: AudioBuffer): Promise<VADSegment[]> {
    console.log('🔍 Performing Voice Activity Detection...');
    
    // Convert AudioBuffer to format expected by VAD pipeline
    const audioArray = audioBuffer.getChannelData(0); // Use first channel
    const sampleRate = audioBuffer.sampleRate;
    
    // Process in 30-second windows for VAD
    const windowSize = 30 * sampleRate;
    const segments: VADSegment[] = [];
    
    for (let start = 0; start < audioArray.length; start += windowSize) {
      const end = Math.min(start + windowSize, audioArray.length);
      const window = audioArray.slice(start, end);
      
      try {
        const vadResult = await this.vadPipeline(window);
        const speechProb = vadResult.find((r: any) => r.label === 'speech')?.score || 0;
        
        if (speechProb > this.config.vadThreshold) {
          segments.push({
            start: start / sampleRate,
            end: end / sampleRate,
            confidence: speechProb
          });
        }
      } catch (error) {
        console.warn('VAD processing failed for segment, including anyway:', error);
        segments.push({
          start: start / sampleRate,
          end: end / sampleRate,
          confidence: 0.5
        });
      }
    }
    
    return this.mergeOverlappingSegments(segments);
  }

  private mergeOverlappingSegments(segments: VADSegment[]): VADSegment[] {
    if (segments.length === 0) return segments;
    
    const merged: VADSegment[] = [];
    let current = segments[0];
    
    for (let i = 1; i < segments.length; i++) {
      const next = segments[i];
      
      // Merge if segments are close together (within 1 second)
      if (next.start - current.end <= 1.0) {
        current.end = next.end;
        current.confidence = Math.max(current.confidence, next.confidence);
      } else {
        merged.push(current);
        current = next;
      }
    }
    
    merged.push(current);
    return merged;
  }

  private createOptimalChunks(vadSegments: VADSegment[], audioBuffer: AudioBuffer): Array<{start: number, end: number}> {
    const chunks: Array<{start: number, end: number}> = [];
    const audioDuration = audioBuffer.duration;
    
    for (const segment of vadSegments) {
      const segmentDuration = segment.end - segment.start;
      
      if (segmentDuration <= this.config.maxSegmentLength) {
        // Segment fits in one chunk
        chunks.push({
          start: Math.max(0, segment.start),
          end: Math.min(audioDuration, segment.end)
        });
      } else {
        // Split large segment into overlapping chunks
        const overlapDuration = this.config.maxSegmentLength * this.config.overlapPercentage;
        let chunkStart = segment.start;
        
        while (chunkStart < segment.end) {
          const chunkEnd = Math.min(chunkStart + this.config.maxSegmentLength, segment.end);
          
          chunks.push({
            start: Math.max(0, chunkStart),
            end: Math.min(audioDuration, chunkEnd)
          });
          
          chunkStart = chunkEnd - overlapDuration;
          
          // Avoid tiny chunks at the end
          if (segment.end - chunkStart < this.config.minSegmentLength) {
            break;
          }
        }
      }
    }
    
    return chunks.filter(chunk => chunk.end - chunk.start >= this.config.minSegmentLength);
  }

  private async extractAudioSegment(audioBuffer: AudioBuffer, startTime: number, endTime: number): Promise<Float32Array> {
    const sampleRate = audioBuffer.sampleRate;
    const startSample = Math.floor(startTime * sampleRate);
    const endSample = Math.floor(endTime * sampleRate);
    
    const channelData = audioBuffer.getChannelData(0);
    return channelData.slice(startSample, endSample);
  }

  async transcribeAudioBlob(audioBlob: Blob): Promise<{text: string, confidence: number, segments: TranscriptionChunk[]}> {
    const segments = await this.processAudioFile(audioBlob);
    
    // Combine all segments into final transcript
    const fullText = segments.map(s => s.text).join(' ');
    const averageConfidence = segments.reduce((sum, s) => sum + s.confidence, 0) / segments.length;
    
    return {
      text: fullText,
      confidence: averageConfidence,
      segments
    };
  }
}

export default WhisperService;