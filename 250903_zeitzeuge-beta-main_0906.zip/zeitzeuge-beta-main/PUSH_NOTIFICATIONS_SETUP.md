# Push Notifications Setup Guide

## Plugin Installation

Das Push Notifications Plugin wurde installiert. Nach der Capacitor-Konfiguration müssen Sie folgende Schritte ausführen:

```bash
npx cap sync
```

## Android Konfiguration

### 1. Firebase Setup (für FCM)
1. Gehen Sie zur [Firebase Console](https://console.firebase.google.com/)
2. Erstellen Sie ein neues Projekt oder wählen Sie ein bestehendes
3. Fügen Sie eine Android-App hinzu mit der Package ID aus `capacitor.config.ts`
4. Laden Sie die `google-services.json` herunter
5. Platzieren Sie sie in `android/app/google-services.json`

### 2. Android Manifest Updates
In `android/app/src/main/AndroidManifest.xml`:

```xml
<!-- Push Notification Permissions -->
<uses-permission android:name="android.permission.INTERNET" />
<uses-permission android:name="android.permission.VIBRATE" />
<uses-permission android:name="android.permission.RECEIVE_BOOT_COMPLETED" />

<!-- Firebase Messaging Service -->
<service
    android:name="com.getcapacitor.plugin.pushnotifications.MessagingService"
    android:exported="false">
    <intent-filter>
        <action android:name="com.google.firebase.MESSAGING_EVENT" />
    </intent-filter>
</service>
```

### 3. Build Gradle Updates
In `android/app/build.gradle`:

```gradle
dependencies {
    implementation 'com.google.firebase:firebase-messaging:23.0.0'
}

apply plugin: 'com.google.gms.google-services'
```

In `android/build.gradle`:

```gradle
dependencies {
    classpath 'com.google.gms:google-services:4.3.10'
}
```

## iOS Konfiguration

### 1. Apple Developer Setup
1. Gehen Sie zum Apple Developer Portal
2. Erstellen Sie ein Push Notification Certificate
3. Aktivieren Sie Push Notifications für Ihre App ID

### 2. Xcode Konfiguration
1. Öffnen Sie das Projekt in Xcode: `npx cap open ios`
2. Wählen Sie Ihr Target → Signing & Capabilities
3. Fügen Sie "Push Notifications" Capability hinzu
4. Stellen Sie sicher, dass "Background Modes" mit "Remote notifications" aktiviert ist

### 3. Info.plist Updates
Falls nicht automatisch hinzugefügt:

```xml
<key>UIBackgroundModes</key>
<array>
    <string>remote-notification</string>
</array>
```

## Verwendung im Code

```typescript
import { PushNotificationSetup } from '@/components/push/PushNotificationSetup';
import { usePushNotifications } from '@/hooks/usePushNotifications';

// In einer Komponente:
<PushNotificationSetup />

// Oder programmatisch:
const { isRegistered, registerForPush } = usePushNotifications();
```

## Database Schema

Die `push_tokens` Tabelle speichert:
- `user_id`: Verknüpfung zum authentifizierten Benutzer
- `token`: FCM/APNS Token
- `platform`: ios/android/web
- `device_info`: Zusätzliche Geräteinformationen
- `is_active`: Token-Status

## Sending Notifications (Edge Function Beispiel)

```typescript
// Später implementierbar via Edge Function
const { data } = await supabase.functions.invoke('send-push-notification', {
  body: {
    userId: 'user-uuid',
    title: 'Neue Nachricht',
    body: 'Sie haben eine neue Nachricht erhalten',
    data: { videoId: 'video-uuid' }
  }
});
```

## Testing

1. **Android**: Verwenden Sie Firebase Console → Cloud Messaging
2. **iOS**: Verwenden Sie Apple Push Notifications Console
3. **App**: Testen Sie mit der `PushNotificationSetup` Komponente

## Troubleshooting

- **Token nicht erhalten**: Prüfen Sie Firebase/Apple-Konfiguration
- **Permissions verweigert**: Benutzer muss manuell in Einstellungen aktivieren
- **Database Fehler**: Stellen Sie sicher, dass User authentifiziert ist
- **Platform nicht unterstützt**: Push funktioniert nur auf nativen Plattformen