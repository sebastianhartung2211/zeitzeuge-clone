// Minimal SW to self-unregister (no caching)
self.addEventListener('install', (event) => {
  self.skipWaiting();
});

self.addEventListener('activate', (event) => {
  event.waitUntil((async () => {
    try {
      // Try to reload open clients to drop control quickly
      const clientList = await self.clients.matchAll({ type: 'window', includeUncontrolled: true });
      for (const client of clientList) {
        try { client.navigate(client.url); } catch (e) {}
      }
    } catch (e) {}
    await self.registration.unregister();
    // Ensure no old caches survive
    if ('caches' in self) {
      const keys = await caches.keys();
      await Promise.all(keys.map(k => caches.delete(k)));
    }
  })());
});

// Do nothing for fetch
self.addEventListener('fetch', () => {});