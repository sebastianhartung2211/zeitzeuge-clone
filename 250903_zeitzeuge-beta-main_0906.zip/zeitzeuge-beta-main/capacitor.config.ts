import { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.zeitzeuge.app',
  appName: 'Zeitzeuge',
  webDir: 'dist',             // Vite-Output
  server: {
    androidScheme: 'https',   // verhindert Mixed-Content-Probleme
    cleartext: false
  },
};

export default config;